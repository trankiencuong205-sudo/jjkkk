package com.example.jjk;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;

/**
 * Lop "dien anh" them vao MOI ky nang kieu data (Moves): khi tung chieu co tran phap + vong tu khi + am thanh,
 * khi trung dich co no sang 3D, tia vo, song xung kich va hit-stop (khung hinh khung khi don manh). Chua test trong game.
 */
public class Cinema {
    private static int lastTick = -1, perTick = 0;

    private static boolean room() { return Config.displays && Disp.count() < Config.maxDisplays * 0.7; }

    public static void start(Moves.M m, ServerWorld w, ServerPlayerEntity p) {
        Vec3d c = p.getEntityPos().add(0, 0.08, 0);
        Vec3d up = new Vec3d(0, 1, 0);
        Vec3d[] b = Fx.basis(up);
        Fx.ring(w, Fx.dust(m.col(), 1.5f), c, b[1], b[2], 1.7, 40, 0);
        Fx.ring(w, Fx.dust(m.col(), 1.1f), c.add(0, 0.9, 0), b[1], b[2], 1.1, 30, 0.5);
        Fx.snd(w, c, SoundEvents.BLOCK_BEACON_POWER_SELECT, 0.8f, 0.8f + Math.min(0.9f, m.energy() / 200f));
        if (!room()) return;
        for (int i = 0; i < 6; i++) {                                           // tran phap luc giac duoi chan
            double a = i * Math.PI / 3;
            Vis3D.plate(w, c.add(Math.cos(a) * 1.3, 0, Math.sin(a) * 1.3), up, m.b1(), 0.15, 0.75, 12);
        }
        Vis3D.plate(w, c.add(0, 0.01, 0), up, m.b2(), 0.2, 2.6, 12);
        Vis3D.pulseShrink(w, c.add(0, 1.0, 0), m.b1(), 2.2, 9);                   // nang luong hoi tu vao nguoi
    }

    public static void impact(Moves.M m, ServerWorld w, ServerPlayerEntity p, LivingEntity e) {
        int now = Data.now;
        if (now != lastTick) { lastTick = now; perTick = 0; }
        if (++perTick > 3) return;                                              // AoE: chi vai tam no / tick
        Vec3d at = Fx.mid(e);
        double big = 1.6 + Math.min(2.4, m.dmg() / 25.0);
        Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
        Fx.ring(w, Fx.dust(m.col(), 1.6f), at, b[1], b[2], big * 0.8, 36, 0);
        Fx.put(w, ParticleTypes.EXPLOSION, at, 1, 0, 0);
        Fx.snd(w, at, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 0.5f, 1.6f);
        if (m.dmg() >= 20 && e.isAlive()) e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 4, 9, false, false));   // hit-stop
        if (!room()) return;
        Vis3D.pulseGrow(w, at, m.b1(), 0.3, big, 6);
        Vis3D.pulseGrow(w, at, m.b2(), 0.2, big * 0.55, 5);
        for (int i = 0; i < 5; i++) new Disp.Beam(w, at, at.add(Fx.randDir().multiply(big * 1.1)), m.b2(), m.b1(), 0.07, 5);
    }
}
