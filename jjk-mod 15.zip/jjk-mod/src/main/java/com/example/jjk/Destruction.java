package com.example.jjk;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * PHA HUY DIA HINH khi dung ky nang (mac dinh BAT, tu hoi phuc sau terrainRestoreSeconds giay):
 * crater (no), slashPlane (nhat chem cat doi nui), tunnel (tia khoan), shatter (nut dat), kem manh vo bay tung toe.
 * Khong pha: bedrock, khoi co block entity (ruong, lo...), phong domain, ngoai world border. Chua test trong game.
 */
public class Destruction {
    private record Temp(ServerWorld w, BlockPos p, BlockState old, int due) { }

    private static final List<Temp> TEMP = new ArrayList<>();
    private static int tickN = 0, callsThisTick = 0, blocksThisTick = 0;
    private static final int PER_TICK_BLOCKS = 3000;

    // ---------- dieu kien ----------
    private static boolean breakable(ServerWorld w, BlockPos p, BlockState s, double power) {
        if (s.isAir() || s.isOf(Blocks.BEDROCK) || s.isOf(Blocks.BARRIER) || s.isOf(Blocks.END_PORTAL_FRAME) || s.isOf(Blocks.COMMAND_BLOCK)) return false;
        if (w.isOutOfHeightLimit(p.getY()) || !w.getWorldBorder().contains(p)) return false;
        if (!w.getChunkManager().isChunkLoaded(p.getX() >> 4, p.getZ() >> 4)) return false;
        if (Room.isProtected(w, p)) return false;
        float h = s.getHardness(w, p);
        if (h < 0) return false;
        if (w.getBlockEntity(p) != null) return false;
        return h <= power * 3.0 + 1.0;
    }

    /** thay khoi (luu khoi cu de hoi phuc). tra ve true neu da doi */
    private static boolean replace(ServerWorld w, BlockPos p, BlockState now) {
        BlockState old = w.getBlockState(p);
        if (old == now) return false;
        if (Config.terrainRestoreSeconds > 0) TEMP.add(new Temp(w, p.toImmutable(), old, Data.now + Config.terrainRestoreSeconds * 20));
        w.setBlockState(p, now, Block.NOTIFY_LISTENERS);
        blocksThisTick++;
        return true;
    }

    private static boolean budget() { return blocksThisTick < PER_TICK_BLOCKS; }

    private static double hash(int x, int y, int z) {
        double v = Math.sin(x * 12.9898 + y * 78.233 + z * 37.719) * 43758.5453;
        return v - Math.floor(v);
    }

    private static final BlockState AIR = Blocks.AIR.getDefaultState();

    // ---------- debris bay ----------
    private static void debris(ServerWorld w, Vec3d c, List<BlockState> samples, double force) {
        if (!Config.displays || samples.isEmpty() || Disp.count() > Config.maxDisplays * 0.8) return;
        int n = Math.min(12, samples.size());
        for (int i = 0; i < n; i++) {
            BlockState st = samples.get(i * samples.size() / n);
            String id = Registries.BLOCK.getId(st.getBlock()).getPath();
            double s = 0.35 + Fx.rnd() * 0.45;
            Disp.H h = Disp.block(w, c, id, s, s, s, Disp.Q.ID, 46);
            Vec3d v = new Vec3d(Fx.rnd(-1, 1), Fx.rnd(0.6, 1.4), Fx.rnd(-1, 1)).multiply(force * 0.18);
            Anims.add(new Anims.Anim() {
                int t = 0; Vec3d pos = c, vel = v;
                public boolean tick() {
                    if (++t > 40) { h.kill(); return true; }
                    vel = vel.add(0, -0.05, 0);
                    pos = pos.add(vel);
                    h.move(pos);
                    return false;
                }
            });
        }
    }

    // ---------- 1. CRATER (no tron) ----------
    public static int crater(ServerWorld w, Vec3d c, double r, double power, boolean scorch) {
        if (!Config.terrainDamage) return 0;
        r = Math.min(r, 9.0);
        int R = (int) Math.ceil(r), removed = 0;
        BlockPos b = BlockPos.ofFloored(c);
        List<BlockState> samples = new ArrayList<>();
        for (int dx = -R; dx <= R; dx++) for (int dy = -R; dy <= R; dy++) for (int dz = -R; dz <= R; dz++) {
            if (removed >= Config.destroyMaxBlocks || !budget()) break;
            double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
            BlockPos q = b.add(dx, dy, dz);
            double edge = r * (0.72 + 0.28 * hash(q.getX(), q.getY(), q.getZ()));
            if (d > edge) {
                if (scorch && d <= r * 1.05 && hash(q.getX() + 7, q.getY(), q.getZ()) < 0.35) {      // vien bi chay xem: magma / blackstone
                    BlockState s = w.getBlockState(q);
                    if (!s.isAir() && breakable(w, q, s, power)) replace(w, q, hash(q.getX(), q.getY() + 3, q.getZ()) < 0.4 ? Blocks.MAGMA_BLOCK.getDefaultState() : Blocks.BLACKSTONE.getDefaultState());
                }
                continue;
            }
            BlockState s = w.getBlockState(q);
            if (!breakable(w, q, s, power)) continue;
            if (samples.size() < 40 && hash(q.getX(), q.getY(), q.getZ() + 5) < 0.12) samples.add(s);
            if (replace(w, q, AIR)) removed++;
        }
        if (removed > 0) { debris(w, c, samples, 1.0 + r * 0.25); Fx.snd(w, c, net.minecraft.sound.SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 1.6f, 0.7f); }
        return removed;
    }

    // ---------- 2. NHAT CHEM: cat mot mat phang (nhu Dismantle / World Cutting Slash) ----------
    public static int slashPlane(ServerWorld w, Vec3d origin, Vec3d dir, Vec3d up, double length, double height, double thick, double power) {
        if (!Config.terrainDamage) return 0;
        length = Math.min(length, 40); height = Math.min(height, 24);
        Vec3d d = dir.normalize(), u = up.normalize(), n = d.crossProduct(u).normalize();
        Vec3d[] corners = {origin.add(u.multiply(height / 2)).add(n.multiply(thick)), origin.add(u.multiply(-height / 2)).add(n.multiply(-thick)),
                origin.add(d.multiply(length)).add(u.multiply(height / 2)).add(n.multiply(thick)), origin.add(d.multiply(length)).add(u.multiply(-height / 2)).add(n.multiply(-thick))};
        int x0 = 1 << 30, y0 = 1 << 30, z0 = 1 << 30, x1 = -(1 << 30), y1 = -(1 << 30), z1 = -(1 << 30);
        for (Vec3d v : corners) {
            x0 = Math.min(x0, (int) Math.floor(v.x) - 1); x1 = Math.max(x1, (int) Math.ceil(v.x) + 1);
            y0 = Math.min(y0, (int) Math.floor(v.y) - 1); y1 = Math.max(y1, (int) Math.ceil(v.y) + 1);
            z0 = Math.min(z0, (int) Math.floor(v.z) - 1); z1 = Math.max(z1, (int) Math.ceil(v.z) + 1);
        }
        int removed = 0;
        List<BlockState> samples = new ArrayList<>();
        for (int x = x0; x <= x1; x++) for (int y = y0; y <= y1; y++) for (int z = z0; z <= z1; z++) {
            if (removed >= Config.destroyMaxBlocks || !budget()) return removed;
            Vec3d rel = new Vec3d(x + 0.5, y + 0.5, z + 0.5).subtract(origin);
            double a = rel.dotProduct(d), bb = rel.dotProduct(u), cc = rel.dotProduct(n);
            if (a < 0 || a > length || Math.abs(bb) > height / 2 || Math.abs(cc) > thick / 2) continue;
            BlockPos q = new BlockPos(x, y, z);
            BlockState s = w.getBlockState(q);
            if (!breakable(w, q, s, power)) continue;
            if (samples.size() < 30 && hash(x, y, z) < 0.1) samples.add(s);
            if (replace(w, q, AIR)) removed++;
        }
        if (removed > 0) debris(w, origin.add(d.multiply(length * 0.5)), samples, 1.4);
        return removed;
    }

    // ---------- 3. DUONG HAM (tia khoan: Hollow Purple, beam...) ----------
    public static int tunnel(ServerWorld w, Vec3d from, Vec3d dir, double len, double radius, double power) {
        if (!Config.terrainDamage) return 0;
        len = Math.min(len, 70); radius = Math.min(radius, 6);
        Vec3d d = dir.normalize();
        Set<Long> done = new HashSet<>();
        int removed = 0, R = (int) Math.ceil(radius);
        List<BlockState> samples = new ArrayList<>();
        for (double t = 0; t <= len; t += 0.6) {
            Vec3d c = from.add(d.multiply(t));
            BlockPos b = BlockPos.ofFloored(c);
            for (int dx = -R; dx <= R; dx++) for (int dy = -R; dy <= R; dy++) for (int dz = -R; dz <= R; dz++) {
                if (removed >= Config.destroyMaxBlocks || !budget()) return removed;
                if (dx * dx + dy * dy + dz * dz > radius * radius) continue;
                BlockPos q = b.add(dx, dy, dz);
                if (!done.add(q.asLong())) continue;
                BlockState s = w.getBlockState(q);
                if (!breakable(w, q, s, power)) continue;
                if (samples.size() < 30 && hash(q.getX(), q.getY(), q.getZ()) < 0.08) samples.add(s);
                if (replace(w, q, AIR)) removed++;
            }
        }
        if (removed > 0) debris(w, from.add(d.multiply(Math.min(len, 10))), samples, 1.6);
        return removed;
    }

    // ---------- 4. NUT DAT (song xung kich lan qua mat dat) ----------
    public static int shatter(ServerWorld w, Vec3d c, double r, double power) {
        if (!Config.terrainDamage) return 0;
        r = Math.min(r, 10);
        int R = (int) Math.ceil(r), removed = 0;
        BlockPos b = BlockPos.ofFloored(c);
        List<BlockState> samples = new ArrayList<>();
        for (int dx = -R; dx <= R; dx++) for (int dz = -R; dz <= R; dz++) {
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d > r || d < 1.8 || removed >= Config.destroyMaxBlocks || !budget()) continue;
            if (hash(b.getX() + dx, 0, b.getZ() + dz) > 0.5 - d / r * 0.25) continue;   // cang xa cang thua
            for (int dy = 3; dy >= -4; dy--) {                                          // tim mat dat gan toa do
                BlockPos q = b.add(dx, dy, dz);
                BlockState s = w.getBlockState(q);
                if (s.isAir() || !w.getBlockState(q.up()).isAir()) continue;
                if (breakable(w, q, s, power)) {
                    if (samples.size() < 20) samples.add(s);
                    if (replace(w, q, AIR)) removed++;
                    if (hash(q.getX(), q.getY(), q.getZ()) < 0.5) { BlockPos q2 = q.down(); BlockState s2 = w.getBlockState(q2); if (breakable(w, q2, s2, power) && replace(w, q2, AIR)) removed++; }
                }
                break;
            }
        }
        if (removed > 0) debris(w, c.add(0, 0.5, 0), samples, 0.8);
        return removed;
    }

    // ---------- tu dong cho ky nang dang du lieu (goi tu Theme.fx) ----------
    public static void onSkill(Moves.M m, ServerWorld w, Vec3d at, Vec3d dir, double size) {
        if (!Config.terrainDamage || m.dmg() < 18) return;
        if (tickN != lastTick) { lastTick = tickN; callsThisTick = 0; }
        if (++callsThisTick > 4) return;
        for (net.minecraft.server.network.ServerPlayerEntity p : w.getPlayers()) if (p.getEntityPos().distanceTo(at) < 2.2) return;   // khong khoan nen duoi chan nguoi dung
        double power = Math.max(1.5, Math.min(9, m.dmg() / 12.0)), r = Math.max(1.5, Math.min(7, size * 0.7));
        boolean fire = m.fx() != null && (m.fx().contains("fire") || m.fx().contains("burn"));
        Vec3d flat = new Vec3d(dir.x, 0, dir.z);
        Vec3d f = flat.lengthSquared() < 1e-4 ? new Vec3d(0, 0, 1) : flat.normalize();
        switch (m.kind()) {
            case "slash" -> slashPlane(w, at.subtract(f.multiply(r)), f, new Vec3d(0, 1, 0), r * 3, r * 1.4, 1.2, power);
            case "beam" -> tunnel(w, at, dir, Math.min(20, m.range()), 0.9 + r * 0.15, power);
            case "nova", "pull" -> { shatter(w, at, r * 1.4, power); }
            default -> crater(w, at, r, power, fire);
        }
    }
    private static int lastTick = -1;

    // ---------- hoi phuc ----------
    private static void restore(Temp t, boolean force) {
        ServerWorld w = t.w;
        BlockPos p = t.p;
        if (!w.getChunkManager().isChunkLoaded(p.getX() >> 4, p.getZ() >> 4)) { Room.addStale(w, p, t.old); return; }
        BlockState cur = w.getBlockState(p);
        if (cur.isAir() || cur.isOf(Blocks.MAGMA_BLOCK) || cur.isOf(Blocks.BLACKSTONE) || force) w.setBlockState(p, t.old, Block.NOTIFY_LISTENERS);
    }

    public static List<String> journalLines() {
        List<String> l = new ArrayList<>();
        for (Temp t : TEMP) l.add(t.w.getRegistryKey().getValue() + "|" + t.p.getX() + "|" + t.p.getY() + "|" + t.p.getZ() + "|" + Room.str(t.old));
        return l;
    }

    public static int pending() { return TEMP.size(); }

    public static void restoreAll() {
        for (Temp t : TEMP) restore(t, false);
        TEMP.clear();
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> Safe.run("Destruction.tick", () -> {
            tickN++; blocksThisTick = 0;
            int n = 0;
            while (!TEMP.isEmpty() && n < 400 && TEMP.get(0).due <= Data.now) { restore(TEMP.remove(0), false); n++; }
            if (n > 0) Room.markDirty();
        }));
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> restoreAll());
    }
}
