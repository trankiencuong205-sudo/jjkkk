package com.example.jjk;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class JjkClient implements ClientModInitializer {
    public static final KeyBinding.Category CATEGORY = KeyBinding.Category.create(Identifier.of(Jjk.ID, "main"));
    private static KeyBinding menu, cast, next, prev;

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(SyncPayload.ID, (payload, context) -> ClientData.parse(payload.data()));
        menu = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.jjk.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_J, CATEGORY));
        cast = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.jjk.cast", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, CATEGORY));
        next = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.jjk.next", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, CATEGORY));
        prev = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.jjk.prev", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, CATEGORY));

        HudElementRegistry.addLast(Identifier.of(Jjk.ID, "hud"), (ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.options.hudHidden || mc.player == null) return;
            int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
            int w = 120, h = 8, x = sw / 2 - 91, y = sh - 56;
            float frac = Math.max(0f, Math.min(1f, ClientData.energy / (float) Math.max(1, ClientData.maxEnergy)));
            int col = 0xFF000000 | ClientData.chara().color;
            ctx.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF000000);
            ctx.fill(x, y, x + w, y + h, 0xFF15101F);
            ctx.fill(x, y, x + (int) (w * frac), y + h, col);
            ctx.fill(x, y, x + (int) (w * frac), y + 2, 0x66FFFFFF);
            ctx.drawTextWithShadow(mc.textRenderer, ClientData.energy + "/" + ClientData.maxEnergy, x + w + 4, y, 0xFFFFFFFF);

            List<Tech.T> list = Tech.of(ClientData.chara());
            if (!list.isEmpty()) {
                Tech.T t = list.get(Math.min(ClientData.sel, list.size() - 1));
                int rem = ClientData.cd.getOrDefault(t.id(), 0);
                String label = t.en() + (rem > 0 ? "  (" + String.format("%.1f", rem / 20.0) + "s)" : "");
                ctx.drawTextWithShadow(mc.textRenderer, "[R] " + label, x, y - 11, rem > 0 ? 0xFFAAAAAA : 0xFFFFFFFF);
                if (rem > 0 && t.cooldown() > 0) {
                    int cw = (int) (w * Math.min(1f, rem / (float) Math.max(1, t.cooldown())));
                    ctx.fill(x, y + h + 1, x + cw, y + h + 3, 0xFFFFAA33);
                }
            }
            int ty = y - 22;
            if (ClientData.infinity) { ctx.drawTextWithShadow(mc.textRenderer, "INFINITY", x, ty, 0xFF9FE8FF); ty -= 10; }
            if (ClientData.reinforce) { ctx.drawTextWithShadow(mc.textRenderer, "REINFORCEMENT", x, ty, 0xFFB090FF); ty -= 10; }
            if (ClientData.domain > 0) ctx.drawTextWithShadow(mc.textRenderer, "DOMAIN EXPANSION  " + (ClientData.domain / 20) + "s", x, ty, 0xFFFF6060);
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            while (menu.wasPressed()) {
                ClientPlayNetworking.send(new ActionPayload(2, 0));
                client.setScreen(new SkillScreen());
            }
            while (cast.wasPressed()) ClientPlayNetworking.send(new ActionPayload(3, 0));
            while (next.wasPressed()) ClientPlayNetworking.send(new ActionPayload(5, 0));
            while (prev.wasPressed()) ClientPlayNetworking.send(new ActionPayload(6, 0));
        });
    }
}
