package com.example.jjk;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.List;
import java.util.UUID;

public class Net {
    public static void register() {
        PayloadTypeRegistry.playC2S().register(ActionPayload.ID, ActionPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SyncPayload.ID, SyncPayload.CODEC);

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> Data.sync(handler.player));

        ServerPlayNetworking.registerGlobalReceiver(ActionPayload.ID, (payload, context) -> {
            ServerPlayerEntity p = context.player();
            UUID id = p.getUuid();
            List<Tech.T> list = Data.techs(id);
            switch (payload.action()) {
                case 0 -> Data.setChara(id, payload.a());
                case 1 -> Data.select(id, payload.a());
                case 3 -> { Tech.T t = Data.selected(id); if (t != null) Abilities.cast(context.server(), p, t); }
                case 4 -> { if (payload.a() >= 0 && payload.a() < list.size()) Abilities.cast(context.server(), p, list.get(payload.a())); }
                case 5 -> Data.select(id, Data.selIndex(id) + 1);
                case 6 -> Data.select(id, Data.selIndex(id) - 1);
                default -> { }
            }
            Data.sync(p);
        });
    }
}
