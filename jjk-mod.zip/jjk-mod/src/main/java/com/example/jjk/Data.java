package com.example.jjk;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/** Trang thai nguoi choi tren may chu: nhan vat, chu luc, hoi chieu, bat/tat. Chi nhan vat + ky thuat chon duoc luu. */
public class Data {
    public static int now = 0;
    private static final Map<UUID, Integer> CHARA = new HashMap<>(), SEL = new HashMap<>();
    private static final Map<UUID, Double> ENERGY = new HashMap<>();
    private static final Map<UUID, Map<String, Integer>> CD = new HashMap<>();
    public static final Set<UUID> INFINITY = new HashSet<>(), REINFORCE = new HashSet<>();
    public static final Map<UUID, Integer> DOMAIN_END = new HashMap<>();
    public static final Map<UUID, Integer> FLASH_STREAK = new HashMap<>(), FLASH_ZONE = new HashMap<>();

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("jjk-players.properties"); }

    public static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(f)) { p.load(in); }
            for (String k : p.stringPropertyNames()) {
                try {
                    if (k.endsWith(".chara")) CHARA.put(UUID.fromString(k.substring(0, k.length() - 6)), Integer.parseInt(p.getProperty(k)));
                    else if (k.endsWith(".sel")) SEL.put(UUID.fromString(k.substring(0, k.length() - 4)), Integer.parseInt(p.getProperty(k)));
                } catch (Exception ignored) { }
            }
        } catch (Exception e) { System.err.println("[jjk] load: " + e); }
    }

    public static void save() {
        try {
            Properties p = new Properties();
            for (Map.Entry<UUID, Integer> e : CHARA.entrySet()) p.setProperty(e.getKey() + ".chara", String.valueOf(e.getValue()));
            for (Map.Entry<UUID, Integer> e : SEL.entrySet()) p.setProperty(e.getKey() + ".sel", String.valueOf(e.getValue()));
            try (OutputStream out = Files.newOutputStream(file())) { p.store(out, "Jujutsu players"); }
        } catch (Exception e) { System.err.println("[jjk] save: " + e); }
    }

    public static Tech.Chara chara(UUID id) {
        Tech.Chara[] all = Tech.Chara.values();
        int c = CHARA.getOrDefault(id, 0);
        return all[Math.max(0, Math.min(all.length - 1, c))];
    }

    public static void setChara(UUID id, int c) {
        if (c < 0 || c >= Tech.Chara.values().length) return;
        CHARA.put(id, c);
        SEL.put(id, 0);
        INFINITY.remove(id);
        REINFORCE.remove(id);
        save();
    }

    public static List<Tech.T> techs(UUID id) { return Tech.of(chara(id)); }

    public static int selIndex(UUID id) {
        int n = techs(id).size();
        int s = SEL.getOrDefault(id, 0);
        return (s < 0 || s >= n) ? 0 : s;
    }

    public static void select(UUID id, int i) {
        int n = techs(id).size();
        if (n == 0) return;
        SEL.put(id, ((i % n) + n) % n);
    }

    public static Tech.T selected(UUID id) {
        List<Tech.T> l = techs(id);
        return l.isEmpty() ? null : l.get(selIndex(id));
    }

    public static int maxEnergy() { return Config.maxEnergy; }

    public static double energy(UUID id) { return ENERGY.getOrDefault(id, (double) Config.maxEnergy); }

    public static boolean spend(UUID id, double c) {
        double e = energy(id);
        if (e < c) return false;
        ENERGY.put(id, e - c);
        return true;
    }

    public static void addEnergy(UUID id, double d) {
        ENERGY.put(id, Math.max(0, Math.min(Config.maxEnergy, energy(id) + d)));
    }

    public static int remaining(UUID id, String tech) {
        Map<String, Integer> m = CD.get(id);
        if (m == null) return 0;
        return Math.max(0, m.getOrDefault(tech, 0) - now);
    }

    public static void setCooldown(UUID id, String tech, int ticks) {
        if (ticks <= 0) return;
        CD.computeIfAbsent(id, k -> new HashMap<>()).put(tech, now + ticks);
    }

    public static boolean domainActive(UUID id) {
        Integer e = DOMAIN_END.get(id);
        return e != null && e > now;
    }

    public static ServerWorld worldOf(MinecraftServer server, ServerPlayerEntity p) {
        for (ServerWorld w : server.getWorlds()) if (w.getPlayers().contains(p)) return w;
        return null;
    }

    public static String syncString(UUID id) {
        StringBuilder sb = new StringBuilder();
        sb.append("c=").append(chara(id).ordinal());
        sb.append(";e=").append((int) energy(id));
        sb.append(";mx=").append(Config.maxEnergy);
        sb.append(";s=").append(selIndex(id));
        sb.append(";inf=").append(INFINITY.contains(id) ? 1 : 0);
        sb.append(";rei=").append(REINFORCE.contains(id) ? 1 : 0);
        Integer de = DOMAIN_END.get(id);
        sb.append(";dom=").append(de != null && de > now ? de - now : 0);
        sb.append(";cd=");
        for (Tech.T t : techs(id)) {
            int r = remaining(id, t.id());
            if (r > 0) sb.append(t.id()).append(':').append(r).append(',');
        }
        return sb.toString();
    }

    public static void sync(ServerPlayerEntity p) {
        ServerPlayNetworking.send(p, new SyncPayload(syncString(p.getUuid())));
    }

    /** moi tick may chu */
    public static void tick(MinecraftServer server) {
        now++;
        for (ServerWorld w : server.getWorlds()) {
            for (ServerPlayerEntity p : w.getPlayers()) {
                UUID id = p.getUuid();
                if (!p.isAlive()) { INFINITY.remove(id); REINFORCE.remove(id); continue; }
                if (Config.unlimited) ENERGY.put(id, (double) Config.maxEnergy);
                else addEnergy(id, Config.regen / 20.0);

                if (INFINITY.contains(id)) {
                    if (!Config.unlimited) ENERGY.put(id, Math.max(0, energy(id) - 4.0 / 20.0));
                    if (energy(id) <= 0.01 && !Config.unlimited) {
                        INFINITY.remove(id);
                        p.sendMessage(Text.literal("Infinity tat: het nang luong!").formatted(Formatting.RED), true);
                    } else Abilities.infinityTick(w, p);
                }
                if (REINFORCE.contains(id)) {
                    if (!Config.unlimited) ENERGY.put(id, Math.max(0, energy(id) - 1.5 / 20.0));
                    if (energy(id) <= 0.01 && !Config.unlimited) {
                        REINFORCE.remove(id);
                        p.sendMessage(Text.literal("Cursed Energy Reinforcement tat: het nang luong!").formatted(Formatting.RED), true);
                    } else Abilities.reinforceTick(w, p);
                }
                if (now % 4 == 0) sync(p);
            }
        }
    }
}
