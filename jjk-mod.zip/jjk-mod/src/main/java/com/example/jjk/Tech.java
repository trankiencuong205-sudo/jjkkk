package com.example.jjk;

import java.util.ArrayList;
import java.util.List;

/** Danh muc ky thuat. status: trung thuc, chua co ban nao duoc test trong game. */
public class Tech {
    public enum Chara {
        GOJO("Satoru Gojo", "Limitless + Six Eyes", 0x6FD0FF),
        SUKUNA("Ryomen Sukuna", "Cleave / Dismantle / Fuga / Malevolent Shrine", 0xFF4A4A),
        YUJI("Yuji Itadori", "Cursed Energy + Black Flash", 0xFF9A3A);
        public final String title, desc; public final int color;
        Chara(String t, String d, int c) { title = t; desc = d; color = c; }
    }

    public static final String UNTESTED = "Da viet, CHUA test trong game";

    /** kind: toggle / instant / charge / domain */
    public record T(String id, String en, String jp, int energy, int cooldown, double damage, String kind, String desc, String status, Chara... users) {
        public boolean toggle() { return kind.equals("toggle"); }
        public boolean domain() { return kind.equals("domain"); }
        public boolean usedBy(Chara c) { for (Chara u : users) if (u == c) return true; return false; }
    }

    public static final List<T> ALL = new ArrayList<>();

    private static void add(String id, String en, String jp, int energy, int cd, double dmg, String kind, String desc, String status, Chara... users) {
        ALL.add(new T(id, en, jp, energy, cd, dmg, kind, desc, status, users));
    }

    static {
        Chara G = Chara.GOJO, S = Chara.SUKUNA, Y = Chara.YUJI;
        add("infinity", "Infinity", "無下限", 0, 20, 0, "toggle",
                "Bat/tat. Chan moi don danh vat ly va dan (co ke tan cong). Quai bi day ra, dan bi lam cham.\nTon 4 nang luong/giay. Khong chan lua, roi, doc.",
                UNTESTED + " (dan bi cham = do server, client co the thay giat)", G);
        add("blue", "Cursed Technique Lapse: Blue", "術式順転「蒼」", 40, 80, 3, "instant",
                "Tao qua cau hut dat truoc mat 50 tick: keo moi quai trong 8 o ve tam, nghien nat 3 st moi 8 tick.\nCuoi cung no tung xung noi.",
                UNTESTED, G);
        add("red", "Cursed Technique Reversal: Red", "術式反転「赫」", 55, 100, 16, "instant",
                "Ban cau do day lui: no khi cham, bung song xung kich ban kinh 7, hat tung moi thu ra ngoai.\nKhong pha khoi dat.",
                UNTESTED, G);
        add("purple", "Secret Technique: Hollow Purple", "茈", 150, 400, 45, "charge",
                "Hai qua Blue va Red hoi tu trong 1.8s thanh qua cau tim, bay 60 o, xuyen moi quai (45 st).\nBat 'purpleErasesBlocks' trong config de xoa dia hinh (mac dinh TAT).",
                UNTESTED, G);
        add("unlimited_void", "Domain Expansion: Unlimited Void", "領域展開「無量空処」", 300, 1800, 2, "domain",
                "Ban kinh 14. Mo rong vo cau thien ha; moi quai ben trong bi cam (khong di chuyen duoc, yeu di), chiu 'qua tai thong tin' 2 st/s.\n10 giay. Chua co: dam doi dien tich (domain clash), moi truong 3D that.",
                UNTESTED + " (hieu ung hat, khong thay doi bau troi/dia hinh)", G);

        add("cleave", "Cleave", "捌", 35, 40, 12, "instant",
                "Nhat chem lon tam 9 o: sat thuong tang theo mau toi da cua muc tieu (6 + 25% mau toi da, toi da 60).",
                UNTESTED, S);
        add("dismantle", "Dismantle", "解", 20, 20, 6, "instant",
                "Loat 5 luoi chem mong bay lien tiep theo quat hinh quat, moi luoi 6 st, tam ~19 o.\nTrung lap, khong xuyen khoi.",
                UNTESTED, S);
        add("fire_arrow", "Fire Arrow", "開 (Fuga)", 90, 160, 30, "charge",
                "Vong lua trieu hoi mui ten lua (14 tick) roi ban di 2.2 o/tick. No ban kinh 7: 30 st, chay 8s.\nKhong dot khoi.",
                UNTESTED, S);
        add("malevolent_shrine", "Domain Expansion: Malevolent Shrine", "領域展開「伏魔御廚子」", 300, 2400, 4, "domain",
                "Ban kinh 16, khong co hang rao. Den tho (xuong + so lau) dung len bang hat; moi quai trong vung bi chem lien tuc.\n8 giay. Chua co: khoi that, domain clash.",
                UNTESTED + " (den tho la hat, khong phai khoi)", S);

        add("black_flash", "Black Flash", "黒閃", 25, 60, 8, "instant",
                "Dam lao toi muc tieu gan nhat (<=6 o). Co co hoi 'Black Flash': sat thuong x2.5, tia set den-do.\nThanh cong lien tuc se vao 'Zone' (Strength II 8s, ti le tang).",
                UNTESTED, Y);

        add("rct", "Reverse Cursed Technique", "反転術式", 60, 100, 0, "instant",
                "Hoi 8 mau (4 tim) va xoa doc / wither.", UNTESTED, G, S);
        add("reinforce", "Cursed Energy Reinforcement", "呪力強化", 0, 20, 0, "toggle",
                "Bat/tat. Speed I + Strength I, ton 1.5 nang luong/giay.", UNTESTED, G, S, Y);
    }

    public static List<T> of(Chara c) {
        List<T> out = new ArrayList<>();
        for (T t : ALL) if (t.usedBy(c)) out.add(t);
        return out;
    }

    public static T byId(String id) {
        for (T t : ALL) if (t.id().equals(id)) return t;
        return null;
    }
}
