package com.example.jjk;

import java.util.HashMap;
import java.util.Map;

public class ClientData {
    public static int chara = 0, energy = 0, maxEnergy = 400, sel = 0, domain = 0;
    public static boolean infinity = false, reinforce = false;
    public static final Map<String, Integer> cd = new HashMap<>();
    public static Runnable listener;

    public static void parse(String s) {
        cd.clear();
        for (String part : s.split(";")) {
            int eq = part.indexOf('=');
            if (eq < 0) continue;
            String k = part.substring(0, eq), v = part.substring(eq + 1);
            try {
                switch (k) {
                    case "c" -> chara = Integer.parseInt(v);
                    case "e" -> energy = Integer.parseInt(v);
                    case "mx" -> maxEnergy = Integer.parseInt(v);
                    case "s" -> sel = Integer.parseInt(v);
                    case "inf" -> infinity = v.equals("1");
                    case "rei" -> reinforce = v.equals("1");
                    case "dom" -> domain = Integer.parseInt(v);
                    case "cd" -> {
                        for (String e : v.split(",")) {
                            String[] a = e.split(":");
                            if (a.length == 2) cd.put(a[0], Integer.parseInt(a[1]));
                        }
                    }
                    default -> { }
                }
            } catch (Exception ignored) { }
        }
        if (listener != null) listener.run();
    }

    public static Tech.Chara chara() {
        Tech.Chara[] all = Tech.Chara.values();
        return all[Math.max(0, Math.min(all.length - 1, chara))];
    }
}
