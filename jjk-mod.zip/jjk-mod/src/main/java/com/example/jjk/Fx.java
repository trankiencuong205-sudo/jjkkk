package com.example.jjk;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** Ham ve hinh hoc bang hat + tien ich chien dau dung chung. */
public class Fx {
    public static ParticleEffect dust(int rgb, float size) { return new DustParticleEffect(rgb, size); }

    public static void pt(ServerWorld w, ParticleEffect e, Vec3d v) { w.spawnParticles(e, v.x, v.y, v.z, 1, 0, 0, 0, 0); }

    public static void put(ServerWorld w, ParticleEffect e, Vec3d v, int n, double spread, double speed) {
        w.spawnParticles(e, v.x, v.y, v.z, n, spread, spread, spread, speed);
    }

    public static double rnd() { return ThreadLocalRandom.current().nextDouble(); }

    public static double rnd(double a, double b) { return a + (b - a) * rnd(); }

    /** {look, right, up} */
    public static Vec3d[] basis(Vec3d look) {
        Vec3d l = look.normalize();
        Vec3d right = l.crossProduct(new Vec3d(0, 1, 0));
        if (right.lengthSquared() < 1.0E-4) right = new Vec3d(1, 0, 0);
        right = right.normalize();
        Vec3d up = right.crossProduct(l).normalize();
        return new Vec3d[]{l, right, up};
    }

    public static void ring(ServerWorld w, ParticleEffect e, Vec3d c, Vec3d u, Vec3d v, double r, int n, double phase) {
        for (int i = 0; i < n; i++) {
            double a = phase + i * Math.PI * 2 / n;
            pt(w, e, c.add(u.multiply(Math.cos(a) * r)).add(v.multiply(Math.sin(a) * r)));
        }
    }

    public static void arc(ServerWorld w, ParticleEffect e, Vec3d c, Vec3d u, Vec3d v, double r, double a0, double a1, int n) {
        for (int i = 0; i <= n; i++) {
            double a = a0 + (a1 - a0) * i / n;
            pt(w, e, c.add(u.multiply(Math.cos(a) * r)).add(v.multiply(Math.sin(a) * r)));
        }
    }

    public static void sphere(ServerWorld w, ParticleEffect e, Vec3d c, double r, int n, double rot) {
        for (int i = 0; i < n; i++) {
            double y = 1 - 2.0 * (i + 0.5) / n;
            double rad = Math.sqrt(Math.max(0, 1 - y * y));
            double th = i * 2.399963 + rot;
            pt(w, e, c.add(Math.cos(th) * rad * r, y * r, Math.sin(th) * rad * r));
        }
    }

    public static void line(ServerWorld w, ParticleEffect e, Vec3d a, Vec3d b, double step) {
        Vec3d d = b.subtract(a);
        double len = d.length();
        if (len < 1.0E-4) return;
        Vec3d s = d.multiply(1.0 / len);
        for (double t = 0; t <= len; t += step) pt(w, e, a.add(s.multiply(t)));
    }

    /** tia set dut doan */
    public static void bolt(ServerWorld w, ParticleEffect e, Vec3d a, Vec3d b, double jitter, double step) {
        Vec3d d = b.subtract(a);
        double len = d.length();
        if (len < 0.1) return;
        int segs = Math.max(2, (int) (len / 1.2));
        Vec3d prev = a;
        for (int i = 1; i <= segs; i++) {
            Vec3d p = a.add(d.multiply((double) i / segs));
            if (i < segs) p = p.add(rnd(-jitter, jitter), rnd(-jitter, jitter), rnd(-jitter, jitter));
            line(w, e, prev, p, step);
            prev = p;
        }
    }

    public static Vec3d randDir() {
        double y = rnd(-1, 1), a = rnd(0, Math.PI * 2), r = Math.sqrt(1 - y * y);
        return new Vec3d(Math.cos(a) * r, y, Math.sin(a) * r);
    }

    public static void snd(ServerWorld w, Vec3d v, SoundEvent s, float vol, float pitch) {
        w.playSound(null, v.x, v.y, v.z, s, SoundCategory.PLAYERS, vol, pitch);
    }

    public static List<LivingEntity> hostiles(ServerWorld w, Entity self, Box box) {
        return w.getEntitiesByClass(LivingEntity.class, box, e -> e != self && e.isAlive() && e instanceof Monster);
    }

    public static Vec3d mid(LivingEntity e) { return e.getEntityPos().add(0, e.getHeight() * 0.5, 0); }

    public static void hurt(ServerWorld w, ServerPlayerEntity p, LivingEntity t, float dmg) {
        t.damage(w, w.getDamageSources().playerAttack(p), dmg);
    }
}
