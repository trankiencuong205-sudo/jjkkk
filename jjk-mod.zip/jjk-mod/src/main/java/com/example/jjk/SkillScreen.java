package com.example.jjk;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/** Menu (phim J): chon nhan vat, chon / dung ky thuat, xem mo ta + trang thai thuc te. */
public class SkillScreen extends Screen {
    private int view = -1;   // ky thuat dang xem

    public SkillScreen() { super(Text.literal("Jujutsu - Ky thuat")); }

    @Override
    protected void init() {
        ClientData.listener = this::clearAndInit;
        Tech.Chara[] cs = Tech.Chara.values();
        for (int i = 0; i < cs.length; i++) {
            final int ci = i;
            boolean cur = ClientData.chara == i;
            addDrawableChild(ButtonWidget.builder(Text.literal((cur ? "> " : "") + cs[i].title), b -> { view = -1; send(0, ci); })
                    .dimensions(10 + i * 124, 8, 120, 18).build());
        }
        List<Tech.T> list = Tech.of(ClientData.chara());
        if (view < 0 || view >= list.size()) view = Math.min(ClientData.sel, Math.max(0, list.size() - 1));
        for (int i = 0; i < list.size(); i++) {
            final int ti = i;
            Tech.T t = list.get(i);
            String mark = ClientData.sel == i ? "* " : "";
            int rem = ClientData.cd.getOrDefault(t.id(), 0);
            addDrawableChild(ButtonWidget.builder(Text.literal(mark + t.en() + (rem > 0 ? " (" + rem / 20 + "s)" : "")), b -> { view = ti; send(1, ti); })
                    .dimensions(10, 34 + i * 20, 230, 18).build());
        }
        int bx = 250, by = height - 50;
        addDrawableChild(ButtonWidget.builder(Text.literal("Dung ky thuat nay"), b -> send(4, view))
                .dimensions(bx, by, 140, 20).build());
    }

    private void send(int action, int a) { ClientPlayNetworking.send(new ActionPayload(action, a)); }

    @Override
    public void removed() { ClientData.listener = null; }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Chu luc: " + ClientData.energy + "/" + ClientData.maxEnergy).formatted(Formatting.AQUA), 10, height - 26, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, Text.literal(ClientData.chara().desc).formatted(Formatting.GRAY), 10, height - 14, 0xFFFFFFFF);
        List<Tech.T> list = Tech.of(ClientData.chara());
        if (view < 0 || view >= list.size()) return;
        Tech.T t = list.get(view);
        int x = 250, y = 36;
        ctx.drawTextWithShadow(textRenderer, Text.literal(t.en()).formatted(Formatting.BOLD, Formatting.WHITE), x, y, 0xFFFFFFFF); y += 12;
        ctx.drawTextWithShadow(textRenderer, Text.literal(t.jp()).formatted(Formatting.GOLD), x, y, 0xFFFFFFFF); y += 14;
        ctx.drawTextWithShadow(textRenderer, Text.literal("Chu luc: " + t.energy() + "   Hoi chieu: " + (t.cooldown() / 20.0) + "s   Sat thuong: " + (int) t.damage()), x, y, 0xFFCCCCCC); y += 14;
        int maxW = Math.max(120, width - x - 10);
        for (String line : t.desc().split("\n")) {
            for (var seq : textRenderer.wrapLines(Text.literal(line), maxW)) {
                ctx.drawTextWithShadow(textRenderer, seq, x, y, 0xFFDDDDDD);
                y += 10;
            }
            y += 3;
        }
        y += 4;
        ctx.drawTextWithShadow(textRenderer, Text.literal("Trang thai: " + t.status()).formatted(Formatting.YELLOW), x, y, 0xFFFFFFFF);
    }
}
