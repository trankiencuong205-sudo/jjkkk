# Jujutsu Cursed Techniques (Fabric 1.21.11) — giai đoạn 1

Mod hoàn toàn độc lập (id `jjk`), không liên quan Demon Slayer.

## Điều khiển
- **J**: mở menu (chọn Gojo / Sukuna / Yuji, chọn kỹ thuật, xem trạng thái)
- **R**: dùng kỹ thuật đang chọn · **G / V**: kỹ thuật kế / trước

## Build ra file .jar
**Cách 1 — GitHub Actions (như mod trước):**
1. Tạo repo GitHub MỚI (ví dụ `jjk`).
2. Upload `jjk-mod.zip` và file `jjk-build.yml` (đặt vào `.github/workflows/build.yml`).
3. Chờ Actions chạy → tải artifact `jjk-jar`. Nếu đỏ, mở mục Annotations và gửi lỗi.

**Cách 2 — trên PC có Java 21 + Gradle 9.2:** giải nén, mở thư mục `jjk-mod`, chạy `gradle build`,
jar nằm ở `build/libs/jujutsu-cursed-0.1.0.jar`. Cần cài kèm Fabric API 0.141.1+1.21.11.

## Cấu hình
`config/jjk-config.properties`: maxEnergy, regenPerSecond, costMultiplier, cooldownMultiplier,
disableCooldowns, unlimitedEnergy, purpleErasesBlocks, domainSeconds.

Xem `CHECKLIST.md` để biết cái gì đã viết / chưa test / chưa làm.
