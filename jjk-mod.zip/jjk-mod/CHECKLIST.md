# Jujutsu Kaisen mod — Master checklist

Trạng thái trung thực. **Chưa có mục nào được "tested"**: dự án này chưa từng được biên dịch hay chạy trong game
(môi trường tạo ra nó không tải được Maven/Fabric). Khi bạn chạy thử, hãy báo từng mục để mình đổi trạng thái.

Chú giải: 🟡 = đã viết, chưa test · ⬜ = planned (chưa viết) · 🟥 = blocked (cần công nghệ/xác minh thêm)

## Giai đoạn 1 (có trong zip này)

| Nhân vật | Kỹ thuật | Trạng thái | Ghi chú |
|---|---|---|---|
| Gojo | Infinity 無下限 | 🟡 | Chặn đòn có kẻ tấn công + đạn; quái bị đẩy. Không chặn lửa/rơi/độc. Đạn bị chậm do server (client có thể giật) |
| Gojo | Blue 蒼 | 🟡 | Hút quái 50 tick, nghiền nát, xung nổ cuối |
| Gojo | Red 赫 | 🟡 | Đạn đẩy lùi, sóng xung kích, không phá khối |
| Gojo | Hollow Purple 茈 | 🟡 | Charge Blue+Red → bay xuyên. Xóa địa hình chỉ khi bật `purpleErasesBlocks` |
| Gojo | Unlimited Void 無量空処 | 🟡 | Vỏ cầu hạt, quái bị tê liệt + sát thương nhẹ. Chưa: domain clash, môi trường 3D thật |
| Sukuna | Cleave 捌 | 🟡 | Sát thương theo máu tối đa mục tiêu |
| Sukuna | Dismantle 解 | 🟡 | 5 lưỡi chém bay, hitbox thật |
| Sukuna | Fire Arrow 開 (Fuga) | 🟡 | Vòng lửa → tên lửa → nổ, không đốt khối |
| Sukuna | Malevolent Shrine 伏魔御廚子 | 🟡 | Đền vẽ bằng hạt (không phải khối), chém liên tục. Chưa: domain clash |
| Yuji | Black Flash 黒閃 | 🟡 | Xác suất + Zone; tia sét đen-đỏ |
| Chung | Reverse Cursed Technique 反転術式 | 🟡 | Hồi 8 máu (Gojo, Sukuna) |
| Chung | Cursed Energy Reinforcement 呪力強化 | 🟡 | Speed I + Strength I |
| Hệ thống | Chu lực, hồi chiêu, HUD, menu J, phím R/G/V, đồng bộ server | 🟡 | Server kiểm tra quyền sở hữu / năng lượng / hồi chiêu |
| Hệ thống | Lưu nhân vật đã chọn | 🟡 | config/jjk-players.properties |

## Các giai đoạn sau (⬜ planned — KHÔNG có trong zip này)

### Gojo / Sukuna mở rộng
- ⬜ Maximum: Blue, Maximum: Red, Hollow Purple 200%, Six Eyes (hiệu ứng/giảm tiêu hao)
- ⬜ Sukuna: Dismantle (Web), World-Cutting Slash, Domain Amplification, biến thể Cleave
- ⬜ Domain clash / Simple Domain / Domain Amplification / Hollow Wicker Basket / Falling Blossom Emotion

### Yuji / Megumi / Nobara
- ⬜ Yuji: Divergent Fist, Manji Kick, Black Flash do thời điểm thật
- ⬜ Megumi — Ten Shadows: Divine Dogs, Nue, Toad, Max Elephant, Rabbit Escape, Round Deer, Piercing Ox, Great Serpent, Tiger Funeral, Mahoraga; domain Chimera Shadow Garden
- ⬜ Nobara: Straw Doll Technique (Resonance, Hairpin)

### Các pháp sư khác
- ⬜ Yuta (Rika, copy, Authentic Mutual Love), Toji (Playful Cloud, Inverted Spear of Heaven, Chain of a Thousand Miles, Split Soul Katana), Maki, Nanami (Ratio Technique), Todo (Boogie Woogie), Choso (Blood Manipulation), Hakari (Idle Death Gamble), Kashimo, Higuruma (Deadly Sentencing), Hana/Angel, Kenjaku, Inumaki, Panda, Geto, Yuki, Naoya (Projection Sorcery)

### Nguyền hồn
- ⬜ Mahito (Idle Transfiguration, Self-Embodiment of Perfection), Jogo (Coffin of the Iron Mountain), Hanami, Dagon (Horizon of the Captivating Skandha), Death Painting Wombs

### Hệ thống lớn
- 🟥 Mob riêng có model/texture/animation 3D: cần đăng ký entity + renderer tùy chỉnh (API client 1.21.11 chưa được xác minh bằng build)
- 🟥 Domain có môi trường 3D thật (đổi trời/khối/ánh sáng): cần render tùy chỉnh hoặc đặt khối tạm thời an toàn
- ⬜ Boss + phase, loot, tiến trình mở khóa, vật phẩm công cụ nguyền (cursed tools), vow
- ⬜ Màn cài đặt từng kỹ thuật trong game (hiện chỉ sửa file config/jjk-config.properties)
