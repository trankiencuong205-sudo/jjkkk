package com.example.jjk;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/**
 * Menu (phim K). 4 tab: Ky nang (chon nhan vat, gan slot) | Trang phuc | Quai | Cai dat (che do test: tat hoi chieu,
 * chu luc vo han, chinh he so hoi chieu / chi phi / hoi chu luc, hoi day ngay).
 */
public class SkillScreen extends Screen {
    private int view = 0;
    private static int mode = 0;   // 0 ky nang | 1 trang phuc | 2 goi quai | 3 cai dat
    private static final int ROW = 14, LY = 76;
    private static int page = 0;

    public SkillScreen() { super(Text.literal("Jujutsu")); }

    private static String onoff(boolean b) { return b ? "BAT" : "TAT"; }

    @Override
    protected void init() {
        ClientData.listener = this::clearAndInit;
        Tech.Chara[] cs = Tech.Chara.values();
        int cols = 6, bw = Math.max(50, (width - 20) / cols - 2);
        for (int i = 0; i < cs.length; i++) {
            final int ci = i;
            boolean cur = ClientData.chara == i;
            addDrawableChild(ButtonWidget.builder(Text.literal((cur ? "> " : "") + cs[i].shortName()), b -> { view = 0; page = 0; send(0, ci, 0); })
                    .dimensions(10 + (i % cols) * (bw + 2), 4 + (i / cols) * 17, bw, 15).build());
        }
        String[] tabs = {"Ky nang", "Trang phuc", "Quai", "Cai dat"};
        int tw = Math.max(50, (width - 20) / 4 - 2);
        int ty = 4 + ((cs.length + cols - 1) / cols) * 17 + 2;
        for (int i = 0; i < 4; i++) {
            final int mi = i;
            addDrawableChild(ButtonWidget.builder(Text.literal((mode == i ? "[" + tabs[i] + "]" : tabs[i])), b -> { mode = mi; view = 0; clearAndInit(); })
                    .dimensions(10 + i * (tw + 2), ty, tw, 15).build());
        }
        if (mode == 0) initSkills();
        else if (mode == 1) initOutfits(cs);
        else if (mode == 2) initMobs();
        else initSettings();
        if (mode == 0) initSlots();
    }

    private void initSkills() {
        List<Tech.T> list = Tech.of(ClientData.chara());
        if (view >= list.size()) view = 0;
        int rows = Math.max(4, (height - 44 - LY) / ROW - 1);
        int pages = Math.max(1, (list.size() + rows - 1) / rows);
        if (view / rows != page && view < list.size()) page = Math.min(page, pages - 1);
        if (page >= pages) page = pages - 1;
        for (int r = 0; r < rows; r++) {
            int i = page * rows + r;
            if (i >= list.size()) break;
            final int ti = i;
            Tech.T t = list.get(i);
            int rem = ClientData.cd.getOrDefault(t.id(), 0);
            String equipped = "";
            for (int s = 0; s < Data.SLOTS; s++) if (t.id().equals(ClientData.slots[s])) equipped += (equipped.isEmpty() ? "" : ",") + JjkClient.keyLabel(s);
            String label = (view == i ? "> " : "") + t.en().replace("Domain Expansion: ", "DE: ") + (equipped.isEmpty() ? "" : " [" + equipped + "]") + (rem > 0 ? " " + rem / 20 + "s" : "");
            addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> { view = ti; clearAndInit(); })
                    .dimensions(10, LY + r * ROW, 230, ROW - 1).build());
        }
        if (pages > 1) {
            int py = LY + rows * ROW;
            addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> { page = Math.max(0, page - 1); clearAndInit(); }).dimensions(10, py, 30, ROW).build());
            addDrawableChild(ButtonWidget.builder(Text.literal((page + 1) + "/" + pages), b -> { }).dimensions(42, py, 40, ROW).build());
            addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> { page = Math.min(pages - 1, page + 1); clearAndInit(); }).dimensions(84, py, 30, ROW).build());
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Dung ky nang dang xem"), b -> send(4, view, 0))
                .dimensions(248, LY, 150, 14).build());
    }

    private void initSlots() {
        int n = Data.SLOTS;
        int sw = Math.max(34, Math.min(60, (width - 20) / n - 2));
        int y = height - 34;
        for (int s = 0; s < n; s++) {
            final int si = s;
            String id = ClientData.slots[s];
            Tech.T t = id == null ? null : Tech.byId(id);
            String lab = "[" + JjkClient.keyLabel(s) + "] " + (t == null ? "-" : Tech.abbr(t));
            int x = 10 + s * (sw + 2);
            addDrawableChild(ButtonWidget.builder(Text.literal(lab), b -> send(8, si, view)).dimensions(x, y, sw, 16).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("x"), b -> send(8, si, -1)).dimensions(x, y + 17, sw, 13).build());
        }
    }

    private void initOutfits(Tech.Chara[] cs) {
        int n = Outfits.NAMES.length;
        int half = (n + 1) / 2, w2 = Math.max(80, (width - 24) / 2);
        for (int i = 0; i < n; i++) {
            final int oi = i;
            int col = i / half, row = i % half;
            String nm = i < cs.length ? cs[i].shortName() : Outfits.extraName(i);
            addDrawableChild(ButtonWidget.builder(Text.literal("Mac: " + nm), b -> send(11, oi, 0))
                    .dimensions(10 + col * (w2 + 4), LY + row * ROW, w2, ROW - 1).build());
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Thao het trang phuc"), b -> send(11, -1, 0))
                .dimensions(10, LY + half * ROW + 4, w2, ROW).build());
    }

    private void initMobs() {
        int half = (Mobs.DEFS.length + 1) / 2, w2 = Math.max(80, (width - 24) / 2);
        for (int i = 0; i < Mobs.DEFS.length; i++) {
            final int mi = i;
            int col = i / half, row = i % half;
            String id = Mobs.DEFS[i].id();
            addDrawableChild(ButtonWidget.builder(Text.literal((view == i ? "> " : "") + Character.toUpperCase(id.charAt(0)) + id.substring(1)), b -> { view = mi; clearAndInit(); })
                    .dimensions(10 + col * (w2 + 4), LY + row * ROW, w2, ROW - 1).build());
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Goi quai dang chon (Creative)"), b -> send(10, view, 0))
                .dimensions(10, LY + half * ROW + 4, 2 * w2 + 4, ROW + 2).build());
    }

    private void initSettings() {
        int w1 = Math.max(120, (width - 30) / 2), x2 = 10 + w1 + 6, y = LY;
        addDrawableChild(ButtonWidget.builder(Text.literal("Hoi day chu luc + hoi chieu NGAY"), b -> send(13, 7, 0)).dimensions(10, y, 2 * w1 + 6, 16).build());
        y += 20;
        addDrawableChild(ButtonWidget.builder(Text.literal("Khong hoi chieu: " + onoff(ClientData.cfgNc)), b -> send(13, 0, 0)).dimensions(10, y, w1, 16).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Chu luc vo han: " + onoff(ClientData.cfgUl)), b -> send(13, 1, 0)).dimensions(x2, y, w1, 16).build());
        y += 20;
        stepper(10, y, w1, "Thoi gian hoi chieu", ClientData.cfgCd, "%", 2, 25, 0, 1000);
        stepper(x2, y, w1, "Chi phi chu luc", ClientData.cfgCost, "%", 3, 25, 0, 1000);
        y += 20;
        stepper(10, y, w1, "Hoi chu luc /giay", ClientData.cfgRegen, "", 4, 10, 0, 1000);
        stepper(x2, y, w1, "Thoi gian domain (s)", ClientData.cfgDom, "", 6, 2, 3, 60);
        y += 20;
        addDrawableChild(ButtonWidget.builder(Text.literal("Hieu ung 3D: " + onoff(ClientData.cfgDisp)), b -> send(13, 8, 0)).dimensions(10, y, w1, 16).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Canh domain 3D: " + onoff(ClientData.cfgShell)), b -> send(13, 9, 0)).dimensions(x2, y, w1, 16).build());
        y += 20;
        addDrawableChild(ButtonWidget.builder(Text.literal("Tu chia trang skill (R/F): " + onoff(ClientData.cfgAuto)), b -> send(13, 10, 0)).dimensions(10, y, w1, 16).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Domain phong khoi that: " + onoff(ClientData.cfgSolid)), b -> send(13, 11, 0)).dimensions(x2, y, w1, 16).build());
        y += 20;
        addDrawableChild(ButtonWidget.builder(Text.literal("Chu luc toi da: " + ClientData.maxEnergy + "  (-100)"), b -> send(13, 5, Math.max(50, ClientData.maxEnergy - 100))).dimensions(10, y, w1, 16).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Chu luc toi da +100"), b -> send(13, 5, ClientData.maxEnergy + 100)).dimensions(x2, y, w1, 16).build());
    }

    /** o chinh so: [-] ten giatri [+] */
    private void stepper(int x, int y, int w, String name, int val, String unit, int code, int step, int min, int max) {
        int bw = 18;
        addDrawableChild(ButtonWidget.builder(Text.literal("-"), b -> send(13, code, Math.max(min, val - step))).dimensions(x, y, bw, 16).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(name + ": " + val + unit), b -> { }).dimensions(x + bw + 1, y, w - 2 * bw - 2, 16).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> send(13, code, Math.min(max, val + step))).dimensions(x + w - bw, y, bw, 16).build());
    }

    private void send(int action, int a, int b) { ClientPlayNetworking.send(new ActionPayload(action, a, b)); }

    @Override
    public void removed() { ClientData.listener = null; }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        int hy = height - 48;
        ctx.drawTextWithShadow(textRenderer, Text.literal("Chu luc: " + ClientData.energy + "/" + ClientData.maxEnergy).formatted(Formatting.AQUA), width - 120, 4 + 0, 0xFFFFFFFF);
        if (mode == 1) {
            ctx.drawTextWithShadow(textRenderer, Text.literal("Bam de mac bo do (thay giap dang mac).").formatted(Formatting.GRAY), 10, hy, 0xFFFFFFFF);
            return;
        }
        if (mode == 3) {
            ctx.drawTextWithShadow(textRenderer, Text.literal("Cai dat ap dung cho ca may chu va luu vao config/jjk-config.properties.").formatted(Formatting.GRAY), 10, hy, 0xFFFFFFFF);
            return;
        }
        if (mode == 2) {
            if (view >= 0 && view < Mobs.DEFS.length) {
                Mobs.Def d = Mobs.DEFS[view];
                ctx.drawTextWithShadow(textRenderer, Text.literal(d.name() + "  HP " + (int) d.hp() + "  DMG " + (int) d.dmg()).formatted(Formatting.WHITE), 10, hy - 22, 0xFFFFFFFF);
                int yy = hy - 10;
                for (var seq : textRenderer.wrapLines(Text.literal(d.desc()), width - 20)) { ctx.drawTextWithShadow(textRenderer, seq, 10, yy, 0xFFDDDDDD); yy += 10; }
            }
            return;
        }
        List<Tech.T> list = Tech.of(ClientData.chara());
        if (view < 0 || view >= list.size()) return;
        Tech.T t = list.get(view);
        int x = 248, y = LY + 20;
        ctx.drawTextWithShadow(textRenderer, Text.literal(t.en()).formatted(Formatting.BOLD, Formatting.WHITE), x, y, 0xFFFFFFFF); y += 11;
        ctx.drawTextWithShadow(textRenderer, Text.literal(t.jp()).formatted(Formatting.GOLD), x, y, 0xFFFFFFFF); y += 11;
        ctx.drawTextWithShadow(textRenderer, Text.literal("CE " + t.energy() + "  CD " + (t.cooldown() / 20.0) + "s  DMG " + (int) t.damage()), x, y, 0xFFCCCCCC); y += 11;
        int maxW = Math.max(100, width - x - 6);
        for (String line : t.desc().split("\n")) {
            for (var seq : textRenderer.wrapLines(Text.literal(line), maxW)) {
                if (y > height - 44) return;
                ctx.drawTextWithShadow(textRenderer, seq, x, y, 0xFFDDDDDD);
                y += 9;
            }
        }
    }
}
