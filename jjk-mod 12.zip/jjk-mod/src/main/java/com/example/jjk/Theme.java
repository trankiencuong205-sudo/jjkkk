package com.example.jjk;

import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

/**
 * Hieu ung 3D RIENG cho tung nhan vat (de cac ky nang khong giong het nhau):
 * Gojo luc giac xanh, Sukuna vet chem do cat cheo, Yuji gai cam, Todo da bay, Nanami dai 7:3, Nobara dinh + hoa,
 * Choso giot mau, Jogo cot lua + da nong, Mahito xuc tu thit, Inumaki vong am thanh, Yuta kiem bat cheo,
 * Toji vet chem xam, Hakari dong xu, Higuruma cot phan quyet, Kashimo set, Maki cung chem xanh, Kenjaku vong trong luc.
 * Chua test trong game.
 */
public class Theme {
    static void line(ServerWorld w, Vec3d a, Vec3d b, String o, String i, double t, int ttl) { new Disp.Beam(w, a, b, o, i, t, ttl); }

    public static void flair(Tech.Chara ch, ServerWorld w, Vec3d at, Vec3d dir, double size) {
        if (!Config.displays || ch == null) return;
        double s = Math.max(1.0, Math.min(8.0, size));
        Vec3d d = dir == null || dir.lengthSquared() < 1e-6 ? new Vec3d(0, 0, 1) : dir.normalize();
        Vec3d[] b = Fx.basis(d);
        switch (ch) {
            case GOJO -> {
                for (int i = 0; i < 6; i++) {
                    double a1 = i * Math.PI / 3, a2 = (i + 1) * Math.PI / 3;
                    Vec3d p1 = at.add(b[1].multiply(Math.cos(a1) * s * 0.8)).add(b[2].multiply(Math.sin(a1) * s * 0.8));
                    Vec3d p2 = at.add(b[1].multiply(Math.cos(a2) * s * 0.8)).add(b[2].multiply(Math.sin(a2) * s * 0.8));
                    line(w, p1, p2, "light_blue_stained_glass", "white_concrete", 0.14, 9);
                    Vis3D.pulseShrink(w, p1, "white_concrete", 0.3, 10);
                }
                Vis3D.plate(w, at, d, "light_blue_stained_glass", 0.3, s * 1.8, 8);
            }
            case SUKUNA -> {
                for (int i = 0; i < 4; i++) {
                    Vec3d r = Fx.randDir().multiply(s * 1.2);
                    line(w, at.subtract(r), at.add(r), "red_concrete", "white_concrete", 0.07, 7);
                }
                for (int i = 0; i < 5; i++) Vis3D.pulseShrink(w, at.add(Fx.randDir().multiply(s * 0.6)), "bone_block", 0.2, 12);
            }
            case YUJI -> {
                for (int i = 0; i < 9; i++) line(w, at, at.add(Fx.randDir().multiply(s * Fx.rnd(0.7, 1.3))), "orange_concrete", "black_concrete", 0.22, 6);
                Vis3D.pulseGrow(w, at, "black_stained_glass", 0.3, s * 1.2, 7);
            }
            case TODO -> {
                String[] st = {"stone", "cobblestone", "dirt", "andesite"};
                for (int i = 0; i < 9; i++) Vis3D.pulseShrink(w, at.add(Fx.rnd(-s, s) * 0.7, Fx.rnd(0, 1.6), Fx.rnd(-s, s) * 0.7), st[i % 4], 0.4, 14);
                Vis3D.plate(w, at, new Vec3d(0, 1, 0), "white_stained_glass", 0.4, s * 1.8, 7);
            }
            case NANAMI -> {
                Vec3d u = b[1].multiply(s * 1.4);
                line(w, at.subtract(u), at.add(u.multiply(0.4)), "gold_block", null, 0.12, 12);
                line(w, at.add(u.multiply(0.5)), at.add(u), "white_concrete", null, 0.12, 12);
                Vis3D.plate(w, at.add(u.multiply(0.45)), d, "yellow_stained_glass", 0.2, s * 0.9, 10);
            }
            case NOBARA -> {
                for (int i = 0; i < 7; i++) {
                    Vec3d r = Fx.randDir().multiply(s * 0.9);
                    line(w, at.add(r), at.add(r.multiply(0.35)), "iron_block", "gray_concrete", 0.09, 16);
                }
                for (int i = 0; i < 4; i++) Vis3D.pulseGrow(w, at.add(Fx.randDir().multiply(s * 0.5)), "pink_concrete", 0.15, 0.5, 10);
            }
            case CHOSO -> {
                for (int i = 0; i < 10; i++) Vis3D.pulseShrink(w, at.add(Fx.rnd(-s, s) * 0.6, Fx.rnd(0.5, 2.5), Fx.rnd(-s, s) * 0.6), "redstone_block", 0.22, 14);
                Vis3D.plate(w, at, new Vec3d(0, 1, 0), "red_stained_glass", 0.3, s * 1.6, 9);
            }
            case JOGO -> {
                Vis3D.pulseGrow(w, at, "orange_concrete", 0.4, s * 0.9, 9);
                Vis3D.pulseGrow(w, at.add(0, s * 0.6, 0), "magma_block", 0.3, s * 0.6, 10);
                for (int i = 0; i < 6; i++) Vis3D.pulseShrink(w, at.add(Fx.rnd(-s, s) * 0.7, Fx.rnd(0, 2.5), Fx.rnd(-s, s) * 0.7), "magma_block", 0.35, 14);
                line(w, at, at.add(0, s * 1.6, 0), "orange_stained_glass", "yellow_concrete", s * 0.5, 8);
            }
            case MAHITO -> {
                for (int i = 0; i < 5; i++) {
                    Vec3d r = at.add(Fx.randDir().multiply(s));
                    Vec3d mid = r.add(at).multiply(0.5).add(Fx.randDir().multiply(0.5));
                    line(w, r, mid, "pink_concrete", null, 0.2, 11);
                    line(w, mid, at, "magenta_concrete", null, 0.14, 11);
                }
            }
            case INUMAKI -> {
                for (int i = 0; i < 3; i++) {
                    final int k = i;
                    Vis3D.later(i * 3, () -> Vis3D.plate(w, at.add(d.multiply(k * 0.4)), d, "white_stained_glass", 0.3, s * (1.2 + 0.5 * k), 7));
                }
                for (int i = 0; i < 5; i++) Vis3D.pulseShrink(w, at.add(b[1].multiply(Fx.rnd(-s, s) * 0.6)).add(b[2].multiply(Fx.rnd(-s, s) * 0.6)), "white_concrete", 0.12, 10);
            }
            case YUTA -> {
                Vec3d r1 = b[1].add(b[2]).normalize().multiply(s * 1.4), r2 = b[1].subtract(b[2]).normalize().multiply(s * 1.4);
                line(w, at.subtract(r1), at.add(r1), "iron_block", "light_blue_stained_glass", 0.12, 9);
                line(w, at.subtract(r2), at.add(r2), "iron_block", "purple_stained_glass", 0.12, 9);
                Vis3D.plate(w, at, d, "light_blue_stained_glass", 0.3, s * 1.4, 8);
            }
            case TOJI -> {
                for (int i = 0; i < 3; i++) {
                    Vec3d r = Fx.randDir().multiply(s);
                    line(w, at.subtract(r), at.add(r), "gray_concrete", "white_concrete", 0.05, 4);
                }
            }
            case HAKARI -> {
                String[] gc = {"gold_block", "pink_concrete", "sea_lantern", "yellow_concrete"};
                for (int i = 0; i < 9; i++) Vis3D.pulseShrink(w, at.add(Fx.randDir().multiply(s * 0.8)), gc[i % 4], 0.3, 12);
                Vis3D.pulseGrow(w, at, "pink_stained_glass", 0.3, s * 1.3, 8);
            }
            case HIGURUMA -> {
                line(w, at, at.add(0, s * 2.0, 0), "gold_block", "yellow_concrete", 0.3, 8);
                Vis3D.plate(w, at.add(0, 0.05, 0), new Vec3d(0, 1, 0), "gold_block", 0.4, s * 1.5, 8);
                Vis3D.pulseShrink(w, at.add(0, s * 2.0, 0), "gold_block", 0.8, 8);
            }
            case KASHIMO -> {
                Vis3D.bolt(w, at.add(0, s * 2.5, 0), at, 0.08, 6);
                for (int i = 0; i < 3; i++) Vis3D.bolt(w, at.add(Fx.randDir().multiply(s * 1.2)), at, 0.05, 5);
            }
            case MAKI -> {
                for (int i = 0; i < 3; i++) {
                    Vec3d r = Fx.randDir().multiply(s);
                    line(w, at.subtract(r), at.add(r), "green_concrete", "white_concrete", 0.07, 5);
                }
            }
            case KENJAKU -> {
                for (int i = 0; i < 6; i++) {
                    double a = i * Math.PI / 3;
                    Vec3d p = at.add(b[1].multiply(Math.cos(a) * s)).add(b[2].multiply(Math.sin(a) * s));
                    Vis3D.pulseShrink(w, p, "purple_concrete", 0.4, 12);
                    line(w, p, at, "purple_stained_glass", null, 0.06, 8);
                }
                Vis3D.pulseGrow(w, at, "black_concrete", 0.2, s * 0.8, 10);
            }
            default -> Vis3D.pulseGrow(w, at, "white_stained_glass", 0.3, s, 8);
        }
    }
}
