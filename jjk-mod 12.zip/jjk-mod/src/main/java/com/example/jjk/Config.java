package com.example.jjk;

import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** config/jjk-config.properties */
public class Config {
    public static int maxEnergy = 400;
    public static double regen = 6.0;          // cursed energy / second
    public static double costMult = 1.0;
    public static double cdMult = 1.0;
    public static boolean noCooldown = false;
    public static boolean unlimited = false;
    public static boolean purpleErasesBlocks = false;
    public static int domainSeconds = 10;
    public static boolean solidDomain = true;  // domain dung phong khoi THAT (khong ai vao duoc); tra lai khoi khi het domain
    public static boolean autoPage = true;     // tu dong chia ky nang thanh trang 8 o, doi trang bang phim (khong can gan tay)
    public static boolean domainShell = true;  // vo/canh 3D cua domain (block_display); tat neu bi giat
    public static boolean naturalMobs = true;  // quai chu linh tu xuat hien ban dem (rat hiem)
    public static boolean displays = true;     // hinh hoc 3D that (display entity); tat neu bi giat/lag

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("jjk-config.properties"); }

    public static int cost(int base) { return unlimited ? 0 : (int) Math.round(base * costMult); }
    public static int cd(int base) { return noCooldown ? 0 : (int) Math.round(base * cdMult); }

    public static void load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                Properties p = new Properties();
                try (InputStream in = Files.newInputStream(f)) { p.load(in); }
                maxEnergy = Integer.parseInt(p.getProperty("maxEnergy", "400"));
                regen = Double.parseDouble(p.getProperty("regenPerSecond", "6.0"));
                costMult = Double.parseDouble(p.getProperty("costMultiplier", "1.0"));
                cdMult = Double.parseDouble(p.getProperty("cooldownMultiplier", "1.0"));
                noCooldown = Boolean.parseBoolean(p.getProperty("disableCooldowns", "false"));
                unlimited = Boolean.parseBoolean(p.getProperty("unlimitedEnergy", "false"));
                purpleErasesBlocks = Boolean.parseBoolean(p.getProperty("purpleErasesBlocks", "false"));
                domainSeconds = Integer.parseInt(p.getProperty("domainSeconds", "10"));
                displays = Boolean.parseBoolean(p.getProperty("displays", "true"));
                domainShell = Boolean.parseBoolean(p.getProperty("domainShell", "true"));
                autoPage = Boolean.parseBoolean(p.getProperty("autoPage", "true"));
                solidDomain = Boolean.parseBoolean(p.getProperty("solidDomain", "true"));
                naturalMobs = Boolean.parseBoolean(p.getProperty("naturalMobs", "true"));
            }
            save();
        } catch (Exception e) { System.err.println("[jjk] config: " + e); }
    }

    public static void save() {
        try {
            Properties p = new Properties();
            p.setProperty("maxEnergy", String.valueOf(maxEnergy));
            p.setProperty("regenPerSecond", String.valueOf(regen));
            p.setProperty("costMultiplier", String.valueOf(costMult));
            p.setProperty("cooldownMultiplier", String.valueOf(cdMult));
            p.setProperty("disableCooldowns", String.valueOf(noCooldown));
            p.setProperty("unlimitedEnergy", String.valueOf(unlimited));
            p.setProperty("purpleErasesBlocks", String.valueOf(purpleErasesBlocks));
            p.setProperty("domainSeconds", String.valueOf(domainSeconds));
            p.setProperty("displays", String.valueOf(displays));
            p.setProperty("domainShell", String.valueOf(domainShell));
            p.setProperty("autoPage", String.valueOf(autoPage));
            p.setProperty("solidDomain", String.valueOf(solidDomain));
            p.setProperty("naturalMobs", String.valueOf(naturalMobs));
            try (OutputStream out = Files.newOutputStream(file())) { p.store(out, "Jujutsu Cursed Techniques config"); }
        } catch (Exception e) { System.err.println("[jjk] config save: " + e); }
    }
}
