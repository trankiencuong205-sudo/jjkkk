package com.example.jjk;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * CAN PHONG BANG KHOI THAT (nhu trong phim: domain la mot phong den kin, khong ai vao duoc).
 * Xay 6 mat (san, tran, 4 tuong) bang khoi that, luu lai khoi cu va TRA LAI khi domain ket thuc
 * (hoac khi tat server). Tuong khong dap duoc khi domain dang mo. Tat bang config solidDomain=false.
 * Chua test trong game.
 */
public class Room {
    private static final List<Room> ALL = new ArrayList<>();
    private static final Set<Long> PROT = new HashSet<>();

    final ServerWorld w;
    final BlockState block;
    final List<BlockPos> cells = new ArrayList<>();
    final Map<Long, BlockState> saved = new HashMap<>();
    int placed = 0, fillTicks, closeTicks = 0;
    boolean closing = false, done = false;

    public Room(ServerWorld w, Vec3d c, int r, int h, String blockId, int fillTicks) {
        this.w = w;
        this.fillTicks = Math.max(1, fillTicks);
        Block b = Registries.BLOCK.get(Identifier.of("minecraft", blockId));
        this.block = b.getDefaultState();
        int x0 = (int) Math.floor(c.x), y0 = (int) Math.floor(c.y), z0 = (int) Math.floor(c.z);
        for (int y = y0 - 1; y <= y0 + h; y++)
            for (int x = -r; x <= r; x++)
                for (int z = -r; z <= r; z++)
                    if (y == y0 - 1 || y == y0 + h || Math.abs(x) == r || Math.abs(z) == r)
                        cells.add(new BlockPos(x0 + x, y, z0 + z));
        ALL.add(this);
    }

    public void startClose(int ticks) {
        closing = true; closeTicks = Math.max(1, ticks);
        while (cells.size() > placed) cells.remove(cells.size() - 1);     // chua dat thi bo
        closeStep = (int) Math.ceil(cells.size() / (double) closeTicks);
    }

    /** tra het khoi cu ngay lap tuc */
    public void closeNow() {
        restore(Integer.MAX_VALUE);
        done = true;
    }

    private void fill(int n) {
        for (int i = 0; i < n && placed < cells.size(); i++, placed++) {
            BlockPos p = cells.get(placed);
            if (!w.getChunkManager().isChunkLoaded(p.getX() >> 4, p.getZ() >> 4)) continue;
            BlockState old = w.getBlockState(p);
            if (old.isOf(net.minecraft.block.Blocks.BEDROCK) || w.getBlockEntity(p) != null) continue;
            saved.put(p.asLong(), old);
            PROT.add(p.asLong());
            w.setBlockState(p, block, Block.NOTIFY_LISTENERS);
        }
    }

    private void restore(int n) {
        for (int i = 0; i < n && !cells.isEmpty(); i++) {
            BlockPos p = cells.remove(cells.size() - 1);
            Long key = p.asLong();
            BlockState old = saved.remove(key);
            PROT.remove(key);
            if (old != null && w.getChunkManager().isChunkLoaded(p.getX() >> 4, p.getZ() >> 4)) w.setBlockState(p, old, Block.NOTIFY_LISTENERS);
        }
        if (cells.isEmpty()) done = true;
    }

    public static boolean isProtected(BlockPos p) { return !PROT.isEmpty() && PROT.contains(p.asLong()); }

    int closeStep = 1;

    private void tick() {
        if (done) return;
        if (!closing) fill((int) Math.ceil(cells.size() / (double) fillTicks));
        else restore(closeStep);
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (Iterator<Room> it = ALL.iterator(); it.hasNext(); ) {
                Room r = it.next();
                r.tick();
                if (r.done) it.remove();
            }
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            for (Room r : ALL) r.closeNow();
            ALL.clear();
            PROT.clear();
        });
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, be) -> !isProtected(pos));
    }
}
