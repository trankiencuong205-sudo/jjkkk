package com.example.jjk;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class JjkClient implements ClientModInitializer {
    public static final KeyBinding.Category CATEGORY = KeyBinding.Category.create(Identifier.of(Jjk.ID, "main"));
    /** phim mac dinh cho 8 slot; doi duoc trong Options > Controls (muc "Jujutsu Cursed Techniques") */
    private static final int[] DEFAULT_KEYS = {GLFW.GLFW_KEY_Z, GLFW.GLFW_KEY_X, GLFW.GLFW_KEY_C, GLFW.GLFW_KEY_V,
            GLFW.GLFW_KEY_G, GLFW.GLFW_KEY_B, GLFW.GLFW_KEY_H, GLFW.GLFW_KEY_Y};
    public static final KeyBinding[] slotKeys = new KeyBinding[Data.SLOTS];
    private static KeyBinding menu, pageNext, pagePrev;

    public static String keyLabel(int slot) {
        try {
            String s = slotKeys[slot].getBoundKeyLocalizedText().getString();
            return s.length() > 3 ? s.substring(0, 3) : s;
        } catch (Exception e) { return "?"; }
    }

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(SyncPayload.ID, (payload, context) -> ClientData.parse(payload.data()));
        menu = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.jjk.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, CATEGORY));
        pageNext = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.jjk.page_next", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, CATEGORY));
        pagePrev = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.jjk.page_prev", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F, CATEGORY));
        for (int i = 0; i < Data.SLOTS; i++)
            slotKeys[i] = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.jjk.slot" + (i + 1), InputUtil.Type.KEYSYM, DEFAULT_KEYS[i], CATEGORY));

        HudElementRegistry.addLast(Identifier.of(Jjk.ID, "hud"), (ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.options.hudHidden || mc.player == null) return;
            int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
            int total = Data.SLOTS * 24 - 2;
            int sx = sw / 2 - total / 2, y = sh - 86;

            // thanh chu luc
            float frac = Math.max(0f, Math.min(1f, ClientData.energy / (float) Math.max(1, ClientData.maxEnergy)));
            int col = 0xFF000000 | ClientData.chara().color;
            int by = y - 11;
            ctx.fill(sx - 1, by - 1, sx + total + 1, by + 7, 0xFF000000);
            ctx.fill(sx, by, sx + total, by + 6, 0xFF15101F);
            ctx.fill(sx, by, sx + (int) (total * frac), by + 6, col);
            ctx.fill(sx, by, sx + (int) (total * frac), by + 2, 0x66FFFFFF);
            String et = "CE " + ClientData.energy + "/" + ClientData.maxEnergy;
            ctx.drawTextWithShadow(mc.textRenderer, et, sx + total + 4, by - 1, 0xFFFFFFFF);

            // 8 o ky nang
            for (int i = 0; i < Data.SLOTS; i++) {
                int x = sx + i * 24;
                String id = ClientData.slots[i];
                Tech.T t = id == null ? null : Tech.byId(id);
                int border = 0xFF000000;
                if (t != null && ((t.id().equals("infinity") && ClientData.infinity) || (t.id().equals("reinforce") && ClientData.reinforce))) border = 0xFF40FF70;
                ctx.fill(x - 1, y - 1, x + 23, y + 23, border);
                if (t == null) {
                    ctx.fill(x, y, x + 22, y + 22, 0xFF202028);
                } else {
                    int ic = Tech.iconColor(t);
                    int r = (int) (((ic >> 16) & 255) * 0.55), g = (int) (((ic >> 8) & 255) * 0.55), b = (int) ((ic & 255) * 0.55);
                    ctx.fill(x, y, x + 22, y + 22, 0xFF000000 | (r << 16) | (g << 8) | b);
                    ctx.fill(x, y, x + 22, y + 2, 0xFF000000 | ic);                  // dai mau tren cung
                    String ab = Tech.abbr(t);
                    ctx.drawTextWithShadow(mc.textRenderer, ab, x + 11 - mc.textRenderer.getWidth(ab) / 2, y + 4, 0xFFFFFFFF);
                    int rem = ClientData.cd.getOrDefault(t.id(), 0);
                    if (rem > 0 && t.cooldown() > 0) {
                        int h = (int) (22 * Math.min(1f, rem / (float) t.cooldown()));
                        ctx.fill(x, y, x + 22, y + h, 0xAA000000);
                        String sec = rem >= 20 ? String.valueOf((rem + 19) / 20) : String.format("%.1f", rem / 20.0);
                        ctx.drawTextWithShadow(mc.textRenderer, sec, x + 11 - mc.textRenderer.getWidth(sec) / 2, y + 7, 0xFFFFDD66);
                    }
                }
                String kl = keyLabel(i);
                ctx.drawTextWithShadow(mc.textRenderer, kl, x + 2, y + 13, 0xFFCCCCCC);
            }
            if (ClientData.cfgAuto && ClientData.np > 1) {
                String pt = "Trang " + (ClientData.pg + 1) + "/" + ClientData.np + "  [R] >  [F] <";
                ctx.drawTextWithShadow(mc.textRenderer, pt, sx, y + 25, 0xFFFFE080);
            }
            int ty = y - 24;
            if (ClientData.domain > 0) ctx.drawTextWithShadow(mc.textRenderer, "DOMAIN EXPANSION  " + (ClientData.domain / 20) + "s", sx, ty, 0xFFFF6060);
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            while (menu.wasPressed()) {
                ClientPlayNetworking.send(new ActionPayload(2, 0, 0));
                client.setScreen(new SkillScreen());
            }
            if (client.currentScreen != null) {            // dang mo menu/chat: khong kich hoat skill
                for (KeyBinding k : slotKeys) while (k.wasPressed()) { }
                return;
            }
            while (pageNext.wasPressed()) ClientPlayNetworking.send(new ActionPayload(14, 1, 0));
            while (pagePrev.wasPressed()) ClientPlayNetworking.send(new ActionPayload(14, -1, 0));
            for (int i = 0; i < Data.SLOTS; i++)
                while (slotKeys[i].wasPressed()) ClientPlayNetworking.send(new ActionPayload(7, i, 0));
        });
    }
}
