package com.example.jjk;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Ten Shadows cua Megumi: 10 shikigami, moi con la mot mo hinh 3D ghep tu block_display (Rig), co hoat anh
 * (chan chay, canh vo, duoi quet...). Thu tu: Divine Dogs, Nue, Great Serpent, Toad, Max Elephant, Rabbit Escape,
 * Round Deer, Piercing Ox, Tiger Funeral, Mahoraga. Chua duoc test trong game.
 */
public class Shiki {
    public static boolean dispatch(String id, ServerWorld w, ServerPlayerEntity p) {
        switch (id) {
            case "divine_dogs" -> dogs(w, p);
            case "nue" -> nue(w, p);
            case "great_serpent" -> serpent(w, p);
            case "toad" -> toad(w, p);
            case "max_elephant" -> elephant(w, p);
            case "rabbit_escape" -> rabbits(w, p);
            case "round_deer" -> deer(w, p);
            case "piercing_ox" -> ox(w, p);
            case "tiger_funeral" -> tiger(w, p);
            case "mahoraga_summon" -> mahoraga(w, p);
            default -> { return false; }
        }
        return true;
    }

    // ---------- tien ich ----------
    static Vec3d flat(Vec3d v) { return new Vec3d(v.x, 0, v.z); }

    static Vec3d dirOf(ServerPlayerEntity p) {
        Vec3d l = flat(p.getRotationVec(1f));
        return l.lengthSquared() < 1.0E-4 ? new Vec3d(0, 0, 1) : l.normalize();
    }

    static Vec3d rightOf(Vec3d dir) { return new Vec3d(-dir.z, 0, dir.x); }   // ben trai cua mo hinh la +X cuc bo

    static LivingEntity nearest(ServerWorld w, ServerPlayerEntity p, Vec3d from, double r) {
        LivingEntity best = null; double bd = 1e9;
        for (LivingEntity e : Fx.hostiles(w, p, new Box(from, from).expand(r))) {
            double d = e.getEntityPos().distanceTo(from);
            if (d < bd && d <= r) { bd = d; best = e; }
        }
        return best;
    }

    static void summonFx(ServerWorld w, Vec3d pos, int col) {
        Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
        for (int i = 0; i < 3; i++) Fx.ring(w, Fx.dust(col, 1.6f), pos.add(0, 0.1 + i * 0.05, 0), b[1], b[2], 0.8 + i * 0.7, 36, 0);
        Fx.put(w, ParticleTypes.LARGE_SMOKE, pos.add(0, 0.5, 0), 14, 0.5, 0.03);
        Fx.snd(w, pos, SoundEvents.ENTITY_WITHER_SHOOT, 0.7f, 1.4f);
    }

    // ---------- mo hinh ----------
    /** chan 2 doan (dui + cang) co khop goi, ban chan */
    static void leg(Rig r, String main, String dark, double x, double z, double hipY, double up, double low, double w, double amp, double sp, double ph) {
        r.swing(main, x, hipY - up / 2, z, w, up, w, x, hipY, z, 1, 0, 0, amp, sp, ph);
        int h = r.idx();
        r.swing(main, x, hipY - up - low / 2, z, w * 0.8, low, w * 0.8, x, hipY - up, z, 1, 0, 0, -amp * 0.9, sp, ph + 0.9);
        r.under(h);
        int k = r.idx();
        r.add(dark, x, hipY - up - low - 0.04, z + w * 0.3, w * 1.05, 0.12, w * 1.6);
        r.under(k);
    }

    static Rig dogModel(ServerWorld w, Vec3d pos, double yaw, String main, String acc, int ttl) {
        Rig r = new Rig(w, pos, yaw, ttl).scale(1.3);
        // than: lung, nguc sau, bung
        r.add(main, 0, 1.18, -0.25, 0.6, 0.55, 0.95).add(main, 0, 1.2, 0.5, 0.72, 0.72, 0.62).add(main, 0, 0.92, 0.0, 0.46, 0.3, 1.3);
        r.add(acc, 0, 1.48, 0.05, 0.22, 0.05, 1.15).add(acc, 0, 1.5, -0.55, 0.3, 0.05, 0.3);
        // co + bo long co
        r.rot(main, 0, 1.55, 0.95, 0.46, 0.55, 0.5, 1, 0, 0, -0.5);
        for (int i = 0; i < 7; i++) { double a = i * 0.9; r.rot(acc, Math.cos(a) * 0.3, 1.5 + Math.sin(a) * 0.3, 0.9, 0.12, 0.34, 0.12, 0, 0, 1, a); }
        // dau: so, mom, ham, mui, rang
        r.add(main, 0, 1.78, 1.3, 0.52, 0.48, 0.5).add(main, 0, 1.68, 1.72, 0.3, 0.26, 0.42).add(acc, 0, 1.72, 1.95, 0.14, 0.12, 0.08);
        r.swing(main, 0, 1.52, 1.66, 0.26, 0.1, 0.4, 0, 1.55, 1.4, 1, 0, 0, 0.12, 0.35, 0);
        for (int i = 0; i < 3; i++) { r.add("white_concrete", 0.1, 1.5, 1.6 + i * 0.12, 0.04, 0.07, 0.04); r.add("white_concrete", -0.1, 1.5, 1.6 + i * 0.12, 0.04, 0.07, 0.04); }
        r.add(acc, 0.15, 1.84, 1.52, 0.14, 0.05, 0.12).add(acc, -0.15, 1.84, 1.52, 0.14, 0.05, 0.12);
        r.add("sea_lantern", 0.14, 1.8, 1.55, 0.09, 0.08, 0.05).add("sea_lantern", -0.14, 1.8, 1.55, 0.09, 0.08, 0.05);
        // tai nhon
        r.rot(main, 0.18, 2.12, 1.22, 0.14, 0.36, 0.1, 0, 0, 1, -0.18).rot(main, -0.18, 2.12, 1.22, 0.14, 0.36, 0.1, 0, 0, 1, 0.18);
        r.rot(acc, 0.2, 2.34, 1.22, 0.08, 0.14, 0.07, 0, 0, 1, -0.18).rot(acc, -0.2, 2.34, 1.22, 0.08, 0.14, 0.07, 0, 0, 1, 0.18);
        // duoi 3 doan
        r.swing(main, 0, 1.4, -0.95, 0.16, 0.16, 0.5, 0, 1.3, -0.7, 0, 1, 0, 0.5, 0.45, 0);
        int t1 = r.idx();
        r.swing(main, 0, 1.55, -1.3, 0.14, 0.14, 0.5, 0, 1.45, -1.05, 0, 1, 0, 0.3, 0.45, 0.6);
        r.under(t1);
        int t2 = r.idx();
        r.add(acc, 0, 1.72, -1.6, 0.12, 0.12, 0.45);
        r.under(t2);
        // 4 chan
        leg(r, main, acc, 0.24, 0.55, 0.92, 0.5, 0.45, 0.2, 0.7, 0.9, 0);
        leg(r, main, acc, -0.24, 0.55, 0.92, 0.5, 0.45, 0.2, 0.7, 0.9, Math.PI);
        leg(r, main, acc, 0.24, -0.6, 0.95, 0.5, 0.45, 0.22, 0.7, 0.9, Math.PI);
        leg(r, main, acc, -0.24, -0.6, 0.95, 0.5, 0.45, 0.22, 0.7, 0.9, 0);
        return r;
    }

    /** cum long vu hinh quat quanh goc (px,py,pz) quay quanh truc Y */
    static void fan(Rig r, String block, double px, double py, double pz, double dx, double len, double thick, double wid, int n, double spread, double a0, int parent) {
        for (int i = 0; i < n; i++) {
            double a = a0 + (i - (n - 1) / 2.0) * spread;
            double L = len * (1.0 - Math.abs(i - (n - 1) / 2.0) * 0.07);
            double cx = px + dx * L / 2, cz = pz;
            r.rotp(block, cx, py, cz, L, thick, wid, px, py, pz, 0, 1, 0, a);
            if (parent >= 0) r.under(parent);
        }
    }

    static Rig nueModel(ServerWorld w, Vec3d pos, double yaw, int ttl) {
        Rig r = new Rig(w, pos, yaw, ttl).scale(1.6);
        String dk = "black_concrete", gy = "gray_concrete", cr = "white_concrete";
        // than
        r.add(dk, 0, 2.1, -0.1, 0.9, 0.85, 1.3).add(cr, 0, 1.85, 0.25, 0.7, 0.55, 0.8).add(gy, 0, 2.5, -0.1, 0.8, 0.15, 1.1);
        r.add(cr, 0, 1.7, 0.15, 0.55, 0.15, 0.6);
        // dau cu: dia mat
        r.add(dk, 0, 2.55, 0.85, 0.72, 0.7, 0.62).add(cr, 0, 2.55, 1.17, 0.62, 0.6, 0.06);
        r.add("light_gray_concrete", 0.17, 2.6, 1.2, 0.26, 0.26, 0.04).add("light_gray_concrete", -0.17, 2.6, 1.2, 0.26, 0.26, 0.04);
        r.add("yellow_concrete", 0.17, 2.6, 1.23, 0.18, 0.18, 0.04).add("yellow_concrete", -0.17, 2.6, 1.23, 0.18, 0.18, 0.04);
        r.add(dk, 0.17, 2.6, 1.26, 0.07, 0.12, 0.03).add(dk, -0.17, 2.6, 1.26, 0.07, 0.12, 0.03);
        r.add("orange_concrete", 0, 2.45, 1.26, 0.13, 0.17, 0.12).add("orange_concrete", 0, 2.34, 1.25, 0.09, 0.14, 0.1);
        r.rot(dk, 0.3, 3.0, 0.85, 0.12, 0.38, 0.12, 0, 0, 1, -0.35).rot(dk, -0.3, 3.0, 0.85, 0.12, 0.38, 0.12, 0, 0, 1, 0.35);
        // canh: goc canh + 7 long vu
        for (int s = -1; s <= 1; s += 2) {
            r.swing(dk, 0.6 * s, 2.45, -0.05, 0.5, 0.18, 0.7, 0.45 * s, 2.45, -0.05, 0, 0, 1, 0.6 * s, 0.9, 0);
            int root = r.idx();
            r.swing(dk, 1.1 * s, 2.45, -0.05, 0.7, 0.12, 0.65, 0.45 * s, 2.45, -0.05, 0, 0, 1, 0.6 * s, 0.9, 0);
            r.under(root);
            for (int i = 0; i < 9; i++) {
                double a = (i - 4) * 0.13;
                double L = 2.5 - Math.abs(i - 4) * 0.18;
                r.rotp(i % 2 == 0 ? dk : gy, 0.45 * s + s * L / 2 + s * 0.6, 2.43 - i * 0.005, -0.05, L, 0.07, 0.5, 1.05 * s, 2.43, -0.05, 0, 1, 0, a * -s);
                r.under(root);
            }
            for (int i = 0; i < 4; i++) {
                double a = (i - 1.5) * 0.2;
                r.rotp("cyan_concrete", 0.45 * s + s * 3.1 + s * 0.25, 2.42, -0.05, 0.5, 0.06, 0.2, 1.05 * s, 2.43, -0.05, 0, 1, 0, a * -s);
                r.under(root);
            }
        }
        // duoi vu hinh quat
        fan(r, dk, 0, 2.1, -0.7, -1, 1.5, 0.07, 0.34, 5, 0.12, 0, -1);
        r.add("cyan_concrete", 0, 2.1, -2.2, 0.16, 0.06, 0.3);
        // chan ve
        r.add("orange_concrete", 0.2, 1.5, 0.2, 0.12, 0.35, 0.12).add("orange_concrete", -0.2, 1.5, 0.2, 0.12, 0.35, 0.12);
        r.add("yellow_concrete", 0.2, 1.3, 0.3, 0.22, 0.08, 0.3).add("yellow_concrete", -0.2, 1.3, 0.3, 0.22, 0.08, 0.3);
        return r;
    }

    static Rig toadModel(ServerWorld w, Vec3d pos, double yaw, int ttl) {
        Rig r = new Rig(w, pos, yaw, ttl).scale(1.4);
        String g = "lime_concrete", d = "green_concrete", y = "yellow_concrete";
        r.add(g, 0, 0.55, -0.1, 1.1, 0.75, 1.1).add(g, 0, 0.45, 0.35, 0.95, 0.6, 0.7).add(y, 0, 0.28, 0.1, 0.9, 0.25, 1.1);
        r.add(d, 0, 0.98, -0.2, 0.9, 0.16, 0.8);
        for (int i = 0; i < 9; i++) r.add(d, ((i * 37) % 9 - 4) * 0.11, 1.0 + (i % 3) * 0.03, -0.45 + (i % 4) * 0.22, 0.14, 0.1, 0.14);
        // dau + mieng rong
        r.add(g, 0, 0.75, 0.75, 1.0, 0.45, 0.6).add("black_concrete", 0, 0.58, 1.06, 0.95, 0.05, 0.04).add(y, 0, 0.45, 0.85, 0.7, 0.2, 0.4);
        r.add("white_concrete", 0, 0.28, 0.9, 0.5, 0.18, 0.2);
        for (int s = -1; s <= 1; s += 2) {
            r.add(g, 0.33 * s, 1.08, 0.7, 0.34, 0.3, 0.34).add("yellow_concrete", 0.33 * s, 1.12, 0.88, 0.22, 0.22, 0.05).add("black_concrete", 0.33 * s, 1.12, 0.91, 0.07, 0.18, 0.03);
            // chan truoc
            r.add(g, 0.5 * s, 0.25, 0.7, 0.18, 0.5, 0.18).add(g, 0.5 * s, 0.05, 0.85, 0.36, 0.1, 0.3).add(d, 0.5 * s, 0.05, 1.05, 0.08, 0.1, 0.1);
            // chan sau gap
            r.add(g, 0.65 * s, 0.45, -0.35, 0.3, 0.5, 0.8).add(g, 0.68 * s, 0.15, -0.7, 0.25, 0.25, 0.7).add(g, 0.7 * s, 0.05, 0.05, 0.5, 0.1, 0.8).add(d, 0.7 * s, 0.05, 0.45, 0.4, 0.1, 0.1);
        }
        return r;
    }

    static Rig elephantModel(ServerWorld w, Vec3d pos, double yaw, int ttl) {
        Rig r = new Rig(w, pos, yaw, ttl);
        String g = "light_blue_stained_glass", g2 = "cyan_stained_glass", wh = "white_concrete";
        // than nhieu lop
        r.add(g, 0, 3.3, -0.2, 3.0, 2.5, 3.6).add(g2, 0, 3.4, -0.2, 2.7, 2.2, 3.3).add(g, 0, 4.35, -0.4, 2.2, 0.5, 2.8).add(g, 0, 2.5, 0.1, 2.6, 0.6, 3.0);
        for (int i = 0; i < 5; i++) r.add("blue_stained_glass", 0, 4.65, -1.4 + i * 0.7, 1.0, 0.18, 0.28);
        // dau + tran
        r.add(g, 0, 3.7, 2.1, 2.0, 2.0, 1.6).add(g2, 0, 4.1, 2.0, 1.5, 0.9, 1.2).add(g, 0, 3.2, 2.9, 1.2, 1.3, 0.5);
        r.add("black_concrete", 0.62, 3.95, 2.88, 0.2, 0.2, 0.08).add("black_concrete", -0.62, 3.95, 2.88, 0.2, 0.2, 0.08);
        r.add("white_concrete", 0.62, 3.95, 2.93, 0.08, 0.08, 0.04).add("white_concrete", -0.62, 3.95, 2.93, 0.08, 0.08, 0.04);
        // tai lon
        r.rot(g2, 1.35, 3.9, 1.85, 0.12, 1.7, 1.5, 0, 1, 0, -0.35).rot(g2, -1.35, 3.9, 1.85, 0.12, 1.7, 1.5, 0, 1, 0, 0.35);
        // nga cong
        r.rot(wh, 0.75, 2.6, 3.35, 0.22, 0.22, 1.5, 1, 0, 0, 0.35).rot(wh, -0.75, 2.6, 3.35, 0.22, 0.22, 1.5, 1, 0, 0, 0.35);
        r.add(wh, 0.75, 2.85, 4.1, 0.18, 0.18, 0.5).add(wh, -0.75, 2.85, 4.1, 0.18, 0.18, 0.5);
        // voi 4 khuc cuon len
        r.swing(g, 0, 2.95, 3.3, 0.8, 0.8, 0.9, 0, 3.2, 2.9, 1, 0, 0, 0.15, 0.3, 0);
        int a = r.idx();
        r.swing(g, 0, 2.5, 3.9, 0.7, 0.9, 0.7, 0, 3.0, 3.5, 1, 0, 0, 0.2, 0.3, 0.4);
        r.under(a);
        int b = r.idx();
        r.swing(g2, 0, 2.0, 4.1, 0.6, 0.9, 0.6, 0, 2.5, 3.9, 1, 0, 0, 0.25, 0.3, 0.8);
        r.under(b);
        int c = r.idx();
        r.swing("blue_stained_glass", 0, 1.7, 4.4, 0.6, 0.5, 0.8, 0, 2.0, 4.1, 1, 0, 0, 0.3, 0.3, 1.2);
        r.under(c);
        // chan tru + mong
        for (int i = 0; i < 4; i++) {
            double x = (i % 2 == 0 ? 1.0 : -1.0), z = (i < 2 ? 1.1 : -1.3);
            r.add(g, x, 1.3, z, 1.0, 2.4, 1.0).add(g2, x, 0.12, z, 1.1, 0.25, 1.15);
            for (int t = -1; t <= 1; t++) r.add(wh, x + t * 0.3, 0.1, z + 0.62, 0.2, 0.2, 0.1);
        }
        r.rot(g, 0, 3.2, -2.3, 0.2, 1.4, 0.2, 1, 0, 0, 0.25).add("blue_stained_glass", 0, 2.45, -2.45, 0.35, 0.3, 0.35);
        return r;
    }

    static Rig rabbitModel(ServerWorld w, Vec3d pos, double yaw, int ttl) {
        Rig r = new Rig(w, pos, yaw, ttl).scale(1.1);
        String wh = "white_concrete", pk = "pink_concrete";
        r.add(wh, 0, 0.3, -0.05, 0.34, 0.3, 0.5).add(wh, 0, 0.36, 0.2, 0.3, 0.3, 0.3);
        r.add(wh, 0, 0.5, 0.42, 0.26, 0.24, 0.26).add(pk, 0, 0.45, 0.57, 0.08, 0.06, 0.04).add("red_concrete", 0.08, 0.55, 0.55, 0.05, 0.05, 0.04).add("red_concrete", -0.08, 0.55, 0.55, 0.05, 0.05, 0.04);
        r.rot(wh, 0.07, 0.86, 0.38, 0.08, 0.4, 0.05, 1, 0, 0, -0.15).rot(wh, -0.07, 0.86, 0.38, 0.08, 0.4, 0.05, 1, 0, 0, -0.15);
        r.rot(pk, 0.07, 0.86, 0.405, 0.04, 0.32, 0.02, 1, 0, 0, -0.15).rot(pk, -0.07, 0.86, 0.405, 0.04, 0.32, 0.02, 1, 0, 0, -0.15);
        r.add(wh, 0, 0.32, -0.34, 0.2, 0.2, 0.14).add(wh, 0.14, 0.12, -0.12, 0.1, 0.22, 0.3).add(wh, -0.14, 0.12, -0.12, 0.1, 0.22, 0.3);
        r.add(wh, 0.08, 0.08, 0.28, 0.07, 0.16, 0.07).add(wh, -0.08, 0.08, 0.28, 0.07, 0.16, 0.07);
        return r;
    }

    static Rig deerModel(ServerWorld w, Vec3d pos, double yaw, int ttl) {
        Rig r = new Rig(w, pos, yaw, ttl).scale(1.35);
        String wh = "white_concrete", gr = "lime_concrete", gl = "lime_stained_glass";
        r.add(wh, 0, 1.3, -0.1, 0.6, 0.6, 1.0).add(wh, 0, 1.33, 0.55, 0.55, 0.55, 0.5).add(gr, 0, 1.64, -0.1, 0.28, 0.05, 1.3);
        r.add(gl, 0, 1.3, 0.0, 0.7, 0.7, 1.7);
        for (int i = 0; i < 5; i++) r.add(gr, (i % 2 == 0 ? 0.2 : -0.2), 1.35 + (i % 3) * 0.08, -0.5 + i * 0.28, 0.12, 0.12, 0.12);
        // co dai + dau thanh
        r.rot(wh, 0, 1.85, 0.8, 0.26, 0.75, 0.28, 1, 0, 0, -0.35).add(wh, 0, 2.38, 1.0, 0.32, 0.32, 0.4).add(wh, 0, 2.3, 1.32, 0.18, 0.18, 0.3);
        r.add("black_concrete", 0, 2.32, 1.48, 0.1, 0.09, 0.06).add("black_concrete", 0.12, 2.44, 1.18, 0.07, 0.07, 0.04).add("black_concrete", -0.12, 2.44, 1.18, 0.07, 0.07, 0.04);
        r.rot(wh, 0.2, 2.55, 0.85, 0.1, 0.22, 0.08, 0, 0, 1, -0.7).rot(wh, -0.2, 2.55, 0.85, 0.1, 0.22, 0.08, 0, 0, 1, 0.7);
        // gac 3 nhanh moi ben
        for (int s = -1; s <= 1; s += 2) {
            r.rot("bone_block", 0.12 * s, 2.82, 0.9, 0.07, 0.6, 0.07, 0, 0, 1, -0.25 * s);
            r.rot("bone_block", 0.34 * s, 3.2, 0.9, 0.07, 0.55, 0.07, 0, 0, 1, -0.5 * s);
            r.rot("bone_block", 0.3 * s, 3.05, 1.12, 0.06, 0.06, 0.4, 1, 0, 0, 0.3);
            r.rot("bone_block", 0.52 * s, 3.55, 0.9, 0.06, 0.4, 0.06, 0, 0, 1, -0.2 * s);
            r.rot("bone_block", 0.55 * s, 3.4, 0.7, 0.06, 0.06, 0.35, 1, 0, 0, -0.3);
            r.add("lime_stained_glass", 0.62 * s, 3.8, 0.9, 0.1, 0.1, 0.1);
        }
        r.swing(wh, 0, 1.45, -0.68, 0.14, 0.2, 0.2, 0, 1.55, -0.6, 1, 0, 0, 0.4, 0.3, 0);
        leg(r, wh, "black_concrete", 0.2, 0.5, 1.0, 0.55, 0.55, 0.13, 0.4, 0.3, 0);
        leg(r, wh, "black_concrete", -0.2, 0.5, 1.0, 0.55, 0.55, 0.13, 0.4, 0.3, Math.PI);
        leg(r, wh, "black_concrete", 0.2, -0.55, 1.0, 0.55, 0.55, 0.14, 0.4, 0.3, Math.PI);
        leg(r, wh, "black_concrete", -0.2, -0.55, 1.0, 0.55, 0.55, 0.14, 0.4, 0.3, 0);
        return r;
    }

    static Rig oxModel(ServerWorld w, Vec3d pos, double yaw, int ttl) {
        Rig r = new Rig(w, pos, yaw, ttl).scale(1.4);
        String bk = "black_concrete", gy = "gray_concrete";
        r.add(bk, 0, 1.2, -0.3, 1.0, 0.95, 1.1).add(bk, 0, 1.4, 0.55, 1.15, 1.2, 0.8).add(gy, 0, 2.05, 0.55, 0.9, 0.35, 0.65).add(bk, 0, 0.82, 0.0, 0.8, 0.3, 1.8);
        r.add("red_concrete", 0, 1.98, 0.1, 0.18, 0.03, 1.5);
        // dau, trau
        r.add(bk, 0, 1.4, 1.35, 0.8, 0.8, 0.75).add(gy, 0, 1.2, 1.78, 0.55, 0.4, 0.4).add("red_concrete", 0, 1.1, 2.0, 0.34, 0.2, 0.06);
        r.add("yellow_concrete", 0, 1.0, 2.0, 0.1, 0.1, 0.05);
        r.add("red_concrete", 0.24, 1.55, 1.74, 0.14, 0.1, 0.05).add("red_concrete", -0.24, 1.55, 1.74, 0.14, 0.1, 0.05);
        r.add(bk, 0.5, 1.58, 1.3, 0.2, 0.12, 0.3).add(bk, -0.5, 1.58, 1.3, 0.2, 0.12, 0.3);
        // sung cong 2 doan huong ra truoc
        for (int s = -1; s <= 1; s += 2) {
            r.rot("bone_block", 0.55 * s, 1.85, 1.28, 0.14, 0.14, 0.55, 0, 1, 0, -0.5 * s);
            r.rot("bone_block", 0.9 * s, 1.95, 1.65, 0.12, 0.12, 0.6, 0, 1, 0, 0.15 * s);
            r.add("white_concrete", 1.0 * s, 1.95, 2.05, 0.08, 0.08, 0.3);
        }
        r.swing(bk, 0, 1.0, -1.0, 0.14, 0.9, 0.14, 0, 1.45, -0.85, 1, 0, 0, 0.4, 0.5, 0);
        int t = r.idx();
        r.add(gy, 0, 0.5, -1.0, 0.22, 0.3, 0.22);
        r.under(t);
        leg(r, bk, "gray_concrete", 0.35, 0.7, 0.95, 0.5, 0.45, 0.28, 0.8, 1.1, 0);
        leg(r, bk, "gray_concrete", -0.35, 0.7, 0.95, 0.5, 0.45, 0.28, 0.8, 1.1, Math.PI);
        leg(r, bk, "gray_concrete", 0.32, -0.75, 0.95, 0.5, 0.45, 0.28, 0.8, 1.1, Math.PI);
        leg(r, bk, "gray_concrete", -0.32, -0.75, 0.95, 0.5, 0.45, 0.28, 0.8, 1.1, 0);
        return r;
    }

    static Rig tigerModel(ServerWorld w, Vec3d pos, double yaw, int ttl) {
        Rig r = new Rig(w, pos, yaw, ttl).scale(1.45);
        String og = "orange_concrete", bk = "black_concrete", wh = "white_concrete";
        r.add(og, 0, 1.15, -0.45, 0.85, 0.78, 0.9).add(og, 0, 1.2, 0.35, 0.95, 0.9, 0.7).add(wh, 0, 0.78, -0.1, 0.7, 0.2, 1.4);
        for (int i = 0; i < 6; i++) { r.add(bk, 0, 1.2 + (i % 2) * 0.02, -0.85 + i * 0.3, 0.9, 0.82, 0.1); }
        for (int i = 0; i < 4; i++) { r.add(bk, 0.46, 1.1, -0.6 + i * 0.35, 0.05, 0.4, 0.1); r.add(bk, -0.46, 1.1, -0.6 + i * 0.35, 0.05, 0.4, 0.1); }
        // dau
        r.add(og, 0, 1.4, 1.0, 0.85, 0.72, 0.62).add(wh, 0, 1.2, 1.35, 0.5, 0.3, 0.3).add(bk, 0, 1.38, 1.5, 0.16, 0.1, 0.05);
        r.add(wh, 0.45, 1.28, 0.95, 0.12, 0.24, 0.3).add(wh, -0.45, 1.28, 0.95, 0.12, 0.24, 0.3);
        r.add("yellow_concrete", 0.2, 1.52, 1.32, 0.13, 0.1, 0.05).add("yellow_concrete", -0.2, 1.52, 1.32, 0.13, 0.1, 0.05).add(bk, 0.2, 1.52, 1.34, 0.04, 0.09, 0.03).add(bk, -0.2, 1.52, 1.34, 0.04, 0.09, 0.03);
        r.add(bk, 0, 1.68, 1.1, 0.4, 0.04, 0.1).add(bk, 0.15, 1.6, 1.28, 0.1, 0.18, 0.04).add(bk, -0.15, 1.6, 1.28, 0.1, 0.18, 0.04);
        r.add("white_concrete", 0.1, 1.05, 1.42, 0.04, 0.12, 0.04).add("white_concrete", -0.1, 1.05, 1.42, 0.04, 0.12, 0.04);
        r.add(og, 0.34, 1.88, 0.88, 0.2, 0.2, 0.1).add(og, -0.34, 1.88, 0.88, 0.2, 0.2, 0.1).add(bk, 0.34, 1.9, 0.83, 0.12, 0.12, 0.04).add(bk, -0.34, 1.9, 0.83, 0.12, 0.12, 0.04);
        // duoi 4 doan vo van
        r.swing(og, 0, 1.3, -1.15, 0.2, 0.2, 0.5, 0, 1.2, -0.9, 0, 1, 0, 0.4, 0.4, 0);
        int a = r.idx();
        r.swing(bk, 0, 1.4, -1.55, 0.18, 0.18, 0.4, 0, 1.3, -1.35, 0, 1, 0, 0.3, 0.4, 0.5);
        r.under(a);
        int b = r.idx();
        r.swing(og, 0, 1.55, -1.9, 0.16, 0.16, 0.4, 0, 1.45, -1.7, 1, 0, 0, -0.35, 0.4, 0.9);
        r.under(b);
        int c = r.idx();
        r.add(bk, 0, 1.75, -2.2, 0.15, 0.15, 0.3);
        r.under(c);
        leg(r, og, bk, 0.32, 0.7, 0.95, 0.5, 0.45, 0.28, 0.9, 1.0, 0);
        leg(r, og, bk, -0.32, 0.7, 0.95, 0.5, 0.45, 0.28, 0.9, 1.0, Math.PI);
        leg(r, og, bk, 0.3, -0.75, 0.95, 0.5, 0.45, 0.28, 0.9, 1.0, Math.PI);
        leg(r, og, bk, -0.3, -0.75, 0.95, 0.5, 0.45, 0.28, 0.9, 1.0, 0);
        return r;
    }

    static Rig mahoragaModel(ServerWorld w, Vec3d pos, double yaw, int ttl) {
        Rig r = new Rig(w, pos, yaw, ttl);
        String wh = "white_concrete", gl = "light_gray_concrete", gy = "gray_concrete", bk = "black_concrete", gd = "gold_block";
        // chan tran trang, vong den o mat ca; hakama den + day lung xam
        for (int sg = -1; sg <= 1; sg += 2) {
            double x = 0.5 * sg;
            r.swing(wh, x, 2.0, 0.0, 0.6, 1.3, 0.62, x, 3.0, 0, 1, 0, 0, 0.3, 0.18, sg > 0 ? 0 : 3.14);
            int h = r.idx();
            r.swing(wh, x, 0.85, 0.05, 0.5, 1.2, 0.5, x, 1.5, 0, 1, 0, 0, -0.25, 0.18, sg > 0 ? 0.9 : 4.0);
            r.under(h);
            int k = r.idx();
            r.add(bk, x, 0.5, 0.05, 0.62, 0.14, 0.62); r.under(k);                 // vong co chan
            r.add(wh, x, 0.07, 0.3, 0.52, 0.14, 0.9); r.under(k);                   // ban chan tran
            for (int t = 0; t < 4; t++) { r.add(gl, x - 0.18 + t * 0.12, 0.05, 0.78, 0.09, 0.08, 0.14); r.under(k); }
        }
        r.add(bk, 0, 2.2, 0, 1.7, 1.6, 1.0);                                        // hakama
        r.add(bk, 0, 1.5, 0.0, 1.5, 0.3, 0.85);
        r.add(gy, 0, 3.05, 0.02, 1.8, 0.4, 1.05);                                   // day lung xam
        r.add(gy, -0.75, 2.2, 0.55, 0.65, 1.3, 0.08);                               // vat vai xam rong ben trai
        r.add(bk, 0.25, 1.9, 0.54, 0.6, 1.8, 0.08);                                 // vat den truoc
        // than tren co bap: bung 6 mui, nguc, vai
        r.add(wh, 0, 3.85, 0, 1.25, 1.05, 0.8);
        for (int i = 0; i < 3; i++) { r.add(gl, -0.3, 3.5 + i * 0.3, 0.41, 0.5, 0.04, 0.04); r.add(gl, 0.3, 3.5 + i * 0.3, 0.41, 0.5, 0.04, 0.04); }
        r.add(gl, 0, 3.85, 0.41, 0.04, 0.9, 0.04);
        r.add(wh, 0, 4.9, 0.0, 2.0, 1.2, 1.0);
        r.add(wh, -0.5, 4.95, 0.35, 0.95, 0.8, 0.45); r.add(wh, 0.5, 4.95, 0.35, 0.95, 0.8, 0.45);
        r.add(gl, 0, 4.7, 0.6, 0.9, 0.05, 0.04);
        r.add(wh, 0, 5.75, 0, 0.6, 0.35, 0.55);
        // day thung den hinh chu V tren nguc
        for (int i = 0; i < 6; i++) r.add(bk, (i - 2.5) * 0.17, 5.0 + Math.abs(i - 2.5) * 0.14, 0.55, 0.1, 0.1, 0.08);
        r.add(bk, 0, 4.8, 0.55, 0.06, 0.4, 0.06);
        // dau nhon: cang, hom ham, rau gai cheo sau
        r.add(wh, 0, 6.3, 0.05, 0.85, 0.85, 0.9); r.add(wh, 0, 6.05, 0.5, 0.6, 0.45, 0.6);
        r.add(bk, 0, 5.95, 0.82, 0.38, 0.06, 0.04); r.add("red_concrete", 0.22, 6.4, 0.5, 0.12, 0.07, 0.05); r.add("red_concrete", -0.22, 6.4, 0.5, 0.12, 0.07, 0.05);
        r.add(gl, 0, 6.65, 0.45, 0.7, 0.06, 0.06);
        for (int i = 0; i < 5; i++) {                                              // gai/cuc canh phia sau + hai ben
            double an = -0.9 + i * 0.45;
            r.rotp(wh, 0.4 * Math.sin(an) , 6.65 + (i % 2) * 0.12, -0.55 - 0.15 * Math.cos(an), 0.2, 0.28, 1.1, 0.0, 6.5, 0.0, 0, 1, 0, an);
        }
        for (int sg = -1; sg <= 1; sg += 2) {
            r.rotp(wh, 0.85 * sg, 6.45, -0.1, 0.12, 0.2, 1.0, 0.0, 6.4, 0.0, 0, 1, 0, 0.9 * sg);
            r.rotp(wh, 0.55 * sg, 6.75, 0.0, 0.1, 0.5, 0.2, 0.55 * sg, 6.5, 0.0, 0, 0, 1, -0.35 * sg);
        }
        // duoi cong len sau lung (chuoi 7 doan)
        for (int i = 0; i < 7; i++) {
            double t = i / 6.0, yy = 2.6 + Math.sin(t * 2.2) * 1.4 - t * 0.2, zz = -0.6 - t * 1.4 + Math.sin(t * 3.0) * 0.3;
            r.swing(wh, 0, yy, zz, 0.3 - t * 0.14, 0.3 - t * 0.14, 0.7, 0, 2.6, -0.5, 1, 0, 0, 0.04 + t * 0.1, 0.16, i * 0.4);
        }
        // hai canh tay: trai (x-) thong xuong nam dam co vong den, phai (x+) quan bang xam, cam kiem den ngan
        for (int sg = -1; sg <= 1; sg += 2) {
            double sx = 1.35 * sg;
            r.add(wh, sx, 5.3, 0.0, 0.8, 0.8, 0.8);                                // vai
            r.swing(wh, sx + 0.1 * sg, 4.35, 0.05, 0.62, 1.3, 0.62, sx, 5.1, 0, 1, 0, 0, 0.35, 0.16, sg > 0 ? 0 : 3.14);
            int u = r.idx();
            r.swing(wh, sx + 0.1 * sg, 3.2, 0.3, 0.52, 1.2, 0.52, sx + 0.1 * sg, 3.8, 0.05, 1, 0, 0, -0.55, 0.16, sg > 0 ? 0 : 3.14);
            r.under(u);
            int f = r.idx();
            String wc = (sg > 0 ? gy : wh);
            double bl = (sg > 0 ? 1.9 : 0.02);
            for (int t = 0; t < 4; t++) { r.add(wc, sx + 0.1 * sg, 3.0 + t * 0.2, 0.3, 0.62, 0.12, 0.62); r.under(f); }
            r.add(bk, sx + 0.1 * sg, 2.5, 0.35, 0.58, 0.12, 0.58); r.under(f);
            r.add(wh, sx + 0.1 * sg, 2.35, 0.4, 0.5, 0.45, 0.5); r.under(f);
            r.add(bk, sx + 0.1 * sg, 2.1, 0.4, 0.14, bl, 0.14); r.under(f);
        }
        // QUANG BAN NGANG vang tren dau: thanh + 5 hat, xoay cham quanh dau
        double hy = 7.6;
        r.spin(gd, 0, hy, 0, 2.6, 0.1, 0.1, 0, hy, 0, 0, 1, 0, 0.05, 0);
        for (int i = -2; i <= 2; i++) r.spin(gd, i * 0.55, hy, 0, 0.3, 0.3, 0.3, 0, hy, 0, 0, 1, 0, 0.05, 0);
        return r;
    }

    // ================= 1. Divine Dogs =================
    static void dogs(ServerWorld w, ServerPlayerEntity p) {
        Vec3d dir = dirOf(p), rt = rightOf(dir);
        Vec3d base = p.getEntityPos();
        Vec3d s1 = base.add(rt.multiply(1.5)), s2 = base.subtract(rt.multiply(1.5));
        int total = 140;
        Rig a = dogModel(w, s1, Rig.yawOf(dir), "white_concrete", "black_concrete", total + 20);
        Rig b = dogModel(w, s2, Rig.yawOf(dir), "black_concrete", "white_concrete", total + 20);
        summonFx(w, s1, 0x202030); summonFx(w, s2, 0x202030);
        Fx.snd(w, base, SoundEvents.ENTITY_RAVAGER_ROAR, 0.8f, 1.6f);
        Anims.add(new Anims.Anim() {
            int t = 0; Vec3d pa = s1, pb = s2; double ya = Rig.yawOf(dir), yb = ya;
            public boolean tick() {
                t++;
                if (p.isRemoved() || !p.isAlive() || t > total) { a.kill(); b.kill(); return true; }
                Vec3d here = p.getEntityPos();
                for (int i = 0; i < 2; i++) {
                    Vec3d cur = i == 0 ? pa : pb;
                    LivingEntity tg = nearest(w, p, cur, 18);
                    Vec3d goal = tg != null ? tg.getEntityPos() : here.add(rt.multiply(i == 0 ? 2 : -2)).subtract(dir.multiply(1.5));
                    Vec3d to = flat(goal.subtract(cur));
                    double dist = to.length();
                    Vec3d nx = cur;
                    if (dist > (tg != null ? 1.6 : 1.0)) { Vec3d st = to.normalize().multiply(Math.min(dist, tg != null ? 0.65 : 0.4)); nx = cur.add(st); nx = new Vec3d(nx.x, here.y, nx.z); }
                    double yw = dist > 0.05 ? Rig.yawOf(to) : (i == 0 ? ya : yb);
                    if (tg != null && dist <= 2.2 && t % 10 == (i == 0 ? 0 : 5)) {
                        Fx.hurt(w, p, tg, 5f);
                        Fx.put(w, Fx.dust(i == 0 ? 0xFFFFFF : 0x101018, 1.4f), Fx.mid(tg), 10, 0.4, 0.1);
                        Fx.put(w, ParticleTypes.CRIT, Fx.mid(tg), 6, 0.4, 0.2);
                        Fx.snd(w, Fx.mid(tg), SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, 0.8f, 0.7f);
                    }
                    if (i == 0) { pa = nx; ya = yw; } else { pb = nx; yb = yw; }
                }
                if (t % 2 == 0) { a.place(pa, ya, t); b.place(pb, yb, t); }
                return false;
            }
        });
    }

    // ================= 2. Nue =================
    static void nue(ServerWorld w, ServerPlayerEntity p) {
        Vec3d c0 = p.getEntityPos();
        LivingEntity aimT = Stage2Skills.aim(w, p, 22);
        Vec3d tgt = aimT != null ? aimT.getEntityPos() : Stage2Skills.rayEnd(w, p, 14);
        Rig r = nueModel(w, c0.add(0, 4, 0), Rig.yawOf(dirOf(p)), 90);
        summonFx(w, c0, 0x202040);
        Fx.snd(w, c0, SoundEvents.ENTITY_PHANTOM_SWOOP, 1.2f, 0.6f);
        Anims.add(new Anims.Anim() {
            int t = 0; Vec3d pos = c0.add(0, 4, 0); double yaw = Rig.yawOf(dirOf(p)); Vec3d diveFrom;
            public boolean tick() {
                t++;
                if (t > 60) { r.kill(); return true; }
                Vec3d old = pos;
                if (t <= 20) {
                    double a = t * 0.3;
                    pos = c0.add(Math.cos(a) * 4, 4.5 + Math.sin(t * 0.4) * 0.4, Math.sin(a) * 4);
                } else if (t <= 32) {
                    if (diveFrom == null) diveFrom = pos;
                    double k = (t - 20) / 12.0;
                    pos = diveFrom.add(tgt.add(0, 1, 0).subtract(diveFrom).multiply(k * k));
                } else if (t <= 52) {
                    pos = pos.add(0, 0.5, 0).add(flat(tgt.subtract(c0)).normalize().multiply(0.3));
                }
                Vec3d mv = flat(pos.subtract(old));
                if (mv.lengthSquared() > 1.0E-4) yaw = Rig.yawOf(mv);
                if (t % 2 == 0) r.place(pos, yaw, t);
                if (t % 3 == 0) Fx.put(w, ParticleTypes.ELECTRIC_SPARK, pos.add(0, 2.4, 0), 6, 0.8, 0.1);
                if (t == 32) {
                    Vec3d hit = tgt.add(0, 0.5, 0);
                    Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
                    Fx.ring(w, Fx.dust(0x80E0FF, 1.8f), hit, b[1], b[2], 4.5, 70, 0);
                    for (int i = 0; i < 5; i++) Vis3D.bolt(w, hit.add(Fx.rnd(-2, 2), 9, Fx.rnd(-2, 2)), hit.add(Fx.rnd(-1.5, 1.5), 0, Fx.rnd(-1.5, 1.5)), 0.18, 8);
                    Fx.snd(w, hit, SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 1.5f, 1.4f);
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(hit, hit).expand(5, 3, 5))) {
                        if (e.getEntityPos().distanceTo(hit) > 5.2) continue;
                        Fx.hurt(w, p, e, 18f);
                        e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 3));
                    }
                }
                return false;
            }
        });
    }

    // ================= 3. Great Serpent =================
    static void serpent(ServerWorld w, ServerPlayerEntity p) {
        Vec3d eye = p.getEyePos().add(0, -0.6, 0), look = p.getRotationVec(1f);
        Vec3d dir = look.normalize(), side = rightOf(flat(dir).lengthSquared() < 1e-4 ? new Vec3d(0, 0, 1) : flat(dir).normalize());
        final int N = 14, TOTAL = 56;
        final List<Vec3d> hist = new ArrayList<>();
        final List<Disp.H> seg = new ArrayList<>();
        if (Config.displays) for (int i = 0; i < N; i++) {
            double th = 0.9 * (1 - i / (double) N) + 0.25;
            String blk = i == 0 ? "black_concrete" : (i % 2 == 0 ? "light_gray_concrete" : "gray_concrete");
            seg.add(Disp.block(w, eye, blk, 1.0, th, th, Disp.Q.ID, TOTAL + 20));
        }
        Fx.snd(w, eye, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 0.4f);
        final Set<LivingEntity> hit = new HashSet<>();
        Anims.add(new Anims.Anim() {
            int t = 0; Vec3d head = eye;
            public boolean tick() {
                t++;
                if (t > TOTAL) { for (Disp.H h : seg) h.kill(); return true; }
                if (t <= 18) head = eye.add(dir.multiply(t * 1.3)).add(side.multiply(Math.sin(t * 0.7) * 2.0)).add(0, Math.sin(t * 0.35) * 0.5, 0);
                hist.add(0, head);
                if (hist.size() > 80) hist.remove(hist.size() - 1);
                if (t % 2 == 0) for (int i = 0; i < seg.size(); i++) {
                    int ia = Math.min(hist.size() - 1, i * 2), ib = Math.min(hist.size() - 1, i * 2 + 2);
                    Vec3d a = hist.get(ia), b = hist.get(ib);
                    Vec3d d = a.subtract(b);
                    double len = Math.max(0.35, d.length() + 0.5);
                    if (d.lengthSquared() < 1.0E-5) d = dir;
                    Disp.Q q = Disp.Q.fromTo(new Vec3d(1, 0, 0), d.normalize());
                    double th = (i == 0 ? 0.9 : 0.8 * (1 - i / (double) N) + 0.25);
                    seg.get(i).move(a.add(b).multiply(0.5));
                    seg.get(i).set(q, len, th, th, 2);
                }
                if (t <= 20) {
                    Fx.put(w, Fx.dust(0x303040, 1.2f), head, 2, 0.3, 0.02);
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(head, head).expand(2.0))) {
                        if (!hit.add(e)) continue;
                        Fx.hurt(w, p, e, 14f);
                        e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 2));
                        Fx.put(w, ParticleTypes.CRIT, Fx.mid(e), 10, 0.4, 0.2);
                    }
                }
                return false;
            }
        });
    }

    // ================= 4. Toad =================
    static void toad(ServerWorld w, ServerPlayerEntity p) {
        LivingEntity t = Stage2Skills.aim(w, p, 16);
        Vec3d dir = dirOf(p), pos = p.getEntityPos().add(rightOf(dir).multiply(1.8));
        Vec3d to = t != null ? flat(t.getEntityPos().subtract(pos)) : dir;
        Rig r = toadModel(w, pos, Rig.yawOf(to.lengthSquared() < 1e-4 ? dir : to.normalize()), 70);
        summonFx(w, pos, 0x20A020);
        Fx.snd(w, pos, SoundEvents.ENTITY_FROG_AMBIENT, 1.4f, 0.5f);
        Anims.add(new Anims.Anim() {
            int n = 0; Disp.Beam tongue;
            public boolean tick() {
                n++;
                if (n > 40 || (t != null && !t.isAlive() && n > 12)) { if (tongue != null) tongue.kill(); r.kill(); return true; }
                Vec3d mouth = pos.add(0, 1.0, 0).add(flat(to).lengthSquared() > 1e-4 ? flat(to).normalize().multiply(1.1) : Vec3d.ZERO);
                if (n == 1) r.place(pos, r.yaw, 0);
                if (t != null && n >= 6 && n <= 20) {
                    Vec3d tm = Fx.mid(t);
                    if (n == 6) { tongue = Config.displays ? new Disp.Beam(w, mouth, tm, "pink_concrete", "red_concrete", 0.22, 40) : null; Fx.snd(w, mouth, SoundEvents.ENTITY_FROG_TONGUE, 1.4f, 0.8f); }
                    if (tongue != null) tongue.update(mouth, tm, 0.22);
                    Vec3d pull = mouth.subtract(tm);
                    if (n <= 14 && pull.length() > 1.5) { Vec3d v = pull.normalize().multiply(0.55); t.addVelocity(v.x, 0.05, v.z); }
                    if (n == 8) { Fx.hurt(w, p, t, 4f); t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 2)); }
                    Fx.line(w, Fx.dust(0xFF70A0, 1.0f), mouth, tm, 0.5);
                } else if (tongue != null && n > 20) { tongue.kill(); tongue = null; }
                return false;
            }
        });
    }

    // ================= 5. Max Elephant =================
    static void elephant(ServerWorld w, ServerPlayerEntity p) {
        Vec3d dir = dirOf(p);
        Vec3d pos = p.getEntityPos().add(dir.multiply(3.5));
        double yaw = Rig.yawOf(dir);
        int total = 70;
        Rig r = elephantModel(w, pos, yaw, total + 10);
        summonFx(w, pos, 0x2090FF);
        Fx.snd(w, pos, SoundEvents.ENTITY_ELDER_GUARDIAN_AMBIENT, 1.3f, 0.5f);
        Anims.add(new Anims.Anim() {
            int t = 0;
            public boolean tick() {
                t++;
                if (t > total) { Fx.put(w, ParticleTypes.SPLASH, pos.add(0, 3, 0), 40, 1.5, 0.2); r.kill(); return true; }
                if (t % 2 == 0) r.place(pos, yaw, t);
                Vec3d tip = pos.add(dir.multiply(5.2)).add(0, 3.2, 0);
                if (t >= 15) {
                    for (int i = 0; i < 14; i++) {
                        double d = Fx.rnd(0, 11), spread = d * 0.22;
                        Vec3d pt = tip.add(dir.multiply(d)).add(Fx.rnd(-spread, spread), -d * 0.12 + Fx.rnd(-spread, spread) * 0.5, Fx.rnd(-spread, spread));
                        Fx.pt(w, Fx.dust(i % 2 == 0 ? 0x40A0FF : 0xB0E8FF, 1.4f), pt);
                        if (i % 4 == 0) Fx.pt(w, ParticleTypes.SPLASH, pt);
                    }
                    if (t % 5 == 0) for (LivingEntity e : Fx.hostiles(w, p, new Box(tip, tip.add(dir.multiply(11))).expand(3.2))) {
                        Vec3d rel = Fx.mid(e).subtract(tip);
                        double along = rel.dotProduct(dir);
                        if (along < 0 || along > 11 || rel.subtract(dir.multiply(along)).length() > 1.0 + along * 0.25) continue;
                        Fx.hurt(w, p, e, 3.5f);
                        e.addVelocity(dir.x * 0.6, 0.12, dir.z * 0.6);
                        e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 30, 1));
                    }
                    if (t % 12 == 0) Fx.snd(w, tip, SoundEvents.ENTITY_PLAYER_SPLASH, 1.0f, 0.7f);
                }
                return false;
            }
        });
    }

    // ================= 6. Rabbit Escape =================
    static void rabbits(ServerWorld w, ServerPlayerEntity p) {
        Vec3d c = p.getEntityPos();
        int total = 100, N = 8;
        List<Rig> rigs = new ArrayList<>();
        List<Vec3d> ps = new ArrayList<>(), vs = new ArrayList<>();
        for (int i = 0; i < N; i++) {
            double a = Fx.rnd(0, 6.28), r = Fx.rnd(1.5, 5);
            Vec3d pos = c.add(Math.cos(a) * r, 0, Math.sin(a) * r);
            rigs.add(rabbitModel(w, pos, Fx.rnd(0, 6.28), total + 10));
            ps.add(pos); vs.add(Vec3d.ZERO);
        }
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, 100, 0, true, false));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 100, 2, true, false));
        for (LivingEntity e : Fx.hostiles(w, p, p.getBoundingBox().expand(10))) e.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 80, 0));
        summonFx(w, c, 0xFFFFFF);
        Fx.snd(w, c, SoundEvents.ENTITY_RABBIT_AMBIENT, 1.5f, 1.4f);
        Anims.add(new Anims.Anim() {
            int t = 0;
            public boolean tick() {
                t++;
                if (t > total || p.isRemoved()) { for (Rig r : rigs) r.kill(); return true; }
                Vec3d here = p.getEntityPos();
                if (t % 2 == 0) for (int i = 0; i < rigs.size(); i++) {
                    if ((t + i * 3) % 20 == 0) {
                        double a = Fx.rnd(0, 6.28);
                        Vec3d toC = flat(here.subtract(ps.get(i)));
                        Vec3d d = new Vec3d(Math.cos(a), 0, Math.sin(a));
                        if (toC.length() > 7) d = toC.normalize();
                        vs.set(i, d.multiply(0.22));
                    }
                    double hop = Math.abs(Math.sin((t + i * 3) * 0.16)) * 0.6;
                    Vec3d np = ps.get(i).add(vs.get(i));
                    ps.set(i, np);
                    Vec3d v = vs.get(i);
                    rigs.get(i).place(new Vec3d(np.x, here.y + hop, np.z), v.lengthSquared() > 1e-4 ? Rig.yawOf(v) : rigs.get(i).yaw, t);
                }
                return false;
            }
        });
    }

    // ================= 7. Round Deer =================
    static void deer(ServerWorld w, ServerPlayerEntity p) {
        Vec3d dir = dirOf(p);
        Vec3d pos = p.getEntityPos().add(rightOf(dir).multiply(-2.2)).add(dir.multiply(0.5));
        double yaw = Rig.yawOf(rightOf(dir));
        int total = 80;
        Rig r = deerModel(w, pos, yaw, total + 10);
        summonFx(w, pos, 0x60FF90);
        p.heal(8f);
        Fx.snd(w, pos, SoundEvents.ENTITY_PLAYER_LEVELUP, 1.0f, 1.6f);
        Anims.add(new Anims.Anim() {
            int t = 0;
            public boolean tick() {
                t++;
                if (t > total) { r.kill(); return true; }
                if (t % 2 == 0) r.place(pos, yaw, t);
                Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
                if (t % 3 == 0) Fx.ring(w, Fx.dust(0x60FF90, 1.2f), pos.add(0, 0.1 + (t % 30) * 0.12, 0), b[1], b[2], 2.5, 40, t);
                if (t % 10 == 0) {
                    for (ServerPlayerEntity o : w.getPlayers()) {
                        if (o.getEntityPos().distanceTo(pos) > 9) continue;
                        o.heal(2f);
                        o.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 60, 1));
                        Fx.put(w, ParticleTypes.HAPPY_VILLAGER, o.getEntityPos().add(0, 1, 0), 6, 0.5, 0);
                    }
                }
                return false;
            }
        });
    }

    // ================= 8. Piercing Ox =================
    static void ox(ServerWorld w, ServerPlayerEntity p) {
        Vec3d dir = dirOf(p);
        Vec3d start = p.getEntityPos().add(dir.multiply(1.2));
        double yaw = Rig.yawOf(dir);
        Rig r = oxModel(w, start, yaw, 50);
        summonFx(w, start, 0x401010);
        Fx.snd(w, start, SoundEvents.ENTITY_RAVAGER_ROAR, 1.2f, 0.9f);
        Set<LivingEntity> hit = new HashSet<>();
        Anims.add(new Anims.Anim() {
            int t = 0; Vec3d pos = start; boolean stopped = false; int stopT = 0;
            public boolean tick() {
                t++;
                if (!stopped) {
                    Vec3d nx = pos.add(dir.multiply(1.1));
                    if (!w.isAir(BlockPos.ofFloored(nx.add(0, 1, 0))) || t > 18) stopped = true; else pos = nx;
                } else if (++stopT > 6) { r.kill(); return true; }
                if (t % 2 == 0) r.place(pos, yaw, stopped ? 0 : t);
                if (!stopped) {
                    Fx.put(w, Fx.dust(0x601818, 1.4f), pos.add(0, 0.3, 0), 3, 0.5, 0.02);
                    Fx.put(w, ParticleTypes.CAMPFIRE_COSY_SMOKE, pos.add(0, 0.2, 0), 1, 0.2, 0.01);
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(pos, pos).expand(2.4, 2, 2.4))) {
                        if (!hit.add(e)) continue;
                        Fx.hurt(w, p, e, 20f);
                        e.addVelocity(dir.x * 1.3, 0.35, dir.z * 1.3);
                        Fx.put(w, ParticleTypes.EXPLOSION, Fx.mid(e), 1, 0, 0);
                        Fx.snd(w, Fx.mid(e), SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, 1.2f, 0.7f);
                    }
                }
                return false;
            }
        });
    }

    // ================= 9. Tiger Funeral =================
    static void tiger(ServerWorld w, ServerPlayerEntity p) {
        Vec3d dir = dirOf(p);
        Vec3d start = p.getEntityPos().add(rightOf(dir).multiply(2.5));
        LivingEntity t0 = nearest(w, p, p.getEntityPos(), 18);
        Vec3d end = t0 != null ? t0.getEntityPos() : p.getEntityPos().add(dir.multiply(9));
        Vec3d toE = flat(end.subtract(start));
        double yaw = Rig.yawOf(toE.lengthSquared() < 1e-4 ? dir : toE.normalize());
        Rig r = tigerModel(w, start, yaw, 60);
        summonFx(w, start, 0xFF8000);
        Fx.snd(w, start, SoundEvents.ENTITY_RAVAGER_ROAR, 1.4f, 1.3f);
        Anims.add(new Anims.Anim() {
            int t = 0; Vec3d pos = start; boolean landed = false;
            public boolean tick() {
                t++;
                if (t > 38) { r.kill(); return true; }
                if (t >= 8 && t <= 20) {
                    double k = (t - 8) / 12.0;
                    pos = start.add(end.subtract(start).multiply(k)).add(0, Math.sin(k * Math.PI) * 3.0, 0);
                    Fx.put(w, Fx.dust(0xFF9020, 1.4f), pos.add(0, 1, 0), 3, 0.4, 0.02);
                }
                if (t % 2 == 0) r.place(pos, yaw, t);
                if (t == 20 && !landed) {
                    landed = true;
                    Vec3d hit = end.add(0, 1, 0);
                    Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
                    for (int i = 1; i <= 3; i++) Fx.ring(w, Fx.dust(0xFF8000, 1.7f), end.add(0, 0.2, 0), b[1], b[2], i * 1.3, 40, 0);
                    Fx.snd(w, end, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 1.2f, 1.1f);
                    Vec3d look = toE.lengthSquared() < 1e-4 ? dir : toE.normalize();
                    Vec3d[] bb = Fx.basis(look);
                    if (Config.displays) for (int i = 0; i < 3; i++) {
                        double tilt = -0.5 + i * 0.5;
                        Vec3d u = bb[1].multiply(Math.cos(tilt)).add(bb[2].multiply(Math.sin(tilt))).normalize();
                        new Disp.Crescent(w, hit.add(look.multiply(-0.5)), u, look, 2.6, 0.4, 0.5, "white_concrete", 8, 8);
                        new Disp.Crescent(w, hit.add(look.multiply(-0.5)), u, look, 2.8, 0.45, 0.9, "orange_stained_glass", 8, 10);
                    }
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(end, end).expand(3, 2, 3))) {
                        if (e.getEntityPos().distanceTo(end) > 3.2) continue;
                        Fx.hurt(w, p, e, 30f);
                        e.setFireTicks(60);
                    }
                }
                return false;
            }
        });
    }

    // ================= 10. Mahoraga =================
    static void mahoraga(ServerWorld w, ServerPlayerEntity p) {
        Vec3d dir = dirOf(p);
        Vec3d start = p.getEntityPos().subtract(dir.multiply(4));
        int total = 300;
        Rig r = mahoragaModel(w, start, Rig.yawOf(dir), total + 20);
        summonFx(w, start, 0xFFE070);
        Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
        for (int i = 0; i < 4; i++) Fx.ring(w, Fx.dust(0xFFE070, 1.8f), start.add(0, 0.1, 0), b[1], b[2], 1.5 + i * 1.1, 60, 0);
        Fx.snd(w, start, SoundEvents.ENTITY_WARDEN_ROAR, 1.5f, 0.7f);
        Fx.snd(w, start, SoundEvents.BLOCK_BELL_USE, 2.0f, 0.5f);
        Anims.add(new Anims.Anim() {
            int t = 0; Vec3d pos = start; double yaw = Rig.yawOf(dir);
            public boolean tick() {
                t++;
                if (p.isRemoved() || !p.isAlive() || t > total) {
                    Fx.sphere(w, Fx.dust(0xFFE070, 1.6f), pos.add(0, 3, 0), 2.5, 80, 0);
                    r.kill();
                    return true;
                }
                Vec3d here = p.getEntityPos();
                LivingEntity tg = nearest(w, p, pos, 16);
                Vec3d goal = tg != null ? tg.getEntityPos() : here.subtract(rightOf(dirOf(p)).multiply(3)).subtract(dirOf(p).multiply(3));
                Vec3d to = flat(goal.subtract(pos));
                double dist = to.length();
                if (dist > (tg != null ? 3.6 : 1.2)) { pos = pos.add(to.normalize().multiply(Math.min(dist, tg != null ? 0.4 : 0.3))); }
                pos = new Vec3d(pos.x, here.y, pos.z);
                if (dist > 0.05) yaw = Rig.yawOf(to);
                if (t % 2 == 0) r.place(pos, yaw, t);
                if (tg != null && dist <= 5.5 && t % 20 == 0) {
                    Vec3d look = flat(tg.getEntityPos().subtract(pos)).normalize();
                    Vec3d hit = pos.add(look.multiply(3)).add(0, 2.5, 0);
                    Vec3d[] bb = Fx.basis(look);
                    if (Config.displays) {
                        new Disp.Crescent(w, hit, bb[1].multiply(Math.cos(0.4)).add(bb[2].multiply(Math.sin(0.4))).normalize(), look, 4.0, 0.6, 1.0, "white_concrete", 10, 8);
                        new Disp.Crescent(w, hit, bb[1].multiply(Math.cos(0.4)).add(bb[2].multiply(Math.sin(0.4))).normalize(), look, 4.4, 0.7, 1.4, "yellow_stained_glass", 10, 10);
                    }
                    Fx.snd(w, hit, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.5f, 0.5f);
                    Fx.snd(w, hit, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 0.8f, 0.8f);
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(pos, pos).expand(5, 3, 5))) {
                        if (e.getEntityPos().distanceTo(pos) > 5.5) continue;
                        Fx.hurt(w, p, e, 18f);
                        Vec3d kb = flat(e.getEntityPos().subtract(pos)).normalize();
                        e.addVelocity(kb.x * 0.9, 0.3, kb.z * 0.9);
                    }
                }
                if (t % 4 == 0) Fx.put(w, Fx.dust(0xFFE070, 1.0f), pos.add(0, 5.2, -0.7), 2, 0.6, 0.02);
                return false;
            }
        });
    }

    // ================= RIKA (Yuta) =================
    static Rig rikaModel(ServerWorld w, Vec3d pos, double yaw, int ttl) {
        Rig r = new Rig(w, pos, yaw, ttl).scale(1.45);
        String sk = "white_concrete", gl = "light_gray_concrete", gy = "gray_concrete", bk = "black_concrete", rd = "red_concrete";
        // duoi/ao choang den cong len nhu ran: 9 doan thu nho dan, doan cuoi cong len
        for (int i = 0; i < 9; i++) {
            double t = i / 8.0, yy = 2.3 - Math.sin(t * 2.3) * 1.5 + Math.max(0, t - 0.8) * 5, zz = -0.1 - t * 2.2;
            double wd = 1.5 - t * 1.25;
            r.swing(bk, 0, yy, zz, Math.max(0.18, wd), Math.max(0.2, wd * 0.8), 0.75, 0, 2.5, 0, 1, 0, 0, 0.05 + t * 0.12, 0.15, i * 0.5);
        }
        r.add(bk, 0, 2.4, 0.1, 1.5, 0.6, 1.0).add(bk, 0, 2.9, 0.25, 1.2, 0.5, 0.9);
        // cot song + suon (ngang, thanh mong) nghieng ve phia truoc
        for (int i = 0; i < 7; i++) {
            double y = 3.2 + i * 0.28, z = 0.2 + i * 0.1, wd = 0.8 + Math.sin(i * 0.45) * 0.5;
            r.add(gl, 0, y, z - 0.05, 0.1, 0.12, 0.12);
            r.add(sk, 0, y, z + 0.1, wd, 0.06, 0.3);
            r.add(gy, 0, y + 0.1, z + 0.3, wd * 0.8, 0.04, 0.05);
        }
        r.add(sk, 0, 4.2, 0.45, 0.14, 1.9, 0.12);
        // vai gu + co duoi
        r.add(sk, 0, 5.2, 0.7, 1.3, 0.25, 0.5);
        r.add(sk, 0, 5.4, 1.0, 0.3, 0.4, 0.3);
        // DAU DAI: nhieu dai xuong nhu so rong, chop sau; mieng ngoac to co rang va luoi do
        for (int i = 0; i < 6; i++) {
            double y = 5.55 + i * 0.2, z = 1.05 - i * 0.18;
            r.add(i % 2 == 0 ? sk : gl, 0, y, z, 0.95 - i * 0.05, 0.2, 0.9 - i * 0.04);
        }
        r.add(sk, 0, 5.85, 1.45, 0.8, 0.75, 0.5);                                   // mat
        r.add(rd, 0, 5.62, 1.63, 0.7, 0.28, 0.1);                                   // hong do
        for (int i = -3; i <= 3; i++) { r.add(sk, i * 0.1, 5.76, 1.69, 0.06, 0.12, 0.04); r.add(sk, i * 0.1, 5.5, 1.69, 0.06, 0.1, 0.04); }
        r.add(bk, 0.22, 6.0, 1.7, 0.2, 0.18, 0.05); r.add(bk, -0.22, 6.0, 1.7, 0.2, 0.18, 0.05);
        r.add(rd, 0.22, 6.0, 1.73, 0.06, 0.06, 0.03); r.add(rd, -0.22, 6.0, 1.73, 0.06, 0.06, 0.03);
        for (int i = -5; i <= 5; i++) r.swing(gy, i * 0.1, 4.2, 0.55, 0.07, 1.8 - Math.abs(i) * 0.1, 0.05, i * 0.1, 5.9, 0.6, 1, 0, 0, 0.15, 0.2, i * 0.6);   // soi toc/dai rung ra sau co
        // hai tay rat dai: tay trai vuon xuong truoc, tay phai co lai; ngon tay dai nhu xuong
        for (int sg = -1; sg <= 1; sg += 2) {
            double sx = 0.85 * sg;
            r.swing(sk, sx, 4.5, 0.9, 0.2, 1.7, 0.2, sx, 5.2, 0.8, 1, 0, 0, 0.3, 0.16, sg > 0 ? 0 : 3.14);
            int u = r.idx();
            r.swing(sk, sx + 0.1 * sg, 3.0, 1.3, 0.17, 1.9, 0.17, sx, 3.8, 1.0, 1, 0, 0, -0.5, 0.16, sg > 0 ? 0.6 : 3.7);
            r.under(u);
            int v = r.idx();
            r.add(sk, sx + 0.1 * sg, 1.95, 1.4, 0.3, 0.12, 0.4); r.under(v);
            for (int f = -2; f <= 2; f++) {
                r.add(sk, sx + 0.1 * sg + f * 0.07, 1.85, 1.9, 0.045, 0.045, 0.85); r.under(v);
                r.add(gy, sx + 0.1 * sg + f * 0.07, 1.85, 2.4, 0.04, 0.04, 0.25); r.under(v);
            }
        }
        return r;
    }

    static void rikaManifest(ServerWorld w, ServerPlayerEntity p) {
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 400, 1));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 400, 1));
        Vec3d dir0 = dirOf(p);
        Vec3d start = p.getEntityPos().subtract(dir0.multiply(2.5));
        int total = 400;
        Rig r = rikaModel(w, start, Rig.yawOf(dir0), total + 20);
        summonFx(w, start, 0x90B8FF);
        Fx.snd(w, start, SoundEvents.ENTITY_WITHER_SPAWN, 1.0f, 1.6f);
        Anims.add(new Anims.Anim() {
            int t = 0; Vec3d pos = start; double yaw = Rig.yawOf(dir0);
            public boolean tick() {
                t++;
                if (p.isRemoved() || !p.isAlive() || t > total) { r.kill(); return true; }
                Vec3d here = p.getEntityPos();
                LivingEntity tg = nearest(w, p, pos, 14);
                Vec3d goal = tg != null ? tg.getEntityPos() : here.subtract(dirOf(p).multiply(2.5)).add(rightOf(dirOf(p)).multiply(1.5));
                Vec3d to = flat(goal.subtract(pos));
                double dist = to.length();
                if (dist > (tg != null ? 2.6 : 1.0)) pos = pos.add(to.normalize().multiply(Math.min(dist, tg != null ? 0.45 : 0.3)));
                pos = new Vec3d(pos.x, here.y + 0.3 + Math.sin(t * 0.1) * 0.15, pos.z);
                if (dist > 0.05) yaw = Rig.yawOf(to);
                if (t % 2 == 0) r.place(pos, yaw, t);
                if (tg != null && dist <= 4.5 && t % 18 == 0) {
                    Vec3d look = flat(tg.getEntityPos().subtract(pos)).normalize();
                    Vec3d hit = pos.add(look.multiply(2.5)).add(0, 1.8, 0);
                    Fx.snd(w, hit, SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, 1.5f, 0.6f);
                    Fx.put(w, ParticleTypes.CRIT, hit, 14, 0.8, 0.3);
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(pos, pos).expand(4.5, 3, 4.5))) {
                        if (e.getEntityPos().distanceTo(pos) > 4.8) continue;
                        Fx.hurt(w, p, e, 10f);
                        Vec3d kb = flat(e.getEntityPos().subtract(pos)).normalize();
                        e.addVelocity(kb.x * 0.7, 0.3, kb.z * 0.7);
                    }
                }
                if (t % 5 == 0) Fx.put(w, Fx.dust(0x90B8FF, 1.0f), pos.add(0, 3.5, 0), 2, 0.7, 0.02);
                return false;
            }
        });
    }
}
