package com.example.jjk;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/** Trang thai nguoi choi tren may chu: nhan vat, chu luc, hoi chieu, bat/tat. Chi nhan vat + ky thuat chon duoc luu. */
public class Data {
    public static int now = 0;
    private static final Map<UUID, Integer> CHARA = new HashMap<>();
    public static final int SLOTS = 8;
    private static final Map<String, String[]> SL = new HashMap<>();
    private static final Map<UUID, Double> ENERGY = new HashMap<>();
    private static final Map<UUID, Map<String, Integer>> CD = new HashMap<>();
    public static final Set<UUID> INFINITY = new HashSet<>(), REINFORCE = new HashSet<>();
    public static final Map<UUID, Integer> DOMAIN_END = new HashMap<>();
    public static final Map<UUID, Integer> FLASH_STREAK = new HashMap<>(), FLASH_ZONE = new HashMap<>();

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("jjk-players.properties"); }

    public static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(f)) { p.load(in); }
            for (String k : p.stringPropertyNames()) {
                try {
                    if (k.endsWith(".chara")) CHARA.put(UUID.fromString(k.substring(0, k.length() - 6)), Integer.parseInt(p.getProperty(k)));
                    else if (k.contains(".slots.")) {
                        String[] parts = k.split("\\.");
                        String[] v = p.getProperty(k).split(",", -1);
                        String[] s = new String[SLOTS];
                        for (int i = 0; i < SLOTS && i < v.length; i++) s[i] = (v[i].isEmpty() || v[i].equals("-")) ? null : v[i];
                        SL.put(parts[0] + "." + parts[2], s);
                    }
                } catch (Exception ignored) { }
            }
        } catch (Exception e) { System.err.println("[jjk] load: " + e); }
    }

    public static void save() {
        try {
            Properties p = new Properties();
            for (Map.Entry<UUID, Integer> e : CHARA.entrySet()) p.setProperty(e.getKey() + ".chara", String.valueOf(e.getValue()));
            for (Map.Entry<String, String[]> e : SL.entrySet()) {
                int dot = e.getKey().lastIndexOf('.');
                StringBuilder sb = new StringBuilder();
                for (String s : e.getValue()) sb.append(s == null ? "-" : s).append(',');
                p.setProperty(e.getKey().substring(0, dot) + ".slots." + e.getKey().substring(dot + 1), sb.toString());
            }
            try (OutputStream out = Files.newOutputStream(file())) { p.store(out, "Jujutsu players"); }
        } catch (Exception e) { System.err.println("[jjk] save: " + e); }
    }

    public static Tech.Chara chara(UUID id) {
        Tech.Chara[] all = Tech.Chara.values();
        int c = CHARA.getOrDefault(id, 0);
        return all[Math.max(0, Math.min(all.length - 1, c))];
    }

    public static void setChara(UUID id, int c) {
        if (c < 0 || c >= Tech.Chara.values().length) return;
        CHARA.put(id, c);
        INFINITY.remove(id);
        REINFORCE.remove(id);
        save();
    }

    public static List<Tech.T> techs(UUID id) { return Tech.of(chara(id)); }

    /** 8 slot cua nhan vat hien tai (moi nhan vat co bo slot rieng, duoc luu). */
    static final Map<UUID, Integer> PAGE = new HashMap<>();

    public static int pages(UUID id) { return Math.max(1, (techs(id).size() + SLOTS - 1) / SLOTS); }

    public static int page(UUID id) { return Math.max(0, Math.min(pages(id) - 1, PAGE.getOrDefault(id, 0))); }

    public static void changePage(UUID id, int d) {
        int n = pages(id);
        PAGE.put(id, ((page(id) + d) % n + n) % n);
    }

    public static String[] slots(UUID id) {
        if (Config.autoPage) {                            // che do tu dong: 8 o = trang hien tai cua danh sach ky nang
            String[] a = new String[SLOTS];
            List<Tech.T> l = techs(id);
            for (int i = 0; i < SLOTS; i++) { int k = page(id) * SLOTS + i; a[i] = k < l.size() ? l.get(k).id() : null; }
            return a;
        }
        Tech.Chara c = chara(id);
        String key = id + "." + c.ordinal();
        String[] s = SL.get(key);
        if (s == null) {
            s = new String[SLOTS];
            List<Tech.T> l = Tech.of(c);
            for (int i = 0; i < SLOTS && i < l.size(); i++) s[i] = l.get(i).id();
            SL.put(key, s);
        }
        return s;
    }

    /** gan ky thuat vao slot; neu ky thuat da o slot khac thi hoan doi. techId=null: xoa slot. */
    public static void equip(UUID id, int slot, String techId) {
        if (slot < 0 || slot >= SLOTS || Config.autoPage) return;
        String[] s = slots(id);
        if (techId != null) {
            Tech.T t = Tech.byId(techId);
            if (t == null || !t.usedBy(chara(id))) return;
            for (int j = 0; j < SLOTS; j++) if (j != slot && techId.equals(s[j])) s[j] = s[slot];
        }
        s[slot] = techId;
        save();
    }

    public static int maxEnergy() { return Config.maxEnergy; }

    public static int maxEnergy(UUID id) { return Progress.maxEnergy(id); }

    public static double energy(UUID id) { return ENERGY.getOrDefault(id, (double) maxEnergy(id)); }

    public static boolean spend(UUID id, double c) {
        double e = energy(id);
        if (e < c) return false;
        ENERGY.put(id, e - c);
        return true;
    }

    public static void addEnergy(UUID id, double d) {
        ENERGY.put(id, Math.max(0, Math.min(maxEnergy(id), energy(id) + d)));
    }

    public static int remaining(UUID id, String tech) {
        Map<String, Integer> m = CD.get(id);
        if (m == null) return 0;
        return Math.max(0, m.getOrDefault(tech, 0) - now);
    }

    public static void setCooldown(UUID id, String tech, int ticks) {
        if (ticks <= 0) return;
        CD.computeIfAbsent(id, k -> new HashMap<>()).put(tech, now + ticks);
    }

    public static boolean domainActive(UUID id) {
        Integer e = DOMAIN_END.get(id);
        return e != null && e > now;
    }

    public static ServerWorld worldOf(MinecraftServer server, ServerPlayerEntity p) {
        for (ServerWorld w : server.getWorlds()) if (w.getPlayers().contains(p)) return w;
        return null;
    }

    public static String syncString(UUID id) {
        StringBuilder sb = new StringBuilder();
        sb.append("c=").append(chara(id).ordinal());
        sb.append(";e=").append((int) energy(id));
        sb.append(";mx=").append(maxEnergy(id));
        sb.append(";gr=").append(Progress.grade(id)).append(";xp=").append(Progress.xp(id)).append(";xn=").append(Progress.nextXp(id));
        sb.append(";sl=");
        for (String s : slots(id)) sb.append(s == null ? "-" : s).append(',');
        sb.append(";pg=").append(page(id)).append(";np=").append(pages(id)).append(";ap=").append(Config.autoPage ? 1 : 0).append(";sd=").append(Config.solidDomain ? 1 : 0);
        sb.append(";inf=").append(INFINITY.contains(id) ? 1 : 0);
        sb.append(";rei=").append(REINFORCE.contains(id) ? 1 : 0);
        Integer de = DOMAIN_END.get(id);
        sb.append(";dom=").append(de != null && de > now ? de - now : 0);
        sb.append(";nc=").append(Config.noCooldown ? 1 : 0).append(";ul=").append(Config.unlimited ? 1 : 0)
          .append(";cm=").append((int) Math.round(Config.cdMult * 100)).append(";km=").append((int) Math.round(Config.costMult * 100))
          .append(";rg=").append((int) Math.round(Config.regen)).append(";ds=").append(Config.domainSeconds)
          .append(";dp=").append(Config.displays ? 1 : 0).append(";sh=").append(Config.domainShell ? 1 : 0);
        sb.append(";cd=");
        for (Tech.T t : techs(id)) {
            int r = remaining(id, t.id());
            if (r > 0) sb.append(t.id()).append(':').append(r).append(',');
        }
        return sb.toString();
    }

    public static void resetCooldowns(UUID id) { CD.remove(id); }

    /** chinh cai dat tu menu (de test do cho hoi chieu / chu luc) */
    public static void tweak(UUID id, int code, int v) {
        switch (code) {
            case 0 -> Config.noCooldown = !Config.noCooldown;
            case 1 -> Config.unlimited = !Config.unlimited;
            case 2 -> Config.cdMult = Math.max(0, Math.min(10, v / 100.0));
            case 3 -> Config.costMult = Math.max(0, Math.min(10, v / 100.0));
            case 4 -> Config.regen = Math.max(0, Math.min(1000, v));
            case 5 -> Config.maxEnergy = Math.max(50, Math.min(100000, v));
            case 6 -> Config.domainSeconds = Math.max(3, Math.min(60, v));
            case 7 -> { ENERGY.put(id, (double) maxEnergy(id)); CD.remove(id); }
            case 8 -> Config.displays = !Config.displays;
            case 9 -> Config.domainShell = !Config.domainShell;
            case 10 -> Config.autoPage = !Config.autoPage;
            case 11 -> Config.solidDomain = !Config.solidDomain;
            default -> { }
        }
        Config.save();
    }

    private static final Map<UUID, String> LAST = new HashMap<>();

    /** chi gui khi noi dung doi (hoac moi 2 giay) de giam luu luong mang */
    public static void sync(ServerPlayerEntity p) {
        String s = syncString(p.getUuid());
        if (s.equals(LAST.get(p.getUuid())) && now % 40 != 0) return;
        LAST.put(p.getUuid(), s);
        ServerPlayNetworking.send(p, new SyncPayload(s));
    }

    /** don dep trang thai tam khi nguoi choi thoat */
    public static void forget(UUID id) {
        INFINITY.remove(id); REINFORCE.remove(id); DOMAIN_END.remove(id);
        FLASH_STREAK.remove(id); FLASH_ZONE.remove(id); LAST.remove(id); PAGE.remove(id);
        Stage3Skills.UZUMAKI.remove(id); Domains.JACKPOT_END.remove(id); Outfits.COPY.remove(id);
    }

    /** moi tick may chu */
    public static void tick(MinecraftServer server) {
        now++;
        for (ServerWorld w : server.getWorlds()) {
            for (ServerPlayerEntity p : w.getPlayers()) {
                UUID id = p.getUuid();
                if (!p.isAlive()) { INFINITY.remove(id); REINFORCE.remove(id); continue; }
                if (Config.unlimited) ENERGY.put(id, (double) maxEnergy(id));
                else addEnergy(id, Config.regen * Progress.regenMult(id) / 20.0);

                if (INFINITY.contains(id)) {
                    if (!Config.unlimited) ENERGY.put(id, Math.max(0, energy(id) - 4.0 / 20.0));
                    if (energy(id) <= 0.01 && !Config.unlimited) {
                        INFINITY.remove(id);
                        p.sendMessage(Text.literal("Infinity tat: het nang luong!").formatted(Formatting.RED), true);
                    } else Abilities.infinityTick(w, p);
                }
                if (REINFORCE.contains(id)) {
                    if (!Config.unlimited) ENERGY.put(id, Math.max(0, energy(id) - 1.5 / 20.0));
                    if (energy(id) <= 0.01 && !Config.unlimited) {
                        REINFORCE.remove(id);
                        p.sendMessage(Text.literal("Cursed Energy Reinforcement tat: het nang luong!").formatted(Formatting.RED), true);
                    } else Abilities.reinforceTick(w, p);
                }
                if (now % 4 == 0) sync(p);
            }
        }
    }
}
