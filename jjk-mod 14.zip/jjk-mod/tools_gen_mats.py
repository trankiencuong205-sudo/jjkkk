import numpy as np, random, math, json, os
from PIL import Image, ImageDraw, ImageFilter
S=64
OUT='/home/claude/jjk-mod/src/main/resources/assets/jjk'
rnd=random.Random(7)

def lerp(a,b,t): return tuple(int(a[i]+(b[i]-a[i])*t) for i in range(3))
def base(col): return Image.new('RGB',(S,S),col)

def wrap_draw(img, fn):
    """ve len anh co wrap (tileable): ve 9 lan voi dich +-S"""
    for dx in (-S,0,S):
        for dy in (-S,0,S):
            fn(dx,dy)

def noise_layer(col_a,col_b,scale=8,seed=1):
    r=np.random.RandomState(seed)
    g=r.rand(S//scale+1,S//scale+1)
    big=np.kron(g,np.ones((scale,scale)))[:S,:S]
    im=Image.fromarray((big*255).astype('uint8')).filter(ImageFilter.GaussianBlur(scale/2.2))
    a=np.array(im)/255.0
    out=np.zeros((S,S,3),'uint8')
    for i in range(3): out[:,:,i]=(col_a[i]+(col_b[i]-col_a[i])*a).astype('uint8')
    return Image.fromarray(out)

def fur(dark,mid,light,n=900,ln=(5,11),slant=0.25,seed=1,gradient=True):
    rr=random.Random(seed)
    img=noise_layer(dark,mid,10,seed)
    d=ImageDraw.Draw(img)
    for _ in range(n):
        x=rr.uniform(0,S); y=rr.uniform(0,S); L=rr.randint(*ln); a=math.pi/2+rr.uniform(-slant,slant)
        t=rr.random(); col=lerp(dark,light,t**1.6)
        def f(dx,dy):
            d.line([(x+dx,y+dy),(x+dx+math.cos(a)*L,y+dy+math.sin(a)*L)],fill=col,width=1)
        wrap_draw(img,f)
    # vai soc toi tao chieu sau
    for _ in range(n//5):
        x=rr.uniform(0,S); y=rr.uniform(0,S); L=rr.randint(3,6)
        def f(dx,dy): d.line([(x+dx,y+dy),(x+dx,y+dy+L)],fill=lerp(dark,(0,0,0),0.5),width=1)
        wrap_draw(img,f)
    return img

def feather(dark,mid,light,seed=2):
    rr=random.Random(seed)
    img=base(dark); d=ImageDraw.Draw(img)
    rows=8; h=S//rows
    for row in range(rows):
        off=(row%2)*8
        for k in range(-1,S//16+2):
            cx=k*16+off+rr.randint(-1,1); y0=row*h
            col=lerp(mid,light,rr.random()*0.6)
            def f(dx,dy):
                pts=[(cx-8+dx,y0+dy),(cx+8+dx,y0+dy),(cx+7+dx,y0+h-2+dy),(cx+dx,y0+h+3+dy),(cx-7+dx,y0+h-2+dy)]
                d.polygon(pts,fill=col,outline=lerp(dark,(0,0,0),0.4))
                d.line([(cx+dx,y0+1+dy),(cx+dx,y0+h+1+dy)],fill=lerp(col,light,0.6),width=1)
            wrap_draw(img,f)
    return img

def skin(basec,wr,spots=None,n_wr=40,seed=3,sheen=True):
    rr=random.Random(seed)
    img=noise_layer(lerp(basec,(0,0,0),0.12),lerp(basec,(255,255,255),0.1),12,seed)
    d=ImageDraw.Draw(img)
    for _ in range(n_wr):
        x=rr.uniform(0,S); y=rr.uniform(0,S); L=rr.randint(6,16); a=rr.uniform(-0.4,0.4)
        def f(dx,dy): d.line([(x+dx,y+dy),(x+dx+math.cos(a)*L,y+dy+math.sin(a)*L*0.4)],fill=wr,width=1)
        wrap_draw(img,f)
    if spots:
        for _ in range(26):
            x=rr.uniform(0,S); y=rr.uniform(0,S); r=rr.uniform(2,5)
            def f(dx,dy): d.ellipse([x+dx-r,y+dy-r*0.8,x+dx+r,y+dy+r*0.8],fill=spots)
            wrap_draw(img,f)
    if sheen:
        for _ in range(30):
            x=rr.uniform(0,S); y=rr.uniform(0,S)
            def f(dx,dy): d.point((x+dx,y+dy),fill=lerp(basec,(255,255,255),0.7))
            wrap_draw(img,f)
    return img

def marble(basec,vein,seed=4):
    rr=random.Random(seed)
    img=noise_layer(lerp(basec,(150,160,175),0.12),basec,14,seed); d=ImageDraw.Draw(img)
    for _ in range(7):
        x=rr.uniform(0,S); y=rr.uniform(0,S); a=rr.uniform(0,math.pi)
        pts=[]
        for i in range(14):
            x+=math.cos(a)*3; y+=math.sin(a)*3; a+=rr.uniform(-0.6,0.6); pts.append((x,y))
        def f(dx,dy): d.line([(px+dx,py+dy) for px,py in pts],fill=vein,width=1)
        wrap_draw(img,f)
    return img

def cloth(basec,hi,seed=5):
    img=noise_layer(lerp(basec,(0,0,0),0.35),basec,16,seed); d=ImageDraw.Draw(img)
    rr=random.Random(seed)
    for k in range(0,S,4):
        d.line([(0,k),(S,k+rr.randint(-1,1))],fill=lerp(basec,hi,0.45),width=1)
    for _ in range(25):
        x=rr.randint(0,S-1); y=rr.randint(0,S-1); d.point((x,y),fill=hi)
    return img

def gold(seed=6):
    img=noise_layer((150,110,20),(240,200,70),8,seed); d=ImageDraw.Draw(img)
    d.rectangle([2,2,S-3,S-3],outline=(110,70,10)); d.rectangle([5,5,S-6,S-6],outline=(255,230,120))
    for k in range(8,S-8,8):
        d.ellipse([k,S//2-3,k+5,S//2+3],outline=(110,70,10))
        d.line([(k+2,10),(k+2,S//2-4)],fill=(110,70,10))
        d.line([(k+2,S//2+4),(k+2,S-10)],fill=(110,70,10))
    return img

def tiger():
    img=fur((18,14,12),(48,38,30),(95,78,55),1100,(6,12),0.2,11)
    d=ImageDraw.Draw(img); rr=random.Random(12)
    for x in range(4,S,16):
        xx=x+rr.randint(-2,2)
        pts=[]; 
        for y in range(0,S+4,4): pts.append((xx+rr.randint(-2,2)+math.sin(y*0.2)*2,y))
        d.line(pts,fill=(190,146,48),width=2)
        pass
    return img.filter(ImageFilter.SMOOTH_MORE).filter(ImageFilter.SHARPEN)

MATS={
 'fur_black':fur((6,6,9),(24,24,30),(70,72,90),1100,seed=21),
 'fur_white':fur((190,195,205),(232,234,240),(255,255,255),900,seed=22),
 'fur_gray':fur((50,54,60),(92,98,106),(150,156,165),900,seed=23),
 'fur_tiger':tiger(),
 'feather_red':feather((70,24,18),(150,56,38),(210,110,70),31),
 'feather_brown':feather((38,22,16),(86,50,32),(140,90,60),32),
 'skin_pink':skin((236,146,176),(200,100,136),None,46,41),
 'skin_frog':skin((86,110,52),(52,72,30),(60,84,34),30,42),
 'skin_frogbelly':skin((226,226,214),(188,188,172),None,24,43),
 'marble_white':marble((244,242,240),(190,196,210),51),
 'marble_gray':marble((170,172,176),(120,124,132),52),
 'cloth_black':cloth((14,16,20),(60,68,84),53),
 'cloth_gray':cloth((96,98,104),(150,154,160),54),
 'gold_ornament':gold(),
 'skin_hand':skin((222,170,130),(190,130,95),None,10,61,False),
}
sheet=Image.new('RGB',(S*8*3,S*2*3+20),(28,30,40))
for i,(k,im) in enumerate(MATS.items()):
    im.save(f'{OUT}/textures/item/mat_{k}.png')
    json.dump({"parent":"minecraft:block/cube_all","textures":{"all":f"jjk:item/mat_{k}"}},open(f'{OUT}/models/item/mat_{k}.json','w'))
    json.dump({"model":{"type":"minecraft:model","model":f"jjk:item/mat_{k}"}},open(f'{OUT}/items/mat_{k}.json','w'))
    sheet.paste(im.resize((S*3,S*3),Image.NEAREST),((i%8)*S*3,(i//8)*S*3))
sheet.save('/mnt/user-data/outputs/jjk-materials-preview.png')
# do mau trung binh cho preview mo hinh
avg={k:tuple(int(c) for c in np.array(im).reshape(-1,3).mean(0)) for k,im in MATS.items()}
json.dump(avg,open('/home/claude/mat_avg.json','w'))
print('ok',len(MATS))
