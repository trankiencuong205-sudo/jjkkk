package com.example.jjk;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

import java.util.ArrayList;
import java.util.List;

/** Hoat anh tung tick chay tren may chu. */
public class Anims {
    public interface Anim { boolean tick(); }   // true = ket thuc

    private static final List<Anim> ACTIVE = new ArrayList<>();
    private static final List<Anim> PENDING = new ArrayList<>();

    public static void add(Anim a) { PENDING.add(a); }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (!PENDING.isEmpty()) { ACTIVE.addAll(PENDING); PENDING.clear(); }
            if (ACTIVE.isEmpty()) return;
            ACTIVE.removeIf(a -> {
                try { return a.tick(); } catch (Throwable e) { Safe.log("anim", e); return true; }
            });
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> { ACTIVE.clear(); PENDING.clear(); });
    }
}
