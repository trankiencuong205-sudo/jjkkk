package com.example.jjk;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.*;

/**
 * PHA HUY dia hinh khi dung ky nang: hố no (crater), duong ham cua tia (carve), vet cat phang (cut), song nut mat dat (ring).
 * Khoi bi pha bay ra thanh manh vun (block_display) roi roi xuong. Gioi han: do cung theo sat thuong, khong dung bedrock /
 * block entity / phong domain / chat long / ngoai world border; toi da Config.destructionLimit khoi moi lan; khong roi vat pham.
 * Tat bang Config.destruction=false. Chua test trong game.
 */
public class Terrain {
    static boolean can(ServerWorld w, BlockPos p, double power) {
        if (w.isOutOfHeightLimit(p.getY()) || !w.getWorldBorder().contains(p)) return false;
        if (!w.getChunkManager().isChunkLoaded(p.getX() >> 4, p.getZ() >> 4)) return false;
        if (Room.isProtected(w, p)) return false;
        BlockState s = w.getBlockState(p);
        if (s.isAir() || s.isOf(Blocks.BEDROCK) || !s.getFluidState().isEmpty()) return false;
        if (w.getBlockEntity(p) != null) return false;
        float h = s.getHardness(w, p);
        return h >= 0 && h <= power;
    }

    static double power(double dmg) { return Math.max(2.0, Math.min(100.0, dmg / 5.0)); }

    /** hang doi pha: moi tick pha perTick khoi theo thu tu (tao cam giac song lan ra) */
    private static void run(ServerWorld w, List<BlockPos> list, Vec3d origin, double power, boolean blast) {
        if (list.isEmpty()) return;
        list.sort(Comparator.comparingDouble(b -> b.getSquaredDistance(origin.x, origin.y, origin.z)));
        if (list.size() > Config.destructionLimit) list = new ArrayList<>(list.subList(0, Config.destructionLimit));
        final List<BlockPos> q = list;
        final int per = Math.max(8, q.size() / 6);
        final List<double[]> deb = new ArrayList<>();             // {x,y,z,vx,vy,vz}
        final List<Disp.H> debH = new ArrayList<>();
        Fx.snd(w, origin, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 1.2f, 0.7f);
        Fx.snd(w, origin, SoundEvents.BLOCK_STONE_BREAK, 1.5f, 0.6f);
        Anims.add(new Anims.Anim() {
            int i = 0, t = 0, shown = 0;
            public boolean tick() {
                t++;
                for (int n = 0; n < per && i < q.size(); n++, i++) {
                    BlockPos p = q.get(i);
                    if (!can(w, p, power)) continue;
                    BlockState s = w.getBlockState(p);
                    w.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
                    if (shown < 22 && (i % 3 == 0) && Config.displays && Disp.count() < Config.maxDisplays * 0.6) {
                        Identifier id = Registries.BLOCK.getId(s.getBlock());
                        if (id.getNamespace().equals("minecraft")) {
                            Vec3d c = Vec3d.ofCenter(p);
                            Disp.H h = Disp.block(w, c, id.getPath(), 0.75, 0.75, 0.75, Disp.Q.ID, 40);
                            Vec3d out = c.subtract(origin);
                            out = out.lengthSquared() < 1e-4 ? new Vec3d(0, 1, 0) : out.normalize();
                            double sp = blast ? 0.55 : 0.35;
                            deb.add(new double[]{c.x, c.y, c.z, out.x * sp + Fx.rnd(-0.1, 0.1), 0.25 + Fx.rnd(0, 0.3), out.z * sp + Fx.rnd(-0.1, 0.1)});
                            debH.add(h);
                            shown++;
                        }
                    }
                }
                for (int k = 0; k < deb.size(); k++) {                // mang vun bay: trong luc
                    double[] d = deb.get(k);
                    d[0] += d[3]; d[1] += d[4]; d[2] += d[5]; d[4] -= 0.06;
                    debH.get(k).move(new Vec3d(d[0], d[1], d[2]));
                }
                if (t > 22) { for (Disp.H h : debH) h.kill(); return true; }
                return i >= q.size() && t > 22;
            }
        });
    }

    private static void sphere(ServerWorld w, Set<Long> seen, List<BlockPos> out, Vec3d c, double r, double power) {
        int R = (int) Math.ceil(r);
        BlockPos b = BlockPos.ofFloored(c);
        for (int dx = -R; dx <= R; dx++) for (int dy = -R; dy <= R; dy++) for (int dz = -R; dz <= R; dz++) {
            BlockPos p = b.add(dx, dy, dz);
            double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
            double wob = 0.88 + 0.22 * Math.abs(Math.sin(p.getX() * 12.9898 + p.getZ() * 78.233 + p.getY() * 37.719));   // mep nham nho
            if (d > r * wob || !seen.add(p.asLong())) continue;
            if (can(w, p, power)) out.add(p);
        }
    }

    /** ho no hinh cau */
    public static void crater(ServerWorld w, Vec3d c, double r, double dmg) {
        if (!Config.destruction || r < 1.2 || dmg < 10) return;
        r = Math.min(r, 14);
        List<BlockPos> l = new ArrayList<>();
        sphere(w, new HashSet<>(), l, c, r, power(dmg));
        run(w, l, c, power(dmg), true);
    }

    /** duong ham xuyen qua dia hinh theo tia */
    public static void carve(ServerWorld w, Vec3d a, Vec3d b, double rad, double dmg) {
        if (!Config.destruction || dmg < 10) return;
        List<BlockPos> l = new ArrayList<>();
        Set<Long> seen = new HashSet<>();
        Vec3d d = b.subtract(a);
        double len = d.length();
        if (len < 0.5) return;
        d = d.normalize();
        double r = Math.max(0.9, Math.min(4.5, rad));
        for (double t = 0; t <= len && l.size() < Config.destructionLimit * 2; t += Math.max(0.7, r * 0.6))
            sphere(w, seen, l, a.add(d.multiply(t)), r, power(dmg));
        run(w, l, a, power(dmg), false);
    }

    /** vet cat phang: mat phang chua huong chem u va huong tien dir, rong halfLen, sau depth */
    public static void cut(ServerWorld w, Vec3d c, Vec3d u, Vec3d dir, double halfLen, double depth, double dmg) {
        if (!Config.destruction || dmg < 10) return;
        Vec3d n = u.crossProduct(dir);
        if (n.lengthSquared() < 1e-4) return;
        n = n.normalize();
        u = u.normalize(); dir = dir.normalize();
        double R = Math.min(12, Math.max(halfLen, depth)) + 1;
        List<BlockPos> l = new ArrayList<>();
        BlockPos b = BlockPos.ofFloored(c);
        int Ri = (int) Math.ceil(R);
        for (int dx = -Ri; dx <= Ri; dx++) for (int dy = -Ri; dy <= Ri; dy++) for (int dz = -Ri; dz <= Ri; dz++) {
            BlockPos p = b.add(dx, dy, dz);
            Vec3d rel = Vec3d.ofCenter(p).subtract(c);
            if (Math.abs(rel.dotProduct(n)) > 0.75) continue;
            double x = rel.dotProduct(u), z = rel.dotProduct(dir);
            if (Math.abs(x) > halfLen || z < -0.5 || z > depth) continue;
            if (can(w, p, power(dmg))) l.add(p);
        }
        run(w, l, c, power(dmg), false);
    }

    /** song nut mat dat lan ra tu chan (nova): lat lop tren cung */
    public static void ring(ServerWorld w, Vec3d feet, double r, double dmg) {
        if (!Config.destruction || dmg < 10) return;
        r = Math.min(r, 12);
        List<BlockPos> l = new ArrayList<>();
        int R = (int) Math.ceil(r);
        BlockPos b = BlockPos.ofFloored(feet);
        for (int dx = -R; dx <= R; dx++) for (int dz = -R; dz <= R; dz++) {
            double d = Math.sqrt(dx * dx + dz * dz);
            if (d > r || d < 1.2) continue;
            for (int dy = 1; dy >= -2; dy--) {
                BlockPos p = b.add(dx, dy, dz);
                if (can(w, p, power(dmg))) {
                    l.add(p);
                    if (d < r * 0.5 && can(w, p.down(), power(dmg))) l.add(p.down());
                    break;
                }
            }
        }
        run(w, l, feet, power(dmg), true);
    }

    /** XOAY HUT (Blue): xe toi cac khoi quanh tam c, bay xoay vao tam roi bien mat */
    public static void vortex(ServerWorld w, Vec3d c, double r, double dmg, int ticks) {
        if (!Config.destruction || dmg < 10) return;
        List<BlockPos> l = new ArrayList<>();
        sphere(w, new HashSet<>(), l, c, Math.min(r, 9), power(dmg));
        if (l.isEmpty()) return;
        l.sort((a, b) -> Double.compare(b.getSquaredDistance(c.x, c.y, c.z), a.getSquaredDistance(c.x, c.y, c.z)));   // xa truoc, gan sau
        if (l.size() > Config.destructionLimit) l = new ArrayList<>(l.subList(0, Config.destructionLimit));
        final List<BlockPos> q = l;
        final List<Disp.H> hs = new ArrayList<>();
        final List<double[]> st = new ArrayList<>();            // {angle, radius, height, speed}
        Anims.add(new Anims.Anim() {
            int t = 0, i = 0;
            public boolean tick() {
                t++;
                int per = Math.max(2, q.size() / Math.max(8, ticks / 2));
                for (int n = 0; n < per && i < q.size() && t <= ticks; n++, i++) {
                    BlockPos p = q.get(i);
                    if (!can(w, p, power(dmg))) continue;
                    BlockState s = w.getBlockState(p);
                    w.setBlockState(p, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL);
                    Identifier id = Registries.BLOCK.getId(s.getBlock());
                    if (hs.size() < 30 && id.getNamespace().equals("minecraft") && Config.displays && Disp.count() < Config.maxDisplays * 0.6) {
                        Vec3d pc = Vec3d.ofCenter(p).subtract(c);
                        hs.add(Disp.block(w, Vec3d.ofCenter(p), id.getPath(), 0.6, 0.6, 0.6, Disp.Q.ID, 80));
                        st.add(new double[]{Math.atan2(pc.z, pc.x), Math.sqrt(pc.x * pc.x + pc.z * pc.z), pc.y, 0.18 + Fx.rnd(0, 0.1)});
                    }
                }
                for (int k = 0; k < hs.size(); k++) {
                    double[] d = st.get(k);
                    d[0] += d[3]; d[1] = Math.max(0.0, d[1] - 0.12); d[2] *= 0.94;
                    hs.get(k).move(c.add(Math.cos(d[0]) * d[1], d[2], Math.sin(d[0]) * d[1]));
                }
                if (t > ticks + 20) { for (Disp.H h : hs) h.kill(); return true; }
                return false;
            }
        });
        Fx.snd(w, c, SoundEvents.BLOCK_STONE_BREAK, 1.2f, 0.5f);
    }
}
