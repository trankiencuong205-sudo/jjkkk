package com.example.jjk;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class JjkClient implements ClientModInitializer {
    public static final KeyBinding.Category CATEGORY = KeyBinding.Category.create(Identifier.of(Jjk.ID, "main"));
    private static KeyBinding menu, next, prev, cast, next2, prev2;

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(SyncPayload.ID, (payload, context) -> ClientData.parse(payload.data()));
        menu = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.jjk.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, CATEGORY));
        cast = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.jjk.cast", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_Z, CATEGORY));
        next = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.jjk.skill_next", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, CATEGORY));
        prev = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.jjk.skill_prev", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F, CATEGORY));
        next2 = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.jjk.skill_next2", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_X, CATEGORY));
        prev2 = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.jjk.skill_prev2", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, CATEGORY));

        HudElementRegistry.addLast(Identifier.of(Jjk.ID, "hud"), (ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.options.hudHidden || mc.player == null) return;
            int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
            int total = 150;
            int sx = sw / 2 - total / 2, y = sh - 72;

            // thanh chu luc
            float frac = Math.max(0f, Math.min(1f, ClientData.energy / (float) Math.max(1, ClientData.maxEnergy)));
            int col = 0xFF000000 | ClientData.chara().color;
            int by = y - 11;
            ctx.fill(sx - 1, by - 1, sx + total + 1, by + 7, 0xFF000000);
            ctx.fill(sx, by, sx + total, by + 6, 0xFF15101F);
            ctx.fill(sx, by, sx + (int) (total * frac), by + 6, col);
            ctx.fill(sx, by, sx + (int) (total * frac), by + 2, 0x66FFFFFF);
            String et = "CE " + ClientData.energy + "/" + ClientData.maxEnergy;
            ctx.drawTextWithShadow(mc.textRenderer, et, sx + total + 4, by - 1, 0xFFFFFFFF);
            String gt = Progress.GRADES[Math.max(0, Math.min(Progress.GRADES.length - 1, ClientData.gr))] + (ClientData.xn > 0 ? "  " + ClientData.xp + "/" + ClientData.xn + " XP" : "  " + ClientData.xp + " XP (MAX)");
            ctx.drawTextWithShadow(mc.textRenderer, gt, sx, by - 11, 0xFFFFD27A);

            // ky nang dang chon (khong con khung 8 o)
            java.util.List<Tech.T> list = Tech.of(ClientData.chara());
            if (!list.isEmpty()) {
                int si = Math.floorMod(ClientData.sel, list.size());
                Tech.T t = list.get(si);
                int ic = Tech.iconColor(t);
                int rem = ClientData.cd.getOrDefault(t.id(), 0);
                String name = t.en().replace("Domain Expansion: ", "DE: ");
                String line = "< " + name + " >";
                int w = Math.max(mc.textRenderer.getWidth(line), 90) + 10;
                int x0 = sw / 2 - w / 2;
                ctx.fill(x0 - 1, y + 3, x0 + w + 1, y + 22, 0xFF000000);
                ctx.fill(x0, y + 4, x0 + w, y + 21, 0xCC15101F);
                ctx.fill(x0, y + 4, x0 + w, y + 6, 0xFF000000 | ic);
                if (rem > 0 && t.cooldown() > 0) {
                    int cw = (int) (w * Math.min(1f, rem / (float) t.cooldown()));
                    ctx.fill(x0, y + 19, x0 + cw, y + 21, 0xFFFFDD66);
                }
                ctx.drawTextWithShadow(mc.textRenderer, line, sw / 2 - mc.textRenderer.getWidth(line) / 2, y + 8, 0xFFFFFFFF);
                String sub = (si + 1) + "/" + list.size() + (rem > 0 ? "   " + (rem >= 20 ? String.valueOf((rem + 19) / 20) : String.format("%.1f", rem / 20.0)) + "s" : "   San sang");
                ctx.drawTextWithShadow(mc.textRenderer, sub, sw / 2 - mc.textRenderer.getWidth(sub) / 2, y + 24, rem > 0 ? 0xFFFFDD66 : 0xFF9AE6A0);
                String hint = "[R/F] doi skill   [Z] dung";
                ctx.drawTextWithShadow(mc.textRenderer, hint, sw / 2 - mc.textRenderer.getWidth(hint) / 2, y + 35, 0xFF999999);
            }
            int ty = y - 24;
            if (ClientData.domain > 0) ctx.drawTextWithShadow(mc.textRenderer, "DOMAIN EXPANSION  " + (ClientData.domain / 20) + "s", sx, ty, 0xFFFF6060);
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            while (menu.wasPressed()) {
                ClientPlayNetworking.send(new ActionPayload(2, 0, 0));
                client.setScreen(new SkillScreen());
            }
            if (client.currentScreen != null) {            // dang mo menu/chat: khong kich hoat skill
                while (cast.wasPressed()) { }
                while (next.wasPressed()) { }
                while (prev.wasPressed()) { }
                while (next2.wasPressed()) { }
                while (prev2.wasPressed()) { }
                return;
            }
            while (next.wasPressed() || next2.wasPressed()) ClientPlayNetworking.send(new ActionPayload(15, 1, 0));
            while (prev.wasPressed() || prev2.wasPressed()) ClientPlayNetworking.send(new ActionPayload(15, -1, 0));
            while (cast.wasPressed()) ClientPlayNetworking.send(new ActionPayload(17, 0, 0));
        });
    }
}
