package com.example.jjk;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.entity.mob.Monster;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * HE THONG CAP BAC (Grade) cho server: XP -> Grade 4 ... Special Grade.
 * Grade cao: nhieu chu luc toi da, hoi nhanh hon, sat thuong cao hon, mo khoa ky nang manh (gradeGate).
 * XP den tu giet chu linh (theo cap) va quai thuong. Luu o config/jjk-progress.properties. Chua test trong game.
 */
public class Progress {
    public static final String[] GRADES = {"Grade 4", "Grade 3", "Grade 2", "Semi-Grade 1", "Grade 1", "Special Grade"};
    public static final int[] NEED = {0, 100, 400, 1000, 2500, 6000};

    private static final Map<UUID, Integer> XP = new HashMap<>();
    private static final Map<UUID, String> NAME = new HashMap<>();
    private static boolean dirty = false;

    public static int xp(UUID id) { return XP.getOrDefault(id, 0); }

    public static int grade(UUID id) {
        int x = xp(id), g = 0;
        for (int i = 0; i < NEED.length; i++) if (x >= NEED[i]) g = i;
        return g;
    }

    /** moc XP cua grade ke tiep; 0 neu da toi da */
    public static int nextXp(UUID id) { int g = grade(id); return g + 1 < NEED.length ? NEED[g + 1] : 0; }

    public static int maxEnergy(UUID id) { return (int) Math.round(Config.maxEnergy * (1.0 + 0.25 * grade(id))); }
    public static double regenMult(UUID id) { return 1.0 + 0.15 * grade(id); }
    public static double dmgMult(UUID id) { return 1.0 + 0.08 * grade(id) + Fingers.dmgBonus(id); }

    /** grade toi thieu de dung ky nang, tinh theo chi phi chu luc */
    public static int required(Tech.T t) {
        if (t.domain()) return 4;
        int e = t.energy();
        return e <= 25 ? 0 : e <= 45 ? 1 : e <= 70 ? 2 : e <= 100 ? 3 : e <= 150 ? 4 : 5;
    }

    public static boolean canUse(MinecraftServer server, ServerPlayerEntity p, Tech.T t) {
        if (!Config.gradeGate || server.isSingleplayer() || p.isCreative()) return true;
        int need = required(t);
        if (grade(p.getUuid()) >= need) return true;
        p.sendMessage(Text.literal("Can " + GRADES[need] + " de dung " + t.en() + " (ban: " + GRADES[grade(p.getUuid())] + "). Giet chu linh de len cap!").formatted(Formatting.RED), true);
        return false;
    }

    public static void addXp(ServerPlayerEntity p, int amount) {
        if (amount <= 0 || p == null) return;
        UUID id = p.getUuid();
        int before = grade(id);
        XP.put(id, xp(id) + amount);
        NAME.put(id, p.getName().getString());
        dirty = true;
        int after = grade(id);
        if (after > before) {
            p.sendMessage(Text.literal("LEN CAP: " + GRADES[after] + "!  (chu luc toi da, hoi chu luc, sat thuong tang)").formatted(Formatting.GOLD), false);
            if (p.getEntityWorld() instanceof ServerWorld w) {
                Vec3d c = p.getEntityPos().add(0, 1, 0);
                Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
                for (int i = 0; i < 4; i++) Fx.ring(w, Fx.dust(0xFFD060, 1.4f), c.add(0, i * 0.5 - 0.5, 0), b[1], b[2], 1.0 + i * 0.25, 30, 0);
                Fx.snd(w, c, SoundEvents.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
            }
            Data.addEnergy(id, 1e9);
        }
    }

    static int killXp(Set<String> tags) {
        if (tags.contains("jjk_mahoraga")) return 800;
        if (tags.contains("jjk_sukuna")) return 600;
        if (tags.contains("jjk_mahito") || tags.contains("jjk_jogo") || tags.contains("jjk_hanami") || tags.contains("jjk_dagon")) return 200;
        if (tags.contains("jjk_special")) return 120;
        if (tags.contains("jjk_grade2")) return 30;
        if (tags.contains("jjk_spirit")) return 10;
        return 0;
    }

    // ---------- luu tru ----------
    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("jjk-progress.properties"); }

    public static void load() {
        try {
            if (!Files.exists(file())) return;
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(file())) { p.load(in); }
            for (String k : p.stringPropertyNames()) {
                try {
                    if (k.endsWith(".xp")) XP.put(UUID.fromString(k.substring(0, k.length() - 3)), Integer.parseInt(p.getProperty(k)));
                    else if (k.endsWith(".name")) NAME.put(UUID.fromString(k.substring(0, k.length() - 5)), p.getProperty(k));
                } catch (Exception ignored) { }
            }
        } catch (Exception e) { Safe.log("Progress.load", e); }
    }

    public static void save() {
        try {
            Properties p = new Properties();
            for (Map.Entry<UUID, Integer> e : XP.entrySet()) {
                p.setProperty(e.getKey() + ".xp", String.valueOf(e.getValue()));
                if (NAME.containsKey(e.getKey())) p.setProperty(e.getKey() + ".name", NAME.get(e.getKey()));
            }
            try (OutputStream out = Files.newOutputStream(file())) { p.store(out, "Jujutsu progress"); }
            dirty = false;
        } catch (Exception e) { Safe.log("Progress.save", e); }
    }

    // ---------- su kien + lenh ----------
    private static int say(ServerCommandSource s, String m) { s.sendFeedback(() -> Text.literal(m), false); return 1; }

    private static boolean admin(ServerCommandSource s) {
        ServerPlayerEntity p = s.getPlayer();
        return p == null || Admin.is(s.getServer(), p);
    }

    public static void register() {
        load();
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> save());
        ServerTickEvents.END_SERVER_TICK.register(s -> { if (dirty && s.getTicks() % 1200 == 0) Safe.run("Progress.save", Progress::save); });
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> Safe.run("Progress.kill", () -> {
            if (!(source.getAttacker() instanceof ServerPlayerEntity sp) || entity instanceof ServerPlayerEntity) return;
            int x = killXp(entity.getCommandTags());
            if (x == 0 && entity instanceof Monster) x = 2;
            if (x > 0) { addXp(sp, x); sp.sendMessage(Text.literal("+" + x + " XP").formatted(Formatting.YELLOW), true); }
        }));
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("jjk")
                .then(CommandManager.literal("grade").executes(c -> {
                    ServerPlayerEntity p = c.getSource().getPlayer();
                    if (p == null) return say(c.getSource(), "Chi nguoi choi moi co grade.");
                    UUID id = p.getUuid();
                    int n = nextXp(id);
                    return say(c.getSource(), "[jjk] " + GRADES[grade(id)] + " - " + xp(id) + " XP" + (n > 0 ? " (len cap tiep o " + n + ")" : " (toi da)")
                        + " | chu luc toi da " + maxEnergy(id));
                }))
                .then(CommandManager.literal("top").executes(c -> {
                    List<Map.Entry<UUID, Integer>> l = new ArrayList<>(XP.entrySet());
                    l.sort((a, b) -> b.getValue() - a.getValue());
                    StringBuilder sb = new StringBuilder("[jjk] BANG XEP HANG");
                    for (int i = 0; i < Math.min(10, l.size()); i++) {
                        UUID id = l.get(i).getKey();
                        sb.append("\n#").append(i + 1).append(' ').append(NAME.getOrDefault(id, "?")).append(" - ").append(GRADES[grade(id)]).append(" (").append(l.get(i).getValue()).append(" XP)");
                    }
                    return say(c.getSource(), sb.toString());
                }))
                .then(CommandManager.literal("givexp")
                    .then(CommandManager.argument("player", EntityArgumentType.player())
                        .then(CommandManager.argument("amount", IntegerArgumentType.integer(1, 1000000)).executes(c -> {
                            if (!admin(c.getSource())) return say(c.getSource(), "Ban khong co quyen.");
                            ServerPlayerEntity t = EntityArgumentType.getPlayer(c, "player");
                            addXp(t, IntegerArgumentType.getInteger(c, "amount"));
                            return say(c.getSource(), "[jjk] da cong XP cho " + t.getName().getString());
                        })))));
        });
    }
}
