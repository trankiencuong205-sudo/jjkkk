package com.example.jjk;

/**
 * Hoa tiet (tranh tuong) cho phong domain bang khoi that. Khong phu thuoc Minecraft nen kiem tra duoc rieng.
 * pick(style, dx, dy, dz, r, h): dx,dz in [-r,r]; dy = -1 (san) .. h (tran). Tra ve id khoi.
 * Cac "tranh" lon: so dau lau (Malevolent Shrine), 777 (Hakari), thien ha xoan oc tren tran (Unlimited Void).
 */
public class Painter {
    static int hash(int x, int y, int z, int s) {
        int h = x * 374761393 + y * 668265263 + z * 2147483647 + s * 1274126177;
        h = (h ^ (h >>> 13)) * 1274126177;
        return (h ^ (h >>> 16)) & 0x7fffffff;
    }

    static final String[] SKULL = {
            "...#########...",
            "..###########..",
            ".#############.",
            ".#############.",
            "##...##.##...##",
            "##...##.##...##",
            "##...##.##...##",
            ".#############.",
            "..####...####..",
            "...####.####...",
            "....#######....",
            "....#.#.#.#....",
            "....#.#.#.#....",
            ".....#####.....",
    };
    static final String[] SEVEN = {"#####", "....#", "...#.", "..#..", "..#..", "..#..", "..#.."};

    static boolean bit(String[] m, double u, double v, double sc) {      // u ngang, v doc (0 = tren cung)
        int x = (int) Math.floor(u / sc), y = (int) Math.floor(v / sc);
        return y >= 0 && y < m.length && x >= 0 && x < m[y].length() && m[y].charAt(x) == '#';
    }

    public static String pick(String style, int dx, int dy, int dz, int r, int h) {
        boolean floor = dy < 0, ceil = dy >= h, wall = !floor && !ceil;
        int n = hash(dx, dy, dz, 7) % 1000;
        double rho = Math.sqrt((double) dx * dx + (double) dz * dz) / r;
        // toa do ngang tren tuong
        int u = Math.abs(dx) == r ? dz : dx;
        boolean backWall = wall && Math.abs(dz) == r && Math.abs(dx) < r;
        switch (style == null ? "" : style) {
            case "void": {
                if (ceil) {
                    double th = Math.atan2(dz, dx), arm = Math.sin(th * 2 - rho * 5.0);
                    if (rho < 0.16) return "sea_lantern";
                    if (rho < 0.3 && n % 4 != 0) return "white_concrete";
                    if (arm > 0.1 && rho < 1.15 && (rho < 0.6 || n % 5 < 3)) {
                        if (rho < 0.3) return "white_concrete";
                        if (rho < 0.55) return "light_blue_concrete";
                        if (rho < 0.8) return "purple_concrete";
                        return "magenta_concrete";
                    }
                }
                if (n < 10) return "sea_lantern";
                if (n < 34) return "white_concrete";
                if (n < 50) return "light_blue_concrete";
                if (n < 62) return "purple_concrete";
                return "black_concrete";
            }
            case "shrine": {
                if (floor) {
                    int m = Math.max(Math.abs(dx), Math.abs(dz));
                    if (rho < 0.5) return ((dx + dz) & 1) == 0 ? "red_concrete" : "crimson_planks";
                    if (m == r - 2) return "red_concrete";
                    return ((dx / 2 + dz / 2) & 1) == 0 ? "black_concrete" : "polished_blackstone";
                }
                if (ceil) return n < 15 ? "red_concrete" : "black_concrete";
                double sv = h - 3 - dy;
                if (Math.abs(u) <= 14 && sv >= 0 && sv < SKULL.length * 2.0) return bit(SKULL, u + 15, sv, 2.0) ? "bone_block" : "black_concrete";
                if (Math.floorMod(u, 8) == 0 && dy < h - 2) return "red_concrete";
                if (dy >= h - 2) return "crimson_planks";
                return "black_concrete";
            }
            case "coffin": {
                double vein = Math.sin(dx * 0.45 + dy * 0.3) + Math.sin(dz * 0.5 - dy * 0.35);
                if (floor) return n % 5 < 3 ? "magma_block" : (n % 5 == 3 ? "shroomlight" : "blackstone");
                if (vein > 1.35) return "magma_block";
                if (n < 12) return "shroomlight";
                return n % 3 == 0 ? "basalt" : "blackstone";
            }
            case "garden": {
                double d = Math.sqrt((double) dx * dx + (double) dz * dz);
                if (floor || ceil) return ((int) (d * 1.1) % 3 == 0) ? "gray_concrete" : "black_concrete";
                if ((dy + u) % 7 == 0 && dy > 2) return "gray_concrete";
                return n < 25 ? "gray_concrete" : "black_concrete";
            }
            case "flesh": {
                if (floor) return n % 4 == 0 ? "pink_concrete" : "red_terracotta";
                if ((dx * 7 + dy * 13 + dz * 3) % 83 == 0) return "white_concrete";
                if (n < 140) return "pink_concrete";
                if (n < 380) return "red_terracotta";
                return "nether_wart_block";
            }
            case "gamble": {
                String[] neon = {"lime_concrete", "pink_concrete", "yellow_concrete", "cyan_concrete", "orange_concrete", "magenta_concrete"};
                if (floor) return ((dx + dz) & 1) == 0 ? "black_concrete" : "purple_concrete";
                if (ceil) return (Math.floorMod(dx, 4) == 0 && Math.floorMod(dz, 4) == 0) ? "sea_lantern" : "black_concrete";
                if (backWall) {                                  // 777 tren tuong
                    double sc = 1.3;
                    for (int k = 0; k < 3; k++) {
                        double uu = (u + 11.75) - k * 8.5;
                        if (bit(SEVEN, uu, h - 4 - dy, sc)) return k == 1 ? "yellow_concrete" : "red_concrete";
                    }
                    if (dy > h - 3 || dy < 2) return neon[Math.floorMod(u / 2, 6)];
                    return "black_concrete";
                }
                if (dy % 4 == 0) return neon[Math.floorMod(u / 3 + dy / 4, 6)];
                return "black_concrete";
            }
            case "court": {
                if (floor) {
                    if (Math.abs(dx) <= 1) return "red_concrete";
                    return ((dx + dz) & 1) == 0 ? "white_concrete" : "black_concrete";
                }
                if (ceil) return (Math.floorMod(dx, 6) == 0 && Math.floorMod(dz, 6) == 0) ? "sea_lantern" : "black_concrete";
                if (Math.floorMod(u, 6) == 0 && dy < h - 1) return "gold_block";
                if (dy >= h - 2) return "gold_block";
                return "gray_concrete";
            }
            case "love": {
                if (floor) return (((int) (rho * 6)) & 1) == 0 ? "light_blue_concrete" : "white_concrete";
                if (ceil) return rho < 0.1 ? "sea_lantern" : (((int) (rho * 8)) % 2 == 0 && rho < 0.9 ? "light_blue_concrete" : "white_concrete");
                if (Math.floorMod(u, 5) == 0 || dy % 6 == 0) return "light_blue_concrete";
                return "white_concrete";
            }
            default:
                return "black_concrete";
        }
    }
}
