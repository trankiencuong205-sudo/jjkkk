package com.example.jjk;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.UUID;

/** Cong kiem tra (nang luong, hoi chieu, quyen so huu) + cac ky thuat don gian. */
public class Abilities {
    private static void msg(ServerPlayerEntity p, String s, Formatting f) { p.sendMessage(Text.literal(s).formatted(f), true); }

    public static void cast(MinecraftServer server, ServerPlayerEntity p, Tech.T t) {
        UUID id = p.getUuid();
        if (!p.isAlive() || p.isSpectator()) return;
        ServerWorld w = Data.worldOf(server, p);
        if (w == null) return;
        if (!t.usedBy(Data.chara(id))) return;                      // server tu kiem tra, khong tin client

        if (t.toggle()) {
            if (Data.remaining(id, t.id()) > 0) return;
            Data.setCooldown(id, t.id(), Config.cd(t.cooldown()));
            java.util.Set<UUID> set = t.id().equals("infinity") ? Data.INFINITY : Data.REINFORCE;
            if (set.contains(id)) {
                set.remove(id);
                msg(p, t.en() + ": TAT", Formatting.GRAY);
                Fx.snd(w, p.getEntityPos(), SoundEvents.BLOCK_BEACON_DEACTIVATE, 0.7f, 1.6f);
            } else {
                if (Data.energy(id) < 10 && !Config.unlimited) { msg(p, "Khong du chu luc!", Formatting.RED); return; }
                set.add(id);
                msg(p, t.en() + ": BAT", Formatting.AQUA);
                Fx.snd(w, p.getEntityPos(), SoundEvents.BLOCK_BEACON_ACTIVATE, 0.7f, 1.9f);
                Vec3d c = p.getEntityPos().add(0, 1, 0);
                Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
                for (int i = 0; i < 3; i++) Fx.ring(w, Fx.dust(t.id().equals("infinity") ? 0x9FE8FF : 0x3A2A8A, 1.2f), c.add(0, i * 0.5 - 0.5, 0), b[1], b[2], 1.1 + i * 0.3, 30, 0);
            }
            return;
        }
        if (Data.remaining(id, t.id()) > 0) {
            msg(p, t.en() + ": hoi chieu " + String.format("%.1f", Data.remaining(id, t.id()) / 20.0) + "s", Formatting.YELLOW);
            return;
        }
        if (t.domain() && Data.domainActive(id)) { msg(p, "Domain dang mo!", Formatting.YELLOW); return; }
        if (!Progress.canUse(server, p, t)) return;
        int cost = Config.cost(t.energy());
        if (!Data.spend(id, cost)) { msg(p, "Khong du chu luc! Can " + cost + ", co " + (int) Data.energy(id), Formatting.RED); return; }
        Data.setCooldown(id, t.id(), Config.cd(t.cooldown()));
        msg(p, t.en() + "  " + t.jp(), Formatting.AQUA);

        Safe.run("Gesture", () -> Gesture.cast(w, p, t));
        dispatchFree(t.id(), w, p);
    }

    /** chay ky nang KHONG tinh chu luc/hoi chieu (dung cho Copy cua Yuta) */
    public static void dispatchFree(String id, ServerWorld w, ServerPlayerEntity p) {
        if (Canon.cast(id, w, p)) return;                 // ky nang viet rieng (ghi de ky nang cu cung id)
        Vis3D.cast(id, w, p);
        switch (id) {
            case "blue" -> GojoSkills.blue(w, p);
            case "red" -> GojoSkills.red(w, p);
            case "purple" -> GojoSkills.purple(w, p);
            case "unlimited_void" -> GojoSkills.unlimitedVoid(w, p);
            case "cleave" -> SukunaSkills.cleave(w, p);
            case "dismantle" -> SukunaSkills.dismantle(w, p);
            case "fire_arrow" -> SukunaSkills.fireArrow(w, p);
            case "malevolent_shrine" -> SukunaSkills.shrine(w, p);
            case "black_flash" -> blackFlash(w, p);
            case "rct" -> rct(w, p);
            default -> Stage2Skills.dispatch(id, w, p);
        }
    }

    // ---------- Infinity (moi tick khi dang bat) ----------
    public static void infinityTick(ServerWorld w, ServerPlayerEntity p) {
        Vec3d c = p.getEntityPos().add(0, p.getHeight() * 0.5, 0);
        for (LivingEntity e : Fx.hostiles(w, p, p.getBoundingBox().expand(3.0))) {
            Vec3d away = e.getEntityPos().subtract(p.getEntityPos());
            double d = Math.max(0.5, away.length());
            if (d < 2.8) {
                Vec3d a = new Vec3d(away.x, 0, away.z).normalize();
                e.addVelocity(a.x * 0.16, 0.0, a.z * 0.16);
            }
        }
        for (ProjectileEntity pr : w.getEntitiesByClass(ProjectileEntity.class, p.getBoundingBox().expand(5.0), x -> x.getOwner() != p)) {
            double d = pr.getEntityPos().distanceTo(c);
            double slow = Math.max(0.05, Math.min(1.0, (d - 1.0) / 4.0));
            pr.setVelocity(pr.getVelocity().multiply(slow));
        }
        if (Data.now % 3 == 0) {
            double t = Data.now * 0.08;
            Vec3d[] b = Fx.basis(new Vec3d(Math.cos(t), 0.4, Math.sin(t)));
            Fx.ring(w, Fx.dust(0xB8EEFF, 0.7f), c, b[1], b[2], 2.3, 18, t);
            Fx.pt(w, ParticleTypes.END_ROD, c.add(Fx.randDir().multiply(2.3)));
        }
    }

    public static void reinforceTick(ServerWorld w, ServerPlayerEntity p) {
        if (Data.now % 10 == 0) {
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 25, 0, true, false));
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 25, 0, true, false));
        }
        if (Data.now % 4 == 0) {
            Vec3d c = p.getEntityPos().add(Fx.rnd(-0.4, 0.4), Fx.rnd(0.1, 1.8), Fx.rnd(-0.4, 0.4));
            Fx.put(w, Fx.dust(0x2A1A6A, 0.9f), c, 1, 0.05, 0);
            Fx.put(w, Fx.dust(0x7A5CFF, 0.6f), c, 1, 0.05, 0);
        }
    }

    // ---------- Reverse Cursed Technique ----------
    private static void rct(ServerWorld w, ServerPlayerEntity p) {
        p.heal(8.0f);
        p.removeStatusEffect(StatusEffects.POISON);
        p.removeStatusEffect(StatusEffects.WITHER);
        Vec3d c = p.getEntityPos();
        Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
        for (int i = 0; i < 12; i++) {
            double h = i * 0.18;
            Fx.ring(w, Fx.dust(i % 2 == 0 ? 0x60FF9A : 0xD8FFE8, 1.0f), c.add(0, h, 0), b[1], b[2], 0.9 - i * 0.03, 14, i * 0.5);
        }
        Fx.put(w, ParticleTypes.HAPPY_VILLAGER, c.add(0, 1, 0), 12, 0.5, 0);
        Fx.snd(w, c, SoundEvents.ENTITY_PLAYER_LEVELUP, 0.6f, 1.7f);
    }

    // ---------- Black Flash ----------
    private static void blackFlash(ServerWorld w, ServerPlayerEntity p) {
        UUID id = p.getUuid();
        Vec3d eye = p.getEyePos(), look = p.getRotationVec(1.0f);
        LivingEntity target = null;
        double best = 99;
        for (LivingEntity e : Fx.hostiles(w, p, new Box(eye, eye.add(look.multiply(6))).expand(1.3))) {
            double d = e.getEntityPos().distanceTo(p.getEntityPos());
            if (d < best) { best = d; target = e; }
        }
        // lao toi
        Vec3d from = p.getEntityPos();
        if (target != null) {
            Vec3d to = target.getEntityPos().subtract(look.multiply(1.1));
            p.requestTeleport(to.x, to.y, to.z);
        } else {
            Vec3d d = new Vec3d(look.x, 0, look.z);
            if (d.lengthSquared() > 1.0E-4) { d = d.normalize().multiply(3.0); p.requestTeleport(from.x + d.x, from.y, from.z + d.z); }
        }
        for (double k = 0; k < from.distanceTo(p.getEntityPos()); k += 0.4) {
            Vec3d v = from.add(p.getEntityPos().subtract(from).normalize().multiply(k)).add(0, 1, 0);
            Fx.put(w, Fx.dust(0x201020, 1.3f), v, 1, 0.1, 0);
        }
        if (target == null) { Fx.snd(w, p.getEntityPos(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 0.8f); return; }

        int zone = Data.FLASH_ZONE.getOrDefault(id, 0);
        boolean inZone = zone > Data.now;
        double chance = inZone ? 0.65 : 0.18 + 0.08 * Math.min(3, Data.FLASH_STREAK.getOrDefault(id, 0));
        boolean flash = Fx.rnd() < chance;
        Vec3d hit = Fx.mid(target);
        if (!flash) {
            Fx.hurt(w, p, target, 8.0f);
            Data.FLASH_STREAK.put(id, 0);
            Fx.put(w, ParticleTypes.CRIT, hit, 12, 0.4, 0.2);
            Fx.snd(w, hit, SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, 1f, 0.9f);
            return;
        }
        int streak = Data.FLASH_STREAK.getOrDefault(id, 0) + 1;
        Data.FLASH_STREAK.put(id, streak);
        Fx.hurt(w, p, target, 20.0f);
        Vec3d kb = target.getEntityPos().subtract(p.getEntityPos()).normalize();
        target.addVelocity(kb.x * 1.4, 0.35, kb.z * 1.4);
        if (streak >= 2) {
            Data.FLASH_ZONE.put(id, Data.now + 160);
            p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 160, 1));
            msg(p, "ZONE!  (Black Flash x" + streak + ")", Formatting.GOLD);
        } else msg(p, "BLACK FLASH!", Formatting.DARK_RED);
        // tia set den-do toa ra + song xung kich den
        for (int i = 0; i < 9; i++) {
            Vec3d end = hit.add(Fx.randDir().multiply(Fx.rnd(2.5, 5.0)));
            Fx.bolt(w, Fx.dust(i % 3 == 0 ? 0xFF1A1A : 0x120008, 1.2f), hit, end, 0.6, 0.35);
        }
        Vec3d[] b = Fx.basis(kb);
        for (int r = 1; r <= 3; r++) {
            Fx.ring(w, Fx.dust(0x0A0008, 1.6f), hit, b[1], b[2], r * 0.9, 24 + r * 6, 0);
            Fx.ring(w, Fx.dust(0xFF2020, 1.0f), hit, b[1], b[2], r * 0.9 + 0.2, 24 + r * 6, 0.3);
        }
        Fx.put(w, ParticleTypes.EXPLOSION, hit, 1, 0, 0);
        Safe.run("Terrain.crater", () -> Terrain.crater(w, hit, 2.6 + streak * 0.6, 60));
        Vis3D.blackFlash(w, hit);
        Fx.put(w, ParticleTypes.ELECTRIC_SPARK, hit, 20, 0.8, 0.3);
        Fx.snd(w, hit, SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT, 1.2f, 1.4f);
        Fx.snd(w, hit, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 0.8f, 1.3f);
    }
}
