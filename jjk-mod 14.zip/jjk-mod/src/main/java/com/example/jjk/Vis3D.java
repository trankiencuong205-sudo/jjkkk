package com.example.jjk;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Lop hinh 3D (block_display) cho cac ky nang con lai: dung chung ham tien ich + chay song song voi ky nang cu
 * (cung huong ngam / muc tieu) de moi chieu deu co hinh khoi that, khong chi hat. Tat ca bi tat khi Config.displays = false.
 */
public class Vis3D {
    // ---------- tien ich ----------
    interface Step { void run(); }

    /** chay sau n tick */
    static void later(int n, Step s) {
        Anims.add(new Anims.Anim() {
            int t = 0;
            public boolean tick() { if (++t >= n) { s.run(); return true; } return false; }
        });
    }

    /** khoi vuong co dinh, thu nho ve ~0 trong ttl tick */
    static Disp.H pulseShrink(ServerWorld w, Vec3d pos, String block, double size, int ttl) {
        Disp.H h = Disp.block(w, pos, block, size, size, size, Disp.Q.ID, ttl + 2);
        h.set(Disp.Q.ID, 0.02, 0.02, 0.02, ttl);
        return h;
    }

    /** khoi vuong nho phinh to ra roi bien mat */
    static Disp.H pulseGrow(ServerWorld w, Vec3d pos, String block, double from, double to, int ttl) {
        Disp.H h = Disp.block(w, pos, block, from, from, from, Disp.Q.ID, ttl + 2);
        h.set(Disp.Q.ID, to, to, to, ttl);
        return h;
    }

    /** tam phang mong huong theo `normal` */
    static Disp.H plate(ServerWorld w, Vec3d pos, Vec3d normal, String block, double w0, double w1, int ttl) {
        Disp.Q q = Disp.Q.fromTo(new Vec3d(0, 0, 1), normal.normalize());
        Disp.H h = Disp.block(w, pos, block, w0, w0, 0.06, q, ttl + 2);
        h.set(q, w1, w1, 0.06, ttl);
        return h;
    }

    /** tia set 3D: chuoi doan gap khuc */
    public static void bolt(ServerWorld w, Vec3d a, Vec3d b, double thick, int ttl) {
        if (!Config.displays) return;
        int n = 7;
        Vec3d d = b.subtract(a);
        Vec3d[] bs = Fx.basis(d.lengthSquared() < 1e-6 ? new Vec3d(0, 1, 0) : d.normalize());
        Vec3d prev = a;
        double jit = Math.min(0.7, d.length() * 0.08);
        for (int i = 1; i <= n; i++) {
            Vec3d pt = a.add(d.multiply(i / (double) n));
            if (i < n) pt = pt.add(bs[1].multiply(Fx.rnd(-jit, jit))).add(bs[2].multiply(Fx.rnd(-jit, jit)));
            new Disp.Beam(w, prev, pt, "white_concrete", null, thick, ttl);
            new Disp.Beam(w, prev, pt, "light_blue_stained_glass", null, thick * 2.8, ttl);
            prev = pt;
        }
    }

    public static void panel(ServerWorld w, Vec3d pos, Vec3d look, String block, double size, int ttl) {
        if (!Config.displays) return;
        plate(w, pos, look, block, size * 0.3, size, ttl);
    }

    public static void blackHole(ServerWorld w, Vec3d c) {
        if (!Config.displays) return;
        pulseShrink(w, c, "purple_stained_glass", 5.0, 14);
        pulseShrink(w, c, "black_concrete", 2.4, 14);
    }

    public static void blackFlash(ServerWorld w, Vec3d hit) {
        if (!Config.displays) return;
        for (int i = 0; i < 8; i++) {
            Vec3d end = hit.add(Fx.randDir().multiply(Fx.rnd(2.5, 5.0)));
            new Disp.Beam(w, hit, end, "black_concrete", "red_concrete", 0.24, 8);
        }
        pulseGrow(w, hit, "black_stained_glass", 0.5, 4.0, 8);
        pulseGrow(w, hit, "red_stained_glass", 0.3, 2.5, 8);
    }

    // ---------- toggle Infinity: vo tinh the bao quanh ----------
    private static final Map<UUID, Disp.Orb> INF = new HashMap<>();
    private static int tickN = 0;

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> Safe.run("Vis3D.tick", () -> {
            tickN++;
            if (!Config.displays) { for (Disp.Orb o : INF.values()) o.kill(); INF.clear(); return; }
            if (tickN % 3 != 0) return;
            List<UUID> seen = new ArrayList<>();
            for (ServerWorld w : server.getWorlds()) for (ServerPlayerEntity p : w.getPlayers()) {
                UUID id = p.getUuid();
                if (!Data.INFINITY.contains(id) || !p.isAlive()) continue;
                seen.add(id);
                Vec3d c = p.getEntityPos().add(0, 1.0, 0);
                Disp.Orb o = INF.get(id);
                if (o == null) { o = new Disp.Orb(w, c, "light_blue_stained_glass", null, null, 3.0, 24000); INF.put(id, o); }
                o.update(c, tickN * 0.03, 1.0, true);
            }
            for (java.util.Iterator<Map.Entry<UUID, Disp.Orb>> it = INF.entrySet().iterator(); it.hasNext(); ) {
                Map.Entry<UUID, Disp.Orb> e = it.next();
                if (!seen.contains(e.getKey())) { e.getValue().kill(); it.remove(); }
            }
        }));
    }

    // ---------- dispatch: chay truoc ky nang cu ----------
    public static void cast(String id, ServerWorld w, ServerPlayerEntity p) {
        if (!Config.displays) return;
        Vec3d eye = p.getEyePos(), look = p.getRotationVec(1f), mid = p.getEntityPos().add(0, 1, 0);
        switch (id) {
            case "boogie_woogie" -> {
                LivingEntity t = Stage2Skills.aim(w, p, 25);
                if (t == null) return;
                Vec3d a = mid, b = Fx.mid(t);
                for (Vec3d v : new Vec3d[]{a, b}) { pulseShrink(w, v, "white_stained_glass", 2.2, 10); pulseShrink(w, v, "cyan_concrete", 0.9, 8); }
                new Disp.Beam(w, a, b, "white_concrete", "cyan_stained_glass", 0.12, 6);
            }
            case "ratio" -> {
                LivingEntity t = Stage2Skills.aim(w, p, 5.5);
                if (t == null) return;
                Vec3d c = t.getEntityPos().add(0, t.getHeight() * 0.7, 0);
                plate(w, c, new Vec3d(0, 1, 0), "white_concrete", 0.3, 2.4, 12);
                plate(w, c.add(0, 0.02, 0), new Vec3d(0, 1, 0), "red_stained_glass", 0.3, 3.0, 12);
                Disp.Q q = Disp.Q.ID;
                Disp.H h = Disp.block(w, Fx.mid(t), "gold_block", 0.05, t.getHeight() * 1.3, 0.05, q, 14);
                h.set(q, 0.05, 0.01, 0.05, 12);
            }
            case "overtime" -> follow(w, p, 100, 6, "orange_stained_glass", 0.3, 2.4, 1.3, 0.12, 0);
            case "heavenly_restriction" -> follow(w, p, 120, 10, "black_concrete", 0.22, 0.22, 1.0, 0.25, 0.1);
            case "resonance" -> {
                LivingEntity t = Stage2Skills.aim(w, p, 18);
                if (t != null) doll(w, t);
            }
            case "hairpin" -> {
                for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(32), x -> Stage2Skills.MARKS.getOrDefault(x.getUuid(), 0) > Data.now)) {
                    new Disp.Beam(w, eye, Fx.mid(e), "iron_block", "white_concrete", 0.14, 8);
                    Vec3d m = Fx.mid(e);
                    later(4, () -> { pulseGrow(w, m, "red_stained_glass", 0.5, 4.0, 8); pulseGrow(w, m, "orange_concrete", 0.3, 1.8, 8); });
                }
            }
            case "supernova" -> supernova(w, p);
            case "idle_transfig" -> {
                LivingEntity t = Stage2Skills.aim(w, p, 6);
                if (t != null) transfig(w, t);
            }
            case "speech_stop" -> {
                for (int k = 0; k < 3; k++) { final int kk = k; later(k * 3 + 1, () -> plate(w, mid.add(0, 0.2, 0), new Vec3d(0, 1, 0), "white_stained_glass", 1.0, 24.0, 10)); }
            }
            case "speech_blast" -> {
                for (int k = 0; k < 5; k++) { final int kk = k; later(k * 2 + 1, () -> plate(w, eye.add(look.multiply(1.5 + kk * 2.0)), look, "white_stained_glass", 1.2, 3.0 + kk * 1.3, 7)); }
            }
            case "speech_explode" -> {
                LivingEntity t = Stage2Skills.aim(w, p, 20);
                Vec3d c = t != null ? Fx.mid(t) : Stage2Skills.rayEnd(w, p, 20);
                pulseGrow(w, c, "white_stained_glass", 0.5, 7.0, 8);
                pulseGrow(w, c, "light_blue_concrete", 0.3, 2.5, 8);
            }
            case "inverted_spear" -> spear(w, p);
            case "playful_cloud" -> {
                Vec3d fl = new Vec3d(look.x, 0, look.z);
                if (fl.lengthSquared() < 1e-4) return;
                fl = fl.normalize();
                for (int k = 0; k < 6; k++) {
                    final int kk = k; final Vec3d f0 = fl;
                    later(k + 1, () -> {
                        Vec3d radial = Domains.rotY(f0, -1.3 + kk * 0.52);
                        Vec3d u = new Vec3d(-radial.z, 0, radial.x);
                        Vec3d c = mid.add(radial.multiply(2.8));
                        new Disp.Crescent(w, c, u, radial, 3.0, 0.5, 0.35, "white_concrete", 8, 5);
                        new Disp.Crescent(w, c, u, radial, 3.2, 0.55, 0.9, "gray_stained_glass", 8, 6);
                    });
                }
            }
            case "rct" -> {
                pulseGrow(w, mid, "lime_stained_glass", 0.6, 2.8, 14);
                pulseGrow(w, mid, "emerald_block", 0.2, 0.9, 14);
            }
            default -> { }
        }
    }

    /** k vat the quay quanh nguoi choi trong ttl tick (tru / hat xoan oc) */
    static void follow(ServerWorld w, ServerPlayerEntity p, int ttl, int k, String block, double sx, double sy, double radius, double speed, double rise) {
        List<Disp.H> hs = new ArrayList<>();
        for (int i = 0; i < k; i++) hs.add(Disp.block(w, p.getEntityPos(), block, sx, sy, sx, Disp.Q.ID, ttl + 4));
        Anims.add(new Anims.Anim() {
            int t = 0;
            public boolean tick() {
                t++;
                if (t > ttl || p.isRemoved() || !p.isAlive()) { for (Disp.H h : hs) h.kill(); return true; }
                if (t % 2 == 0) for (int i = 0; i < hs.size(); i++) {
                    double a = t * speed + i * Math.PI * 2 / hs.size();
                    double y = rise > 0 ? ((t * 0.08 + i * 0.35) % 2.2) : sy / 2;
                    hs.get(i).move(p.getEntityPos().add(Math.cos(a) * radius, y, Math.sin(a) * radius));
                }
                return false;
            }
        });
    }

    /** bu nhin rom + dinh sat gan vao muc tieu 8 giay */
    static void doll(ServerWorld w, LivingEntity t) {
        Disp.H body = Disp.block(w, t.getEntityPos(), "hay_block", 0.38, 0.55, 0.22, Disp.Q.ID, 170);
        Disp.H head = Disp.block(w, t.getEntityPos(), "hay_block", 0.24, 0.24, 0.24, Disp.Q.ID, 170);
        Disp.Q tilt = Disp.Q.axis(0, 0, 1, 0.6);
        Disp.H nail = Disp.block(w, t.getEntityPos(), "iron_block", 0.06, 0.75, 0.06, tilt, 170);
        Disp.H nailHead = Disp.block(w, t.getEntityPos(), "gray_concrete", 0.16, 0.06, 0.16, tilt, 170);
        Anims.add(new Anims.Anim() {
            int n = 0;
            public boolean tick() {
                n++;
                if (n > 160 || !t.isAlive() || Stage2Skills.MARKS.getOrDefault(t.getUuid(), 0) <= Data.now) { body.kill(); head.kill(); nail.kill(); nailHead.kill(); return true; }
                if (n % 2 == 0) {
                    Vec3d c = t.getEntityPos().add(0.6, t.getHeight() * 0.9 + Math.sin(n * 0.2) * 0.08, 0);
                    body.move(c); head.move(c.add(0, 0.42, 0)); nail.move(c); nailHead.move(c.add(-0.2, 0.34, 0));
                }
                return false;
            }
        });
    }

    static void transfig(ServerWorld w, LivingEntity t) {
        Disp.Orb o = new Disp.Orb(w, Fx.mid(t), "magenta_stained_glass", "pink_concrete", null, 1.8, 50);
        Anims.add(new Anims.Anim() {
            int n = 0;
            public boolean tick() {
                n++;
                if (n > 40 || !t.isAlive()) { o.kill(); return true; }
                o.update(Fx.mid(t), n * 0.25, 1.0 + 0.3 * Math.sin(n * 0.6), n % 2 == 0);
                return false;
            }
        });
    }

    static void supernova(ServerWorld w, ServerPlayerEntity p) {
        Vec3d eye = p.getEyePos();
        Vec3d end = Stage2Skills.rayEnd(w, p, 22);
        List<Disp.Orb> orbs = new ArrayList<>();
        for (int i = 0; i < 7; i++) orbs.add(new Disp.Orb(w, eye, "red_stained_glass", "redstone_block", null, 0.7, 40));
        Vec3d[] b = Fx.basis(p.getRotationVec(1f));
        Anims.add(new Anims.Anim() {
            int t = 0;
            public boolean tick() {
                t++;
                if (t > 26) {
                    for (Disp.Orb o : orbs) o.kill();
                    pulseGrow(w, end, "red_stained_glass", 0.5, 5.0, 8);
                    return true;
                }
                for (int i = 0; i < orbs.size(); i++) {
                    double ang = i * Math.PI * 2 / 7 + t * 0.2;
                    Vec3d ring = eye.add(b[0].multiply(1.5)).add(b[1].multiply(Math.cos(ang) * 1.3)).add(b[2].multiply(Math.sin(ang) * 1.3));
                    Vec3d pos;
                    if (t <= 10) pos = ring;
                    else {
                        double k = (t - 10) / 16.0;
                        Vec3d arc = new Vec3d(0, Math.sin(k * Math.PI) * 1.5 * Math.cos(i), 0);
                        pos = ring.add(end.subtract(ring).multiply(k * k)).add(arc);
                    }
                    orbs.get(i).update(pos, t * 0.3, 1.0, t % 2 == 0);
                }
                return false;
            }
        });
    }

    static void spear(ServerWorld w, ServerPlayerEntity p) {
        Vec3d eye = p.getEyePos().add(0, -0.3, 0), look = p.getRotationVec(1f).normalize();
        Disp.Q q = Disp.Q.fromTo(new Vec3d(0, 0, 1), look);
        Disp.H shaft = Disp.block(w, eye, "black_concrete", 0.1, 0.1, 2.6, q, 14);
        Disp.H blade = Disp.block(w, eye, "iron_block", 0.18, 0.36, 0.9, q, 14);
        Disp.H guard = Disp.block(w, eye, "gold_block", 0.35, 0.12, 0.12, q, 14);
        Anims.add(new Anims.Anim() {
            int t = 0;
            public boolean tick() {
                t++;
                if (t > 10) { shaft.kill(); blade.kill(); guard.kill(); return true; }
                double ext = t <= 4 ? 0.6 + t * 0.7 : Math.max(0.3, 3.4 - (t - 4) * 0.5);
                Vec3d base = eye.add(look.multiply(ext));
                shaft.move(base); blade.move(base.add(look.multiply(1.5))); guard.move(base.add(look.multiply(1.0)));
                return false;
            }
        });
    }
}
