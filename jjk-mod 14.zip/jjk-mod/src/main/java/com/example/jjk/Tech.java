package com.example.jjk;

import java.util.ArrayList;
import java.util.List;

/** Danh muc ky thuat. status: trung thuc, chua co ban nao duoc test trong game. */
public class Tech {
    public enum Chara {
        GOJO("Satoru Gojo", "Limitless + Six Eyes", 0x6FD0FF),
        SUKUNA("Ryomen Sukuna", "Cleave / Dismantle / Fuga / Malevolent Shrine", 0xFF4A4A),
        YUJI("Yuji Itadori", "Cursed Energy + Black Flash", 0xFF9A3A),
        MEGUMI("Megumi Fushiguro", "Ten Shadows", 0x5A6A9A),
        TODO("Aoi Todo", "Boogie Woogie + Black Flash", 0xC09060),
        NANAMI("Kento Nanami", "Ratio Technique", 0xE0C060),
        NOBARA("Nobara Kugisaki", "Straw Doll Technique", 0xD07080),
        CHOSO("Choso", "Blood Manipulation", 0xB01830),
        JOGO("Jogo", "Disaster Flames", 0xFF6A20),
        MAHITO("Mahito", "Idle Transfiguration", 0x8A5AC0),
        INUMAKI("Toge Inumaki", "Cursed Speech", 0xE8E8F0),
        YUTA("Yuta Okkotsu", "Rika", 0x90B8FF),
        TOJI("Toji Fushiguro", "Heavenly Restriction", 0x909098),
        HAKARI("Kinji Hakari", "Idle Death Gamble", 0xFF40D0),
        HIGURUMA("Hiromi Higuruma", "Judgeman", 0xE0C040),
        KASHIMO("Hajime Kashimo", "Lightning", 0x40C0FF),
        MAKI("Maki Zenin", "Heavenly Restriction (cursed tools)", 0x4AA070),
        KENJAKU("Kenjaku", "Cursed Spirit Manipulation", 0x9A60C0);
        public final String title, desc; public final int color;
        Chara(String t, String d, int c) { title = t; desc = d; color = c; }
        public String shortName() { String n = name(); return n.charAt(0) + n.substring(1).toLowerCase(); }
    }

    public static final String UNTESTED = "Da viet, CHUA test trong game";

    /** kind: toggle / instant / charge / domain */
    public record T(String id, String en, String jp, int energy, int cooldown, double damage, String kind, String desc, String status, Chara... users) {
        public boolean toggle() { return kind.equals("toggle"); }
        public boolean domain() { return kind.equals("domain"); }
        public boolean usedBy(Chara c) { for (Chara u : users) if (u == c) return true; return false; }
    }

    public static final List<T> ALL = new ArrayList<>();

    static void add(String id, String en, String jp, int energy, int cd, double dmg, String kind, String desc, String status, Chara... users) {
        T t = new T(id, en, jp, energy, cd, dmg, kind, desc, status, users);
        for (int i = 0; i < ALL.size(); i++) if (ALL.get(i).id().equals(id)) { ALL.set(i, t); return; }     // trung id: thay the tai cho (ghi de)
        ALL.add(t);
    }

    static {
        Chara G = Chara.GOJO, S = Chara.SUKUNA, Y = Chara.YUJI;
        add("infinity", "Infinity", "無下限", 0, 20, 0, "toggle",
                "Bat/tat. Chan moi don danh vat ly va dan (co ke tan cong). Quai bi day ra, dan bi lam cham.\nTon 4 nang luong/giay. Khong chan lua, roi, doc.",
                UNTESTED + " (dan bi cham = do server, client co the thay giat)", G);
        add("blue", "Cursed Technique Lapse: Blue", "術式順転「蒼」", 40, 80, 3, "instant",
                "Tao qua cau hut dat truoc mat 50 tick: keo moi quai trong 8 o ve tam, nghien nat 3 st moi 8 tick.\nCuoi cung no tung xung noi.",
                UNTESTED, G);
        add("red", "Cursed Technique Reversal: Red", "術式反転「赫」", 55, 100, 16, "instant",
                "Ban cau do day lui: no khi cham, bung song xung kich ban kinh 7, hat tung moi thu ra ngoai.\nKhong pha khoi dat.",
                UNTESTED, G);
        add("purple", "Secret Technique: Hollow Purple", "茈", 150, 400, 45, "charge",
                "Hai qua Blue va Red hoi tu trong 1.8s thanh qua cau tim, bay 60 o, xuyen moi quai (45 st).\nBat 'purpleErasesBlocks' trong config de xoa dia hinh (mac dinh TAT).",
                UNTESTED, G);
        add("unlimited_void", "Domain Expansion: Unlimited Void", "領域展開「無量空処」", 300, 1800, 2, "domain",
                "Ban kinh 14. Mo rong vo cau thien ha; moi quai ben trong bi cam (khong di chuyen duoc, yeu di), chiu 'qua tai thong tin' 2 st/s.\n10 giay. Chua co: dam doi dien tich (domain clash), moi truong 3D that.",
                UNTESTED + " (hieu ung hat, khong thay doi bau troi/dia hinh)", G);

        add("cleave", "Cleave", "捌", 35, 40, 12, "instant",
                "Nhat chem lon tam 9 o: sat thuong tang theo mau toi da cua muc tieu (6 + 25% mau toi da, toi da 60).",
                UNTESTED, S);
        add("dismantle", "Dismantle", "解", 20, 20, 6, "instant",
                "Loat 5 luoi chem mong bay lien tiep theo quat hinh quat, moi luoi 6 st, tam ~19 o.\nTrung lap, khong xuyen khoi.",
                UNTESTED, S);
        add("fire_arrow", "Fire Arrow", "開 (Fuga)", 90, 160, 30, "charge",
                "Vong lua trieu hoi mui ten lua (14 tick) roi ban di 2.2 o/tick. No ban kinh 7: 30 st, chay 8s.\nKhong dot khoi.",
                UNTESTED, S);
        add("malevolent_shrine", "Domain Expansion: Malevolent Shrine", "領域展開「伏魔御廚子」", 300, 2400, 4, "domain",
                "Ban kinh 16, khong co hang rao. Den tho (xuong + so lau) dung len bang hat; moi quai trong vung bi chem lien tuc.\n8 giay. Chua co: khoi that, domain clash.",
                UNTESTED + " (den tho la hat, khong phai khoi)", S);

        add("black_flash", "Black Flash", "黒閃", 25, 60, 8, "instant",
                "Dam lao toi muc tieu gan nhat (<=6 o). Co co hoi 'Black Flash': sat thuong x2.5, tia set den-do.\nThanh cong lien tuc se vao 'Zone' (Strength II 8s, ti le tang).",
                UNTESTED, Y);


        // ================= GIAI DOAN 2 =================
        Chara ME = Chara.MEGUMI, TO = Chara.TODO, NA = Chara.NANAMI, NO = Chara.NOBARA, CH = Chara.CHOSO,
              JO = Chara.JOGO, MA = Chara.MAHITO, IN = Chara.INUMAKI, YU = Chara.YUTA, TJ = Chara.TOJI;
        String U2 = UNTESTED + " (giai doan 2)";
        add("nue", "Nue", "鵺", 60, 120, 18, "instant", "Trieu hoi chim Nue bay vong len roi sa xuong diem ngam; set danh ban kinh 5 (18 st, lam cham).\nChim la hoat anh hat, khong phai mob that.", U2, ME);
        add("toad", "Toad", "蝦蟇", 35, 60, 4, "instant", "Luoi ech phong toi muc tieu (14 o) va keo no ve phia ban.", U2, ME);
        add("great_serpent", "Great Serpent", "大蛇", 55, 140, 14, "instant", "Ran bong lon luon qua theo duong zigzag, xuyen nhieu quai (14 st, lam cham).\nRan la hoat anh hat.", U2, ME);
        add("boogie_woogie", "Boogie Woogie", "不義遊戯", 30, 40, 0, "instant", "Vo tay: doi cho voi quai trong tam nhin (25 o).", U2, TO);
        add("ratio", "Ratio Technique (7:3)", "十劃呪法", 40, 60, 12, "instant", "Chia than muc tieu 7:3, danh trung diem yeu: 12 + 12% mau toi da. Tam 5.5 o.", U2, NA);
        add("overtime", "Overtime", "残業", 50, 400, 0, "instant", "12 giay Strength II + Speed II + Resistance I, sau do kiet suc 10 giay.", U2, NA);
        add("resonance", "Straw Doll: Resonance", "共鳴り", 30, 50, 6, "instant", "Dong dinh len muc tieu (6 st) va danh dau trong 8 giay.", U2, NO);
        add("hairpin", "Hairpin", "簪", 50, 100, 20, "instant", "Kich no moi muc tieu dang bi Resonance trong 32 o (20 st + no lan).", U2, NO);
        add("piercing_blood", "Piercing Blood", "穿血", 55, 120, 22, "instant", "Nen mau roi ban tia mau xuyen 45 o (22 st).", U2, CH);
        add("supernova", "Supernova", "苅祓", 70, 160, 9, "instant", "Chum 7 cau mau bay cong roi no (9 st moi qua).", U2, CH);
        add("meteor", "Maximum: Meteor", "極ノ番「隕」", 120, 500, 40, "instant", "Thien thach lua roi tu tren cao, vong canh bao thu nho. No ban kinh 9 (40 st, chay 10s). Khong pha khoi.", U2, JO);
        add("coffin", "Domain Expansion: Coffin of the Iron Mountain", "領域展開「蓋棺鉄囲山」", 300, 2400, 5, "domain", "Nui lua hinh non bang hat: quai trong ban kinh 15 bi chay va 5 st/0.5s.\nChua co: domain clash, khoi that.", U2, JO);
        add("idle_transfig", "Idle Transfiguration", "無為転変", 70, 160, 20, "instant", "Cham muc tieu (<=6 o): 30% mau toi da (toi da 60) + Weakness/Slowness/Nausea.", U2, MA);
        add("speech_stop", "Cursed Speech: Stop", "止まれ", 40, 160, 0, "instant", "Quai trong 12 o gan nhu dung yen 5 giay.", U2, IN);
        add("speech_blast", "Cursed Speech: Blast Away", "吹っ飛べ", 35, 100, 5, "instant", "Hat bay moi quai o hinh quat truoc mat (10 o).", U2, IN);
        add("speech_explode", "Cursed Speech: Explode", "爆ぜろ", 60, 140, 18, "instant", "No muc tieu tai cho (tam 20 o), ban kinh 3.5.", U2, IN);
        add("rika_beam", "Rika: Cursed Energy Beam", "リカ・呪力砲", 100, 260, 35, "instant", "Nap nang luong 16 tick roi ban tia khong lo xuyen 40 o (35 st).", U2, YU);
        add("rika_manifest", "Rika Manifestation", "完全顕現", 80, 600, 8, "instant", "20 giay: bong Rika khong lo sau lung, tan cong quai gan (8 st/1.5s), Strength II + Resistance II.\nBong la hoat anh hat.", U2, YU);
        add("heavenly_restriction", "Heavenly Restriction", "天与呪縛", 0, 1200, 0, "instant", "30 giay Strength III + Speed III + Resistance I. Khong ton chu luc.", U2, TJ, Chara.MAKI);
        add("inverted_spear", "Inverted Spear of Heaven", "天逆鉾", 25, 100, 10, "instant", "Dam trung (<=4.5 o): 10 st va xoa moi hieu ung cua muc tieu.", U2, TJ, Chara.MAKI);
        add("playful_cloud", "Playful Cloud", "游雲", 20, 80, 16, "instant", "Vung quet nang 180 do ban kinh 4: 16 st, hat tung.", U2, TJ, Chara.MAKI);

        // ================= GIAI DOAN 3: domain co hinh anh + nhan vat moi =================
        String U3 = UNTESTED + " (giai doan 3)";
        add("divine_dogs", "Divine Dogs", "玉犬", 50, 200, 20, "instant",
                "Trieu hoi 2 chu cho 3D (Trang & Den). Chung chay ve phia quai gan nhat va can 5 st moi 0.5s trong 7 giay; neu khong co quai thi chay theo ban.", U3, Chara.MEGUMI);
        add("max_elephant", "Max Elephant", "満象", 90, 400, 30, "instant",
                "Con voi nuoc khong lo 3D xuat hien truoc mat, phun tia nuoc doi dien 11 o trong 2.5s: 3.5 st / 0.25s, day lui, lam cham.", U3, Chara.MEGUMI);
        add("rabbit_escape", "Rabbit Escape", "脱兎", 40, 300, 0, "instant",
                "12 con tho 3D nhay quanh ban 5 giay; ban Invisibility + Speed III, quai trong 10 o bi mu 4 giay.", U3, Chara.MEGUMI);
        add("round_deer", "Round Deer", "円鹿", 70, 400, 0, "instant",
                "Con huou 3D hoi 8 mau ngay + hoi them cho moi nguoi trong 9 o trong 4 giay (Regen II).", U3, Chara.MEGUMI);
        add("piercing_ox", "Piercing Ox", "穿牛", 60, 200, 20, "instant",
                "Con bo 3D lao thang ve phia truoc toi 18 o, hat tung + 20 st moi quai bi dam.", U3, Chara.MEGUMI);
        add("tiger_funeral", "Tiger Funeral", "虎葬", 100, 400, 30, "instant",
                "Hum 3D nhay tu ben canh vot len quai gan nhat: 30 st, chay, vet cao 3 lan.", U3, Chara.MEGUMI);
        add("mahoraga_summon", "Eight-Handled Sword Divergent Sila Divine General Mahoraga", "八握剣異戒神将魔虚羅", 250, 2400, 18, "instant",
                "Trieu hoi Mahoraga 3D (banh xe thich ung tren lung, thanh kiem) 15 giay: tu tan cong quai gan trong 5.5 o, 18 st moi 1s, khong lo.", U3, Chara.MEGUMI);

        add("chimera_garden", "Domain Expansion: Chimera Shadow Garden", "領域展開「嵌合暗翳庭」", 300, 2400, 4, "domain",
                "Ban kinh 12. Canh 3D: vo bao den xam, nen bong toi, gai bong, 3 Divine Dog canh gac. Quai ben trong bi bong troi (Slowness IV) + 4 st/s; ban duoc Speed II.", U3, Chara.MEGUMI);
        add("self_embodiment", "Domain Expansion: Self-Embodiment of Perfection", "領域展開「自閉円頓裹」", 300, 2400, 3, "domain",
                "Ban kinh 12. Canh 3D: noi tang thit, mat tren vach, xuc tu. Moi quai ben trong bi Wither II + Weakness + Nausea va 3 st / 0.5s ('cham vao linh hon').", U3, Chara.MAHITO);
        add("idle_death_gamble", "Domain Expansion: Idle Death Gamble", "領域展開「坐殺博徒」", 300, 2400, 3, "domain",
                "Ban kinh 12. Canh 3D: sanh pachinko neon, may slot 3 cuon. Sau 3s quay: 30% JACKPOT (Regen IV, Resistance IV, Strength III, Speed III 15s, hoi day mau, Shutter Doors x2). Khong trung van gay sat thuong chac chan.", U3, Chara.HAKARI);
        add("shutter_doors", "Shutter Doors", "ガタガタ", 45, 120, 30, "instant",
                "Loat 10 cu dam lien tiep ve phia truoc trong 1 giay (3 st moi cu, x2 khi dang jackpot).", U3, Chara.HAKARI);
        add("deadly_sentencing", "Domain Expansion: Deadly Sentencing", "領域展開「誅伏賜死」", 300, 2400, 4, "domain",
                "Ban kinh 12. Canh 3D: phap dinh toi, ban quan toa, cot da, cai bua. Quai bi cam; sau 2.5s tuyen 'GUILTY' va Executioner's Sword rot xuong tung quai (30 st, chem chet neu <35% mau).", U3, Chara.HIGURUMA);
        add("executioners_sword", "Executioner's Sword", "死刑執行人の剣", 60, 140, 25, "instant",
                "Thanh kiem khong lo rot xuong muc tieu (<=14 o): 25 st; chem chet ngay neu duoi 35% mau.", U3, Chara.HIGURUMA);
        add("confiscation", "Confiscation", "没収", 35, 120, 4, "instant",
                "Tich thu ky nang muc tieu (<=10 o): Weakness III + Slowness II + Mining Fatigue 10 giay.", U3, Chara.HIGURUMA);
        add("lightning_discharge", "Lightning Discharge", "雷撃", 45, 80, 14, "instant",
                "Set danh muc tieu ngam (<=18 o) roi nhay sang toi da 4 quai gan do (14/10/8/6 st), lam tê liet ngan.", U3, Chara.KASHIMO);
        add("lightning_dash", "Lightning Dash", "雷速", 35, 70, 12, "instant",
                "Bien thanh tia set lao ve phia truoc toi 14 o, trung quai tren duong di (12 st).", U3, Chara.KASHIMO);
        add("mythical_beast_amber", "Mythical Beast Amber", "幻獣琥珀", 110, 700, 3, "instant",
                "15 giay: Speed III, Strength II, Resistance I; dien phong quanh nguoi 3 st / 0.25s cho quai trong 3 o.", U3, Chara.KASHIMO);
        add("split_soul_katana", "Split Soul Katana", "游雲・魂", 50, 100, 22, "instant",
                "Chem tam 5 o xuyen giap: 22 st + 10% mau toi da cua muc tieu (toi da 40).", U3, Chara.MAKI);
        add("slash_flurry", "Slash Flurry", "乱斬", 40, 120, 24, "instant",
                "6 nhat chem lien tiep trong 12 tick ve phia truoc (4 st moi nhat, tam 4.5 o).", U3, Chara.MAKI);
        add("uzumaki_absorb", "Cursed Spirit Manipulation: Absorb", "呪霊操術", 40, 160, 10, "instant",
                "Hut cac quai trong 10 o (10 st). Quai nao chet duoc hap thu: +30 chu luc va +1 'tich' Uzumaki (toi da 10).", U3, Chara.KENJAKU);
        add("maximum_uzumaki", "Maximum: Uzumaki", "極ノ番「うずまき」", 100, 400, 40, "instant",
                "Ban tia xoay oc tim 40 o. Sat thuong 15 + 12 moi 'tich' Uzumaki da hap thu (tieu het tich).", U3, Chara.KENJAKU);

        add("rct", "Reverse Cursed Technique", "反転術式", 60, 100, 0, "instant",
                "Hoi 8 mau (4 tim) va xoa doc / wither.", UNTESTED, G, S, Chara.HAKARI, Chara.HIGURUMA);
        add("copy_outfit", "Copy: Outfit Echo", "模倣・装", 40, 120, 0, "instant", "Sao chep trang phuc + mot buff cua nhan vat tiep theo (xoay vong 18 bo + Rika), 20 giay.", U3, Chara.YUTA);
        add("authentic_love", "Domain Expansion: Authentic Mutual Love", "領域展開「真贋相愛」", 300, 2400, 4, "domain",
                "Ban kinh 12. Canh 3D: tran sang trang day kiem cam xuyen vao tam. Moi quai trong vung chiu chem tu dong (4 st/0.5s) va 'mua kiem' 6 st moi 2s; ban hoi chu luc tu tu.", U3, Chara.YUTA);
        add("reinforce", "Cursed Energy Reinforcement", "呪力強化", 0, 20, 0, "toggle",
                "Bat/tat. Speed I + Strength I, ton 1.5 nang luong/giay.", UNTESTED, G, S, Y, Chara.HAKARI, Chara.KASHIMO, Chara.MAKI, Chara.KENJAKU);
    }

    static { Pack3.load(); Moves.registerTechs(); Canon.registerTechs(); }

    public static List<T> of(Chara c) {
        List<T> out = new ArrayList<>();
        for (T t : ALL) if (t.usedBy(c)) out.add(t);
        return out;
    }

    /** ky hieu 2 chu cai cho icon */
    public static String abbr(T t) {
        String n = t.en();
        int c = n.lastIndexOf(':');
        if (c >= 0) n = n.substring(c + 1);
        n = n.replaceAll("\\(.*?\\)", "").trim();
        String[] w = n.split("\\s+");
        if (w.length >= 2) return ("" + w[0].charAt(0) + w[1].charAt(0)).toUpperCase();
        return n.length() >= 2 ? Character.toUpperCase(n.charAt(0)) + n.substring(1, 2).toLowerCase() : n;
    }

    public static int iconColor(T t) {
        return switch (t.id()) {
            case "infinity" -> 0x9FE8FF; case "blue" -> 0x2E9BFF; case "red" -> 0xFF3030; case "purple" -> 0xB060FF;
            case "unlimited_void" -> 0x6A5CFF; case "cleave" -> 0xFF4040; case "dismantle" -> 0xFFB0B8;
            case "fire_arrow" -> 0xFF7A1A; case "malevolent_shrine" -> 0xB01020; case "black_flash" -> 0xE02020;
            case "rct" -> 0x60FF9A; case "reinforce" -> 0x7A5CFF;
            default -> t.users().length > 0 ? t.users()[0].color : 0x888888;
        };
    }

    public static String icon(String id) {
        return switch (id) {
            case "infinity" -> "無"; case "blue" -> "蒼"; case "red" -> "赫"; case "purple" -> "茈"; case "unlimited_void" -> "領";
            case "cleave" -> "捌"; case "dismantle" -> "解"; case "fire_arrow" -> "開"; case "malevolent_shrine" -> "伏";
            case "black_flash" -> "黒"; case "rct" -> "反"; case "reinforce" -> "強";
            case "copy_outfit" -> "装"; case "inverted_spear" -> "鉾"; case "playful_cloud" -> "雲"; case "split_soul" -> "魂"; case "amber_lightning" -> "琥"; case "hairpin" -> "簪"; case "confiscation" -> "没"; case "love_train" -> "愛"; case "hollow_purple_200" -> "茈"; case "boogie_chaos" -> "替"; case "ratio_critical" -> "会"; case "convergence" -> "斂"; case "maximum_meteor" -> "隕"; case "distorted_killing" -> "殺"; case "copy_cast" -> "模"; case "rika_full" -> "里"; case "nue" -> "鵺"; case "toad" -> "蝦"; case "great_serpent" -> "蛇"; case "boogie_woogie" -> "戯";
            case "ratio" -> "十"; case "overtime" -> "残"; case "resonance" -> "鳴"; case "hairpin" -> "簪";
            case "piercing_blood" -> "穿"; case "supernova" -> "苅"; case "meteor" -> "隕"; case "coffin" -> "蓋";
            case "idle_transfig" -> "転"; case "speech_stop" -> "止"; case "speech_blast" -> "吹"; case "speech_explode" -> "爆";
            case "rika_beam" -> "砲"; case "rika_manifest" -> "顕"; case "heavenly_restriction" -> "天";
            case "inverted_spear" -> "逆"; case "playful_cloud" -> "游";
            case "chimera_garden" -> "影"; case "self_embodiment" -> "肉"; case "idle_death_gamble" -> "博"; case "shutter_doors" -> "戸";
            case "deadly_sentencing" -> "誅"; case "executioners_sword" -> "刑"; case "confiscation" -> "没"; case "lightning_discharge" -> "雷";
            case "lightning_dash" -> "速"; case "mythical_beast_amber" -> "琥"; case "split_soul_katana" -> "魂"; case "slash_flurry" -> "斬";
            case "uzumaki_absorb" -> "操"; case "maximum_uzumaki" -> "渦";
            case "divine_dogs" -> "犬"; case "max_elephant" -> "象"; case "rabbit_escape" -> "兎"; case "round_deer" -> "鹿";
            case "piercing_ox" -> "牛"; case "tiger_funeral" -> "虎"; case "mahoraga_summon" -> "魔";
            default -> Moves.iconOf(id);
        };
    }

    public static int iconColor(String id) {
        return switch (id) {
            case "blue" -> 0x2E9BFF; case "red" -> 0xE02A2A; case "purple" -> 0x9B3DFF; case "infinity" -> 0x9FE8FF;
            case "unlimited_void" -> 0x5A3CFF; case "cleave" -> 0xC01830; case "dismantle" -> 0xD84860;
            case "fire_arrow" -> 0xFF7A1A; case "malevolent_shrine" -> 0x8A1020; case "black_flash" -> 0x601020;
            case "rct" -> 0x40D080; case "reinforce" -> 0x6A4AD0;
            default -> {
                T t = byId(id);
                yield t != null && t.users().length > 0 ? t.users()[0].color : 0x808080;
            }
        };
    }

    public static T byId(String id) {
        for (T t : ALL) if (t.id().equals(id)) return t;
        return null;
    }
}
