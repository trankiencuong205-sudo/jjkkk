package com.example.jjk;

import java.util.HashMap;
import java.util.Map;

/** Bao ve may chu: loi trong ky nang/hoat anh KHONG duoc lam sap server. Ghi log (toi da vai lan moi noi). */
public class Safe {
    private static final Map<String, Integer> COUNT = new HashMap<>();

    public static void run(String where, Runnable r) {
        try { r.run(); } catch (Throwable t) { log(where, t); }
    }

    public static void log(String where, Throwable t) {
        int n = COUNT.merge(where, 1, Integer::sum);
        if (n <= 5) {
            System.err.println("[jjk] loi o " + where + " (" + n + "): " + t);
            if (n == 1) t.printStackTrace();
        }
    }
}
