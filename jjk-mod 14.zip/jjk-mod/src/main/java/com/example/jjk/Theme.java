package com.example.jjk;

import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

/**
 * Hieu ung 3D RIENG cho tung nhan vat (de cac ky nang khong giong het nhau):
 * Gojo luc giac xanh, Sukuna vet chem do cat cheo, Yuji gai cam, Todo da bay, Nanami dai 7:3, Nobara dinh + hoa,
 * Choso giot mau, Jogo cot lua + da nong, Mahito xuc tu thit, Inumaki vong am thanh, Yuta kiem bat cheo,
 * Toji vet chem xam, Hakari dong xu, Higuruma cot phan quyet, Kashimo set, Maki cung chem xanh, Kenjaku vong trong luc.
 * Chua test trong game.
 */
public class Theme {
    static void line(ServerWorld w, Vec3d a, Vec3d b, String o, String i, double t, int ttl) { new Disp.Beam(w, a, b, o, i, t, ttl); }

    public static void style(String sty, ServerWorld w, Vec3d at, Vec3d dir, double size, String b1, String b2) {
        if (!Config.displays || sty == null) return;
        double s = Math.max(1.0, Math.min(8.0, size));
        Vec3d d = dir == null || dir.lengthSquared() < 1e-6 ? new Vec3d(0, 0, 1) : dir.normalize();
        Vec3d[] b = Fx.basis(d);
        switch (sty) {
            case "hex" -> {
                for (int i = 0; i < 6; i++) {
                    double a1 = i * Math.PI / 3, a2 = (i + 1) * Math.PI / 3;
                    Vec3d p1 = at.add(b[1].multiply(Math.cos(a1) * s * 0.8)).add(b[2].multiply(Math.sin(a1) * s * 0.8));
                    Vec3d p2 = at.add(b[1].multiply(Math.cos(a2) * s * 0.8)).add(b[2].multiply(Math.sin(a2) * s * 0.8));
                    line(w, p1, p2, "light_blue_stained_glass", "white_concrete", 0.14, 9);
                    Vis3D.pulseShrink(w, p1, "white_concrete", 0.3, 10);
                }
                Vis3D.plate(w, at, d, "light_blue_stained_glass", 0.3, s * 1.8, 8);
            }
            case "xcut" -> {
                for (int i = 0; i < 4; i++) {
                    Vec3d r = Fx.randDir().multiply(s * 1.2);
                    line(w, at.subtract(r), at.add(r), "red_concrete", "white_concrete", 0.07, 7);
                }
                for (int i = 0; i < 5; i++) Vis3D.pulseShrink(w, at.add(Fx.randDir().multiply(s * 0.6)), "bone_block", 0.2, 12);
            }
            case "spikes" -> {
                for (int i = 0; i < 9; i++) line(w, at, at.add(Fx.randDir().multiply(s * Fx.rnd(0.7, 1.3))), "orange_concrete", "black_concrete", 0.22, 6);
                Vis3D.pulseGrow(w, at, "black_stained_glass", 0.3, s * 1.2, 7);
            }
            case "rocks" -> {
                String[] st = {"stone", "cobblestone", "dirt", "andesite"};
                for (int i = 0; i < 9; i++) Vis3D.pulseShrink(w, at.add(Fx.rnd(-s, s) * 0.7, Fx.rnd(0, 1.6), Fx.rnd(-s, s) * 0.7), st[i % 4], 0.4, 14);
                Vis3D.plate(w, at, new Vec3d(0, 1, 0), "white_stained_glass", 0.4, s * 1.8, 7);
            }
            case "ratio" -> {
                Vec3d u = b[1].multiply(s * 1.4);
                line(w, at.subtract(u), at.add(u.multiply(0.4)), "gold_block", null, 0.12, 12);
                line(w, at.add(u.multiply(0.5)), at.add(u), "white_concrete", null, 0.12, 12);
                Vis3D.plate(w, at.add(u.multiply(0.45)), d, "yellow_stained_glass", 0.2, s * 0.9, 10);
            }
            case "nails" -> {
                for (int i = 0; i < 7; i++) {
                    Vec3d r = Fx.randDir().multiply(s * 0.9);
                    line(w, at.add(r), at.add(r.multiply(0.35)), "iron_block", "gray_concrete", 0.09, 16);
                }
                for (int i = 0; i < 4; i++) Vis3D.pulseGrow(w, at.add(Fx.randDir().multiply(s * 0.5)), "pink_concrete", 0.15, 0.5, 10);
            }
            case "drops" -> {
                for (int i = 0; i < 10; i++) Vis3D.pulseShrink(w, at.add(Fx.rnd(-s, s) * 0.6, Fx.rnd(0.5, 2.5), Fx.rnd(-s, s) * 0.6), "redstone_block", 0.22, 14);
                Vis3D.plate(w, at, new Vec3d(0, 1, 0), "red_stained_glass", 0.3, s * 1.6, 9);
            }
            case "column" -> {
                Vis3D.pulseGrow(w, at, "orange_concrete", 0.4, s * 0.9, 9);
                Vis3D.pulseGrow(w, at.add(0, s * 0.6, 0), "magma_block", 0.3, s * 0.6, 10);
                for (int i = 0; i < 6; i++) Vis3D.pulseShrink(w, at.add(Fx.rnd(-s, s) * 0.7, Fx.rnd(0, 2.5), Fx.rnd(-s, s) * 0.7), "magma_block", 0.35, 14);
                line(w, at, at.add(0, s * 1.6, 0), "orange_stained_glass", "yellow_concrete", s * 0.5, 8);
            }
            case "tendrils" -> {
                for (int i = 0; i < 5; i++) {
                    Vec3d r = at.add(Fx.randDir().multiply(s));
                    Vec3d mid = r.add(at).multiply(0.5).add(Fx.randDir().multiply(0.5));
                    line(w, r, mid, "pink_concrete", null, 0.2, 11);
                    line(w, mid, at, "magenta_concrete", null, 0.14, 11);
                }
            }
            case "rings" -> {
                for (int i = 0; i < 3; i++) {
                    final int k = i;
                    Vis3D.later(i * 3, () -> Vis3D.plate(w, at.add(d.multiply(k * 0.4)), d, "white_stained_glass", 0.3, s * (1.2 + 0.5 * k), 7));
                }
                for (int i = 0; i < 5; i++) Vis3D.pulseShrink(w, at.add(b[1].multiply(Fx.rnd(-s, s) * 0.6)).add(b[2].multiply(Fx.rnd(-s, s) * 0.6)), "white_concrete", 0.12, 10);
            }
            case "swords" -> {
                Vec3d r1 = b[1].add(b[2]).normalize().multiply(s * 1.4), r2 = b[1].subtract(b[2]).normalize().multiply(s * 1.4);
                line(w, at.subtract(r1), at.add(r1), "iron_block", "light_blue_stained_glass", 0.12, 9);
                line(w, at.subtract(r2), at.add(r2), "iron_block", "purple_stained_glass", 0.12, 9);
                Vis3D.plate(w, at, d, "light_blue_stained_glass", 0.3, s * 1.4, 8);
            }
            case "slashes" -> {
                for (int i = 0; i < 3; i++) {
                    Vec3d r = Fx.randDir().multiply(s);
                    line(w, at.subtract(r), at.add(r), "gray_concrete", "white_concrete", 0.05, 4);
                }
            }
            case "coins" -> {
                String[] gc = {"gold_block", "pink_concrete", "sea_lantern", "yellow_concrete"};
                for (int i = 0; i < 9; i++) Vis3D.pulseShrink(w, at.add(Fx.randDir().multiply(s * 0.8)), gc[i % 4], 0.3, 12);
                Vis3D.pulseGrow(w, at, "pink_stained_glass", 0.3, s * 1.3, 8);
            }
            case "gavel" -> {
                line(w, at, at.add(0, s * 2.0, 0), "gold_block", "yellow_concrete", 0.3, 8);
                Vis3D.plate(w, at.add(0, 0.05, 0), new Vec3d(0, 1, 0), "gold_block", 0.4, s * 1.5, 8);
                Vis3D.pulseShrink(w, at.add(0, s * 2.0, 0), "gold_block", 0.8, 8);
            }
            case "bolts" -> {
                Vis3D.bolt(w, at.add(0, s * 2.5, 0), at, 0.08, 6);
                for (int i = 0; i < 3; i++) Vis3D.bolt(w, at.add(Fx.randDir().multiply(s * 1.2)), at, 0.05, 5);
            }
            case "arcs" -> {
                for (int i = 0; i < 3; i++) {
                    Vec3d r = Fx.randDir().multiply(s);
                    line(w, at.subtract(r), at.add(r), "green_concrete", "white_concrete", 0.07, 5);
                }
            }
            case "gravity" -> {
                for (int i = 0; i < 6; i++) {
                    double a = i * Math.PI / 3;
                    Vec3d p = at.add(b[1].multiply(Math.cos(a) * s)).add(b[2].multiply(Math.sin(a) * s));
                    Vis3D.pulseShrink(w, p, "purple_concrete", 0.4, 12);
                    line(w, p, at, "purple_stained_glass", null, 0.06, 8);
                }
                Vis3D.pulseGrow(w, at, "black_concrete", 0.2, s * 0.8, 10);
            }
            case "star5" -> {
                Vec3d[] v = new Vec3d[5];
                for (int i = 0; i < 5; i++) { double a = i * Math.PI * 2 / 5 + 0.3; v[i] = at.add(b[1].multiply(Math.cos(a) * s)).add(b[2].multiply(Math.sin(a) * s)); }
                for (int i = 0; i < 5; i++) line(w, v[i], v[(i + 2) % 5], b1, b2, 0.1, 9);
                Vis3D.pulseGrow(w, at, b2, 0.3, s * 0.7, 8);
            }
            case "sun" -> {
                for (int i = 0; i < 12; i++) Vis3D.pulseGrow(w, at.add(Fx.randDir().multiply(s * 0.9)), i % 2 == 0 ? b1 : b2, 0.15, 0.55, 9);
                Vis3D.pulseGrow(w, at, b2, 0.4, s * 1.1, 8);
            }
            case "shards" -> {
                for (int i = 0; i < 10; i++) {
                    Vec3d p = at.add(Fx.randDir().multiply(s * Fx.rnd(0.4, 1.1)));
                    Vis3D.pulseShrink(w, p, i % 2 == 0 ? b1 : b2, Fx.rnd(0.15, 0.45), 12);
                }
            }
            case "rain" -> {
                for (int i = 0; i < 8; i++) {
                    Vec3d g = at.add(Fx.rnd(-s, s) * 0.7, 0, Fx.rnd(-s, s) * 0.7);
                    line(w, g.add(0, 7, 0), g, b1, b2, 0.08, 6);
                }
            }
            case "pillars" -> {
                for (int i = 0; i < 5; i++) {
                    double a = i * Math.PI * 2 / 5;
                    Vec3d g = at.add(Math.cos(a) * s * 0.8, 0, Math.sin(a) * s * 0.8);
                    line(w, g, g.add(0, s * 2.2, 0), b1, b2, 0.28, 9);
                }
            }
            case "helix" -> {
                for (int i = 0; i < 14; i++) {
                    double a = i * 0.7, y = i * 0.2;
                    Vis3D.pulseShrink(w, at.add(Math.cos(a) * s * 0.6, y, Math.sin(a) * s * 0.6), i % 2 == 0 ? b1 : b2, 0.28, 12);
                }
            }
            case "dome" -> {
                for (int i = 1; i <= 3; i++) {
                    final int k = i;
                    Vis3D.later(i * 2, () -> Vis3D.plate(w, at.add(0, k * 0.5, 0), new Vec3d(0, 1, 0), k % 2 == 0 ? b2 : b1, 0.3, s * (0.6 + 0.5 * k), 7));
                }
                Vis3D.pulseGrow(w, at, b1, 0.3, s * 1.3, 8);
            }
            case "meteor" -> {
                Vec3d from = at.add(5, 9, 3);
                line(w, from, at, b1, b2, 0.5, 7);
                Vis3D.pulseGrow(w, at, b2, 0.4, s * 1.2, 8);
            }
            case "cage" -> {
                double k = s * 0.8;
                for (int i = 0; i < 4; i++) {
                    double a = i * Math.PI / 2 + Math.PI / 4;
                    Vec3d lo = at.add(Math.cos(a) * k, -k * 0.5, Math.sin(a) * k), hi = lo.add(0, k * 1.6, 0);
                    line(w, lo, hi, b1, null, 0.07, 10);
                    double a2 = a + Math.PI / 2;
                    Vec3d lo2 = at.add(Math.cos(a2) * k, -k * 0.5, Math.sin(a2) * k), hi2 = lo2.add(0, k * 1.6, 0);
                    line(w, lo, lo2, b2, null, 0.07, 10);
                    line(w, hi, hi2, b2, null, 0.07, 10);
                }
            }
            case "wings" -> {
                for (int sg = -1; sg <= 1; sg += 2) new Disp.Crescent(w, at.add(b[2].multiply(sg * s * 0.6)), b[1], d, s * 1.6, 0.5, 0.3, b1, 8, 7);
                Vis3D.pulseGrow(w, at, b2, 0.2, s * 0.6, 7);
            }
            case "links" -> {
                for (int i = 0; i < 7; i++) Vis3D.pulseShrink(w, at.add(d.multiply(i * 0.5 - 1.2)), i % 2 == 0 ? b1 : b2, 0.3, 10);
                line(w, at.subtract(d.multiply(1.5)), at.add(d.multiply(2)), b2, null, 0.06, 8);
            }
            default -> Vis3D.pulseGrow(w, at, b1, 0.3, s, 8);
        }
    }

    static final java.util.Map<String, String[]> LISTS = new java.util.HashMap<>();
    static final java.util.Map<String, String> ASSIGN = new java.util.HashMap<>();
    static {
        LISTS.put("GOJO", new String[]{"hex", "rings", "gravity", "star5", "sun", "spikes"});
        LISTS.put("SUKUNA", new String[]{"xcut", "slashes", "shards", "rain", "spikes", "pillars"});
        LISTS.put("YUJI", new String[]{"spikes", "rocks", "shards", "rings", "dome", "star5"});
        LISTS.put("TODO", new String[]{"rocks", "dome", "shards", "pillars", "rings", "spikes"});
        LISTS.put("NANAMI", new String[]{"ratio", "xcut", "rain", "cage", "slashes", "rings"});
        LISTS.put("NOBARA", new String[]{"nails", "rain", "star5", "drops", "spikes", "wings"});
        LISTS.put("CHOSO", new String[]{"drops", "helix", "rain", "wings", "rings", "shards"});
        LISTS.put("JOGO", new String[]{"column", "meteor", "rocks", "pillars", "sun", "helix"});
        LISTS.put("MAHITO", new String[]{"tendrils", "helix", "cage", "shards", "drops", "wings"});
        LISTS.put("INUMAKI", new String[]{"rings", "dome", "helix", "star5", "wings", "cage"});
        LISTS.put("YUTA", new String[]{"swords", "wings", "rain", "rings", "star5", "cage"});
        LISTS.put("TOJI", new String[]{"slashes", "xcut", "spikes", "links", "shards", "rain"});
        LISTS.put("HAKARI", new String[]{"coins", "sun", "rings", "star5", "dome", "helix"});
        LISTS.put("HIGURUMA", new String[]{"gavel", "cage", "pillars", "rings", "links", "dome"});
        LISTS.put("KASHIMO", new String[]{"bolts", "helix", "dome", "star5", "pillars", "rain"});
        LISTS.put("MAKI", new String[]{"arcs", "slashes", "links", "spikes", "xcut", "wings"});
        LISTS.put("KENJAKU", new String[]{"gravity", "helix", "cage", "tendrils", "dome", "rings"});
    }

    /** moi ky nang cua cung mot nhan vat nhan mot kieu hieu ung KHAC nhau (xoay vong), mau theo block cua ky nang */
    static String styleFor(Moves.M m) {
        for (String tok : m.fx().split(",")) if (tok.startsWith("vfx:")) return tok.substring(4);
        String st = ASSIGN.get(m.id());
        if (st != null) return st;
        Tech.Chara ch = m.users() != null && m.users().length > 0 ? m.users()[0] : null;
        if (ch == null) return "sun";
        String[] l = LISTS.getOrDefault(ch.name(), new String[]{"sun"});
        int idx = 0;
        for (Moves.M o : Moves.MAP.values()) {
            if (o.users() == null || o.users().length == 0 || o.users()[0] != ch) continue;
            if (o.id().equals(m.id())) break;
            idx++;
        }
        st = l[idx % l.length];
        ASSIGN.put(m.id(), st);
        return st;
    }

    public static void fx(Moves.M m, ServerWorld w, Vec3d at, Vec3d dir, double size) {
        style(styleFor(m), w, at, dir, size, m.b1(), m.b2());
        Safe.run("Destruction", () -> Destruction.onSkill(m, w, at, dir, size));
    }
}
