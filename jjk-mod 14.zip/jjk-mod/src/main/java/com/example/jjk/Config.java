package com.example.jjk;

import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** config/jjk-config.properties */
public class Config {
    public static int maxEnergy = 400;
    public static double regen = 6.0;          // cursed energy / second
    public static double costMult = 1.0;
    public static double cdMult = 1.0;
    public static boolean noCooldown = false;
    public static boolean unlimited = false;
    public static boolean purpleErasesBlocks = true;
    public static int domainSeconds = 10;
    public static boolean solidDomain = true;  // domain dung phong khoi THAT (khong ai vao duoc); tra lai khoi khi het domain
    public static boolean autoPage = true;     // tu dong chia ky nang thanh trang 8 o, doi trang bang phim (khong can gan tay)
    public static boolean domainShell = true;  // vo/canh 3D cua domain (block_display); tat neu bi giat
    public static boolean naturalMobs = false; // quai chu linh tu xuat hien ban dem (mac dinh TAT cho server)  // quai chu linh tu xuat hien ban dem (rat hiem)
    public static String admins = "";          // ten nguoi choi (cach nhau dau phay) duoc doi cai dat / goi quai tren server
    public static int maxDisplays = 1500;      // gioi han so display entity cung luc (chong lag)
    public static int maxRooms = 2;            // so phong domain bang khoi that cung luc
    public static int actionsPerSecond = 25;   // chong spam goi tin
    public static boolean curseEvents = true;  // su kien Lam Chu Linh dinh ky (co thanh boss bar, thuong XP)
    public static int eventMinutes = 30;       // chu ky su kien (phut)
    public static boolean gradeGate = true;    // ky nang manh doi hoi Grade (chi tren server rieng; creative va 1 nguoi choi bo qua)
    public static boolean texturedModels = true; // thuc than dung texture rieng (item_display); tat neu bi loi hien thi (se dung khoi vanilla)
    public static boolean terrainDamage = true;   // ky nang pha dia hinh (no, chem cat, khoan)
    public static int terrainRestoreSeconds = 90; // khoi bi pha tu hoi phuc sau N giay (0 = vinh vien)
    public static int destroyMaxBlocks = 1500;    // toi da khoi bi pha moi lan
    public static boolean destruction = true;  // ky nang pha huy dia hinh (ho no, duong ham, vet cat). Tat tren server cong cong neu can
    public static int destructionLimit = 450;  // so khoi toi da bi pha moi lan dung ky nang
    public static boolean displays = true;     // hinh hoc 3D that (display entity); tat neu bi giat/lag

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("jjk-config.properties"); }

    public static int cost(int base) { return unlimited ? 0 : (int) Math.round(base * costMult); }
    public static int cd(int base) { return noCooldown ? 0 : (int) Math.round(base * cdMult); }

    public static void load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                Properties p = new Properties();
                try (InputStream in = Files.newInputStream(f)) { p.load(in); }
                maxEnergy = Integer.parseInt(p.getProperty("maxEnergy", "400"));
                regen = Double.parseDouble(p.getProperty("regenPerSecond", "6.0"));
                costMult = Double.parseDouble(p.getProperty("costMultiplier", "1.0"));
                cdMult = Double.parseDouble(p.getProperty("cooldownMultiplier", "1.0"));
                noCooldown = Boolean.parseBoolean(p.getProperty("disableCooldowns", "false"));
                unlimited = Boolean.parseBoolean(p.getProperty("unlimitedEnergy", "false"));
                purpleErasesBlocks = Boolean.parseBoolean(p.getProperty("purpleErasesBlocks", "true"));
                domainSeconds = Integer.parseInt(p.getProperty("domainSeconds", "10"));
                displays = Boolean.parseBoolean(p.getProperty("displays", "true"));
                domainShell = Boolean.parseBoolean(p.getProperty("domainShell", "true"));
                autoPage = Boolean.parseBoolean(p.getProperty("autoPage", "true"));
                solidDomain = Boolean.parseBoolean(p.getProperty("solidDomain", "true"));
                naturalMobs = Boolean.parseBoolean(p.getProperty("naturalMobs", "false"));
                admins = p.getProperty("admins", "");
                curseEvents = Boolean.parseBoolean(p.getProperty("curseEvents", "true"));
                eventMinutes = Math.max(5, Integer.parseInt(p.getProperty("eventMinutes", "30")));
                texturedModels = Boolean.parseBoolean(p.getProperty("texturedModels", "true"));
                terrainDamage = Boolean.parseBoolean(p.getProperty("terrainDamage", "true"));
                terrainRestoreSeconds = Math.max(0, Integer.parseInt(p.getProperty("terrainRestoreSeconds", "90")));
                destroyMaxBlocks = Math.max(50, Integer.parseInt(p.getProperty("destroyMaxBlocks", "1500")));
                destruction = Boolean.parseBoolean(p.getProperty("destruction", "true"));
                destructionLimit = Math.max(20, Integer.parseInt(p.getProperty("destructionLimit", "450")));
                gradeGate = Boolean.parseBoolean(p.getProperty("gradeGate", "true"));
                maxDisplays = Math.max(100, Integer.parseInt(p.getProperty("maxDisplays", "1500")));
                maxRooms = Math.max(0, Integer.parseInt(p.getProperty("maxRooms", "2")));
                actionsPerSecond = Math.max(5, Integer.parseInt(p.getProperty("actionsPerSecond", "25")));
            }
            save();
        } catch (Exception e) { System.err.println("[jjk] config: " + e); }
    }

    public static void save() {
        try {
            Properties p = new Properties();
            p.setProperty("maxEnergy", String.valueOf(maxEnergy));
            p.setProperty("regenPerSecond", String.valueOf(regen));
            p.setProperty("costMultiplier", String.valueOf(costMult));
            p.setProperty("cooldownMultiplier", String.valueOf(cdMult));
            p.setProperty("disableCooldowns", String.valueOf(noCooldown));
            p.setProperty("unlimitedEnergy", String.valueOf(unlimited));
            p.setProperty("purpleErasesBlocks", String.valueOf(purpleErasesBlocks));
            p.setProperty("domainSeconds", String.valueOf(domainSeconds));
            p.setProperty("displays", String.valueOf(displays));
            p.setProperty("domainShell", String.valueOf(domainShell));
            p.setProperty("autoPage", String.valueOf(autoPage));
            p.setProperty("solidDomain", String.valueOf(solidDomain));
            p.setProperty("naturalMobs", String.valueOf(naturalMobs));
            p.setProperty("admins", admins);
            p.setProperty("curseEvents", String.valueOf(curseEvents));
            p.setProperty("eventMinutes", String.valueOf(eventMinutes));
            p.setProperty("texturedModels", String.valueOf(texturedModels));
            p.setProperty("terrainDamage", String.valueOf(terrainDamage));
            p.setProperty("terrainRestoreSeconds", String.valueOf(terrainRestoreSeconds));
            p.setProperty("destroyMaxBlocks", String.valueOf(destroyMaxBlocks));
            p.setProperty("destruction", String.valueOf(destruction));
            p.setProperty("destructionLimit", String.valueOf(destructionLimit));
            p.setProperty("gradeGate", String.valueOf(gradeGate));
            p.setProperty("maxDisplays", String.valueOf(maxDisplays));
            p.setProperty("maxRooms", String.valueOf(maxRooms));
            p.setProperty("actionsPerSecond", String.valueOf(actionsPerSecond));
            try (OutputStream out = Files.newOutputStream(file())) { p.store(out, "Jujutsu Cursed Techniques config"); }
        } catch (Exception e) { System.err.println("[jjk] config save: " + e); }
    }
}
