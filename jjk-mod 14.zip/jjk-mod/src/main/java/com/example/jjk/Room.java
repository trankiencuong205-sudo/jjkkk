package com.example.jjk;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.state.property.Property;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * CAN PHONG BANG KHOI THAT (nhu trong phim: domain la mot phong den kin, khong ai vao duoc).
 * Xay 6 mat (san, tran, 4 tuong) bang khoi that, luu lai khoi cu va TRA LAI khi domain ket thuc
 * (hoac khi tat server). Tuong khong dap duoc khi domain dang mo. Tat bang config solidDomain=false.
 * Chua test trong game.
 */
public class Room {
    private static final List<Room> ALL = new ArrayList<>();
    private static final Map<Long, ServerWorld> PROT = new HashMap<>();
    /** khoi cu chua tra lai duoc (chunk chua tai / server sap giua chung) - luu vao journal va tra khi chunk tai len */
    private static final List<Stale> PENDING = new ArrayList<>();
    private static boolean dirty = false;
    private static int tickN = 0;
    static final int MAX_AGE = 20 * 60 * 3;           // phong ton tai toi da 3 phut, qua han tu dong tra lai
    int age = 0;

    record Stale(String dim, int x, int y, int z, String state) {}

    final ServerWorld w;
    final BlockState block;
    final List<BlockPos> cells = new ArrayList<>();
    final Map<Long, BlockState> saved = new HashMap<>();
    int placed = 0, fillTicks, closeTicks = 0;
    boolean closing = false, done = false;

    final String style; final int x0, y0, z0, rr, hh;
    final Map<String, BlockState> cache = new HashMap<>();

    BlockState state(String id) {
        return cache.computeIfAbsent(id, k -> {
            Block bl = Registries.BLOCK.get(Identifier.of("minecraft", k));
            return bl == net.minecraft.block.Blocks.AIR ? block : bl.getDefaultState();
        });
    }

    public Room(ServerWorld w, Vec3d c, int r, int h, String blockId, int fillTicks, String style) {
        this.w = w;
        this.style = style;
        this.fillTicks = Math.max(1, fillTicks);
        Block b = Registries.BLOCK.get(Identifier.of("minecraft", blockId));
        this.block = b.getDefaultState();
        x0 = (int) Math.floor(c.x); y0 = (int) Math.floor(c.y); z0 = (int) Math.floor(c.z); rr = r; hh = h;
        for (int y = y0 - 1; y <= y0 + h; y++)
            for (int x = -r; x <= r; x++)
                for (int z = -r; z <= r; z++)
                    if (y == y0 - 1 || y == y0 + h || Math.abs(x) == r || Math.abs(z) == r)
                        cells.add(new BlockPos(x0 + x, y, z0 + z));
        ALL.add(this);
    }

    public void startClose(int ticks) {
        closing = true; closeTicks = Math.max(1, ticks);
        while (cells.size() > placed) cells.remove(cells.size() - 1);     // chua dat thi bo
        closeStep = (int) Math.ceil(cells.size() / (double) closeTicks);
    }

    /** tra het khoi cu ngay lap tuc */
    public void closeNow() {
        restore(Integer.MAX_VALUE);
        done = true;
    }

    private void fill(int n) {
        for (int i = 0; i < n && placed < cells.size(); i++, placed++) {
            BlockPos p = cells.get(placed);
            if (w.isOutOfHeightLimit(p.getY()) || !w.getWorldBorder().contains(p)) continue;
            if (!w.getChunkManager().isChunkLoaded(p.getX() >> 4, p.getZ() >> 4)) continue;
            BlockState old = w.getBlockState(p);
            if (old.isOf(net.minecraft.block.Blocks.BEDROCK) || w.getBlockEntity(p) != null) continue;
            saved.put(p.asLong(), old);
            PROT.put(p.asLong(), w);
            dirty = true;
            BlockState put = style == null ? block : state(Painter.pick(style, p.getX() - x0, p.getY() - y0, p.getZ() - z0, rr, hh));
            w.setBlockState(p, put, Block.NOTIFY_LISTENERS);
        }
    }

    private void restore(int n) {
        for (int i = 0; i < n && !cells.isEmpty(); i++) {
            BlockPos p = cells.remove(cells.size() - 1);
            Long key = p.asLong();
            BlockState old = saved.remove(key);
            PROT.remove(key);
            if (old == null) continue;
            if (w.getChunkManager().isChunkLoaded(p.getX() >> 4, p.getZ() >> 4)) w.setBlockState(p, old, Block.NOTIFY_LISTENERS);
            else PENDING.add(new Stale(w.getRegistryKey().getValue().toString(), p.getX(), p.getY(), p.getZ(), str(old)));
            dirty = true;
        }
        if (cells.isEmpty()) done = true;
    }

    public static boolean isProtected(ServerWorld w, BlockPos p) { return !PROT.isEmpty() && PROT.get(p.asLong()) == w; }

    public static void markDirty() { dirty = true; }

    /** them mot khoi cu vao hang cho tra lai (khi chunk chua tai) */
    public static void addStale(ServerWorld w, BlockPos p, BlockState old) {
        PENDING.add(new Stale(w.getRegistryKey().getValue().toString(), p.getX(), p.getY(), p.getZ(), str(old)));
        dirty = true;
    }

    public static int active() { int n = 0; for (Room r : ALL) if (!r.done) n++; return n; }
    public static int pending() { return PENDING.size(); }

    /** tra het moi phong + khoi cu con ton (lenh /jjk cleanup) */
    public static int cleanupAll(MinecraftServer server) {
        int n = ALL.size();
        for (Room r : new ArrayList<>(ALL)) r.closeNow();
        ALL.clear(); PROT.clear();
        flushPending(server, true);
        dirty = true;
        return n;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static String str(BlockState st) {
        StringBuilder sb = new StringBuilder(Registries.BLOCK.getId(st.getBlock()).toString());
        boolean first = true;
        for (Map.Entry<Property<?>, Comparable<?>> e : st.getEntries().entrySet()) {
            sb.append(first ? '[' : ',').append(e.getKey().getName()).append('=').append(((Property) e.getKey()).name((Comparable) e.getValue()));
            first = false;
        }
        if (!first) sb.append(']');
        return sb.toString();
    }

    private static Path journal() { return FabricLoader.getInstance().getConfigDir().resolve("jjk-room-journal.txt"); }

    /** ghi journal: moi khoi cu dang bi phong che + khoi chua tra duoc. Neu server sap, lan khoi dong sau se tra lai. */
    private static void writeJournal() {
        try {
            List<String> lines = new ArrayList<>();
            for (Room r : ALL) for (Map.Entry<Long, BlockState> e : r.saved.entrySet()) {
                BlockPos p = BlockPos.fromLong(e.getKey());
                lines.add(r.w.getRegistryKey().getValue() + "|" + p.getX() + "|" + p.getY() + "|" + p.getZ() + "|" + str(e.getValue()));
            }
            lines.addAll(Destruction.journalLines());
            for (Stale s : PENDING) lines.add(s.dim + "|" + s.x + "|" + s.y + "|" + s.z + "|" + s.state);
            if (lines.isEmpty()) Files.deleteIfExists(journal());
            else Files.write(journal(), lines);
        } catch (Exception e) { Safe.log("Room.journal", e); }
    }

    private static void loadJournal() {
        try {
            if (!Files.exists(journal())) return;
            for (String ln : Files.readAllLines(journal())) {
                String[] a = ln.split("\\|", 5);
                if (a.length == 5) PENDING.add(new Stale(a[0], Integer.parseInt(a[1]), Integer.parseInt(a[2]), Integer.parseInt(a[3]), a[4]));
            }
            System.out.println("[jjk] journal phong: " + PENDING.size() + " khoi cu cho tra lai (server tung tat dot ngot)");
        } catch (Exception e) { Safe.log("Room.loadJournal", e); }
    }

    /** tra cac khoi cu o chunk da tai (gioi han moi lan de khong giat) */
    private static void flushPending(MinecraftServer server, boolean all) {
        int budget = all ? Integer.MAX_VALUE : 400;
        for (Iterator<Stale> it = PENDING.iterator(); it.hasNext() && budget > 0; ) {
            Stale s = it.next();
            ServerWorld w = server.getWorld(RegistryKey.of(RegistryKeys.WORLD, Identifier.of(s.dim)));
            if (w == null) { it.remove(); continue; }
            if (!w.getChunkManager().isChunkLoaded(s.x >> 4, s.z >> 4)) continue;
            if (Disp.tryRun(w, "setblock " + s.x + " " + s.y + " " + s.z + " " + s.state + " replace")) { it.remove(); budget--; dirty = true; }
            else { it.remove(); }                       // lenh hong (khoi khong con ton tai) - bo, tranh lap vo han
        }
    }

    int closeStep = 1;

    private void tick() {
        if (done) return;
        if (++age > MAX_AGE && !closing) startClose(20);
        if (!closing) fill((int) Math.ceil(cells.size() / (double) fillTicks));
        else restore(closeStep);
    }

    public static void register() {
        ServerLifecycleEvents.SERVER_STARTED.register(server -> loadJournal());
        ServerTickEvents.END_SERVER_TICK.register(server -> Safe.run("Room.tick", () -> {
            tickN++;
            for (Iterator<Room> it = ALL.iterator(); it.hasNext(); ) {
                Room r = it.next();
                try { r.tick(); } catch (Throwable t) { Safe.log("Room.tick1", t); r.closeNow(); }
                if (r.done) { it.remove(); dirty = true; }
            }
            if (tickN % 40 == 0 && !PENDING.isEmpty()) flushPending(server, false);
            if (dirty && tickN % 40 == 0) { dirty = false; writeJournal(); }
        }));
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            for (Room r : ALL) r.closeNow();
            ALL.clear();
            PROT.clear();
            flushPending(server, true);
            writeJournal();
        });
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, be) -> !(world instanceof ServerWorld sw) || !isProtected(sw, pos));
    }
}
