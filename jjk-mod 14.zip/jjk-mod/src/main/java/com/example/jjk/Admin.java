package com.example.jjk;

import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Quyen quan tri cua mod (khong phu thuoc he thong op cua Minecraft de tranh loi tuong thich):
 * - choi mot minh / LAN host: moi nguoi la admin
 * - server rieng: ten nguoi choi phai nam trong "admins=" cua config/jjk-config.properties
 */
public class Admin {
    public static boolean is(MinecraftServer server, ServerPlayerEntity p) {
        if (server == null || p == null) return false;
        if (server.isSingleplayer()) return true;
        String n = p.getName().getString().toLowerCase();
        for (String a : Config.admins.split(",")) if (!a.isBlank() && a.trim().toLowerCase().equals(n)) return true;
        return false;
    }

    private static boolean ok(ServerCommandSource s) {
        ServerPlayerEntity p = s.getPlayer();
        return p == null || is(s.getServer(), p);           // console luon duoc
    }

    private static int say(ServerCommandSource s, String msg) {
        s.sendFeedback(() -> Text.literal(msg), false);
        return 1;
    }

    /** /jjk status | cleanup | reload  (chi admin / console) */
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("jjk")
                .then(CommandManager.literal("status").executes(c -> {
                    if (!ok(c.getSource())) return say(c.getSource(), "Ban khong co quyen.");
                    return say(c.getSource(), "[jjk] hieu ung=" + Disp.count() + "/" + Config.maxDisplays
                        + ", phong domain=" + Room.active() + "/" + Config.maxRooms + ", khoi cho tra=" + Room.pending()
                        + ", solidDomain=" + Config.solidDomain + ", purpleErasesBlocks=" + Config.purpleErasesBlocks);
                }))
                .then(CommandManager.literal("cleanup").executes(c -> {
                    if (!ok(c.getSource())) return say(c.getSource(), "Ban khong co quyen.");
                    int n = Room.cleanupAll(c.getSource().getServer());
                    int d = Disp.clearAll();
                    return say(c.getSource(), "[jjk] da dong " + n + " phong, xoa " + d + " hieu ung.");
                }))
                .then(CommandManager.literal("reload").executes(c -> {
                    if (!ok(c.getSource())) return say(c.getSource(), "Ban khong co quyen.");
                    Config.load();
                    return say(c.getSource(), "[jjk] da nap lai config.");
                })));
        });
    }
}
