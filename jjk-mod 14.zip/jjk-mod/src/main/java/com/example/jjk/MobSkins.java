package com.example.jjk;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

import java.util.*;

/**
 * "SKIN" 3D cho quai boss: than xac la quai vanilla (an hinh), con hinh la mo hinh Rig (block_display) bam theo quai.
 * Mahoraga = mo hinh Mahoraga trang + vong vang; Special-Grade = mo hinh xuong cao nhu Rika. Chua test trong game.
 */
public class MobSkins {
    private static final class Skin {
        final ServerWorld w; final String kind; Rig rig; int born = 0;
        Skin(ServerWorld w, String kind) { this.w = w; this.kind = kind; }
    }
    private static final Map<UUID, Skin> SKINS = new HashMap<>();
    private static int tickN = 0;
    private static final int TTL = 6000;

    private static Rig build(ServerWorld w, Vec3d pos, double yaw, String kind) {
        return kind.equals("mahoraga") ? Shiki.mahoragaModel(w, pos, yaw, TTL).scale(1.5)
                                       : Shiki.rikaModel(w, pos, yaw, TTL, 1.3);
    }

    private static void drop(UUID id) {
        Skin s = SKINS.remove(id);
        if (s != null && s.rig != null) s.rig.kill();
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> Safe.run("MobSkins.tick", () -> {
            tickN++;
            if (!Config.displays) { for (UUID id : new ArrayList<>(SKINS.keySet())) drop(id); return; }
            if (tickN % 20 == 0) {                                   // tim quai can skin gan nguoi choi
                for (ServerWorld w : server.getWorlds()) for (ServerPlayerEntity pl : w.getPlayers())
                    for (LivingEntity m : w.getEntitiesByClass(LivingEntity.class, pl.getBoundingBox().expand(64),
                            e -> e.isAlive() && (e.getCommandTags().contains("jjk_mahoraga") || e.getCommandTags().contains("jjk_special")))) {
                        if (SKINS.containsKey(m.getUuid()) || SKINS.size() >= 6) continue;
                        String kind = m.getCommandTags().contains("jjk_mahoraga") ? "mahoraga" : "rika";
                        m.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, 1_000_000, 0, false, false));
                        m.equipStack(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
                        Skin s = new Skin(w, kind);
                        s.rig = build(w, m.getEntityPos(), -Math.toRadians(m.getYaw()), kind);
                        SKINS.put(m.getUuid(), s);
                    }
            }
            for (Iterator<Map.Entry<UUID, Skin>> it = SKINS.entrySet().iterator(); it.hasNext(); ) {
                Map.Entry<UUID, Skin> e = it.next();
                Skin s = e.getValue();
                Entity m = s.w.getEntity(e.getKey());
                if (m == null || !m.isAlive()) {                      // quai chet / roi chunk: go skin
                    if (s.rig != null) s.rig.kill();
                    it.remove();
                    continue;
                }
                Vec3d pos = m.getEntityPos();
                double yaw = -Math.toRadians(m.getYaw());
                if (++s.born > TTL - 200) { s.rig.kill(); s.rig = build(s.w, pos, yaw, s.kind); s.born = 0; }   // display het han -> dung lai
                if (tickN % 2 == 0) s.rig.place(pos, yaw, tickN);
            }
        }));
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> { for (UUID id : new ArrayList<>(SKINS.keySet())) drop(id); });
    }
}
