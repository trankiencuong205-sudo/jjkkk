package com.example.jjk;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/**
 * HOAT ANH TAY khi tung ky nang: hai ban tay 3D (block_display, 5 ngon, 2 khop) hien truoc nguoi dung va tao the an
 * dac trung (Gojo: ngon tro-giua cheo, Sukuna: chap tay an, Megumi: an cho, Todo: vo tay, Yuji/Toji: nam dam...),
 * kem vung tay that (swing) va am thanh khoi dong rieng tung nhan vat. Chua test trong game.
 */
public class Gesture {
    // dinh dang mot the an: {pitch, bend thumb, index, middle, ring, pinky, crossMiddle(0/1), gapX}
    private static final double F = 1.5;

    private static double[] pose(String name) {
        return switch (name) {
            case "point" -> new double[]{0.0, 1.0, 0, F, F, F, 0, 0.0};          // ngon tro chi thang
            case "cross" -> new double[]{0.0, 1.0, 0, 0, F, F, 1, 0.0};          // ngon tro + giua cheo (Gojo)
            case "fist" -> new double[]{0.0, 1.2, F, F, F, F, 0, 0.0};
            case "palm" -> new double[]{0.0, 0.2, 0.05, 0.05, 0.05, 0.05, 0, 0.0};
            case "dog" -> new double[]{0.0, 0.8, 0, F, F, 0, 0, 0.0};            // an cho (Megumi): tro + ut doi len
            case "seal" -> new double[]{1.35, 0.3, 0.1, 0.1, 0.1, 0.1, 0, 0.07};  // chap tay thang len (Sukuna / vo tay)
            case "gun" -> new double[]{0.0, 0.0, 0, F, F, F, 0, 0.0};
            default -> new double[]{0.0, 0.5, 0.5, 0.5, 0.5, 0.5, 0, 0.0};
        };
    }

    /** the an mac dinh cua tung nhan vat; domain dung the an rieng */
    static String styleOf(Tech.Chara c, Tech.T t) {
        if (t.domain()) {
            return switch (c) {
                case GOJO -> "cross";
                case SUKUNA -> "seal";
                case MEGUMI -> "dog";
                case YUTA -> "cross";
                case KENJAKU, MAHITO, JOGO -> "seal";
                default -> "seal";
            };
        }
        String id = t.id();
        if (id.contains("blue") || id.contains("red") || id.contains("purple") || id.contains("beam") || id.contains("bolt")) return "point";
        return switch (c) {
            case GOJO -> "cross";
            case SUKUNA -> "point";
            case MEGUMI -> "dog";
            case YUJI, TODO, TOJI, MAKI, HAKARI, KASHIMO, HIGURUMA -> id.contains("clap") || id.contains("boogie") ? "seal" : "fist";
            case NANAMI, NOBARA -> "gun";
            case INUMAKI, CHOSO, MAHITO, JOGO, KENJAKU -> "palm";
            case YUTA -> "point";
        };
    }

    private static void soundOf(ServerWorld w, Vec3d at, Tech.Chara c) {
        switch (c) {
            case GOJO -> Fx.snd(w, at, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, 1.2f, 0.7f);
            case SUKUNA -> Fx.snd(w, at, SoundEvents.ENTITY_WITHER_SHOOT, 0.6f, 0.6f);
            case MEGUMI -> Fx.snd(w, at, SoundEvents.ENTITY_EVOKER_CAST_SPELL, 0.9f, 0.8f);
            case JOGO -> Fx.snd(w, at, SoundEvents.ITEM_FIRECHARGE_USE, 1.0f, 0.7f);
            case KASHIMO -> Fx.snd(w, at, SoundEvents.ITEM_TRIDENT_THUNDER, 0.5f, 1.8f);
            case YUJI, TODO, TOJI, MAKI, HAKARI -> Fx.snd(w, at, SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, 1.0f, 0.7f);
            default -> Fx.snd(w, at, SoundEvents.ENTITY_EVOKER_CAST_SPELL, 0.7f, 1.2f);
        }
    }

    private static void hand(Rig r, String skin, double hx, double hy, double hz, double sgn, double[] ps) {
        double pitch = ps[0];
        r.rotp(skin, hx, hy, hz, 0.13, 0.045, 0.14, hx, hy, hz - 0.07, 1, 0, 0, -pitch);
        int root = r.idx();
        for (int f = 0; f < 4; f++) {
            double fx = hx + (f - 1.5) * 0.034 * sgn + ((f == 2 && ps[6] > 0) ? -0.026 * sgn : 0) + ps[7] * 0;
            double bend = ps[2 + f];
            double kz = hz + 0.07;
            r.rotp(skin, fx, hy, kz + 0.03, 0.03, 0.03, 0.06, fx, hy, kz, 1, 0, 0, bend * 0.55);
            r.under(root);
            int s1 = r.idx();
            r.rotp(skin, fx, hy, kz + 0.085, 0.028, 0.028, 0.05, fx, hy, kz + 0.06, 1, 0, 0, bend * 0.9);
            r.under(s1);
        }
        r.rotp(skin, hx + sgn * 0.085, hy, hz + 0.0, 0.04, 0.035, 0.07, hx + sgn * 0.06, hy, hz - 0.03, 0, 1, 0, sgn * (0.7 - ps[1] * 0.35));
        r.under(root);
    }

    public static void cast(ServerWorld w, ServerPlayerEntity p, Tech.T t) {
        Tech.Chara c = Data.chara(p.getUuid());
        p.swingHand(Hand.MAIN_HAND);
        soundOf(w, p.getEntityPos(), c);
        if (!Config.displays || Disp.count() > Config.maxDisplays * 0.75) return;
        String style = styleOf(c, t);
        double[] ps = pose(style);
        String skin = Config.texturedModels ? "@skin_hand" : "orange_terracotta";
        Vec3d look0 = p.getRotationVec(1f);
        Vec3d fl = new Vec3d(look0.x, 0, look0.z);
        fl = fl.lengthSquared() < 1e-4 ? new Vec3d(0, 0, 1) : fl.normalize();
        final double yaw = Rig.yawOf(fl);
        final Rig rig = new Rig(w, p.getEyePos(), yaw, 40);
        boolean both = !style.equals("point") || t.domain();
        if (style.equals("seal")) {                               // hai tay chap vao nhau o giua
            hand(rig, skin, -0.055, 0, 0, -1, ps);
            hand(rig, skin, 0.055, 0, 0, 1, ps);
        } else if (both) {
            hand(rig, skin, 0.2, 0, 0, 1, ps);
            hand(rig, skin, -0.2, 0, 0, -1, ps);
        } else {
            hand(rig, skin, 0.2, 0, 0, 1, ps);
            hand(rig, skin, -0.2, 0, 0, -1, pose("fist"));
        }
        final int life = t.domain() ? 34 : 16;
        final int col = c.color;
        Anims.add(new Anims.Anim() {
            int n = 0;
            public boolean tick() {
                n++;
                if (n > life || p.isRemoved() || !p.isAlive()) { rig.kill(); return true; }
                Vec3d look = p.getRotationVec(1f);
                Vec3d flat = new Vec3d(look.x, 0, look.z);
                flat = flat.lengthSquared() < 1e-4 ? new Vec3d(0, 0, 1) : flat.normalize();
                Vec3d right = new Vec3d(-flat.z, 0, flat.x);
                double raise = Math.min(1.0, n / 4.0);
                Vec3d base = p.getEyePos().add(0, -0.62 + 0.12 * raise, 0).add(flat.multiply(0.55 + 0.1 * raise));
                rig.place(base, Rig.yawOf(flat), n);
                if (n % 2 == 0) Fx.put(w, Fx.dust(col, 1.0f), base.add(0, 0.05, 0).add(flat.multiply(0.15)), 2, 0.12, 0.01);
                return false;
            }
        });
    }
}
