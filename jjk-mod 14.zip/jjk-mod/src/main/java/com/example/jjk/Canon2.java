package com.example.jjk;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/** Dot 2 ky nang rieng (co che rieng, khong dung khuon chung): Toji, Maki, Kashimo, Nobara, Higuruma, Hakari. Chua test trong game. */
public class Canon2 {
    public static void registerTechs() {
        String st = Tech.UNTESTED + " (canon 2)";
        Tech.add("inverted_spear", "Inverted Spear of Heaven", "天逆鉾", 70, 400, 30, "instant",
                "Lao toi muc tieu va dam: SAT THUONG lon va XOA het hieu ung (buff/giap phep) cua no.", st, Tech.Chara.TOJI);
        Tech.add("playful_cloud", "Playful Cloud Barrage", "游雲連撃", 55, 260, 18, "instant",
                "Loat 6 don chem nhanh vao muc tieu gan nhat trong 1.5 giay, moi don co vet chem hinh vong cung.", st, Tech.Chara.TOJI);
        Tech.add("split_soul_katana", "Split Soul Katana", "游雲・魂断", 75, 350, 34, "instant",
                "Chem vong cung rong 7 o: bo qua giap, moi quai trung deu chay mau (Wither ngan).", st, Tech.Chara.MAKI);
        Tech.add("mythical_beast_amber", "Mythical Beast Amber", "幻獣琥珀", 120, 800, 8, "instant",
                "Bien thanh tia chop 8 giay: toc do cuc cao, moi 0.25 giay phong set vao quai quanh minh.", st, Tech.Chara.KASHIMO);
        Tech.add("hairpin", "Hairpin", "簪", 65, 300, 36, "instant",
                "Cam 5 cay dinh len muc tieu da dong tam, bam vao Cong Huong: ca 5 no cung luc.", st, Tech.Chara.NOBARA);
        Tech.add("confiscation", "Confiscation", "没収", 60, 450, 0, "instant",
                "Toa an phan quyet muc tieu gan nhat: bi tuoc tu do - dong cung, Weakness va phat sang 6 giay.", st, Tech.Chara.HIGURUMA);
        Tech.add("love_train", "Private Pure Love Train", "私有地・純愛列車", 110, 900, 0, "instant",
                "Hakari vao che do tau cao toc 10 giay: Resistance V, hoi mau, toc do cao, vet giai nang luong sau luong.", st, Tech.Chara.HAKARI);
    }

    public static boolean cast(String id, ServerWorld w, ServerPlayerEntity p) {
        switch (id) {
            case "inverted_spear" -> spear(w, p);
            case "playful_cloud" -> cloud(w, p);
            case "split_soul_katana" -> splitSoul(w, p);
            case "mythical_beast_amber" -> amber(w, p);
            case "hairpin" -> hairpin(w, p);
            case "confiscation" -> confiscate(w, p);
            case "love_train" -> train(w, p);
            default -> { return false; }
        }
        return true;
    }

    private static LivingEntity target(ServerWorld w, ServerPlayerEntity p, double r) {
        LivingEntity t = Stage2Skills.aim(w, p, r);
        if (t == null) t = Shiki.nearest(w, p, p.getEntityPos(), r * 0.8);
        if (t == null) p.sendMessage(Text.literal("Khong co muc tieu"), true);
        return t;
    }

    static void spear(ServerWorld w, ServerPlayerEntity p) {
        LivingEntity t = target(w, p, 12);
        if (t == null) return;
        Vec3d from = p.getEntityPos().add(0, 1, 0), to = Fx.mid(t);
        Vec3d dir = to.subtract(from);
        if (dir.lengthSquared() > 1e-4) {
            Vec3d stop = to.subtract(dir.normalize().multiply(1.2));
            p.requestTeleport(stop.x, t.getY(), stop.z);
        }
        Fx.line(w, Fx.dust(0x9090A0, 1.2f), from, to, 0.3);
        Fx.line(w, Fx.dust(0xFF3030, 1.0f), from.add(0, 0.1, 0), to, 0.5);
        if (Config.displays) new Disp.Beam(w, from, to, "iron_block", "red_concrete", 0.12, 8);
        t.clearStatusEffects();                                                       // phu dinh hieu ung
        Fx.hurt(w, p, t, 30f);
        Fx.put(w, ParticleTypes.CRIT, to, 30, 0.4, 0.5);
        Fx.snd(w, to, SoundEvents.ITEM_TRIDENT_HIT, 1.6f, 0.7f);
        Fx.snd(w, to, SoundEvents.BLOCK_ANVIL_LAND, 0.8f, 1.6f);
    }

    static void cloud(ServerWorld w, ServerPlayerEntity p) {
        LivingEntity t = target(w, p, 8);
        if (t == null) return;
        Anims.add(new Anims.Anim() {
            int n = 0;
            public boolean tick() {
                if (!t.isAlive() || p.isRemoved() || !p.isAlive()) return true;
                n++;
                if (n % 5 != 0) return false;
                int k = n / 5;                                                            // 1..6
                Vec3d c = Fx.mid(t);
                Vec3d side = new Vec3d(Math.cos(k * 1.9), 0, Math.sin(k * 1.9));
                Vec3d up = new Vec3d(0, 1, 0);
                Fx.arc(w, Fx.dust(0xE8E8F0, 1.3f), c, side, up, 1.1 + 0.15 * k, -1.2 + k * 0.2, 1.2 + k * 0.2, 18);
                Fx.hurt(w, p, t, 18f / 6f * 2f);
                Fx.snd(w, c, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.2f, 0.8f + k * 0.12f);
                if (k == 6) { Fx.put(w, ParticleTypes.CRIT, c, 25, 0.5, 0.4); return true; }
                return false;
            }
        });
    }

    static void splitSoul(ServerWorld w, ServerPlayerEntity p) {
        Vec3d look = Canon.flatLook(p);
        Vec3d c = p.getEntityPos().add(0, 1.1, 0);
        Vec3d[] b = Fx.basis(look);
        Fx.arc(w, Fx.dust(0x30FF90, 1.8f), c, b[1], b[2].add(0, 0, 0), 4.5, -1.5, 1.5, 50);
        Fx.arc(w, Fx.dust(0xFFFFFF, 1.2f), c, b[1], b[2], 5.5, -1.5, 1.5, 60);
        if (Config.displays) new Disp.Crescent(w, c.add(look.multiply(1.5)), new Vec3d(0, 1, 0), look, 5.0, 0.4, 0.4, "white_concrete", 8, 6);
        Fx.snd(w, c, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.6f, 0.6f);
        Fx.snd(w, c, SoundEvents.ITEM_TRIDENT_RIPTIDE_3, 0.8f, 1.5f);
        Box box = new Box(c, c).expand(7.5);
        for (LivingEntity e : Fx.hostiles(w, p, box)) {
            Vec3d d = e.getEntityPos().subtract(p.getEntityPos()).multiply(1, 0, 1);
            if (d.lengthSquared() < 1e-4 || d.normalize().dotProduct(look) < 0.2 || d.length() > 7.5) continue;
            Fx.hurt(w, p, e, 34f);
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 60, 1));
            Fx.put(w, ParticleTypes.CRIT, Fx.mid(e), 12, 0.3, 0.3);
        }
    }

    static void amber(ServerWorld w, ServerPlayerEntity p) {
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 170, 4));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 170, 1));
        Fx.snd(w, p.getEntityPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 1.2f, 1.8f);
        Anims.add(new Anims.Anim() {
            int n = 0;
            public boolean tick() {
                if (!p.isAlive() || p.isRemoved() || ++n > 160) return true;
                Vec3d c = p.getEntityPos().add(0, 1, 0);
                Fx.bolt(w, Fx.dust(0x60C8FF, 1.2f), c.add(Fx.randDir().multiply(1.6)), c.add(Fx.randDir().multiply(1.6)), 0.5, 0.3);
                Fx.put(w, ParticleTypes.ELECTRIC_SPARK, c, 3, 0.5, 0.1);
                if (n % 5 == 0) {
                    List<LivingEntity> l = Fx.hostiles(w, p, new Box(c, c).expand(4.5));
                    for (LivingEntity e : l) {
                        Fx.bolt(w, Fx.dust(0xB0E8FF, 1.5f), c, Fx.mid(e), 0.4, 0.3);
                        Fx.hurt(w, p, e, 4f);
                        e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 20, 2));
                    }
                    if (!l.isEmpty()) Fx.snd(w, c, SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT, 0.5f, 2.0f);
                }
                return false;
            }
        });
    }

    static void hairpin(ServerWorld w, ServerPlayerEntity p) {
        LivingEntity t = target(w, p, 22);
        if (t == null) return;
        Anims.add(new Anims.Anim() {
            int n = 0;
            public boolean tick() {
                if (!t.isAlive() || p.isRemoved()) return true;
                n++;
                Vec3d c = Fx.mid(t);
                if (n <= 25 && n % 5 == 0) {                                         // 5 cay dinh bay vao
                    double a = n * 1.26;
                    Vec3d from = c.add(Math.cos(a) * 3, 3.5, Math.sin(a) * 3);
                    Fx.line(w, Fx.dust(0xB8B8C8, 1.1f), from, c, 0.3);
                    if (Config.displays) new Disp.Beam(w, from, c, "iron_block", "gray_concrete", 0.06, 6);
                    Fx.snd(w, c, SoundEvents.ENTITY_ARROW_HIT, 1.2f, 1.4f);
                }
                if (n > 25 && n < 40) Fx.ring(w, Fx.dust(0xFF70A0, 1.3f), c, new Vec3d(1, 0, 0), new Vec3d(0, 0, 1), 0.6 + (n - 25) * 0.08, 20, n * 0.3);
                if (n == 40) {                                                       // Cong Huong
                    Fx.sphere(w, Fx.dust(0xFF4080, 2.0f), c, 2.2, 90, 0);
                    Fx.put(w, ParticleTypes.EXPLOSION, c, 5, 1.0, 0.0);
                    Fx.hurt(w, p, t, 36f);
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(c, c).expand(3))) if (e != t) Fx.hurt(w, p, e, 12f);
                    Fx.snd(w, c, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 1.2f, 1.3f);
                    return true;
                }
                return false;
            }
        });
    }

    static void confiscate(ServerWorld w, ServerPlayerEntity p) {
        LivingEntity t = target(w, p, 20);
        if (t == null) return;
        Vec3d base = t.getEntityPos();
        t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 120, 9));
        t.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 120, 3));
        t.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 120, 0));
        Fx.snd(w, base, SoundEvents.BLOCK_ANVIL_LAND, 1.5f, 0.6f);
        Fx.snd(w, base, SoundEvents.BLOCK_BELL_USE, 1.5f, 0.5f);
        Anims.add(new Anims.Anim() {
            int n = 0;
            public boolean tick() {
                if (!t.isAlive() || ++n > 120) return true;
                Vec3d b = t.getEntityPos();
                for (int i = 0; i < 4; i++) {                                         // 4 thanh song gio
                    double a = i * Math.PI / 2;
                    Fx.line(w, Fx.dust(0xE0C040, 1.0f), b.add(Math.cos(a) * 0.9, 0, Math.sin(a) * 0.9), b.add(Math.cos(a) * 0.9, t.getHeight() + 0.3, Math.sin(a) * 0.9), 0.4);
                }
                Fx.ring(w, Fx.dust(0xE0C040, 1.0f), b.add(0, t.getHeight() + 0.3, 0), new Vec3d(1, 0, 0), new Vec3d(0, 0, 1), 0.9, 16, 0);
                return false;
            }
        });
    }

    static void train(ServerWorld w, ServerPlayerEntity p) {
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 200, 4));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 200, 3));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 200, 3));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 200, 2));
        Fx.snd(w, p.getEntityPos(), SoundEvents.BLOCK_BEACON_ACTIVATE, 1.5f, 1.2f);
        Fx.snd(w, p.getEntityPos(), SoundEvents.ENTITY_FIREWORK_ROCKET_LAUNCH, 1.2f, 0.8f);
        Anims.add(new Anims.Anim() {
            int n = 0;
            public boolean tick() {
                if (!p.isAlive() || p.isRemoved() || ++n > 200) return true;
                Vec3d c = p.getEntityPos().add(0, 1, 0);
                int col = (n / 4) % 2 == 0 ? 0xFF40D0 : 0x40FFFF;
                Fx.put(w, Fx.dust(col, 1.6f), c, 6, 0.5, 0.05);
                Fx.ring(w, Fx.dust(col, 1.2f), p.getEntityPos().add(0, 0.1, 0), new Vec3d(1, 0, 0), new Vec3d(0, 0, 1), 1.0 + (n % 10) * 0.1, 18, n * 0.2);
                if (n % 6 == 0) Fx.put(w, ParticleTypes.END_ROD, c.add(0, 0.5, 0), 4, 0.8, 0.1);
                return false;
            }
        });
    }
}
