package com.example.jjk;

/** Goi ky nang 3: 54 chieu moi (3 chieu / nhan vat) dung co che dac biet moi (lifesteal, shock, delay, mark...). Chua test trong game. */
public class Pack3 {
    static boolean done = false;

    static void load() {
        if (done) return;
        done = true;
        Tech.Chara G = Tech.Chara.GOJO, S = Tech.Chara.SUKUNA, Y = Tech.Chara.YUJI, ME = Tech.Chara.MEGUMI, TO = Tech.Chara.TODO,
                NA = Tech.Chara.NANAMI, NO = Tech.Chara.NOBARA, CH = Tech.Chara.CHOSO, JO = Tech.Chara.JOGO, MA = Tech.Chara.MAHITO,
                IN = Tech.Chara.INUMAKI, YU = Tech.Chara.YUTA, TJ = Tech.Chara.TOJI, HK = Tech.Chara.HAKARI, HG = Tech.Chara.HIGURUMA,
                KS = Tech.Chara.KASHIMO, MK = Tech.Chara.MAKI, KJ = Tech.Chara.KENJAKU;
        String LB = "light_blue_stained_glass", RG = "red_stained_glass", OG = "orange_stained_glass", WG = "white_stained_glass",
                YG = "yellow_stained_glass", PG = "purple_stained_glass", BG = "black_stained_glass", GG = "gray_stained_glass", CG = "cyan_stained_glass";

        // ---- Gojo ----
        Moves.def("g_azure_storm", "nova", "Blue: Azure Storm", "蒼・嵐", "嵐", 85, 380, 26, LB, "blue_concrete", 0x3090FF, 0, 14, 1, 1.4, "slow:40:3,launch:4,vfx:gravity", "Bao Blue ban kinh 14: hat tung, lam cham moi quai (26 st).", G);
        Moves.def("g_red_lance", "beam", "Red: Piercing Lance", "赫・槍", "槍", 70, 300, 40, RG, "red_concrete", 0xFF3030, 34, 0.9, 1, 0, "stun:30,launch:3,vfx:spikes", "Tia Red xuyen dai 34 o: choang va hat tung (40 st).", G);
        Moves.def("g_six_eyes", "buff", "Six Eyes: Overclock", "六眼・全開", "眼", 70, 600, 0, WG, "light_blue_concrete", 0x9FE8FF, 0, 0, 1, 0, "speed:400:2,haste:400:2,regen:100:1,res:400:1,vfx:hex", "20 giay: Speed II, Haste II, Resistance, hoi mau (Luc Nhan toan luc).", G);
        // ---- Sukuna ----
        Moves.def("s_cleave_edge", "slash", "Cleave: Edge Storm", "捌・刃嵐", "刃", 90, 380, 50, RG, "white_concrete", 0xFF2020, 7, 4, 9, 0, "dot:3,vfx:slashes", "9 nhat chem lien hoan, de lai vet chay mau (50 st).", S);
        Moves.def("s_fuga_lite", "proj", "Fuga: Ember", "開・燼", "燼", 110, 480, 60, OG, "magma_block", 0xFF6010, 40, 3.5, 1, 2.2, "fire:200,chain:3,vfx:meteor", "Mui ten lua no lan sang 3 muc tieu (60 st).", S);
        Moves.def("s_malice", "debuff", "Malevolent Malice", "悪意", "悪", 75, 420, 20, RG, "black_concrete", 0x701010, 0, 12, 1, 0, "wither:200:2,weak:200:2,mark:60,vfx:cage", "Ac y bao trum ban kinh 12: Wither II, Weakness, danh dau no sau 3s.", S);
        // ---- Yuji ----
        Moves.def("y_black_barrage", "multi", "Black Flash Barrage", "黒閃連打", "閃", 80, 300, 56, OG, "black_concrete", 0xE02020, 3, 2.4, 8, 2, "stun:20,lifesteal:15", "8 cu dam hac thiem lien tiep, hut mau 15% (56 st).", Y);
        Moves.def("y_soul_rend", "strike", "Soul Rend", "魂裂き", "裂", 65, 260, 34, OG, "red_concrete", 0xE02020, 6, 3, 5, 0, "delay:20,vfx:pillars", "5 vu no hon, moi vu danh lai sau 1 giay (34 st).", Y);
        Moves.def("y_resolve", "buff", "Unyielding Resolve", "不屈", "屈", 70, 600, 0, OG, "yellow_concrete", 0xFF9A3A, 0, 0, 1, 0, "str:400:2,res:400:1,regen:200:1,speed:300:1,vfx:star5", "20 giay: Strength III, Resistance, hoi mau, Speed.", Y);
        // ---- Megumi ----
        Moves.def("me_shadow_pool", "debuff", "Shadow Pool", "影溜り", "溜", 55, 300, 12, GG, "black_concrete", 0x5A6A9A, 0, 9, 1, 0, "slow:200:4,fatigue:200:2,wither:60:1,vfx:tendrils", "Vung bong toi ban kinh 9 nhot chan quai (Slowness V).", ME);
        Moves.def("me_nue_strike", "strike", "Nue: Thunder Dive", "鵺・雷降", "雷", 70, 280, 26, YG, "yellow_concrete", 0xFFE070, 24, 2.5, 6, 0, "shock:3,vfx:bolts", "6 tia set rot xuong, giat dien lan sang (26 st).", ME);
        Moves.def("me_chimera", "nova", "Chimera Shadow Garden", "嵌合暗翳庭", "庭", 85, 400, 28, GG, "black_concrete", 0x5A6A9A, 0, 8, 1, 1.3, "launch:4,dot:2,vfx:wings", "Song bong toi ban kinh 8 hat tung va chay mau (28 st).", ME);
        // ---- Todo ----
        Moves.def("to_swap_ambush", "dash", "Boogie Woogie: Ambush", "不義遊戯・奇襲", "奇", 50, 160, 30, CG, "white_concrete", 0xC09060, 14, 0, 1, 0, "stun:20,vfx:xcut", "Lao 14 o doi cho, gay choang moi quai tren duong (30 st).", TO);
        Moves.def("to_crash_clap", "nova", "Crash Clap", "破壊拍手", "破", 70, 320, 34, WG, "white_concrete", 0xC09060, 0, 11, 1, 1.6, "stun:30,launch:3,vfx:rings", "Vo tay chan dong ban kinh 11 (34 st).", TO);
        Moves.def("to_bf_chain", "multi", "Black Flash Chain", "黒閃連鎖", "鎖", 90, 380, 60, BG, "red_concrete", 0xE02020, 3, 2.4, 5, 2, "chain:3,exec,vfx:shards", "5 cu Black Flash lan sang 3 muc tieu, xu quyet quai yeu (60 st).", TO);
        // ---- Nanami ----
        Moves.def("na_ratio_lock", "debuff", "Ratio: Weak Point Lock", "十劃呪法・固定", "固", 55, 260, 30, YG, "gold_block", 0xE0C060, 16, 0, 1, 0, "weak:100:2,slow:60:3,mark:40,vfx:ratio", "Khoa diem yeu 1 muc tieu: yeu + cham, no sau 2s (30 st).", NA);
        Moves.def("na_bind_vow", "buff", "Overtime Binding Vow", "縛り・残業", "縛", 65, 600, 0, YG, "gold_block", 0xE0C060, 0, 0, 1, 0, "str:300:3,haste:300:2,res:300:1,vfx:ratio", "15 giay: Strength IV, Haste II, Resistance (rang buoc lam them).", NA);
        Moves.def("na_overtime_barrage", "slash", "Overtime Barrage", "残業・乱舞", "乱", 80, 340, 44, YG, "white_concrete", 0xE0C060, 8, 4, 7, 0, "exec,vfx:cage", "7 nhat chem 7:3, xu quyet quai yeu (44 st).", NA);
        // ---- Nobara ----
        Moves.def("no_resonance_chain", "chain", "Resonance: Chain Link", "共鳴り・連鎖", "鎖", 55, 240, 32, "hay_block", "iron_block", 0xD07080, 22, 0, 1, 0, "chain:5,shock:2,vfx:nails", "Cong huong lan sang 5 muc tieu (32 st).", NO);
        Moves.def("no_hairpin_barrage", "strike", "Hairpin Barrage", "簪・乱射", "簪", 60, 260, 22, "iron_block", "red_concrete", 0xD07080, 18, 3, 8, 0, "delay:15,vfx:rain", "8 dinh cam xuong, moi dinh no lai sau 0.75s (22 st).", NO);
        Moves.def("no_flash_nail", "beam", "Black Flash Nail", "黒閃釘", "釘", 70, 300, 48, "iron_block", "black_concrete", 0xE02020, 26, 0.6, 1, 0, "exec,vfx:star5", "Dinh Black Flash xuyen dai 26 o, xu quyet quai yeu (48 st).", NO);
        // ---- Choso ----
        Moves.def("ch_supernova", "proj", "Supernova", "超新星", "新", 85, 420, 40, RG, "redstone_block", 0xB01830, 40, 3, 1, 2.0, "dot:3,chain:2,vfx:drops", "Ngoi sao mau no tung, chay mau lan sang 2 muc tieu (40 st).", CH);
        Moves.def("ch_blood_edge", "slash", "Piercing Blood Edge", "穿血刃", "刃", 65, 260, 38, RG, "red_concrete", 0xB01830, 8, 4, 6, 0, "lifesteal:20,vfx:wings", "6 luoi mau, hut mau 20% (38 st).", CH);
        Moves.def("ch_flowing_red", "buff", "Flowing Red Scale", "赤鱗躍動", "鱗", 60, 500, 0, RG, "red_concrete", 0xB01830, 0, 0, 1, 0, "speed:300:3,str:300:2,regen:200:1,vfx:helix", "15 giay: Speed IV, Strength III, hoi mau (Xich Lan).", CH);
        // ---- Jogo ----
        Moves.def("jo_meteor_lite", "strike", "Meteor: Rain", "極ノ番・雨", "隕", 95, 420, 36, OG, "magma_block", 0xFF6010, 28, 4, 7, 0, "fire:200,delay:25,vfx:meteor", "7 thien thach rot, no lai lan hai (36 st).", JO);
        Moves.def("jo_ember_insects", "chain", "Ember Insects", "火蟲", "蟲", 50, 240, 24, OG, "yellow_concrete", 0xFF6010, 18, 0, 1, 0, "fire:150,chain:5,dot:3,vfx:column", "Dan con trung lua bay lan sang 5 muc tieu (24 st).", JO);
        Moves.def("jo_heat_aura", "nova", "Heat Aura", "熱波", "熱", 55, 220, 18, OG, "magma_block", 0xFF6010, 0, 7, 1, 1.0, "fire:200,launch:2,vfx:sun", "Lan song nhiet ban kinh 7: chay + hat bay (18 st).", JO);
        // ---- Mahito ----
        Moves.def("ma_soul_touch", "debuff", "Soul Touch", "魂の接触", "魂", 60, 280, 50, "purple_stained_glass", "light_gray_concrete", 0x8A5AC0, 4, 0, 1, 0, "weak:200:3,slow:100:3,mark:30", "Cham vao linh hon (tam 4 o): suy nhuoc + no tre (50 st).", MA);
        Moves.def("ma_polymorphic", "multi", "Polymorphic Soul Isomer", "多重魂・変形", "変", 65, 280, 34, "purple_stained_glass", "gray_concrete", 0x8A5AC0, 3, 2.4, 5, 2, "dot:3,lifesteal:25,vfx:tendrils", "5 don bien hinh, chay mau + hut mau 25% (34 st).", MA);
        Moves.def("ma_body_repel", "buff", "Body Repel", "自閉円頓裹", "裹", 60, 500, 0, "purple_stained_glass", "gray_concrete", 0x8A5AC0, 0, 0, 1, 0, "res:300:2,regen:300:2,speed:200:1,vfx:cage", "15 giay: Resistance III, hoi mau nhanh.", MA);
        // ---- Inumaki ----
        Moves.def("in_dont_move", "debuff", "Don't Move", "動くな", "止", 55, 300, 0, WG, "white_concrete", 0xE8E8F0, 0, 14, 1, 0, "slow:100:9,fatigue:100:4,stun:100,vfx:rings", "Moi quai ban kinh 14 dung hinh 5 giay.", IN);
        Moves.def("in_blast_away", "nova", "Blast Away", "吹っ飛べ", "吹", 60, 260, 30, WG, "light_blue_concrete", 0xE8E8F0, 0, 12, 1, 1.8, "launch:6,vfx:dome", "Lenh hat tung moi quai ban kinh 12 (30 st).", IN);
        Moves.def("in_get_crushed", "strike", "Get Crushed", "潰れろ", "潰", 80, 340, 40, WG, "gray_concrete", 0xE8E8F0, 18, 3, 5, 0, "stun:20,exec,vfx:pillars", "5 cot ep xuong, xu quyet quai yeu (40 st).", IN);
        // ---- Yuta ----
        Moves.def("yu_rika_beam", "beam", "Rika: Cursed Beam", "里香・呪光", "光", 90, 400, 56, "light_blue_stained_glass", "white_concrete", 0x90B8FF, 38, 1.2, 1, 0, "chain:2,vfx:swords", "Tia chu luc cua Rika dai 38 o (56 st).", YU);
        Moves.def("yu_copy_slash", "slash", "Copy: Blade Flurry", "模倣・剣舞", "剣", 70, 300, 46, "light_blue_stained_glass", "iron_block", 0x90B8FF, 9, 4.5, 8, 0, "dot:2,lifesteal:10,vfx:wings", "8 nhat kiem sao chep, hut mau 10% (46 st).", YU);
        Moves.def("yu_pure_love", "buff", "Pure Love", "純愛", "愛", 80, 700, 0, "light_blue_stained_glass", "pink_concrete", 0x90B8FF, 0, 0, 1, 0, "str:400:3,res:400:2,regen:200:2,speed:300:2,vfx:star5", "20 giay: Strength IV, Resistance III, hoi mau (Rika nhap the).", YU);
        // ---- Toji ----
        Moves.def("tj_inverted_stab", "dash", "Inverted Spear: Stab", "天逆鉾・突", "突", 45, 150, 44, GG, "iron_block", 0x909098, 12, 0, 1, 0, "stun:20,exec,vfx:links", "Lao 12 o dam xuyen, xu quyet quai yeu (44 st).", TJ);
        Moves.def("tj_chain_whip", "chain", "Chain of a Thousand Miles", "游雲・連", "游", 50, 220, 30, GG, "iron_block", 0x909098, 24, 0, 1, 0, "chain:4,stun:20,vfx:links", "Xich quat lan sang 4 muc tieu va lam choang (30 st).", TJ);
        Moves.def("tj_playful_smash", "strike", "Playful Cloud: Smash", "游雲・叩", "叩", 65, 280, 62, GG, "iron_block", 0x909098, 6, 3.5, 3, 0, "launch:5,stun:30,vfx:rocks", "3 cu dap bang gay xoay (62 st), hat tung va lam choang.", TJ);
        // ---- Hakari ----
        Moves.def("hk_jackpot_rush", "dash", "Jackpot Rush", "大当たり突進", "当", 55, 200, 36, YG, "gold_block", 0xFF40D0, 14, 0, 1, 0, "lifesteal:15,vfx:coins", "Lao 14 o, hut mau 15% (36 st).", HK);
        Moves.def("hk_shutter_doors", "nova", "Shutter Doors", "シャッター", "閉", 65, 300, 28, YG, "gold_block", 0xFF40D0, 0, 9, 1, 1.4, "stun:20,launch:3,vfx:dome", "Cua cuon dap ban kinh 9: choang + hat tung (28 st).", HK);
        Moves.def("hk_idle_surge", "buff", "Idle Surge", "大当たり・活性", "活", 70, 600, 0, YG, "gold_block", 0xFF40D0, 0, 0, 1, 0, "str:400:2,regen:400:3,res:300:2,vfx:sun", "20 giay: Strength III, hoi mau cuc nhanh (chu luc vo han kieu Jackpot).", HK);
        // ---- Higuruma ----
        Moves.def("hg_gavel_slam", "strike", "Gavel Slam", "死刑・槌", "槌", 70, 300, 54, YG, "gold_block", 0xE0C040, 16, 4, 3, 0, "stun:40,vfx:gavel", "3 cu bua phan xet (54 st), choang 2 giay.", HG);
        Moves.def("hg_confiscate", "debuff", "Confiscation", "没収", "没", 60, 300, 20, YG, "black_concrete", 0xE0C040, 18, 0, 1, 0, "weak:300:4,slow:100:2,mark:50,vfx:cage", "Tich thu: yeu cuc manh 15 giay + no tre (20 st).", HG);
        Moves.def("hg_executioner", "beam", "Executioner's Edge", "執行人の剣", "斬", 85, 400, 66, YG, "iron_block", 0xE0C040, 26, 0.7, 1, 0, "exec,vfx:swords", "Luoi hanh hinh xuyen dai 26 o (66 st), xu quyet quai yeu.", HG);
        // ---- Kashimo ----
        Moves.def("ks_thunder_dash", "dash", "Thunder Dash", "雷走", "雷", 50, 160, 38, CG, "light_blue_concrete", 0x40C0FF, 16, 0, 1, 0, "shock:3,stun:15,vfx:bolts", "Lao 16 o nhu set, giat dien lan sang 3 muc tieu (38 st).", KS);
        Moves.def("ks_plasma", "proj", "Plasma Orb", "雷球", "球", 80, 380, 52, CG, "cyan_concrete", 0x40C0FF, 42, 3, 1, 2.6, "chain:5,shock:3,vfx:bolts", "Qua cau plasma lan 5 muc tieu (52 st).", KS);
        Moves.def("ks_storm_core", "nova", "Storm Core", "雷核", "核", 85, 400, 36, CG, "light_blue_concrete", 0x40C0FF, 0, 12, 1, 1.6, "shock:6,stun:30,vfx:helix", "Nua bao set ban kinh 12: te liet + giat dien (36 st).", KS);
        // ---- Maki ----
        Moves.def("mk_slaughter", "slash", "Slaughter Demon", "游雲・屠", "屠", 70, 260, 46, GG, "iron_block", 0x4AA070, 7, 4, 6, 0, "dot:3,exec,vfx:slashes", "6 nhat kiem cua Ma Tru, chay mau + xu quyet (46 st).", MK);
        Moves.def("mk_chain_scythe", "chain", "Chain Scythe", "鎖鎌", "鎌", 50, 220, 32, GG, "iron_block", 0x4AA070, 24, 0, 1, 0, "chain:4,launch:3,vfx:links", "Liem xich lan sang 4 muc tieu, hat tung (32 st).", MK);
        Moves.def("mk_hr_burst", "buff", "Heavenly Burst", "天与暴発", "暴", 65, 600, 0, GG, "green_concrete", 0x4AA070, 0, 0, 1, 0, "speed:300:3,str:300:3,res:200:1,haste:300:2,vfx:arcs", "15 giay: Speed IV, Strength IV, Haste II (thien du bao phat).", MK);
        // ---- Kenjaku ----
        Moves.def("kj_curse_flood", "debuff", "Curse Flood", "呪霊洪水", "洪", 70, 340, 24, PG, "black_concrete", 0x9A60C0, 0, 14, 1, 0, "wither:200:2,slow:100:3,poison:100:1,vfx:tendrils", "Chu linh tran ngap ban kinh 14: Wither II + doc (24 st).", KJ);
        Moves.def("kj_gravity_well", "pull", "Gravity Well", "重力井", "井", 85, 420, 30, PG, "purple_concrete", 0x9A60C0, 22, 14, 80, 0, "slow:60:3,vfx:gravity", "Gieng trong luc hut moi quai ban kinh 14 trong 4 giay (30 st).", KJ);
        Moves.def("kj_brain_surge", "buff", "Brain Surge", "脳・活性", "脳", 70, 600, 0, PG, "purple_concrete", 0x9A60C0, 0, 0, 1, 0, "str:300:2,speed:300:2,regen:200:2,res:200:2,vfx:helix", "15 giay: Strength III, Speed III, hoi mau, Resistance III.", KJ);
    }
}
