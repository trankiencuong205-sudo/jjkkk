package com.example.jjk;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;

import java.util.ArrayList;
import java.util.List;

/**
 * SU KIEN "LAN CHU LINH": dinh ky (curseEvents, moi eventMinutes phut) hoac /jjk event start.
 * 3 dot chu linh quanh mot nguoi choi, dot cuoi co boss (Mahito/Jogo/Hanami/Dagon). Co thanh boss bar.
 * Thang: XP + hoi chu luc cho nguoi trong vung. Het gio: quai bi xoa. Quai su kien co tag "jjk_event". Chua test trong game.
 */
public class Events {
    private static boolean active = false;
    private static ServerBossBar bar;
    private static ServerWorld world;
    private static Vec3d center;
    private static int wave = 0, waveTicks = 0, totalTicks = 0, waveSize = 1, countdown = 0;
    private static int timer = 0;
    private static final int WAVE_TIMEOUT = 20 * 150, TOTAL_TIMEOUT = 20 * 60 * 8, RADIUS = 70;

    private static List<LivingEntity> alive() {
        if (world == null) return List.of();
        return world.getEntitiesByClass(LivingEntity.class, new Box(center, center).expand(RADIUS + 30), e -> e.isAlive() && e.getCommandTags().contains("jjk_event"));
    }

    private static List<ServerPlayerEntity> near() {
        List<ServerPlayerEntity> l = new ArrayList<>();
        if (world == null) return l;
        for (ServerPlayerEntity p : world.getPlayers()) if (!p.isSpectator() && p.getEntityPos().distanceTo(center) < RADIUS) l.add(p);
        return l;
    }

    public static boolean start(MinecraftServer server) {
        if (active) return false;
        List<ServerPlayerEntity> all = new ArrayList<>();
        for (ServerWorld w : server.getWorlds()) for (ServerPlayerEntity p : w.getPlayers()) if (!p.isSpectator() && p.isAlive()) all.add(p);
        if (all.isEmpty()) return false;
        ServerPlayerEntity pick = all.get((int) (Fx.rnd() * all.size()));
        world = (ServerWorld) pick.getEntityWorld();
        center = pick.getEntityPos();
        active = true; wave = 0; waveTicks = 0; totalTicks = 0; countdown = 60;
        bar = new ServerBossBar(Text.literal("LAN CHU LINH").formatted(Formatting.DARK_PURPLE), BossBar.Color.PURPLE, BossBar.Style.NOTCHED_10);
        server.getPlayerManager().broadcast(Text.literal("Chu linh dang tran den quanh " + pick.getName().getString() + "! Hay tap hop va chien dau!").formatted(Formatting.DARK_PURPLE), false);
        return true;
    }

    public static void stop() {
        for (LivingEntity e : alive()) e.discard();
        end();
    }

    private static void end() {
        active = false;
        if (bar != null) { bar.clearPlayers(); bar = null; }
        world = null;
    }

    private static void spawnWave(int n) {
        int players = Math.max(1, near().size());
        int cnt = Math.min(18, 3 + n * 2 + players * 2);
        waveSize = cnt;
        for (int i = 0; i < cnt; i++) {
            int idx = n == 0 ? 0 : n == 1 ? (i % 3 == 0 ? 1 : 0) : (i % 4 == 0 ? 2 : i % 2 == 0 ? 1 : 0);
            drop(idx);
        }
        if (n == 2) { drop(3 + (int) (Fx.rnd() * 4)); waveSize++; }        // boss: Mahito / Jogo / Hanami / Dagon
        for (ServerPlayerEntity p : near()) p.sendMessage(Text.literal("Dot " + (n + 1) + "/3" + (n == 2 ? " - BOSS!" : "")).formatted(Formatting.LIGHT_PURPLE), true);
    }

    private static void drop(int idx) {
        double ang = Fx.rnd() * Math.PI * 2, r = Fx.rnd(14, 28);
        int x = (int) (center.x + Math.cos(ang) * r), z = (int) (center.z + Math.sin(ang) * r);
        if (!world.getChunkManager().isChunkLoaded(x >> 4, z >> 4)) return;
        int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING, x, z);
        Mobs.spawn(world, idx, new Vec3d(x + 0.5, y, z + 0.5), "jjk_event");
    }

    private static void tick(MinecraftServer server) {
        if (!active) {
            if (Config.curseEvents && ++timer >= Config.eventMinutes * 1200) { timer = 0; start(server); }
            return;
        }
        if (world == null || center == null) { end(); return; }
        totalTicks++; waveTicks++;
        List<ServerPlayerEntity> ps = near();
        if (totalTicks % 20 == 0 && bar != null) {
            for (ServerPlayerEntity p : new ArrayList<>(bar.getPlayers())) if (!ps.contains(p)) bar.removePlayer(p);
            for (ServerPlayerEntity p : ps) bar.addPlayer(p);
        }
        if (ps.isEmpty() && totalTicks % 200 == 0 && world.getPlayers().isEmpty()) { stop(); return; }
        if (totalTicks > TOTAL_TIMEOUT) {
            server.getPlayerManager().broadcast(Text.literal("Lan chu linh tan bien...").formatted(Formatting.GRAY), false);
            stop(); return;
        }
        if (countdown > 0) {
            if (--countdown == 0) { spawnWave(wave); waveTicks = 0; }
            if (bar != null) bar.setPercent(1f);
            return;
        }
        int left = alive().size();
        if (bar != null) {
            bar.setName(Text.literal("LAN CHU LINH - Dot " + (wave + 1) + "/3  (con " + left + ")").formatted(Formatting.DARK_PURPLE));
            bar.setPercent(Math.max(0f, Math.min(1f, left / (float) Math.max(1, waveSize))));
        }
        if (left == 0 || waveTicks > WAVE_TIMEOUT) {
            for (LivingEntity e : alive()) e.discard();
            if (++wave >= 3) {                                     // thang
                for (ServerPlayerEntity p : ps) {
                    Progress.addXp(p, 150);
                    Data.addEnergy(p.getUuid(), 1e9);
                    Disp.tryRun(world, "give " + p.getUuid() + " minecraft:bone[custom_name={text:\"Cursed Finger\",italic:false,color:\"dark_red\"},enchantment_glint_override=true]");
                    p.sendMessage(Text.literal("DA DE NEN LAN CHU LINH!  +150 XP").formatted(Formatting.GOLD), false);
                }
                end();
            } else { countdown = 100; waveTicks = 0; }
        }
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> Safe.run("Events.tick", () -> tick(server)));
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("jjk").then(CommandManager.literal("event")
                .then(CommandManager.literal("start").executes(c -> {
                    if (!ok(c.getSource())) return say(c.getSource(), "Ban khong co quyen.");
                    return say(c.getSource(), start(c.getSource().getServer()) ? "[jjk] bat dau su kien." : "[jjk] khong bat dau duoc (dang chay hoac khong co nguoi choi).");
                }))
                .then(CommandManager.literal("stop").executes(c -> {
                    if (!ok(c.getSource())) return say(c.getSource(), "Ban khong co quyen.");
                    stop();
                    return say(c.getSource(), "[jjk] da dung su kien.");
                }))));
        });
    }

    private static boolean ok(ServerCommandSource s) { ServerPlayerEntity p = s.getPlayer(); return p == null || Admin.is(s.getServer(), p); }
    private static int say(ServerCommandSource s, String m) { s.sendFeedback(() -> Text.literal(m), false); return 1; }
}
