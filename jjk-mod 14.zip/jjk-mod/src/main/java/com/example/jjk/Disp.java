package com.example.jjk;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.entity.Entity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Hinh hoc 3D that bang "display entity" cua Minecraft (block_display): khoi kinh/be tong phat sang, xoay, thu phong
 * muot (noi suy phia client). Tao bang lenh /summon de khong phu thuoc API noi bo. Moi thuc the co TTL cung
 * -> tu bien mat ke ca khi hoat anh loi; thuc the mo coi (sau khi tat server giua chung) bi xoa khi tai lai.
 */
public class Disp {
    // ---------- quaternion nho ----------
    public static final class Q {
        public static final Q ID = new Q(0, 0, 0, 1);
        final double x, y, z, w;
        Q(double x, double y, double z, double w) { this.x = x; this.y = y; this.z = z; this.w = w; }
        public static Q axis(double ax, double ay, double az, double ang) {
            double n = Math.sqrt(ax * ax + ay * ay + az * az);
            if (n < 1.0E-9) return ID;
            double s = Math.sin(ang / 2) / n;
            return new Q(ax * s, ay * s, az * s, Math.cos(ang / 2));
        }
        public Q mul(Q o) {
            return new Q(w * o.x + x * o.w + y * o.z - z * o.y,
                    w * o.y - x * o.z + y * o.w + z * o.x,
                    w * o.z + x * o.y - y * o.x + z * o.w,
                    w * o.w - x * o.x - y * o.y - z * o.z);
        }
        public Vec3d rot(Vec3d v) {
            double tx = 2 * (y * v.z - z * v.y), ty = 2 * (z * v.x - x * v.z), tz = 2 * (x * v.y - y * v.x);
            return new Vec3d(v.x + w * tx + (y * tz - z * ty), v.y + w * ty + (z * tx - x * tz), v.z + w * tz + (x * ty - y * tx));
        }
        /** phep quay dua vector don vi a thanh b */
        public static Q fromTo(Vec3d a, Vec3d b) {
            double d = a.dotProduct(b);
            if (d > 0.99999) return ID;
            if (d < -0.99999) {
                Vec3d p = Math.abs(a.x) < 0.9 ? new Vec3d(1, 0, 0) : new Vec3d(0, 1, 0);
                Vec3d ax = a.crossProduct(p);
                return axis(ax.x, ax.y, ax.z, Math.PI);
            }
            Vec3d ax = a.crossProduct(b);
            return axis(ax.x, ax.y, ax.z, Math.acos(Math.max(-1, Math.min(1, d))));
        }
    }

    // ---------- 1 khoi hien thi ----------
    public static final class H {
        final ServerWorld w; final String tag; Entity ent; int expire; boolean item;

        void set(Q q, double sx, double sy, double sz, int interp) {
            if (ent == null || ent.isRemoved()) return;
            run(w, "data merge entity " + ent.getUuid() + " {start_interpolation:-1,interpolation_duration:" + interp + ",transformation:" + (item ? centered(q, sx, sy, sz) : transform(q, sx, sy, sz)) + "}");
        }

        void move(Vec3d p) {
            if (ent == null || ent.isRemoved()) return;
            ent.requestTeleport(p.x, p.y, p.z);
        }

        public void kill() {
            expire = 0;
            if (ent != null) ent.discard();
            ent = null;
            LIVE.remove(tag);
        }

        H(ServerWorld w, String tag) { this.w = w; this.tag = tag; }
    }

    private static final List<H> ALL = new ArrayList<>();
    private static final Set<String> LIVE = new HashSet<>();
    private static final List<Entity> ORPHANS = new ArrayList<>();
    private static int seq = 0, now = 0;
    public static int count() { return ALL.size(); }
    public static int clearAll() { int n = ALL.size(); for (H h : new ArrayList<>(ALL)) h.kill(); ALL.clear(); return n; }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> Safe.run("Disp.tick", () -> {
            now++;
            if (!ORPHANS.isEmpty()) { for (Entity e : ORPHANS) e.discard(); ORPHANS.clear(); }
            for (Iterator<H> it = ALL.iterator(); it.hasNext(); ) {
                H h = it.next();
                if (h.ent == null || now >= h.expire || h.ent.isRemoved()) { h.kill(); it.remove(); }
            }
        }));
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> { for (H h : ALL) h.kill(); ALL.clear(); });
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (!entity.getCommandTags().contains("jjkfx")) return;
            for (String t : entity.getCommandTags()) if (LIVE.contains(t)) return;
            ORPHANS.add(entity);
        });
    }

    private static String f(double v) { return String.format(Locale.ROOT, "%.4ff", v); }

    private static String centered(Q q, double sx, double sy, double sz) {
        return "{left_rotation:[" + f(q.x) + "," + f(q.y) + "," + f(q.z) + "," + f(q.w) + "],right_rotation:[0f,0f,0f,1f],scale:["
                + f(sx) + "," + f(sy) + "," + f(sz) + "],translation:[0f,0f,0f]}";
    }

    private static String transform(Q q, double sx, double sy, double sz) {
        Vec3d t = q.rot(new Vec3d(sx / 2, sy / 2, sz / 2)).multiply(-1);
        return "{left_rotation:[" + f(q.x) + "," + f(q.y) + "," + f(q.z) + "," + f(q.w) + "],right_rotation:[0f,0f,0f,1f],scale:["
                + f(sx) + "," + f(sy) + "," + f(sz) + "],translation:[" + f(t.x) + "," + f(t.y) + "," + f(t.z) + "]}";
    }

    static void run(ServerWorld w, String cmd) { tryRun(w, cmd); }

    /** chay lenh, tra ve true neu thanh cong (dung de thu nhieu cu phap theo phien ban) */
    public static boolean tryRun(ServerWorld w, String cmd) {
        try {
            MinecraftServer server = w.getServer();
            ServerCommandSource src = server.getCommandSource().withWorld(w).withSilent();
            server.getCommandManager().getDispatcher().execute(cmd, src);
            return true;
        } catch (CommandSyntaxException | RuntimeException e) {
            System.err.println("[jjk] command failed: " + e.getMessage());
            return false;
        }
    }

    public static H block(ServerWorld w, Vec3d pos, String blockId, double sx, double sy, double sz, Q q, int ttlTicks) {
        if (ALL.size() >= Config.maxDisplays) return new H(w, "jjkfx_none");           // tran so luong hieu ung: chong lag server
        String tag = "jjkfx" + (++seq);
        LIVE.add(tag);
        H h = new H(w, tag);
        h.item = blockId.startsWith("@");
        h.expire = now + ttlTicks;
        String cmd;
        if (blockId.startsWith("@")) {                    // vat lieu co texture rieng (item_display, mo hinh jjk:mat_<ten>); goc o TAM nen translation = 0
            cmd = String.format(Locale.ROOT, "summon item_display %.3f %.3f %.3f {item:{id:\"minecraft:stick\",count:1,components:{\"minecraft:item_model\":\"jjk:mat_%s\"}},item_display:\"none\","
                            + "view_range:4.0f,teleport_duration:2,interpolation_duration:2,"
                            + "transformation:%s,Tags:[\"jjkfx\",\"%s\"]}",
                    pos.x, pos.y, pos.z, blockId.substring(1), centered(q, sx, sy, sz), tag);
        } else {
            cmd = String.format(Locale.ROOT, "summon block_display %.3f %.3f %.3f {block_state:{Name:\"minecraft:%s\"},"
                            + "brightness:{sky:15,block:15},view_range:4.0f,teleport_duration:2,interpolation_duration:2,"
                            + "transformation:%s,Tags:[\"jjkfx\",\"%s\"]}",
                    pos.x, pos.y, pos.z, blockId, transform(q, sx, sy, sz), tag);
        }
        run(w, cmd);
        for (Entity e : w.getEntitiesByClass(Entity.class, new Box(pos, pos).expand(2.0), x -> x.getCommandTags().contains(tag))) { h.ent = e; break; }
        if (h.ent == null) { LIVE.remove(tag); return h; }
        ALL.add(h);
        return h;
    }

    // ---------- Qua cau nang luong (da dien xoay) ----------
    public static final class Orb {
        final H[] glass = new H[3]; final H core, halo; final Q[] base = new Q[3]; final double size;
        public Orb(ServerWorld w, Vec3d pos, String glassBlock, String coreBlock, String haloBlock, double size, int ttl) {
            this.size = size;
            base[0] = Q.ID;
            base[1] = Q.axis(1, 0, 1, Math.PI / 4).mul(Q.axis(0, 1, 0, Math.PI / 4));
            base[2] = Q.axis(0, 1, 1, Math.PI / 4).mul(Q.axis(1, 0, 0, Math.PI / 3));
            for (int i = 0; i < 3; i++) glass[i] = block(w, pos, glassBlock, size, size, size, base[i], ttl);
            core = coreBlock == null ? null : block(w, pos, coreBlock, size * 0.55, size * 0.55, size * 0.55, Q.ID, ttl);
            halo = haloBlock == null ? null : block(w, pos, haloBlock, size * 1.6, size * 1.6, size * 1.6, base[1], ttl);
        }
        /** goi moi tick: di chuyen; xoay/thu phong chi cap nhat khi refresh = true (de giam so lenh) */
        public void update(Vec3d pos, double spin, double scale, boolean refresh) {
            Q[] spinQ = {Q.axis(0, 1, 0, spin), Q.axis(1, 0, 0, spin * 1.3), Q.axis(0, 0, 1, spin * 0.8)};
            for (int i = 0; i < 3; i++) {
                glass[i].move(pos);
                if (refresh) glass[i].set(spinQ[i].mul(base[i]), size * scale, size * scale, size * scale, 3);
            }
            if (core != null) { core.move(pos); if (refresh) core.set(Q.axis(1, 1, 0, spin * 1.7), size * 0.55 * scale, size * 0.55 * scale, size * 0.55 * scale, 3); }
            if (halo != null) { halo.move(pos); if (refresh) halo.set(Q.axis(0, 1, 1, -spin), size * 1.6 * scale, size * 1.6 * scale, size * 1.6 * scale, 3); }
        }
        public void kill() {
            for (H h : glass) h.kill();
            if (core != null) core.kill();
            if (halo != null) halo.kill();
        }
    }

    // ---------- Tia nang luong (hop dai) ----------
    public static final class Beam {
        final H outer, inner;
        public Beam(ServerWorld w, Vec3d from, Vec3d to, String outerBlock, String innerBlock, double thick, int ttl) {
            Vec3d d = to.subtract(from);
            double len = Math.max(0.1, d.length());
            Q q = Q.fromTo(new Vec3d(1, 0, 0), d.multiply(1.0 / len));
            Vec3d mid = from.add(to).multiply(0.5);
            outer = block(w, mid, outerBlock, len, thick, thick, q, ttl);
            inner = innerBlock == null ? null : block(w, mid, innerBlock, len, thick * 0.45, thick * 0.45, q, ttl);
        }
        public void update(Vec3d from, Vec3d to, double thick) {
            Vec3d d = to.subtract(from);
            double len = Math.max(0.1, d.length());
            Q q = Q.fromTo(new Vec3d(1, 0, 0), d.multiply(1.0 / len));
            Vec3d mid = from.add(to).multiply(0.5);
            outer.move(mid); outer.set(q, len, thick, thick, 1);
            if (inner != null) { inner.move(mid); inner.set(q, len, thick * 0.45, thick * 0.45, 1); }
        }
        public void kill() { outer.kill(); if (inner != null) inner.kill(); }
    }

    // ---------- Luoi chem cong (nhieu doan ghep) ----------
    public static final class Crescent {
        final List<H> segs = new ArrayList<>(); final List<Vec3d> offs = new ArrayList<>();
        public Crescent(ServerWorld w, Vec3d center, Vec3d u, Vec3d dir, double L, double bend, double width, String main, int n, int ttl) {
            for (int i = 0; i < n; i++) {
                double s0 = -1 + 2.0 * i / n, s1 = -1 + 2.0 * (i + 1) / n;
                Vec3d a = u.multiply(s0 * L).subtract(dir.multiply(bend * s0 * s0));
                Vec3d b = u.multiply(s1 * L).subtract(dir.multiply(bend * s1 * s1));
                Vec3d t = b.subtract(a);
                double len = t.length();
                Q q = Q.fromTo(new Vec3d(1, 0, 0), t.multiply(1.0 / len));
                Vec3d off = a.add(b).multiply(0.5);
                double taper = 0.35 + 0.65 * Math.sin(Math.PI * (i + 0.5) / n);       // mong o hai dau
                segs.add(block(w, center.add(off), main, len * 1.15, 0.05, width * taper, q, ttl));
                offs.add(off);
            }
        }
        public void moveTo(Vec3d center) { for (int i = 0; i < segs.size(); i++) segs.get(i).move(center.add(offs.get(i))); }
        public void kill() { for (H h : segs) h.kill(); }
    }
}
