package com.example.jjk;

import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * NGON TAY SUKUNA: boss roi "Cursed Finger" (xuong co ten). Chuot phai de NUOT: +XP, +3% sat thuong moi ngon (toi da 20).
 * Nuot du 20 ngon -> Sukuna thuc tinh (boss) xuat hien ngay canh ban, ban reset ve 0 ngon (giu XP). Chua test trong game.
 */
public class Fingers {
    private static final Map<UUID, Integer> COUNT = new HashMap<>();

    public static int count(UUID id) { return COUNT.getOrDefault(id, 0); }
    public static double dmgBonus(UUID id) { return 0.03 * count(id); }

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("jjk-fingers.properties"); }

    static void load() {
        try {
            if (!Files.exists(file())) return;
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(file())) { p.load(in); }
            for (String k : p.stringPropertyNames()) try { COUNT.put(UUID.fromString(k), Integer.parseInt(p.getProperty(k))); } catch (Exception ignored) { }
        } catch (Exception e) { Safe.log("Fingers.load", e); }
    }

    static void save() {
        try {
            Properties p = new Properties();
            for (Map.Entry<UUID, Integer> e : COUNT.entrySet()) p.setProperty(e.getKey().toString(), String.valueOf(e.getValue()));
            try (OutputStream out = Files.newOutputStream(file())) { p.store(out, "Sukuna fingers consumed"); }
        } catch (Exception e) { Safe.log("Fingers.save", e); }
    }

    private static boolean isFinger(ItemStack s) {
        return s.isOf(Items.BONE) && s.getName().getString().contains("Cursed Finger");
    }

    public static void register() {
        load();
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> save());
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack st = player.getStackInHand(hand);
            if (world.isClient() || !isFinger(st) || !(player instanceof ServerPlayerEntity sp) || !(world instanceof ServerWorld w)) return ActionResult.PASS;
            try {
                st.decrement(1);
                UUID id = sp.getUuid();
                int n = count(id) + 1;
                Progress.addXp(sp, 50);
                Vec3d c = sp.getEntityPos().add(0, 1, 0);
                Fx.sphere(w, Fx.dust(0x701010, 1.6f), c, 1.2, 50, 0);
                Fx.snd(w, c, net.minecraft.sound.SoundEvents.ENTITY_WARDEN_HEARTBEAT, 2.0f, 0.6f);
                if (n >= 20) {
                    COUNT.put(id, 0);
                    sp.sendMessage(Text.literal("20/20 ngon tay... SUKUNA THUC TINH!").formatted(Formatting.DARK_RED, Formatting.BOLD), false);
                    Mobs.spawn(w, 7, sp.getEntityPos().add(sp.getRotationVec(1f).multiply(1, 0, 1).normalize().multiply(5)));
                } else {
                    COUNT.put(id, n);
                    sp.sendMessage(Text.literal("Ban nuot mot Cursed Finger (" + n + "/20). Sat thuong +" + (int) Math.round(dmgBonus(id) * 100) + "%").formatted(Formatting.DARK_RED), true);
                }
                save();
            } catch (Throwable t) { Safe.log("Fingers.use", t); }
            return ActionResult.SUCCESS;
        });
    }
}
