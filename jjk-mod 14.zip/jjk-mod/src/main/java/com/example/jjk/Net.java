package com.example.jjk;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.List;
import java.util.UUID;

public class Net {
    private static final java.util.Map<UUID, int[]> RATE = new java.util.HashMap<>();     // {tick cua so, so goi}

    static boolean allow(UUID id, int tick) {
        int[] r = RATE.computeIfAbsent(id, k -> new int[]{tick, 0});
        if (tick - r[0] >= 20) { r[0] = tick; r[1] = 0; }
        return ++r[1] <= Config.actionsPerSecond;
    }

    public static void register() {
        PayloadTypeRegistry.playC2S().register(ActionPayload.ID, ActionPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SyncPayload.ID, SyncPayload.CODEC);

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> Data.sync(handler.player));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> { RATE.remove(handler.player.getUuid()); Data.forget(handler.player.getUuid()); });

        ServerPlayNetworking.registerGlobalReceiver(ActionPayload.ID, (payload, context) -> {
            ServerPlayerEntity p = context.player();
            UUID id = p.getUuid();
            if (!allow(id, context.server().getTicks())) return;                  // chong spam
            int act = payload.action();
            if ((act == 13 || act == 10) && !Admin.is(context.server(), p)) {       // chi admin moi doi cai dat / goi quai
                p.sendMessage(net.minecraft.text.Text.literal("Ban khong co quyen (them ten vao admins= trong config/jjk-config.properties)."), true);
                return;
            }
            List<Tech.T> list = Data.techs(id);
            switch (payload.action()) {
                case 0 -> Data.setChara(id, payload.a());
                case 4 -> {                                       // dung ky nang theo chi so trong danh sach nhan vat (nut trong menu)
                    if (payload.a() >= 0 && payload.a() < list.size()) Abilities.cast(context.server(), p, list.get(payload.a()));
                }
                case 7 -> {                                       // phim slot: server tu tra o -> ky nang (khong tin client)
                    String[] sl = Data.slots(id);
                    int s = payload.a();
                    if (s >= 0 && s < sl.length && sl[s] != null) {
                        Tech.T t = Tech.byId(sl[s]);
                        if (t != null) Abilities.cast(context.server(), p, t);
                    }
                }
                case 8 -> {                                       // gan / thay / xoa ky nang trong slot
                    int b = payload.b();
                    if (b < 0) Data.equip(id, payload.a(), null);
                    else if (b < list.size()) Data.equip(id, payload.a(), list.get(b).id());
                }
                case 15 -> Data.changeSel(id, payload.a());       // chuyen ky nang (+1 / -1)
                case 16 -> Data.setSel(id, payload.a());          // chon ky nang theo chi so (tu menu)
                case 17 -> {                                      // tung ky nang dang chon
                    Tech.T t = Data.selected(id);
                    if (t != null) Abilities.cast(context.server(), p, t);
                }
                case 14 -> Data.changePage(id, payload.a());      // doi trang ky nang
                case 13 -> Data.tweak(id, payload.a(), payload.b());   // cai dat / che do test
                case 10 -> Mobs.spawnNear(p, payload.a());       // goi quai (creative)
                case 11 -> {                                      // mac / thao trang phuc
                    if (p.getEntityWorld() instanceof net.minecraft.server.world.ServerWorld sw) Outfits.wear(sw, p, payload.a());
                }
                default -> { }                                    // 2 = xin dong bo (sync ben duoi)
            }
            Data.sync(p);
        });
    }
}
