package com.example.jjk;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Mo rong linh vuc (domain) CO HINH ANH 3D: moi domain dung mot "canh" bang block_display (Disp):
 * vo cau/khoi bao quanh bi lat nguoc (scale am) de nhin tu ben trong, nen, cot, den tho, nui lua, ban xu an...
 * Co the tat bang config domainShell=false (chi con hat). Chua duoc test trong game.
 */
public class Domains {
    static Vec3d rotY(Vec3d v, double a) {
        double c = Math.cos(a), s = Math.sin(a);
        return new Vec3d(v.x * c + v.z * s, v.y, -v.x * s + v.z * c);
    }

    // ============== Canh (scene) ==============
    public static final class Scene {
        final ServerWorld w; final Vec3d c; final int ttl; final boolean on;
        final List<Disp.H> parts = new ArrayList<>();
        final List<Disp.H> orbs = new ArrayList<>();
        final List<Vec3d> offs = new ArrayList<>();
        final List<Double> spd = new ArrayList<>();

        Scene(ServerWorld w, Vec3d c, int ttl) {
            this.w = w; this.c = c; this.ttl = ttl;
            this.on = Config.displays && Config.domainShell;
        }

        Disp.H box(String b, double ox, double oy, double oz, double sx, double sy, double sz) {
            return boxQ(b, ox, oy, oz, sx, sy, sz, Disp.Q.ID);
        }

        Disp.H boxQ(String b, double ox, double oy, double oz, double sx, double sy, double sz, Disp.Q q) {
            if (!on) return null;
            if (room != null && sy <= 0.07 && sx >= 3) return null;      // san phang: da co hoa tiet bang khoi that
            Disp.H h = Disp.block(w, c.add(ox, oy, oz), b, sx, sy, sz, q, ttl);
            parts.add(h);
            return h;
        }

        /** hat/khoi nho quay quanh tam (sao, den, mat...) */
        void orbit(String b, double ox, double oy, double oz, double size, double speed) {
            if (!on) return;
            Disp.H h = Disp.block(w, c.add(ox, oy, oz), b, size, size, size, Disp.Q.ID, ttl);
            orbs.add(h); offs.add(new Vec3d(ox, oy, oz)); spd.add(speed);
        }

        final List<Disp.H> walls = new ArrayList<>();
        final List<Double> wallSz = new ArrayList<>();
        final List<Disp.Q> wallQ = new ArrayList<>();

        /** CAN PHONG kin: 4 tuong + tran (tam mong nhin duoc tu ca hai mat, khong can scale am); r = nua canh, cy = nua chieu cao */
        Room room;

        void shell(String b, double r, double cy, int grow) { shell(b, r, cy, grow, null); }

        void shell(String b, double r, double cy, int grow, String style) {
            if (Config.solidDomain && Room.active() < Config.maxRooms) {   // phong khoi THAT: khong can tuong hien thi
                room = new Room(w, c, (int) Math.round(r), (int) Math.round(cy * 2), b.equals("white_concrete") ? b : "black_concrete", grow, style);
                return;
            }
            if (!on) return;
            double t = 0.5, h = cy * 2;
            double[][] d = {{r, cy, 0, t, h, 2 * r}, {-r, cy, 0, t, h, 2 * r}, {0, cy, r, 2 * r, h, t}, {0, cy, -r, 2 * r, h, t}, {0, h, 0, 2 * r, t, 2 * r}};
            for (double[] x : d) {
                Disp.H hh = Disp.block(w, c.add(x[0], x[1], x[2]), b, 0.02, 0.02, 0.02, Disp.Q.ID, ttl);
                if (hh == null) continue;
                hh.set(Disp.Q.ID, x[3], x[4], x[5], grow);
                walls.add(hh);
            }
        }

        /** vien/den trang tri gan tuong (khung, cot, bang phang sat tuong) */
        void trim(String b, double ox, double oy, double oz, double sx, double sy, double sz) { box(b, ox, oy, oz, sx, sy, sz); }

        /** NGON TAY SUKUNA (xac kho, 3 dot + mong den), nam ngang tren mat dat hoac lo lung; yaw la huong, y la do cao tam */
        void finger(double ox, double oy, double oz, double yaw, double tilt) {
            if (!on) return;
            Disp.Q q = Disp.Q.axis(0, 1, 0, yaw).mul(Disp.Q.axis(1, 0, 0, tilt));
            double[][] seg = {{0, 0, -0.36, 0.2, 0.18, 0.34}, {0, 0.01, 0, 0.17, 0.16, 0.3}, {0, 0.0, 0.3, 0.15, 0.14, 0.26}};
            String[] bl = {"brown_terracotta", "terracotta", "brown_terracotta"};
            for (int i = 0; i < 3; i++) {
                Vec3d l = q.rot(new Vec3d(seg[i][0], seg[i][1], seg[i][2]));
                boxQ(bl[i], ox + l.x, oy + l.y, oz + l.z, seg[i][3], seg[i][4], seg[i][5], q);
            }
            Vec3d l = q.rot(new Vec3d(0, 0.02, 0.46));
            boxQ("black_concrete", ox + l.x, oy + l.y, oz + l.z, 0.12, 0.1, 0.09, q);   // mong
            Vec3d g = q.rot(new Vec3d(0, 0.1, -0.5));
            boxQ("red_concrete", ox + g.x, oy + g.y, oz + g.z, 0.05, 0.05, 0.05, q);   // vet nguyen
        }

        void tick(int t) {
            if (!on || t % 3 != 0) return;
            for (int i = 0; i < orbs.size(); i++) {
                Vec3d o = rotY(offs.get(i), spd.get(i) * 3);
                offs.set(i, o);
                orbs.get(i).move(c.add(o));
            }
        }

        void beginEnd(int ticks) {
            if (room != null) room.startClose(ticks);
            if (!on) return;
            for (Disp.H h : parts) h.kill();
            for (Disp.H h : orbs) h.kill();
            parts.clear(); orbs.clear(); offs.clear(); spd.clear();
            for (Disp.H hh : walls) hh.set(Disp.Q.ID, 0.02, 0.02, 0.02, ticks);
        }

        void kill() {
            if (room != null) { room.closeNow(); room = null; }
            for (Disp.H h : parts) h.kill();
            for (Disp.H h : orbs) h.kill();
            for (Disp.H hh : walls) hh.kill();
            walls.clear();
            parts.clear(); orbs.clear(); offs.clear(); spd.clear();
        }
    }

    // ============== cac canh ==============
    public static Scene voidScene(ServerWorld w, Vec3d c, int ttl, int grow) {
        Scene s = new Scene(w, c, ttl);
        s.shell("black_concrete", 14, 9, grow, "void");
        s.box("black_concrete", 0, 0.02, 0, 29, 0.05, 29);
        String[] st = {"white_concrete", "light_blue_concrete", "white_concrete", "purple_concrete", "sea_lantern"};
        for (int i = 0; i < 44; i++) {
            Vec3d d = Fx.randDir().multiply(Fx.rnd(2, 12));
            s.orbit(st[i % 5], d.x, 6 + d.y * 0.9, d.z, Fx.rnd(0.1, 0.28), Fx.rnd(0.004, 0.012) * (i % 2 == 0 ? 1 : -1));
        }
        String[] gal = {"light_blue_concrete", "white_concrete", "magenta_concrete", "cyan_concrete"};
        for (int arm = 0; arm < 3; arm++) for (int i = 0; i < 20; i++) {
            double a = i * 0.4 + arm * Math.PI * 2 / 3, r = 1.5 + i * 0.5;
            s.orbit(gal[(i + arm) % 4], Math.cos(a) * r, 3 + Math.sin(i * 0.7) * 0.4, Math.sin(a) * r, 0.2 + 0.1 * ((i + arm) % 3), 0.008);
        }
        return s;
    }

    public static Scene shrineScene(ServerWorld w, Vec3d c, int ttl) {
        Scene s = new Scene(w, c, ttl);
        s.shell("black_concrete", 16, 15, 20, "shrine");
        s.box("black_concrete", 0, 0.02, 0, 31, 0.05, 31);
        s.boxQ("red_concrete", 0, 0.05, 0, 17, 0.05, 17, Disp.Q.axis(0, 1, 0, Math.PI / 4));
        for (int k = 0; k < 8; k++) {
            double a = k * Math.PI / 4 + Math.PI / 8;
            double x = Math.cos(a) * 9.5, z = Math.sin(a) * 9.5;
            s.box("dark_oak_log", x, 5, z, 0.9, 10, 0.9);
            s.box("gold_block", x, 10.2, z, 1.3, 0.5, 1.3);
            s.box("red_concrete", x, 0.3, z, 1.3, 0.5, 1.3);
        }
        s.box("dark_oak_planks", 0, 10.6, 0, 23, 0.6, 23);
        s.box("crimson_planks", 0, 12.4, 0, 17, 0.6, 17);
        s.box("gold_block", 0, 14.0, 0, 11, 0.6, 11);
        s.box("black_concrete", 0, 14.6, 0, 7, 0.6, 7);
        s.box("bone_block", 0, 18.5, 0, 0.6, 7.5, 0.6);                       // cot song
        for (int i = 0; i < 6; i++) {
            double y = 16 + i * 0.8, len = 3.6 - Math.abs(i - 2) * 0.3;
            s.box("bone_block", 0, y, 0, len, 0.3, 0.3);
            s.box("bone_block", 0, y, 0, 0.3, 0.3, len);
        }
        s.box("bone_block", 0, 24.5, 0, 3.6, 2.5, 3.0);                        // so
        s.box("bone_block", 0, 22.8, 0.25, 2.6, 0.9, 2.3);                     // ham
        s.box("black_concrete", -0.8, 24.9, 1.55, 0.7, 0.7, 0.1);
        s.box("black_concrete", 0.8, 24.9, 1.55, 0.7, 0.7, 0.1);
        s.box("black_concrete", 0, 24.0, 1.55, 0.35, 0.5, 0.1);
        for (int i = 0; i < 14; i++) {                                         // dong xuong quanh
            double a = Fx.rnd(0, 6.28), r = Fx.rnd(3, 13);
            s.boxQ("bone_block", Math.cos(a) * r, 0.25, Math.sin(a) * r, Fx.rnd(0.8, 1.6), 0.3, 0.3, Disp.Q.axis(0, 1, 0, Fx.rnd(0, 3.14)));
        }
        // 20 NGON TAY SUKUNA: 8 tren be da quanh bo, 12 xep thanh vong quanh co so tren dinh
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4, r = 12.5;
            s.box("polished_blackstone", Math.cos(a) * r, 0.4, Math.sin(a) * r, 0.9, 0.8, 0.9);
            s.finger(Math.cos(a) * r, 0.95, Math.sin(a) * r, a + Math.PI / 2, 0);
        }
        for (int i = 0; i < 12; i++) {
            double a = i * Math.PI / 6, r = 2.6;
            s.finger(Math.cos(a) * r, 15.05, Math.sin(a) * r, a + Math.PI / 2, 0);
        }
        return s;
    }

    public static Scene coffinScene(ServerWorld w, Vec3d c, int ttl, int grow) {
        Scene s = new Scene(w, c, ttl);
        s.shell("black_concrete", 17, 11, grow, "coffin");
        s.trim("magma_block", 0, 0.1, 0, 33, 0.2, 33);
        s.box("magma_block", 0, 0.02, 0, 33, 0.05, 33);
        int n = 12;
        for (int i = 0; i < n; i++) {
            double a = i * Math.PI * 2 / n;
            Vec3d dir = new Vec3d(Math.sin(a), 0, Math.cos(a));
            Disp.Q q = Disp.Q.axis(0, 1, 0, a).mul(Disp.Q.axis(1, 0, 0, -0.46));
            s.boxQ(i % 2 == 0 ? "blackstone" : "basalt", dir.x * 5.8, 6.5, dir.z * 5.8, 5.6, 14.5, i % 2 == 0 ? 0.8 : 0.9, q);
        }
        s.box("lava", 0, 13.6, 0, 5.5, 0.3, 5.5);
        for (int i = 0; i < 16; i++) {
            double a = Fx.rnd(0, 6.28), r = Fx.rnd(8, 15);
            s.orbit("magma_block", Math.cos(a) * r, Fx.rnd(0.5, 9), Math.sin(a) * r, Fx.rnd(0.2, 0.5), 0.01);
        }
        return s;
    }

    public static Scene gardenScene(ServerWorld w, Vec3d c, int ttl, int grow) {
        Scene s = new Scene(w, c, ttl);
        s.shell("gray_concrete", 12, 7, grow, "garden");
        s.box("black_concrete", 0, 0.02, 0, 25, 0.05, 25);
        for (int i = 0; i < 16; i++) {
            double a = Fx.rnd(0, 6.28), r = Fx.rnd(3, 11), h = Fx.rnd(1.5, 5);
            s.boxQ("black_concrete", Math.cos(a) * r, h / 2, Math.sin(a) * r, 0.35, h, 0.35, Disp.Q.axis(Fx.rnd(-1, 1), 0, Fx.rnd(-1, 1), Fx.rnd(0, 0.3)));
        }
        for (int d = 0; d < 3; d++) {                                          // 3 Divine Dogs thu nho dang dung canh gac
            double a = d * Math.PI * 2 / 3 + 0.6, r = 6.5, yaw = a + Math.PI;
            Vec3d base = new Vec3d(Math.cos(a) * r, 0, Math.sin(a) * r);
            dogPart(s, base, yaw, 0, 0.75, 0, 1.5, 0.7, 0.6);            // than
            dogPart(s, base, yaw, 0, 1.05, 0.95, 0.65, 0.6, 0.6);        // dau
            dogPart(s, base, yaw, 0, 1.0, 1.35, 0.3, 0.2, 0.25);         // mom
            dogPart(s, base, yaw, 0, 1.0, -0.9, 0.2, 0.2, 0.7);          // duoi
            for (int l = 0; l < 4; l++) dogPart(s, base, yaw, (l % 2 == 0 ? -0.3 : 0.3), 0.3, (l < 2 ? 0.55 : -0.55), 0.2, 0.6, 0.2);
            dogPart(s, base, yaw, -0.2, 1.2, 1.2, 0.1, 0.1, 0.06);
            dogPart(s, base, yaw, 0.2, 1.2, 1.2, 0.1, 0.1, 0.06);
        }
        return s;
    }

    private static void dogPart(Scene s, Vec3d base, double yaw, double lx, double ly, double lz, double sx, double sy, double sz) {
        Vec3d o = rotY(new Vec3d(lx, ly, lz), yaw).add(base.x, ly - ly + ly * 0, base.z);
        s.boxQ("black_concrete", o.x, ly, o.z, sx, sy, sz, Disp.Q.axis(0, 1, 0, yaw));
    }

    public static Scene fleshScene(ServerWorld w, Vec3d c, int ttl, int grow) {
        Scene s = new Scene(w, c, ttl);
        s.shell("nether_wart_block", 12, 7, grow, "flesh");
        s.box("red_terracotta", 0, 0.02, 0, 25, 0.05, 25);
        for (int i = 0; i < 12; i++) {                                         // mat tren vach
            Vec3d d = Fx.randDir();
            Vec3d p = new Vec3d(d.x, Math.abs(d.y) * 0.9 + 0.1, d.z).normalize().multiply(11.3);
            s.box("white_concrete", p.x, 5 + p.y - 1, p.z, 0.9, 0.9, 0.9);
            Vec3d in = p.normalize().multiply(-0.5);
            s.box("black_concrete", p.x + in.x, 5 + p.y - 1 + in.y, p.z + in.z, 0.45, 0.45, 0.45);
        }
        for (int i = 0; i < 12; i++) {                                         // xuc tu thit
            double a = Fx.rnd(0, 6.28), r = Fx.rnd(2, 10), h = Fx.rnd(1.5, 4.5);
            s.boxQ("pink_concrete", Math.cos(a) * r, h / 2, Math.sin(a) * r, 0.5, h, 0.5, Disp.Q.axis(Fx.rnd(-1, 1), 0, Fx.rnd(-1, 1), Fx.rnd(0, 0.35)));
        }
        return s;
    }

    /** reels cua Hakari: tra ve ds khoi de doi block */
    public static Scene gambleScene(ServerWorld w, Vec3d c, int ttl, int grow, List<Disp.H> reels) {
        Scene s = new Scene(w, c, ttl);
        s.shell("purple_concrete", 12, 8, grow, "gamble");
        s.box("black_concrete", 0, 0.02, 0, 25, 0.05, 25);
        String[] neon = {"sea_lantern", "shroomlight", "glowstone", "pink_concrete", "light_blue_concrete", "lime_concrete", "yellow_concrete"};
        for (int i = 0; i < 28; i++) {
            double a = i * Math.PI * 2 / 28;
            s.orbit(neon[i % neon.length], Math.cos(a) * 10, 0.4, Math.sin(a) * 10, 0.5, 0.012);
        }
        for (int i = 0; i < 30; i++) {
            Vec3d d = Fx.randDir().multiply(Fx.rnd(3, 11));
            s.orbit(neon[(i * 3) % neon.length], d.x, 5 + d.y * 0.7, d.z, Fx.rnd(0.15, 0.4), Fx.rnd(0.006, 0.02) * (i % 2 == 0 ? 1 : -1));
        }
        s.box("black_concrete", 0, 2.6, 6, 6.2, 5.2, 1.2);                     // may slot
        s.box("red_concrete", 0, 5.4, 6, 6.6, 0.4, 1.4);
        s.box("yellow_concrete", 3.6, 3.0, 6, 0.3, 2.2, 0.3);                  // can gat
        s.box("red_concrete", 3.6, 4.2, 6, 0.7, 0.7, 0.7);
        for (int i = 0; i < 3; i++) {
            Disp.H r = s.box("redstone_block", -1.7 + i * 1.7, 3.4, 5.3, 1.4, 1.4, 0.3);
            if (r != null) reels.add(r);
        }
        return s;
    }

    public static Scene courtScene(ServerWorld w, Vec3d c, int ttl, int grow, List<Disp.H> gavel) {
        Scene s = new Scene(w, c, ttl);
        s.shell("gray_concrete", 12, 8, grow, "court");
        s.box("polished_blackstone", 0, 0.02, 0, 25, 0.05, 25);
        s.box("white_concrete", 0, 0.05, 0, 3.0, 0.03, 20);
        for (int k = 0; k < 4; k++) {
            double x = (k % 2 == 0 ? -1 : 1) * 9.0, z = (k < 2 ? -1 : 1) * 9.0;
            s.box("quartz_pillar", x, 4.5, z, 1.2, 9, 1.2);
            s.box("gold_block", x, 9.1, z, 1.6, 0.4, 1.6);
        }
        s.box("dark_oak_planks", 0, 1.1, -8, 9, 2.2, 1.8);                    // ban quan toa
        s.box("dark_oak_log", 0, 2.3, -8.7, 9.4, 0.25, 0.7);
        s.box("gold_block", 0, 3.0, -8.9, 1.4, 0.5, 0.3);                     // bieu tuong can
        s.box("gold_block", -2.5, 6.0, -11.5, 0.2, 5, 0.2);
        s.box("gold_block", 2.5, 6.0, -11.5, 0.2, 5, 0.2);
        s.box("gold_block", 0, 8.6, -11.5, 5.6, 0.2, 0.2);
        Disp.H head = s.box("dark_oak_log", 1.0, 2.9, -8.0, 0.9, 0.5, 0.5);   // bua
        s.box("dark_oak_planks", 1.0, 2.55, -8.0, 0.3, 0.2, 0.3);
        if (head != null) gavel.add(head);
        for (int i = 0; i < 10; i++) {
            double a = Fx.rnd(0, 6.28), r = Fx.rnd(5, 11);
            s.orbit("sea_lantern", Math.cos(a) * r, Fx.rnd(2, 8), Math.sin(a) * r, 0.25, 0.004);
        }
        return s;
    }

    // ============== chay domain moi ==============
    public interface Eff { void tick(ServerWorld w, ServerPlayerEntity p, Vec3d c, int t, List<LivingEntity> in, Scene s); }

    static void announce(ServerWorld w, Vec3d c, double R, String jp, String en, String color) {
        for (ServerPlayerEntity pl : w.getPlayers()) {
            if (pl.getEntityPos().distanceTo(c) > R + 10) continue;
            String id = pl.getUuid().toString();
            Disp.tryRun(w, "title " + id + " times 5 50 15");
            Disp.tryRun(w, "title " + id + " subtitle {text:\"" + en + "\",color:\"gray\",italic:true}");
            Disp.tryRun(w, "title " + id + " title {text:\"" + jp + "\",color:\"" + color + "\",bold:true}");
        }
    }

    public static void announce(ServerWorld w, ServerPlayerEntity p, double R, String jp, String en, String color) {
        announce(w, p.getEntityPos(), R, jp, en, color);
    }

    static void run(ServerWorld w, ServerPlayerEntity p, String jp, String en, String tcolor, int pcolor, double R, int expand, int dur, int collapse, Scene s, Eff eff) {
        Vec3d c = p.getEntityPos();
        Data.DOMAIN_END.put(p.getUuid(), Data.now + expand + dur + collapse);
        announce(w, c, R, jp, en, tcolor);
        Fx.snd(w, c, SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 2.0f, 0.6f);
        Fx.snd(w, c, SoundEvents.ENTITY_WITHER_SPAWN, 1.2f, 0.5f);
        Anims.add(new Anims.Anim() {
            int t = 0;
            public boolean tick() {
                if (p.isRemoved() || !p.isAlive()) { Data.DOMAIN_END.remove(p.getUuid()); s.kill(); return true; }
                t++;
                s.tick(t);
                Vec3d mid = c.add(0, R * 0.4, 0);
                if (t <= expand) {
                    double r = R * (t / (double) expand);
                    Fx.sphere(w, Fx.dust(pcolor, 1.8f), mid, r, 110, t * 0.12);
                    Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
                    Fx.ring(w, Fx.dust(0xFFFFFF, 1.4f), c.add(0, 0.2, 0), b[1], b[2], r, 60, 0);
                    return false;
                }
                int a = t - expand;
                if (a <= dur) {
                    List<LivingEntity> in = new ArrayList<>();
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(c, c).expand(R, R, R))) if (e.getEntityPos().distanceTo(c) <= R) in.add(e);
                    for (int i = 0; i < 10; i++) Fx.pt(w, Fx.dust(pcolor, 0.9f), c.add(Fx.randDir().multiply(R * Math.cbrt(Fx.rnd()))).add(0, R * 0.4, 0));
                    eff.tick(w, p, c, a, in, s);
                    return false;
                }
                if (a == dur + 1) s.beginEnd(collapse);
                if (a > dur) {
                    double r = Math.max(0.5, R * (1 - (a - dur) / (double) collapse));
                    Fx.sphere(w, Fx.dust(pcolor, 1.6f), mid, r, 80, t * 0.05);
                }
                if (a >= dur + collapse) {
                    Data.DOMAIN_END.remove(p.getUuid());
                    s.kill();
                    Fx.snd(w, c, SoundEvents.BLOCK_BEACON_DEACTIVATE, 1.5f, 0.6f);
                    return true;
                }
                return false;
            }
        });
    }

    static int total(int expand, int dur, int collapse) { return expand + dur + collapse + 20; }

    // ---- Chimera Shadow Garden (Megumi) ----
    public static void garden(ServerWorld w, ServerPlayerEntity p) {
        int ex = 24, dur = Config.domainSeconds * 20, co = 12;
        Scene s = gardenScene(w, p.getEntityPos(), total(ex, dur, co), ex);
        run(w, p, "領域展開", "Chimera Shadow Garden - 嵌合暗翳庭", "dark_gray", 0x202030, 12, ex, dur, co, s, (ww, pl, c, t, in, sc) -> {
            if (t % 20 == 1) pl.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 30, 1, true, false));
            for (LivingEntity e : in) {
                if (t % 10 == 0) e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 25, 3));
                if (t % 20 == 0) {
                    Fx.hurt(ww, pl, e, 4.0f);
                    Vec3d f = e.getEntityPos();
                    for (int i = 0; i < 5; i++) Fx.line(ww, Fx.dust(0x08080F, 1.5f), f.add(Fx.rnd(-0.5, 0.5), 0, Fx.rnd(-0.5, 0.5)), f.add(Fx.rnd(-0.4, 0.4), Fx.rnd(1.2, 2.2), Fx.rnd(-0.4, 0.4)), 0.25);
                }
            }
        });
    }

    // ---- Self-Embodiment of Perfection (Mahito) ----
    public static void flesh(ServerWorld w, ServerPlayerEntity p) {
        int ex = 24, dur = Config.domainSeconds * 20, co = 12;
        Scene s = fleshScene(w, p.getEntityPos(), total(ex, dur, co), ex);
        run(w, p, "領域展開", "Self-Embodiment of Perfection - 自閉円頓裹", "light_purple", 0xC04060, 12, ex, dur, co, s, (ww, pl, c, t, in, sc) -> {
            for (LivingEntity e : in) {
                if (t % 10 == 0) {
                    e.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 40, 1));
                    e.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 40, 2));
                    e.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 80, 0));
                    Fx.hurt(ww, pl, e, 3.0f);
                    Vec3d m = Fx.mid(e);
                    for (int i = 0; i < 3; i++) Fx.line(ww, Fx.dust(0xE0708A, 1.2f), m.add(Fx.randDir().multiply(Fx.rnd(2, 4))), m, 0.4);
                    Fx.put(ww, ParticleTypes.CRIMSON_SPORE, m, 8, 0.5, 0.02);
                }
            }
        });
    }

    // ---- Idle Death Gamble (Hakari) ----
    public static final Map<UUID, Integer> JACKPOT_END = new HashMap<>();

    public static boolean jackpot(UUID id) { return JACKPOT_END.getOrDefault(id, 0) > Data.now; }

    public static void gamble(ServerWorld w, ServerPlayerEntity p) {
        int ex = 24, dur = Config.domainSeconds * 20, co = 12;
        List<Disp.H> reels = new ArrayList<>();
        Scene s = gambleScene(w, p.getEntityPos(), total(ex, dur, co), ex, reels);
        String[] sym = {"redstone_block", "emerald_block", "diamond_block", "lapis_block", "iron_block", "gold_block"};
        Eff eff = new Eff() {
            boolean rolled = false; boolean win = false;
            public void tick(ServerWorld ww, ServerPlayerEntity pl, Vec3d c, int t, List<LivingEntity> in, Scene sc) {
                if (!rolled) {
                    if (t % 3 == 0) for (Disp.H r : reels) if (r.ent != null) Disp.run(ww, "data merge entity " + r.ent.getUuid() + " {block_state:{Name:\"minecraft:" + sym[(int) (Fx.rnd() * sym.length)] + "\"}}");
                    if (t == 60) {
                        rolled = true;
                        win = Fx.rnd() < 0.3;
                        for (int i = 0; i < reels.size(); i++) {
                            Disp.H r = reels.get(i);
                            String b = win ? "gold_block" : sym[i % 3];
                            if (r.ent != null) Disp.run(ww, "data merge entity " + r.ent.getUuid() + " {block_state:{Name:\"minecraft:" + b + "\"}}");
                        }
                        if (win) {
                            JACKPOT_END.put(pl.getUuid(), Data.now + 300);
                            pl.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 300, 3));
                            pl.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 300, 3));
                            pl.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 300, 2));
                            pl.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 300, 2));
                            pl.heal(20f);
                            announce(ww, c, 12, "JACKPOT!!", "777 - Private Pure Love Train", "gold");
                            for (int i = 0; i < 8; i++) Fx.put(ww, ParticleTypes.FIREWORK, c.add(Fx.rnd(-6, 6), Fx.rnd(2, 8), Fx.rnd(-6, 6)), 12, 0.6, 0.15);
                            Fx.snd(ww, c, SoundEvents.ENTITY_PLAYER_LEVELUP, 2.0f, 0.8f);
                            Fx.snd(ww, c, SoundEvents.BLOCK_NOTE_BLOCK_BELL.value(), 2.0f, 1.2f);
                        } else {
                            pl.sendMessage(Text.literal("Khong trung... (2 - 1 - 3)").formatted(Formatting.GRAY), true);
                            Fx.snd(ww, c, SoundEvents.BLOCK_NOTE_BLOCK_BELL.value(), 1.0f, 0.5f);
                        }
                    }
                } else if (win && t % 4 == 0) {
                    Fx.put(ww, ParticleTypes.FIREWORK, c.add(Fx.rnd(-6, 6), Fx.rnd(2, 8), Fx.rnd(-6, 6)), 6, 0.3, 0.1);
                    Fx.put(ww, Fx.dust(0xFFD040, 1.6f), c.add(Fx.rnd(-8, 8), Fx.rnd(1, 9), Fx.rnd(-8, 8)), 6, 0.2, 0);
                }
                for (LivingEntity e : in) {                                    // domain: cu dung vao la trung (gay sat thuong chac chan)
                    if (t % 20 == 0) { Fx.hurt(ww, pl, e, win ? 6.0f : 3.0f); Fx.put(ww, ParticleTypes.CRIT, Fx.mid(e), 10, 0.4, 0.2); }
                    if (t % 10 == 0) e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 25, 2));
                }
            }
        };
        run(w, p, "領域展開", "Idle Death Gamble - 坐殺博徒", "light_purple", 0xFF40D0, 12, ex, dur, co, s, eff);
    }

    // ---- Deadly Sentencing (Higuruma) ----
    public static void court(ServerWorld w, ServerPlayerEntity p) {
        int ex = 24, dur = Config.domainSeconds * 20, co = 12;
        List<Disp.H> gavel = new ArrayList<>();
        Vec3d c0 = p.getEntityPos();
        Scene s = courtScene(w, c0, total(ex, dur, co), ex, gavel);
        Eff eff = new Eff() {
            public void tick(ServerWorld ww, ServerPlayerEntity pl, Vec3d c, int t, List<LivingEntity> in, Scene sc) {
                for (LivingEntity e : in) if (t % 10 == 0) {                   // bi cao: bi cam, khong the hanh dong
                    e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 25, 6));
                    e.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 40, 2));
                }
                if (t == 50) {                                                  // bua phan quyet
                    if (!gavel.isEmpty()) gavel.get(0).move(c.add(1.0, 2.5, -8.0));
                    Fx.snd(ww, c, SoundEvents.BLOCK_ANVIL_LAND, 2.0f, 0.5f);
                    announce(ww, c, 12, "有罪", "GUILTY - Deadly Sentencing", "gold");
                    int n = 0;
                    for (LivingEntity e : in) if (n++ < 6) Stage3Skills.swordDrop(ww, pl, e, 30f, true);
                    Fx.ring(ww, Fx.dust(0xFFD040, 1.6f), c.add(0, 0.3, 0), new Vec3d(1, 0, 0), new Vec3d(0, 0, 1), 11, 100, 0);
                }
                if (t == 45 && !gavel.isEmpty()) gavel.get(0).move(c.add(1.0, 4.2, -8.0));
                if (t > 50 && t % 40 == 0) for (LivingEntity e : in) {          // quan toa tiep tuc xu: moi 2 giay phat them
                    Fx.hurt(ww, pl, e, 4.0f);
                    Vec3d m = Fx.mid(e);
                    Fx.line(ww, Fx.dust(0xFFD040, 1.0f), m.add(0, 6, 0), m, 0.4);
                }
            }
        };
        run(w, p, "領域展開", "Deadly Sentencing - 誅伏賜死", "gold", 0xE0C040, 12, ex, dur, co, s, eff);
    }

    // ---- Authentic Mutual Love (Yuta): phong trang, san xanh nhat, hang tram guom ghim vao tam ----
    public static Scene swordScene(ServerWorld w, Vec3d c, int ttl, int grow) {
        Scene s = new Scene(w, c, ttl);
        s.shell("white_concrete", 13, 9, grow, "love");
        s.box("light_blue_concrete", 0, 0.02, 0, 27, 0.05, 27);
        s.box("white_concrete", 0, 0.06, 0, 6, 0.04, 6);
        Vec3d mid = new Vec3d(0, 4, 0);
        for (int i = 0; i < 44; i++) {
            double a = i * 2.399963, ring = 5 + (i % 4) * 2.2, y = 1.5 + (i * 7 % 13) * 0.75;
            Vec3d pos = new Vec3d(Math.cos(a) * ring, y, Math.sin(a) * ring);
            Vec3d dir = mid.subtract(pos).normalize();
            Disp.Q q = Disp.Q.fromTo(new Vec3d(0, 0, 1), dir);
            Vec3d hilt = pos.subtract(dir.multiply(0.9));
            s.boxQ("iron_block", pos.x, pos.y, pos.z, 0.1, 0.32, 1.8, q);          // luoi
            s.boxQ("gold_block", hilt.x, hilt.y, hilt.z, 0.12, 0.5, 0.2, q);       // chan guom
            Vec3d gr = pos.subtract(dir.multiply(1.25));
            s.boxQ("black_concrete", gr.x, gr.y, gr.z, 0.12, 0.12, 0.5, q);        // can
        }
        for (int i = 0; i < 16; i++) {
            double a = i * Math.PI / 8;
            s.orbit("sea_lantern", Math.cos(a) * 9, 0.4 + (i % 3) * 3, Math.sin(a) * 9, 0.3, 0.01);
        }
        return s;
    }

    public static void swords(ServerWorld w, ServerPlayerEntity p) {
        int ex = 24, dur = Config.domainSeconds * 20, co = 12;
        Scene s = swordScene(w, p.getEntityPos(), total(ex, dur, co), ex);
        run(w, p, "領域展開", "Authentic Mutual Love - 真贋相愛", "white", 0xB8E8FF, 12, ex, dur, co, s, (ww, pl, c, t, in, sc) -> {
            for (LivingEntity e : in) {
                if (t % 10 == 0) {
                    Fx.hurt(ww, pl, e, 4.0f);
                    Vec3d m = Fx.mid(e);
                    for (int i = 0; i < 3; i++) Fx.line(ww, Fx.dust(0xE8F4FF, 1.0f), m.add(Fx.randDir().multiply(Fx.rnd(4, 7))), m, 0.35);
                    Fx.put(ww, ParticleTypes.CRIT, m, 6, 0.4, 0.2);
                }
                if (t % 10 == 5) e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 25, 2));
            }
            if (t % 20 == 1) pl.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 30, 1, true, false));
        });
    }
}
