package com.example.jjk;

import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/**
 * Mo hinh 3D ghep tu nhieu block_display (hop chu nhat) co the di chuyen, quay huong va hoat anh (chan vung, canh vo, duoi quet...).
 * Toa do cuc bo: +Z = phia truoc, +Y = len, +X = ben trai cua mo hinh. yaw quay quanh truc Y.
 * Moi bo phan co the "swing" (dao dong sin quanh mot truc tai diem xoay) hoac "spin" (quay lien tuc).
 */
public final class Rig {
    static final class Part {
        Disp.H h; Vec3d off, size, pivot, axis; double amp, speed, phase, spin; boolean anim, done; Part parent;
    }

    final ServerWorld w; final List<Part> parts = new ArrayList<>();
    Vec3d pos; double yaw; final int ttl; double lastYaw = 1e9; double scale = 1.0;
    final boolean on = Config.displays;

    public Rig(ServerWorld w, Vec3d pos, double yaw, int ttl) { this.w = w; this.pos = pos; this.yaw = yaw; this.ttl = ttl; }

    public Rig scale(double s) { this.scale = s; return this; }

    // gia tri: "ten_texture|khoi_vanilla_du_phong"  (khi texturedModels=false thi dung khoi vanilla)
    private static java.util.Map<String, String> m(String... kv) { java.util.Map<String, String> x = new java.util.HashMap<>(); for (int i = 0; i + 1 < kv.length; i += 2) x.put(kv[i], kv[i + 1]); return x; }
    private static final java.util.Map<String, String> FUR = m(
            "white_concrete", "fur_white|white_wool", "black_concrete", "fur_black|black_wool", "gray_concrete", "fur_gray|gray_wool",
            "light_gray_concrete", "fur_white|light_gray_wool", "pink_concrete", "skin_pink|pink_wool", "pink_wool", "skin_pink|pink_wool",
            "gray_terracotta", "fur_tiger|black_wool", "yellow_terracotta", "fur_tiger|yellow_wool");
    private static final java.util.Map<String, String> FROG = m(
            "green_terracotta", "skin_frog|green_wool", "green_concrete", "skin_frog|moss_block", "white_concrete", "skin_frogbelly|white_wool");
    private static final java.util.Map<String, String> BIRD = m(
            "red_terracotta", "feather_red|red_terracotta", "brown_terracotta", "feather_brown|brown_terracotta", "white_concrete", "fur_white|white_wool");
    private static final java.util.Map<String, String> ELEPHANT = m(
            "pink_concrete", "skin_pink|pink_wool", "pink_wool", "skin_pink|pink_wool", "gold_block", "gold_ornament|gold_block");
    private static final java.util.Map<String, String> QUARTZ = m(
            "white_concrete", "marble_white|smooth_quartz", "light_gray_concrete", "marble_gray|quartz_block",
            "black_concrete", "cloth_black|black_concrete", "gray_concrete", "cloth_gray|gray_concrete");
    private java.util.Map<String, String> skin = null;

    /** chat lieu: fur (long thu), frog (ech), bird (long vu), elephant (voi hong), quartz (Mahoraga: da cam thach) */
    public Rig skin(String kind) {
        skin = switch (kind) { case "fur" -> FUR; case "frog" -> FROG; case "bird" -> BIRD; case "elephant" -> ELEPHANT; case "quartz" -> QUARTZ; default -> null; };
        return this;
    }

    private Part make(String block, double ox, double oy, double oz, double sx, double sy, double sz) {
        if (skin != null && skin.containsKey(block)) {
            String[] v = skin.get(block).split("\\|");
            block = Config.texturedModels ? "@" + v[0] : v[1];
        }
        Part p = new Part();
        p.off = new Vec3d(ox * scale, oy * scale, oz * scale);
        p.size = new Vec3d(sx * scale, sy * scale, sz * scale);
        p.pivot = p.off; p.axis = new Vec3d(1, 0, 0);
        if (on) {
            Disp.Q q = Disp.Q.axis(0, 1, 0, yaw);
            p.h = Disp.block(w, pos.add(q.rot(p.off)), block, p.size.x, p.size.y, p.size.z, q, ttl);
        }
        parts.add(p);
        return p;
    }

    /** bo phan tinh */
    public Rig add(String block, double ox, double oy, double oz, double sx, double sy, double sz) {
        make(block, ox, oy, oz, sx, sy, sz);
        return this;
    }

    /** bo phan dao dong quanh (px,py,pz) theo truc (ax,ay,az): goc = amp * sin(speed * t + phase) */
    public Rig swing(String block, double ox, double oy, double oz, double sx, double sy, double sz,
                     double px, double py, double pz, double ax, double ay, double az, double amp, double speed, double phase) {
        Part p = make(block, ox, oy, oz, sx, sy, sz);
        p.pivot = new Vec3d(px * scale, py * scale, pz * scale);
        p.axis = new Vec3d(ax, ay, az);
        p.amp = amp; p.speed = speed; p.phase = phase; p.anim = true;
        return this;
    }

    /** bo phan quay deu quanh (px,py,pz) theo truc (ax,ay,az): goc = spin * t + phase */
    public Rig spin(String block, double ox, double oy, double oz, double sx, double sy, double sz,
                    double px, double py, double pz, double ax, double ay, double az, double spin, double phase) {
        Part p = make(block, ox, oy, oz, sx, sy, sz);
        p.pivot = new Vec3d(px * scale, py * scale, pz * scale);
        p.axis = new Vec3d(ax, ay, az);
        p.spin = spin; p.phase = phase; p.anim = true;
        return this;
    }

    /** bo phan xoay co dinh mot goc quanh (px,py,pz) (khong hoat anh) */
    public Rig rotp(String block, double ox, double oy, double oz, double sx, double sy, double sz,
                    double px, double py, double pz, double ax, double ay, double az, double angle) {
        Part p = make(block, ox, oy, oz, sx, sy, sz);
        p.pivot = new Vec3d(px * scale, py * scale, pz * scale);
        p.axis = new Vec3d(ax, ay, az);
        p.phase = angle; p.anim = true;
        return this;
    }

    /** bo phan xoay co dinh quanh chinh tam cua no */
    public Rig rot(String block, double ox, double oy, double oz, double sx, double sy, double sz, double ax, double ay, double az, double angle) {
        return rotp(block, ox, oy, oz, sx, sy, sz, ox, oy, oz, ax, ay, az, angle);
    }

    /** chi so cua bo phan vua them */
    public int idx() { return parts.size() - 1; }

    /** dat bo phan vua them la CON cua bo phan i (di theo chuyen dong cua i: khop goi, khuyu tay...) */
    public Rig under(int i) { if (i >= 0 && i < parts.size() - 1) parts.get(parts.size() - 1).parent = parts.get(i); return this; }

    private double angleOf(Part p, int t) {
        if (p.spin != 0) return p.spin * t + p.phase;
        if (p.amp != 0) return p.amp * Math.sin(p.speed * t + p.phase);
        return p.phase;
    }

    private Disp.Q localQ(Part p, int t) {
        return p.anim ? Disp.Q.axis(p.axis.x, p.axis.y, p.axis.z, angleOf(p, t)) : Disp.Q.ID;
    }

    private Vec3d apply(Part p, Vec3d x, int t) {
        Vec3d y = p.anim ? p.pivot.add(localQ(p, t).rot(x.subtract(p.pivot))) : x;
        return p.parent == null ? y : apply(p.parent, y, t);
    }

    private Disp.Q orient(Part p, int t) {
        Disp.Q q = localQ(p, t);
        return p.parent == null ? q : orient(p.parent, t).mul(q);
    }

    private boolean moving(Part p) {
        for (Part c = p; c != null; c = c.parent) if (c.amp != 0 || c.spin != 0) return true;
        return false;
    }

    /** cap nhat vi tri / huong / hoat anh. t = bo dem tick (tang dan) */
    public void place(Vec3d newPos, double newYaw, int t) {
        pos = newPos; yaw = newYaw;
        if (!on) return;
        Disp.Q yq = Disp.Q.axis(0, 1, 0, yaw);
        boolean turned = Math.abs(yaw - lastYaw) > 0.05;
        for (Part p : parts) {
            if (p.h == null) continue;
            Vec3d center = apply(p, p.off, t);
            p.h.move(pos.add(yq.rot(center)));
            if (turned || moving(p) || !p.done) { p.h.set(yq.mul(orient(p, t)), p.size.x, p.size.y, p.size.z, 2); p.done = true; }
        }
        if (turned) lastYaw = yaw;
    }

    public void kill() { for (Part p : parts) if (p.h != null) p.h.kill(); parts.clear(); }

    public static double yawOf(Vec3d dir) { return Math.atan2(dir.x, dir.z); }
}
