package com.example.jjk;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Ky nang "nhu that" viet rieng tung chieu (nhieu giai doan, co che rieng), bam theo phim/truyen:
 * Hollow Purple 200%, World Cutting Slash, Spiderweb, Divergent Fist (tre nhip), Boogie Woogie hoan doi,
 * Ratio 7:3 Critical, Convergence, Maximum Meteor, Distorted Killing, Copy (Yuta), Rika Full Manifestation.
 * Chua test trong game.
 */
public class Canon {
    public static boolean cast(String id, ServerWorld w, ServerPlayerEntity p) {
        switch (id) {
            case "hollow_purple_200" -> purple200(w, p);
            case "world_slash" -> worldSlash(w, p);
            case "spiderweb" -> spiderweb(w, p);
            case "divergent_fist" -> divergent(w, p);
            case "boogie_chaos" -> chaos(w, p);
            case "ratio_critical" -> critical(w, p);
            case "convergence" -> convergence(w, p);
            case "maximum_meteor" -> maxMeteor(w, p);
            case "distorted_killing" -> distorted(w, p);
            case "copy_cast" -> copyCast(w, p);
            case "rika_full" -> Shiki.rikaFull(w, p);
            default -> { return Canon2.cast(id, w, p); }
        }
        return true;
    }

    public static void registerTechs() {
        Canon2.registerTechs();
        Tech.Chara G = Tech.Chara.GOJO, TO = Tech.Chara.TODO, NA = Tech.Chara.NANAMI, CH = Tech.Chara.CHOSO, JO = Tech.Chara.JOGO,
                MA = Tech.Chara.MAHITO, YU = Tech.Chara.YUTA;
        String st = Tech.UNTESTED + " (canon)";
        Tech.add("hollow_purple_200", "Hollow Purple: 200%", "茈・二〇〇%", 220, 1000, 60, "instant",
                "Xanh va Do xoay quanh nhau 3.5 giay roi hoi tu thanh Tim khong lo, bay xa 100 o xoa so moi thu (60 st, xoa khoi neu bat trong cai dat).", st, G);
        Tech.add("boogie_chaos", "Boogie Woogie: Chaos", "不義遊戯・乱", 70, 300, 0, "instant",
                "Vo tay: ban va toi da 3 quai gan nhat HOAN DOI vi tri theo vong tron (quai bi choang ngan).", st, TO);
        Tech.add("ratio_critical", "Ratio: 7:3 Critical", "十劃・会心", 60, 200, 40, "instant",
                "Danh dau duong 7:3 tren co the muc tieu roi chem trung diem yeu: sat thuong lon theo mau toi da + Weakness.", st, NA);
        Tech.add("convergence", "Convergence: Piercing Blood", "百斂・穿血", 100, 400, 45, "instant",
                "Hut mau trong khong khi vao mot qua cau 2 giay roi ban tia mau xuyen 50 o (45 st + Wither).", st, CH);
        Tech.add("maximum_meteor", "Maximum: Meteor", "極ノ番「隕」", 160, 900, 70, "instant",
                "Goi thien thach khong lo tu tren troi (2.7 giay) ro xuong diem ngam: no ban kinh 14, chay, lo mieng hoa nui.", st, JO);
        Tech.add("distorted_killing", "Instant Spirit Body of Distorted Killing", "無為転変・遊離式", 80, 300, 30, "instant",
                "Bien than thanh khoi thit day gai lao toi truoc 20 o, nghien nat moi thu tren duong di.", st, MA);
        Tech.add("copy_cast", "Copy", "模倣", 90, 400, 0, "instant",
                "Sao chep NGAU NHIEN mot ky thuat cua nhan vat khac va tung ra ngay (khong ton them chu luc).", st, YU);
        Tech.add("rika_full", "Rika: Full Manifestation", "リカ・完全顕現", 200, 1200, 26, "instant",
                "Rika hien the hoan toan: khong lo gap 2 lan, danh quet rong 8 o trong 15 giay (26 st/don).", st, YU);
    }

    // ================= tien ich =================
    static Vec3d flatLook(ServerPlayerEntity p) {
        Vec3d l = p.getRotationVec(1f);
        Vec3d f = new Vec3d(l.x, 0, l.z);
        return f.lengthSquared() < 1e-4 ? new Vec3d(0, 0, 1) : f.normalize();
    }

    static void erase(ServerWorld w, Vec3d c, double r) {
        if (!Config.purpleErasesBlocks) return;
        int R = (int) Math.ceil(r);
        BlockPos b = BlockPos.ofFloored(c);
        for (int dx = -R; dx <= R; dx++) for (int dy = -R; dy <= R; dy++) for (int dz = -R; dz <= R; dz++) {
            if (dx * dx + dy * dy + dz * dz > r * r) continue;
            BlockPos q = b.add(dx, dy, dz);
            BlockState st = w.getBlockState(q);
            if (st.isAir() || st.isOf(Blocks.BEDROCK) || Room.isProtected(w, q)) continue;
            w.setBlockState(q, Blocks.AIR.getDefaultState(), 2);
        }
    }

    // ================= GOJO: Hollow Purple 200% =================
    static void purple200(ServerWorld w, ServerPlayerEntity p) {
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 6, true, false));
        Fx.snd(w, p.getEntityPos(), SoundEvents.BLOCK_BEACON_POWER_SELECT, 1.6f, 0.5f);
        Anims.add(new Anims.Anim() {
            int t = 0;
            Disp.Orb blue, red, core;
            Vec3d pos, dir;
            final Set<Integer> hit = new HashSet<>();
            void clean() { if (blue != null) blue.kill(); if (red != null) red.kill(); if (core != null) core.kill(); blue = red = core = null; }
            public boolean tick() {
                if (p.isRemoved() || !p.isAlive()) { clean(); return true; }
                t++;
                if (t <= 70) {                                                    // pha 1: Xanh/Do xoay quanh nhau, thu hep
                    Vec3d look = p.getRotationVec(1f).normalize();
                    Vec3d[] b = Fx.basis(look);
                    Vec3d c = p.getEyePos().add(look.multiply(4.5)).add(0, -0.2, 0);
                    double k = t / 70.0, ease = k * k * (3 - 2 * k);
                    double ang = t * 0.3 * (1 + ease * 2.5), rad = 3.4 * (1 - ease) + 0.15;
                    Vec3d off = b[1].multiply(Math.cos(ang) * rad).add(b[2].multiply(Math.sin(ang) * rad));
                    Vec3d bp = c.add(off), rp = c.subtract(off);
                    if (Config.displays) {
                        if (blue == null) {
                            blue = new Disp.Orb(w, bp, "light_blue_stained_glass", "white_concrete", null, 1.0, 130);
                            red = new Disp.Orb(w, rp, "red_stained_glass", "redstone_block", null, 1.0, 130);
                        }
                        blue.update(bp, t * 0.5, 0.5 + 0.7 * ease, t % 2 == 0);
                        red.update(rp, t * 0.5, 0.5 + 0.7 * ease, t % 2 == 0);
                    }
                    Fx.put(w, Fx.dust(0x2E9BFF, 1.2f), bp, 2, 0.15, 0);
                    Fx.put(w, Fx.dust(0xFF2A2A, 1.2f), rp, 2, 0.15, 0);
                    if (t % 5 == 0) {
                        Fx.ring(w, Fx.dust(0x6FC0FF, 0.8f), bp, b[1], b[2], 0.9, 16, t);
                        Fx.ring(w, Fx.dust(0xFF7070, 0.8f), rp, b[1], b[2], 0.9, 16, t);
                    }
                    if (t == 70) {
                        clean();
                        pos = c;
                        Vis3D.pulseGrow(w, c, "white_concrete", 0.5, 9, 8);
                        Fx.put(w, ParticleTypes.END_ROD, c, 60, 1.5, 0.4);
                        Fx.snd(w, c, SoundEvents.BLOCK_BEACON_ACTIVATE, 2.0f, 0.5f);
                        if (Config.displays) core = new Disp.Orb(w, c, "purple_stained_glass", "white_concrete", "black_stained_glass", 3.2, 140);
                    }
                    return false;
                }
                if (t <= 100) {                                                   // pha 2: Tim phinh to, tich nang luong
                    double g = (t - 70) / 30.0;
                    Vec3d look = p.getRotationVec(1f).normalize();
                    pos = p.getEyePos().add(look.multiply(5)).add(0, -0.2, 0);
                    if (core != null) core.update(pos, t * 0.3, 0.4 + 0.8 * g, t % 2 == 0);
                    Vec3d[] b = Fx.basis(look);
                    Fx.ring(w, Fx.dust(0x0A0014, 1.6f), pos, b[1], b[2], 1.2 + g * 2.0, 40, t * 0.3);
                    if (t % 2 == 0) Fx.bolt(w, Fx.dust(0xB060FF, 1.0f), pos, pos.add(Fx.randDir().multiply(Fx.rnd(3, 5))), 0.5, 0.5);
                    if (t == 100) {
                        dir = look;
                        Fx.snd(w, pos, SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 2.5f, 0.6f);
                        Fx.snd(w, pos, SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 1.5f, 0.4f);
                    }
                    return false;
                }
                int ft = t - 100;                                                 // pha 3: bay xa va xoa so moi thu
                if (ft > 45) {
                    explodeAt(pos);
                    clean();
                    return true;
                }
                pos = pos.add(dir.multiply(2.4));
                if (core != null) core.update(pos, t * 0.3, 1.2, t % 2 == 0);
                erase(w, pos, 4.0);
                Fx.put(w, Fx.dust(0x9B3DFF, 2.0f), pos, 14, 2.2, 0);
                Fx.put(w, ParticleTypes.PORTAL, pos, 20, 2.0, 0.5);
                for (LivingEntity e : Fx.hostiles(w, p, new Box(pos, pos).expand(6))) {
                    if (!hit.add(e.getId())) continue;
                    Fx.hurt(w, p, e, 60f);
                    e.addVelocity(dir.x * 1.8, 0.5, dir.z * 1.8);
                }
                if (!w.isAir(BlockPos.ofFloored(pos.add(dir.multiply(3)))) && !Config.purpleErasesBlocks) { explodeAt(pos); clean(); return true; }
                return false;
            }
            void explodeAt(Vec3d c) {
                Vis3D.pulseGrow(w, c, "purple_stained_glass", 1.0, 26, 10);
                Vis3D.pulseGrow(w, c, "white_concrete", 0.5, 10, 7);
                Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
                for (int i = 1; i <= 4; i++) Fx.ring(w, Fx.dust(0xB060FF, 2.0f), c, b[1], b[2], i * 3.0, 50 + i * 12, 0);
                Fx.snd(w, c, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 2.5f, 0.5f);
                erase(w, c, 6.0);
                for (LivingEntity e : Fx.hostiles(w, p, new Box(c, c).expand(12))) {
                    if (e.getEntityPos().distanceTo(c) > 12) continue;
                    if (hit.add(e.getId())) Fx.hurt(w, p, e, 40f);
                    Vec3d kb = e.getEntityPos().subtract(c).multiply(1, 0, 1);
                    if (kb.lengthSquared() > 1e-3) { kb = kb.normalize().multiply(1.6); e.addVelocity(kb.x, 0.6, kb.z); }
                }
            }
        });
    }

    // ================= SUKUNA: World Cutting Slash =================
    static void worldSlash(ServerWorld w, ServerPlayerEntity p) {
        Vec3d look = flatLook(p);
        Vec3d right = new Vec3d(-look.z, 0, look.x);
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 50, 5, true, false));
        Fx.snd(w, p.getEntityPos(), SoundEvents.ENTITY_WARDEN_NEARBY_CLOSER, 1.5f, 0.6f);
        Anims.add(new Anims.Anim() {
            int t = 0;
            public boolean tick() {
                if (p.isRemoved() || !p.isAlive()) return true;
                t++;
                Vec3d hand = p.getEyePos().add(look.multiply(1.2)).add(0, 0.6, 0);
                if (t <= 36) {                                                    // gom nang luong: cac tia do chay vao tay
                    for (int i = 0; i < 3; i++) {
                        Vec3d from = hand.add(Fx.randDir().multiply(Fx.rnd(2.5, 5)));
                        Fx.line(w, Fx.dust(i == 0 ? 0xFFFFFF : 0xFF2020, 1.1f), from, hand, 0.5);
                    }
                    Vec3d[] b = Fx.basis(look);
                    Fx.ring(w, Fx.dust(0xFF3030, 1.3f), hand, b[1], b[2], 3.5 * (1 - t / 36.0) + 0.3, 30, t);
                    if (Config.displays && t % 6 == 0) Vis3D.pulseShrink(w, hand, "red_concrete", 1.2, 6);
                    return false;
                }
                if (t == 37) fire();
                return t >= 40;
            }
            void fire() {
                Vec3d o = p.getEntityPos().add(0, 1.2, 0);
                Fx.snd(w, o, SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 2.5f, 0.5f);
                Fx.snd(w, o, SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 2.0f, 0.7f);
                if (Config.displays) {
                    Disp.Q q = Disp.Q.fromTo(new Vec3d(0, 0, 1), look);
                    Vec3d c = o.add(look.multiply(46));
                    Disp.H a = Disp.block(w, c, "red_concrete", 0.1, 36, 92, q, 16);
                    Disp.H b2 = Disp.block(w, c, "white_concrete", 0.04, 34, 90, q, 16);
                    if (a != null) a.set(q, 0.7, 36, 92, 2);
                    if (b2 != null) b2.set(q, 0.3, 34, 90, 2);
                    Vis3D.later(3, () -> { if (a != null) a.set(q, 0.02, 36, 92, 10); if (b2 != null) b2.set(q, 0.01, 34, 90, 10); });
                }
                for (double d = 0; d <= 90; d += 1.5) {
                    Vec3d v = o.add(look.multiply(d));
                    for (double y = -6; y <= 14; y += 2.5) Fx.pt(w, Fx.dust(0xFF2020, 1.6f), v.add(0, y, 0));
                    if (Config.purpleErasesBlocks) for (int y = -4; y <= 12; y++) {
                        BlockPos q2 = BlockPos.ofFloored(v.add(0, y, 0));
                        BlockState st = w.getBlockState(q2);
                        if (st.isAir() || st.isOf(Blocks.BEDROCK) || Room.isProtected(w, q2)) continue;
                        w.setBlockState(q2, Blocks.AIR.getDefaultState(), 2);
                    }
                }
                for (LivingEntity e : Fx.hostiles(w, p, new Box(o, o.add(look.multiply(90))).expand(4, 24, 4))) {
                    Vec3d rel = Fx.mid(e).subtract(o);
                    double along = rel.dotProduct(look), lat = Math.abs(rel.dotProduct(right));
                    if (along < 0 || along > 92 || lat > 2.2) continue;
                    Fx.hurt(w, p, e, 70f);
                    e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 4));
                    Fx.put(w, Fx.dust(0xFF2020, 2.0f), Fx.mid(e), 25, 0.6, 0.2);
                }
            }
        });
    }

    // ================= SUKUNA: Spiderweb =================
    static void spiderweb(ServerWorld w, ServerPlayerEntity p) {
        Vec3d look = p.getRotationVec(1f).normalize();
        Vec3d[] b = Fx.basis(look);
        Vec3d c = p.getEyePos().add(look.multiply(7));
        double R = 6.5;
        Fx.snd(w, c, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.5f, 0.6f);
        Anims.add(new Anims.Anim() {
            int t = 0;
            public boolean tick() {
                if (p.isRemoved()) return true;
                t++;
                if (t <= 10) {                                                    // 10 tia huong tam, moi tick mot tia
                    double a = (t - 1) * Math.PI * 2 / 10;
                    Vec3d end = c.add(b[1].multiply(Math.cos(a) * R)).add(b[2].multiply(Math.sin(a) * R));
                    if (Config.displays) new Disp.Beam(w, c, end, "red_concrete", "white_concrete", 0.16, 22);
                    Fx.line(w, Fx.dust(0xFF2020, 1.3f), c, end, 0.5);
                    Fx.snd(w, end, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 0.7f, 1.2f + t * 0.05f);
                } else if (t <= 14) {                                             // 4 vong tron dong tam
                    double rad = R * (t - 10) / 4.0;
                    for (int i = 0; i < 14; i++) {
                        double a1 = i * Math.PI * 2 / 14, a2 = (i + 1) * Math.PI * 2 / 14;
                        Vec3d p1 = c.add(b[1].multiply(Math.cos(a1) * rad)).add(b[2].multiply(Math.sin(a1) * rad));
                        Vec3d p2 = c.add(b[1].multiply(Math.cos(a2) * rad)).add(b[2].multiply(Math.sin(a2) * rad));
                        if (Config.displays) new Disp.Beam(w, p1, p2, "red_concrete", null, 0.12, 18);
                        Fx.line(w, Fx.dust(0xFF4040, 1.1f), p1, p2, 0.5);
                    }
                } else if (t == 17) {                                             // luoi xiet: chem moi thu cham mang
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(c, c).expand(R + 2))) {
                        Vec3d rel = Fx.mid(e).subtract(c);
                        double dp = Math.abs(rel.dotProduct(look)), rr = Math.sqrt(Math.max(0, rel.lengthSquared() - dp * dp));
                        if (dp > 2.2 || rr > R + 0.6) continue;
                        Fx.hurt(w, p, e, 42f);
                        e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 3));
                        Fx.put(w, Fx.dust(0xFF2020, 1.8f), Fx.mid(e), 20, 0.5, 0.15);
                        Fx.put(w, ParticleTypes.CRIT, Fx.mid(e), 14, 0.5, 0.3);
                    }
                    Fx.snd(w, c, SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, 1.6f, 0.6f);
                    Vis3D.pulseGrow(w, c, "white_stained_glass", 0.5, R * 1.6, 6);
                    return true;
                }
                return false;
            }
        });
    }

    // ================= YUJI: Divergent Fist (cu thu hai tre nhip) =================
    static void divergent(ServerWorld w, ServerPlayerEntity p) {
        LivingEntity t = Stage2Skills.aim(w, p, 6.0);
        if (t == null) t = Shiki.nearest(w, p, p.getEntityPos(), 4.5);
        if (t == null) { p.sendMessage(Text.literal("Khong co muc tieu"), true); return; }
        final LivingEntity tg = t;
        Vec3d m1 = Fx.mid(tg);
        Fx.hurt(w, p, tg, 10f);
        Fx.snd(w, m1, SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, 1.5f, 0.9f);
        Fx.put(w, Fx.dust(0xFF9A3A, 1.6f), m1, 14, 0.4, 0.1);
        Vis3D.pulseGrow(w, m1, "orange_stained_glass", 0.3, 2.0, 5);
        Vis3D.later(10, () -> {                                                   // cu thu hai den tre, tu ben trong
            if (!tg.isAlive()) return;
            Vec3d m = Fx.mid(tg);
            Fx.hurt(w, p, tg, 22f);
            tg.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 25, 6));
            Vec3d kb = tg.getEntityPos().subtract(p.getEntityPos()).multiply(1, 0, 1);
            if (kb.lengthSquared() > 1e-3) { kb = kb.normalize().multiply(1.1); tg.addVelocity(kb.x, 0.35, kb.z); }
            Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
            Fx.ring(w, Fx.dust(0xFF7A1A, 1.8f), m, b[1], b[2], 1.2, 30, 0);
            Fx.ring(w, Fx.dust(0xFFFFFF, 1.2f), m, b[1], b[2], 2.4, 40, 0);
            Fx.put(w, ParticleTypes.EXPLOSION, m, 1, 0, 0);
            Vis3D.pulseGrow(w, m, "orange_stained_glass", 0.4, 4.0, 8);
            Vis3D.pulseGrow(w, m, "white_concrete", 0.2, 1.4, 6);
            Fx.snd(w, m, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 1.0f, 1.5f);
        });
    }

    // ================= TODO: Boogie Woogie hoan doi vong tron =================
    static void chaos(ServerWorld w, ServerPlayerEntity p) {
        List<LivingEntity> hs = new ArrayList<>(Fx.hostiles(w, p, p.getBoundingBox().expand(20)));
        hs.sort((a, b) -> Double.compare(a.squaredDistanceTo(p), b.squaredDistanceTo(p)));
        if (hs.size() > 3) hs = new ArrayList<>(hs.subList(0, 3));
        if (hs.isEmpty()) { p.sendMessage(Text.literal("Khong co muc tieu"), true); return; }
        Fx.snd(w, p.getEntityPos(), SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, 1.6f, 1.6f);
        List<Vec3d> pos = new ArrayList<>();
        pos.add(p.getEntityPos());
        for (LivingEntity e : hs) pos.add(e.getEntityPos());
        int n = pos.size();
        for (int i = 0; i < n; i++) {
            Vec3d from = pos.get(i), to = pos.get((i + 1) % n);
            Vis3D.pulseShrink(w, from.add(0, 1, 0), "white_concrete", 1.4, 8);
            Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
            Fx.ring(w, Fx.dust(0x9FE8FF, 1.3f), from.add(0, 0.2, 0), b[1], b[2], 1.2, 24, 0);
            if (Config.displays) new Disp.Beam(w, from.add(0, 1, 0), to.add(0, 1, 0), "light_blue_stained_glass", "white_concrete", 0.12, 8);
            Fx.line(w, Fx.dust(0xFFFFFF, 1.0f), from.add(0, 1, 0), to.add(0, 1, 0), 0.5);
        }
        // doi cho: nguoi choi di den vi tri quai dau, quai thu i den vi tri thu i+1...
        p.requestTeleport(pos.get(1 % n).x, pos.get(1 % n).y, pos.get(1 % n).z);
        for (int i = 0; i < hs.size(); i++) {
            Vec3d to = pos.get((i + 2) % n);
            LivingEntity e = hs.get(i);
            e.requestTeleport(to.x, to.y, to.z);
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 30, 5));
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 40, 1));
        }
        Fx.snd(w, p.getEntityPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, 1.2f, 1.4f);
    }

    // ================= NANAMI: Ratio 7:3 Critical =================
    static void critical(ServerWorld w, ServerPlayerEntity p) {
        LivingEntity t = Stage2Skills.aim(w, p, 7.0);
        if (t == null) t = Shiki.nearest(w, p, p.getEntityPos(), 6.0);
        if (t == null) { p.sendMessage(Text.literal("Khong co muc tieu"), true); return; }
        final LivingEntity tg = t;
        Vec3d look = flatLook(p);
        Vec3d right = new Vec3d(-look.z, 0, look.x);
        Fx.snd(w, tg.getEntityPos(), SoundEvents.BLOCK_NOTE_BLOCK_CHIME.value(), 1.5f, 1.6f);
        Anims.add(new Anims.Anim() {
            int n = 0;
            public boolean tick() {
                if (!tg.isAlive() || p.isRemoved()) return true;
                n++;
                Vec3d base = tg.getEntityPos();
                double y = base.y + tg.getHeight() * 0.7;               // diem 7:3
                Vec3d c = new Vec3d(base.x, y, base.z);
                if (n == 1 && Config.displays) {
                    new Disp.Beam(w, c.subtract(right.multiply(1.6)), c.add(right.multiply(1.6)), "gold_block", "white_concrete", 0.07, 14);
                    new Disp.Beam(w, c.add(0, -0.4, 0), c.add(0, 0.4, 0), "gold_block", null, 0.07, 14);
                }
                Fx.line(w, Fx.dust(0xFFD040, 1.0f), c.subtract(right.multiply(1.6)), c.add(right.multiply(1.6)), 0.25);
                if (n == 14) {
                    Vec3d u = Fx.basis(look)[1].add(Fx.basis(look)[2]).normalize();
                    if (Config.displays) {
                        new Disp.Crescent(w, c, u, look, 3.2, 0.5, 0.3, "white_concrete", 8, 5);
                        new Disp.Crescent(w, c, u, look, 3.5, 0.55, 0.8, "yellow_stained_glass", 8, 7);
                    }
                    float dmg = 14f + (float) Math.min(40, tg.getMaxHealth() * 0.35);
                    Fx.hurt(w, p, tg, dmg);
                    tg.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 100, 1));
                    Fx.put(w, ParticleTypes.CRIT, c, 30, 0.5, 0.4);
                    Fx.put(w, Fx.dust(0xFFD040, 1.8f), c, 20, 0.5, 0.2);
                    Fx.snd(w, c, SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, 2.0f, 0.7f);
                    Fx.snd(w, c, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.5f, 0.8f);
                    return true;
                }
                return false;
            }
        });
    }

    // ================= CHOSO: Convergence =================
    static void convergence(ServerWorld w, ServerPlayerEntity p) {
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 50, 5, true, false));
        Fx.snd(w, p.getEntityPos(), SoundEvents.ENTITY_WARDEN_HEARTBEAT, 1.5f, 0.7f);
        Anims.add(new Anims.Anim() {
            int t = 0;
            Disp.Orb orb;
            public boolean tick() {
                if (p.isRemoved() || !p.isAlive()) { if (orb != null) orb.kill(); return true; }
                t++;
                Vec3d look = p.getRotationVec(1f).normalize();
                Vec3d c = p.getEyePos().add(look.multiply(3.0)).add(0, -0.1, 0);
                if (t <= 40) {
                    double g = t / 40.0;
                    if (Config.displays) {
                        if (orb == null) orb = new Disp.Orb(w, c, "red_stained_glass", "redstone_block", null, 1.6, 70);
                        orb.update(c, t * 0.5, 0.2 + 1.0 * g, t % 2 == 0);
                    }
                    for (int i = 0; i < 2; i++) {                                // mau chay tu khong khi vao qua cau
                        Vec3d from = c.add(Fx.randDir().multiply(Fx.rnd(4, 8)));
                        if (Config.displays) new Disp.Beam(w, from, c, "red_stained_glass", null, 0.07, 3);
                        Fx.line(w, Fx.dust(0xB01830, 1.0f), from, c, 0.6);
                    }
                    return false;
                }
                if (t == 41) {
                    Vec3d dir = look;
                    Vec3d end = c.add(dir.multiply(50));
                    for (double d = 1; d <= 50; d += 0.5) { Vec3d v = c.add(dir.multiply(d)); if (!w.isAir(BlockPos.ofFloored(v))) { end = v; break; } }
                    Fx.snd(w, c, SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 2.0f, 1.3f);
                    if (orb != null) orb.kill();
                    final Vec3d e2 = end;
                    if (Config.displays) {
                        Disp.Beam core = new Disp.Beam(w, c, e2, "red_stained_glass", "white_concrete", 1.1, 14);
                        Vis3D.later(2, () -> core.update(c, e2, 0.6));
                        Vis3D.later(6, () -> core.update(c, e2, 0.2));
                        Vis3D.pulseGrow(w, c, "redstone_block", 0.5, 4, 8);
                        Vis3D.pulseGrow(w, e2, "red_stained_glass", 0.4, 5, 10);
                    }
                    Fx.line(w, Fx.dust(0xE02030, 1.6f), c, e2, 0.4);
                    Vec3d[] bb = Fx.basis(dir);
                    for (double d = 0; d < c.distanceTo(e2); d += 2) Fx.ring(w, Fx.dust(0x801020, 1.2f), c.add(dir.multiply(d)), bb[1], bb[2], 1.0 + d * 0.03, 14, d);
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(c, e2).expand(3))) {
                        if (segDist(Fx.mid(e), c, e2) > 1.8) continue;
                        Fx.hurt(w, p, e, 45f);
                        e.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 80, 1));
                        Vec3d kb = dir.multiply(1.4);
                        e.addVelocity(kb.x, 0.3, kb.z);
                        Fx.put(w, Fx.dust(0xB01830, 2.0f), Fx.mid(e), 25, 0.5, 0.2);
                    }
                    return true;
                }
                return true;
            }
        });
    }

    static double segDist(Vec3d p, Vec3d a, Vec3d b) {
        Vec3d ab = b.subtract(a);
        double l2 = ab.lengthSquared();
        double t = l2 < 1e-9 ? 0 : Math.max(0, Math.min(1, p.subtract(a).dotProduct(ab) / l2));
        return p.distanceTo(a.add(ab.multiply(t)));
    }

    // ================= JOGO: Maximum Meteor =================
    static void maxMeteor(ServerWorld w, ServerPlayerEntity p) {
        LivingEntity tg = Stage2Skills.aim(w, p, 45);
        Vec3d target = tg != null ? tg.getEntityPos() : Stage2Skills.rayEnd(w, p, 40);
        Vec3d from = target.add(10, 48, 6);
        Fx.snd(w, p.getEntityPos(), SoundEvents.ENTITY_BLAZE_SHOOT, 1.6f, 0.5f);
        Fx.snd(w, target, SoundEvents.ENTITY_WITHER_SPAWN, 1.0f, 0.5f);
        Anims.add(new Anims.Anim() {
            int t = 0;
            Disp.Orb orb; Disp.Beam trail;
            public boolean tick() {
                if (p.isRemoved()) { if (orb != null) orb.kill(); if (trail != null) trail.kill(); return true; }
                t++;
                Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
                double mark = Math.min(1.0, t / 54.0);
                if (t % 3 == 0) Fx.ring(w, Fx.dust(0xFF4010, 1.5f), target.add(0, 0.2, 0), b[1], b[2], 14 * mark, 60, t);
                if (t % 6 == 0) Fx.ring(w, Fx.dust(0xFFB020, 1.2f), target.add(0, 0.25, 0), b[1], b[2], 14 * (1 - mark), 50, 0);
                double k = Math.min(1.0, t / 55.0), ease = k * k;
                Vec3d pos = from.add(target.subtract(from).multiply(ease));
                if (Config.displays) {
                    if (orb == null) {
                        orb = new Disp.Orb(w, pos, "orange_stained_glass", "magma_block", "yellow_stained_glass", 6.5, 90);
                        trail = new Disp.Beam(w, pos.add(10, 12, 6), pos, "orange_stained_glass", "yellow_concrete", 3.0, 90);
                    }
                    orb.update(pos, t * 0.2, 1.0, t % 2 == 0);
                    trail.update(pos.add(new Vec3d(10, 48, 6).normalize().multiply(14)), pos, 3.0);
                }
                Fx.put(w, ParticleTypes.FLAME, pos, 14, 3.0, 0.1);
                Fx.put(w, ParticleTypes.LAVA, pos, 4, 2.5, 0);
                if (t == 55) {
                    if (orb != null) orb.kill();
                    if (trail != null) trail.kill();
                    impact(target);
                    return true;
                }
                return false;
            }
            void impact(Vec3d c) {
                Vis3D.pulseGrow(w, c.add(0, 2, 0), "orange_stained_glass", 2, 30, 10);
                Vis3D.pulseGrow(w, c.add(0, 2, 0), "yellow_concrete", 1, 14, 8);
                Vis3D.pulseGrow(w, c.add(0, 1, 0), "magma_block", 1, 22, 12);
                for (int i = 1; i <= 5; i++) Fx.ring(w, Fx.dust(0xFF6A10, 2.0f), c.add(0, 0.3, 0), new Vec3d(1, 0, 0), new Vec3d(0, 0, 1), i * 3.0, 50 + i * 14, 0);
                Fx.put(w, ParticleTypes.EXPLOSION_EMITTER, c.add(0, 2, 0), 3, 3.0, 0);
                Fx.snd(w, c, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 3.0f, 0.5f);
                Fx.snd(w, c, SoundEvents.ENTITY_DRAGON_FIREBALL_EXPLODE, 2.5f, 0.6f);
                erase(w, c, 4.5);
                for (LivingEntity e : Fx.hostiles(w, p, new Box(c, c).expand(15))) {
                    double d = e.getEntityPos().distanceTo(c);
                    if (d > 14.5) continue;
                    Fx.hurt(w, p, e, (float) (70 * (1 - d / 14 * 0.6)));
                    e.setFireTicks(200);
                    Vec3d kb = e.getEntityPos().subtract(c).multiply(1, 0, 1);
                    if (kb.lengthSquared() > 1e-3) { kb = kb.normalize().multiply(1.4); e.addVelocity(kb.x, 0.8, kb.z); }
                }
            }
        });
    }

    // ================= MAHITO: Distorted Killing =================
    static void distorted(ServerWorld w, ServerPlayerEntity p) {
        Vec3d dir = flatLook(p);
        Vec3d[] bs = Fx.basis(dir);
        Fx.snd(w, p.getEntityPos(), SoundEvents.ENTITY_RAVAGER_ROAR, 1.2f, 1.6f);
        Anims.add(new Anims.Anim() {
            int t = 0;
            final Disp.Beam[] spikes = new Disp.Beam[8];
            void clean() { for (int i = 0; i < spikes.length; i++) if (spikes[i] != null) { spikes[i].kill(); spikes[i] = null; } }
            public boolean tick() {
                if (p.isRemoved() || !p.isAlive() || t >= 24) { clean(); return true; }
                t++;
                Vec3d here = p.getEntityPos();
                Vec3d next = here.add(dir.multiply(0.85));
                if (!w.isAir(BlockPos.ofFloored(next.add(0, 0.5, 0))) || !w.isAir(BlockPos.ofFloored(next.add(0, 1.5, 0)))) { clean(); return true; }
                p.requestTeleport(next.x, next.y, next.z);
                Vec3d c = next.add(0, 1.0, 0);
                for (int i = 0; i < 8; i++) {
                    double a = i * Math.PI / 4 + t * 0.5;
                    Vec3d d2 = bs[1].multiply(Math.cos(a)).add(bs[2].multiply(Math.sin(a))).add(dir.multiply(0.5 * ((i % 2 == 0) ? 1 : -0.5))).normalize();
                    Vec3d a1 = c.add(d2.multiply(0.5)), a2 = c.add(d2.multiply(i % 2 == 0 ? 2.4 : 1.7));
                    if (Config.displays) {
                        if (spikes[i] == null) spikes[i] = new Disp.Beam(w, a1, a2, i % 2 == 0 ? "pink_concrete" : "magenta_concrete", null, 0.28, 40);
                        else spikes[i].update(a1, a2, 0.28);
                    }
                    Fx.pt(w, Fx.dust(0xE0708A, 1.2f), a2);
                }
                Fx.put(w, Fx.dust(0xA03060, 1.5f), c, 6, 0.8, 0.05);
                if (t % 3 == 0) {
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(c, c).expand(2.8))) {
                        Fx.hurt(w, p, e, 5f);
                        e.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 60, 0));
                        Vec3d kb = dir.multiply(0.7);
                        e.addVelocity(kb.x, 0.2, kb.z);
                    }
                    Fx.snd(w, c, SoundEvents.ENTITY_PLAYER_ATTACK_KNOCKBACK, 0.8f, 0.7f);
                }
                return false;
            }
        });
    }

    // ================= YUTA: Copy =================
    static void copyCast(ServerWorld w, ServerPlayerEntity p) {
        List<Tech.T> pool = new ArrayList<>();
        for (Tech.Chara c : Tech.Chara.values()) {
            if (c == Tech.Chara.YUTA) continue;
            for (Tech.T t : Tech.of(c)) {
                if (t.domain() || t.toggle() || t.id().equals("mahoraga_summon") || t.id().startsWith("copy") || t.id().equals("rct") || t.id().equals("black_flash")) continue;
                if (t.usedBy(Tech.Chara.YUTA)) continue;
                pool.add(t);
            }
        }
        if (pool.isEmpty()) return;
        Collections.shuffle(pool);
        Tech.T pick = pool.get(0);
        Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
        for (int i = 0; i < 4; i++) Fx.ring(w, Fx.dust(0x90B8FF, 1.4f), p.getEntityPos().add(0, i * 0.5, 0), b[1], b[2], 1.3 - i * 0.2, 30, i);
        Vis3D.pulseShrink(w, p.getEntityPos().add(0, 1, 0), "light_blue_stained_glass", 3.5, 8);
        p.sendMessage(Text.literal("Copy: " + pick.en() + "  " + pick.jp()), true);
        Fx.snd(w, p.getEntityPos(), SoundEvents.BLOCK_ENCHANTMENT_TABLE_USE, 1.5f, 1.2f);
        Vis3D.later(6, () -> Abilities.dispatchFree(pick.id(), w, p));
    }
}
