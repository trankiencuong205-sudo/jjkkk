# JJK Mod - Huong dan mo SERVER

> CANH BAO TRUNG THUC: mod nay CHUA tung duoc bien dich/chay thu trong game boi nguoi viet.
> Truoc khi mo server cong khai: build bang GitHub Actions, thu trong WORLD THU rieng (checklist o cuoi).

## Cai dat
- Server va TAT CA nguoi choi deu can: Minecraft 1.21.11, Fabric Loader >= 0.18.0, Fabric API 0.141.1+1.21.11, file `jujutsu-cursed-0.1.0.jar`.
- Bo jar vao thu muc `mods/` cua server va cua tung nguoi choi (menu/phim bam la phia client).

## Cau hinh: `config/jjk-config.properties` (tren server)
| Khoa | Mac dinh | Y nghia |
|---|---|---|
| admins | (trong) | Ten nguoi choi, cach nhau dau phay. Chi nhung nguoi nay doi duoc cai dat server / goi quai. Che do 1 nguoi/LAN: ai cung la admin. |
| solidDomain | true | Domain = phong khoi that. Dat false neu muon chi hien thi (nhe hon, an toan hon). |
| maxRooms | 2 | So phong domain cung luc; vuot thi domain dung hieu ung hien thi thay the. |
| purpleErasesBlocks | true | Hollow Purple xoa khoi (ca obsidian, tru bedrock). TREN SERVER CONG CONG nen dat false hoac destruction=false (chong grief). |
| naturalMobs | false | Quai chu linh xuat hien tu nhien. |
| maxDisplays | 1500 | Tran so hieu ung 3D cung luc (chong lag). Giam neu server yeu. |
| actionsPerSecond | 25 | Gioi han goi tin/giay moi nguoi (chong spam/hack client). |
| curseEvents / eventMinutes | true / 30 | Su kien Lan Chu Linh tu dong. |
| gradeGate | true | Ky nang manh can Grade (chi tren server rieng). |
| texturedModels | true | Thuc than dung texture rieng (item_display). Neu thay o vuong tim-den hoac mat hinh, dat false de quay ve khoi vanilla. |
| destruction / destructionLimit | true / 450 | Ky nang pha huy dia hinh (ho no, duong ham, vet cat, song nut dat). Khong pha bedrock/ruong/phong domain; khong roi vat pham. Dat destruction=false tren server cong cong neu khong muon grief. |
| displays / domainShell | true | Tat neu lag. |

Them ten admin, vd: `admins=TenCuaBan,PhoAdmin` roi go `/jjk reload`.

## He thong cap bac (Grade) - de nguoi choi co dong luc cay
- XP: giet chu linh (Grade4 +10, Grade2 +30, Special +120, Mahito/Jogo/Hanami/Dagon +200, Sukuna +600, Mahoraga +800), quai thuong +2, thang Lan Chu Linh +150.
- 6 cap: Grade 4 (0) > Grade 3 (100) > Grade 2 (400) > Semi-Grade 1 (1000) > Grade 1 (2500) > Special Grade (6000 XP).
- Moi cap: +25% chu luc toi da, +15% toc do hoi chu luc, +8% sat thuong.
- `gradeGate=true`: ky nang manh can Grade cao (theo chi phi chu luc; domain can Grade 1). Creative va choi 1 nguoi bo qua gioi han nay.
- Lenh moi nguoi: `/jjk grade`, `/jjk top`. Admin: `/jjk givexp <nguoi> <so>`.

## Ngon tay Sukuna
Boss va Lan Chu Linh roi "Cursed Finger". Chuot phai de nuot: +50 XP, +3% sat thuong moi ngon. Du 20 ngon: Sukuna thuc tinh (boss) xuat hien, dem ngon reset ve 0.

## Su kien "Lan Chu Linh"
- Tu dong moi `eventMinutes` phut (mac dinh 30) neu co nguoi online; tat bang `curseEvents=false`.
- 3 dot chu linh quanh mot nguoi choi, dot cuoi co boss; co thanh boss bar; thang thi XP + hoi day chu luc; qua 8 phut quai tu bien mat.
- Admin: `/jjk event start`, `/jjk event stop`.

## Lenh admin (op khong can; chi can nam trong `admins` hoac la console)
- `/jjk status` - so hieu ung, so phong, khoi dang cho tra.
- `/jjk cleanup` - dong het phong domain, tra khoi cu, xoa hieu ung.
- `/jjk reload` - nap lai config.

## Co che an toan da them
- Loi trong ky nang/hoat anh bi bat va ghi log, khong lam sap server.
- Gioi han toc do goi tin; hanh dong nhay cam bi khoa cho admin; don dep du lieu khi nguoi choi thoat.
- Phong domain: toi da 3 phut tu dong tra khoi; khong dap duoc khi dang mo; bo qua bedrock/block entity (ruong...); bo qua o ngoai gioi han the gioi/world border; khi tat server tra lai het.
- JOURNAL `config/jjk-room-journal.txt`: neu server sap giua domain, lan khoi dong sau mod tu tra khoi cu khi chunk tai len. KHONG xoa file nay.
- Tran so display entity (`maxDisplays`).

## Rui ro con lai (nen biet)
- Domain thay doi khoi trong the gioi tam thoi: nguoi dung trong tuong co the bi ngat (chua xu ly day ra). Nen BACKUP world truoc khi mo.
- Chua kiem chung do chinh xac cac ky thuat co the gay lag khi nhieu nguoi cung dung; bat dau voi it nguoi.
- Bao ve khoi chi chan nguoi choi dap; no/TNT/piston chua duoc chan.
- Khong co he thong bao ve vung (claim) - chi nen dung cung plugin/mod khac neu can.

## Checklist thu truoc khi mo
1. Build xanh tren GitHub Actions; server + 2 client vao duoc.
2. `/jjk status` chay. Nguoi khong phai admin bam tab Cai dat -> bi tu choi.
3. Dung 1 domain moi loai: phong hien ra, khong dap duoc, het domain khoi tra nguyen ven.
4. Dung domain roi `stop` server giua chung -> khoi dong lai -> khoi duoc tra (xem log "journal phong").
5. 3-4 nguoi cung dung ky nang 5 phut: TPS on dinh (`/tick query` hoac `/forge tps` tuong duong).
6. Backup world dinh ky.
