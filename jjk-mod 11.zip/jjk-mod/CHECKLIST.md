# Jujutsu Kaisen mod — Master checklist

Trạng thái trung thực. **Chưa có mục nào được "tested"**: dự án này chưa từng được biên dịch hay chạy trong game
(môi trường tạo ra nó không tải được Maven/Fabric). Khi bạn chạy thử, hãy báo từng mục để mình đổi trạng thái.

Chú giải: 🟡 = đã viết, chưa test · ⬜ = planned (chưa viết) · 🟥 = blocked (cần công nghệ/xác minh thêm)

## Giai đoạn 1 (có trong zip này)

| Nhân vật | Kỹ thuật | Trạng thái | Ghi chú |
|---|---|---|---|
| Gojo | Infinity 無下限 | 🟡 | Chặn đòn có kẻ tấn công + đạn; quái bị đẩy. Không chặn lửa/rơi/độc. Đạn bị chậm do server (client có thể giật) |
| Gojo | Blue 蒼 | 🟡 | Hút quái 50 tick, nghiền nát, xung nổ cuối |
| Gojo | Red 赫 | 🟡 | Đạn đẩy lùi, sóng xung kích, không phá khối |
| Gojo | Hollow Purple 茈 | 🟡 | Charge Blue+Red → bay xuyên. Xóa địa hình chỉ khi bật `purpleErasesBlocks` |
| Gojo | Unlimited Void 無量空処 | 🟡 | Vỏ cầu hạt, quái bị tê liệt + sát thương nhẹ. Chưa: domain clash, môi trường 3D thật |
| Sukuna | Cleave 捌 | 🟡 | Sát thương theo máu tối đa mục tiêu |
| Sukuna | Dismantle 解 | 🟡 | 5 lưỡi chém bay, hitbox thật |
| Sukuna | Fire Arrow 開 (Fuga) | 🟡 | Vòng lửa → tên lửa → nổ, không đốt khối |
| Sukuna | Malevolent Shrine 伏魔御廚子 | 🟡 | Đền vẽ bằng hạt (không phải khối), chém liên tục. Chưa: domain clash |
| Yuji | Black Flash 黒閃 | 🟡 | Xác suất + Zone; tia sét đen-đỏ |
| Chung | Reverse Cursed Technique 反転術式 | 🟡 | Hồi 8 máu (Gojo, Sukuna) |
| Chung | Cursed Energy Reinforcement 呪力強化 | 🟡 | Speed I + Strength I |
| Hệ thống | Chu lực, hồi chiêu, HUD, menu J, phím R/G/V, đồng bộ server | 🟡 | Server kiểm tra quyền sở hữu / năng lượng / hồi chiêu |
| Hệ thống | Lưu nhân vật đã chọn | 🟡 | config/jjk-players.properties |

## Nâng cấp hiệu ứng (display entity) — 🟡 chưa test, chưa ai xem bằng mắt
Orb nhiều khối kính xoay + lõi phát sáng (Blue, Red, Hollow Purple, Fire Arrow, Meteor), tia hộp dài (Purple, Fire Arrow, Piercing Blood, Rika Beam), lưỡi chém cong nhiều đoạn (Cleave, Dismantle). Các chiêu khác vẫn là hạt. Tắt bằng `displays=false`.

## Giai đoạn 2 (có trong zip này — tất cả 🟡 chưa test; hoạt ảnh bằng hạt, không có mob/model thật)

| Nhân vật | Kỹ thuật |
|---|---|
| Megumi | Nue, Toad, Great Serpent (hoạt ảnh hạt; chưa có Divine Dogs, Mahoraga, Chimera Shadow Garden) |
| Todo | Boogie Woogie (hoán đổi vị trí với quái), Black Flash |
| Nanami | Ratio Technique 7:3, Overtime |
| Nobara | Straw Doll: Resonance, Hairpin |
| Choso | Piercing Blood, Supernova |
| Jogo | Maximum: Meteor, Domain: Coffin of the Iron Mountain (núi lửa bằng hạt) |
| Mahito | Idle Transfiguration (chưa có Domain Self-Embodiment of Perfection) |
| Inumaki | Cursed Speech: Stop / Blast Away / Explode |
| Yuta | Rika Cursed Energy Beam, Rika Manifestation (bóng Rika bằng hạt) |
| Toji | Heavenly Restriction, Inverted Spear of Heaven, Playful Cloud |
| Hệ thống | 8 ô kỹ năng với phím riêng, menu K gắn/thay/xóa, HUD icon + hồi chiêu, lưu theo nhân vật |

## Các giai đoạn sau (⬜ planned — KHÔNG có trong zip này)

### Gojo / Sukuna mở rộng
- ⬜ Maximum: Blue, Maximum: Red, Hollow Purple 200%, Six Eyes (hiệu ứng/giảm tiêu hao)
- ⬜ Sukuna: Dismantle (Web), World-Cutting Slash, Domain Amplification, biến thể Cleave
- ⬜ Domain clash / Simple Domain / Domain Amplification / Hollow Wicker Basket / Falling Blossom Emotion

### Yuji / Megumi / Nobara
- ⬜ Yuji: Divergent Fist, Manji Kick, Black Flash do thời điểm thật
- ⬜ Megumi — Ten Shadows: Divine Dogs, Nue, Toad, Max Elephant, Rabbit Escape, Round Deer, Piercing Ox, Great Serpent, Tiger Funeral, Mahoraga; domain Chimera Shadow Garden
- ⬜ Nobara: Straw Doll Technique (Resonance, Hairpin)

### Các pháp sư khác
- ⬜ Yuta (copy, Authentic Mutual Love), Toji (Chain of a Thousand Miles, Split Soul Katana), Maki, Nanami (Collapse), Todo (Black Flash theo thời điểm), Choso (Flowing Red Scale, Blood Edge), Hakari (Idle Death Gamble), Kashimo, Higuruma (Deadly Sentencing), Hana/Angel, Kenjaku, Inumaki, Panda, Geto, Yuki, Naoya (Projection Sorcery)

### Nguyền hồn
- ⬜ Mahito (Idle Transfiguration, Self-Embodiment of Perfection), Jogo (Coffin of the Iron Mountain), Hanami, Dagon (Horizon of the Captivating Skandha), Death Painting Wombs

### Hệ thống lớn
- 🟥 Mob riêng có model/texture/animation 3D: cần đăng ký entity + renderer tùy chỉnh (API client 1.21.11 chưa được xác minh bằng build)
- 🟥 Domain có môi trường 3D thật (đổi trời/khối/ánh sáng): cần render tùy chỉnh hoặc đặt khối tạm thời an toàn
- ⬜ Boss + phase, loot, tiến trình mở khóa, vật phẩm công cụ nguyền (cursed tools), vow
- ⬜ Màn cài đặt từng kỹ thuật trong game (hiện chỉ sửa file config/jjk-config.properties)

## Stage 3: Quai + Trang phuc (CHUA build, CHUA test trong game)
| Muc | Trang thai |
|---|---|
| 13 bo trang phuc (texture rieng, equippable asset_id jjk:<ten>) | 🟡 da viet, chua thay trong game |
| Menu K > tab Trang phuc / Quai | 🟡 chua test |
| Cursed Spirit G4 / G2 / Special-Grade | 🟡 than xac vanilla (vex/spider/ravager) + ten, scale, AI |
| Mahito, Jogo, Hanami, Dagon | 🟡 than xac vanilla + ky nang Java |
| Sukuna boss (Cleave/Dismantle/Fuga/Shrine) | 🟡 |
| Mahoraga (thich ung sat thuong) | 🟡 dung AFTER_DAMAGE hoi mau lai, chua phai thich ung that |
| Tu xuat hien ban dem (config naturalMobs) | 🟡 |
| Model 3D rieng cho quai | ❌ chua co (can Blockbench/GeckoLib) |
| Goi quai chi o Creative | ✔ theo thiet ke |

## Stage 3b: Domain 3D + nhan vat moi + menu Cai dat (CHUA build, CHUA test)
| Muc | Trang thai |
|---|---|
| Menu K > tab Cai dat (tat hoi chieu, chu luc vo han, he so CD/chi phi, hoi chu luc, hoi day ngay, thoi gian domain) | 🟡 |
| Canh 3D cho Unlimited Void / Malevolent Shrine / Coffin of Iron Mountain (block_display, vo lat nguoc) | 🟡 phu thuoc scale am cua display co render mat trong; tat bang domainShell=false |
| Domain moi: Chimera Shadow Garden, Self-Embodiment of Perfection, Idle Death Gamble (slot 3 cuon + jackpot), Deadly Sentencing (phap dinh + kiem hanh quyet) | 🟡 |
| Nhan vat moi: Hakari, Higuruma, Kashimo, Maki, Kenjaku (14 ky nang moi) | 🟡 |
| Trang phuc cho 5 nhan vat moi | 🟡 |
| Domain clash (va cham domain) | ❌ chua co |
| Kenjaku: Brain swap, Womb Profusion | ❌ chua co |

## Stage 3c: 3D cho moi ky nang + 10 shikigami cua Megumi (CHUA build, CHUA test)
| Muc | Trang thai |
|---|---|
| 10 shikigami 3D: Divine Dogs, Nue, Great Serpent, Toad, Max Elephant, Rabbit Escape, Round Deer, Piercing Ox, Tiger Funeral, Mahoraga (Rig: nhieu block_display co hoat anh chan/canh/duoi) | 🟡 chua thay trong game |
| 3D cho Boogie Woogie, Ratio, Overtime, Resonance (bu rom+dinh), Hairpin, Supernova, Idle Transfiguration, Cursed Speech x3, Black Flash, Heavenly Restriction, Inverted Spear, Playful Cloud, RCT, Infinity (the bao quanh) | 🟡 chay song song ky nang cu (cung huong ngam) |
| 3D cho Kashimo (set 3D), Maki (vet chem), Hakari (canh cua neon), Kenjaku (lo den) | 🟡 |
| Reinforce, Heavenly aura chi la hat/than don gian | 🟡 |
| Model dong vat chi la khoi hop chu nhat (low-poly), khong co model Blockbench | ⚠ gioi han |

## Giai doan 4-5 (Moves + phong linh vuc) - 🟡 chua test, chua bien dich
- 🟡 ~180 ky nang du lieu (Moves.java), moi nhan vat >= 13 ky nang, co hinh 3D.
- 🟡 Linh vuc la CAN PHONG kin (4 tuong + tran bang tam mong, khong dung scale am), Malevolent Shrine co 20 ngon tay Sukuna (bone/terracotta).
- 🟡 Authentic Mutual Love (Yuta): phong trang, san xanh, 44 thanh kiem ghim vao tam.
- 🟡 Rika 3D (rika_manifest), Mahoraga co banh xe phap moi, trang phuc ve lai + Rika, ky nang copy_outfit cua Yuta.
