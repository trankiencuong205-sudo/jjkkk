package com.example.jjk;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Bo ky nang giai doan 4: ~50 chieu moi, moi chieu thuoc mot "loai" co hinh 3D (qua cau bay, tia, vet chem,
 * song xung kich, cot giang tu tren troi, hut xoay, chuoi, dam lien hoan, dash, buff). Du lieu dang bang (xem def(...)).
 * Chua test trong game.
 */
public class Moves {
    public record M(String id, String kind, String en, String jp, String icon, int energy, int cd, double dmg, String b1, String b2,
                    int col, double range, double rad, int n, double speed, String fx, String desc, Tech.Chara[] users) { }

    static final Map<String, M> MAP = new LinkedHashMap<>();

    static void def(String id, String kind, String en, String jp, String icon, int energy, int cd, double dmg, String b1, String b2,
                    int col, double range, double rad, int n, double speed, String fx, String desc, Tech.Chara... users) {
        MAP.put(id, new M(id, kind, en, jp, icon, energy, cd, dmg, b1, b2, col, range, rad, n, speed, fx, desc, users));
    }

    public static String iconOf(String id) { M m = MAP.get(id); return m == null ? "?" : m.icon; }

    public static void registerTechs() {
        for (M m : MAP.values()) Tech.add(m.id, m.en, m.jp, m.energy, m.cd, m.dmg, "instant", m.desc, Tech.UNTESTED + " (giai doan 4)", m.users);
    }

    static {
        Tech.Chara G = Tech.Chara.GOJO, S = Tech.Chara.SUKUNA, Y = Tech.Chara.YUJI, ME = Tech.Chara.MEGUMI, TO = Tech.Chara.TODO,
                NA = Tech.Chara.NANAMI, NO = Tech.Chara.NOBARA, CH = Tech.Chara.CHOSO, JO = Tech.Chara.JOGO, MA = Tech.Chara.MAHITO,
                IN = Tech.Chara.INUMAKI, YU = Tech.Chara.YUTA, TJ = Tech.Chara.TOJI, HK = Tech.Chara.HAKARI, HG = Tech.Chara.HIGURUMA,
                KS = Tech.Chara.KASHIMO, MK = Tech.Chara.MAKI, KJ = Tech.Chara.KENJAKU;
        String LB = "light_blue_stained_glass", RG = "red_stained_glass", OG = "orange_stained_glass", WG = "white_stained_glass";
        // ---- Gojo ----
        def("gojo_blink", "dash", "Limitless: Blink", "無下限・瞬歩", "瞬", 25, 60, 0, LB, "white_concrete", 0x9FE8FF, 14, 0, 1, 0, "", "Dich chuyen tuc thoi ve phia truoc toi 14 o (dung vat can thi dung lai), de lai vet sang.", G);
        def("blue_max", "pull", "Lapse Blue: Maximum Output", "蒼・最大出力", "蒼", 90, 500, 24, LB, "blue_concrete", 0x3090FF, 18, 12, 60, 0, "slow:30:2", "Cau hut khong lo tai diem ngam: hut moi quai trong 12 o trong 3 giay, nghien nat 24 st.", G);
        def("red_max", "nova", "Reversal Red: Maximum Output", "赫・最大出力", "赫", 100, 500, 30, RG, "redstone_block", 0xFF3030, 0, 10, 1, 1.6, "", "Song xung kich do ban kinh 10: 30 st va hat bay moi quai.", G);
        def("infinity_repel", "nova", "Infinity: Repel", "無下限・反発", "斥", 30, 100, 8, WG, "light_blue_concrete", 0x9FE8FF, 0, 6, 1, 1.3, "", "Day moi quai trong 6 o ra xa (8 st).", G);
        // ---- Sukuna ----
        def("world_slash", "beam", "World Cutting Slash", "世界を断つ斬撃", "世", 120, 600, 55, RG, "white_concrete", 0xFF2020, 40, 0.5, 1, 0, "", "Nhat chem xuyen the gioi dai 40 o, 55 st moi quai trung.", S);
        def("spiderweb", "slash", "Spiderweb", "蜘蛛の巣", "巣", 80, 300, 28, RG, "white_concrete", 0xFF2020, 9, 4.5, 7, 0, "", "7 duong chem dan thanh mang nhen truoc mat (28 st tong).", S);
        def("furnace", "nova", "Furnace", "竈", "竈", 90, 400, 20, OG, "magma_block", 0xFF6010, 0, 9, 1, 1.0, "fire:120", "Bien lua ban kinh 9: 20 st + chay 6 giay.", S);
        def("flame_rain", "strike", "Flame Rain", "炎雨", "雨", 100, 500, 14, OG, "yellow_concrete", 0xFF6010, 22, 3, 6, 0, "fire:80", "6 cot lua rot xuong quanh diem ngam (14 st moi cot, chay).", S);
        // ---- Yuji ----
        def("divergent_fist", "multi", "Divergent Fist", "逕庭拳", "逕", 35, 100, 26, OG, "white_concrete", 0xFF9A3A, 3, 2.4, 2, 10, "", "Hai cu dam lech nhip (13 st moi cu), cu thu hai den tre 0.5s.", Y);
        def("manji_kick", "dash", "Manji Kick", "卍蹴り", "蹴", 30, 100, 16, OG, "yellow_concrete", 0xFF9A3A, 8, 0, 1, 0, "", "Lao toi 8 o va da trung moi quai tren duong (16 st).", Y);
        def("flash_barrage", "multi", "Black Flash Barrage", "黒閃連打", "連", 70, 300, 36, "black_stained_glass", "red_concrete", 0xE02020, 3, 2.4, 6, 2, "", "6 cu dam lien tiep mang tia den-do (36 st tong).", Y);
        def("cursed_blast", "beam", "Cursed Energy Blast", "呪力砲", "砲", 45, 120, 22, OG, "yellow_concrete", 0xFF9A3A, 20, 0.6, 1, 0, "", "Tia nang luong thang 20 o (22 st).", Y);
        // ---- Megumi ----
        def("shadow_step", "dash", "Shadow Travel", "影渡り", "影", 30, 80, 0, "black_concrete", "gray_stained_glass", 0x202030, 16, 0, 1, 0, "", "Lan qua bong toi 16 o ve phia truoc.", ME);
        // ---- Todo ----
        def("todo_clap", "nova", "Pulse Clap", "柏手", "柏", 35, 100, 14, WG, "cyan_concrete", 0xC09060, 0, 6, 1, 1.0, "slow:30:1", "Vo tay tao song xung kich ban kinh 6 (14 st, lam cham).", TO);
        def("brother_strike", "multi", "Brotherly Strike", "親友の一撃", "兄", 60, 200, 30, OG, "white_concrete", 0xC09060, 3, 2.6, 3, 6, "", "3 cu dam nhanh theo nhip Boogie Woogie (30 st).", TO);
        def("todo_rush", "dash", "Bare-Fist Rush", "突進", "突", 40, 120, 20, "brown_stained_glass", "white_concrete", 0xC09060, 10, 0, 1, 0, "", "Lao toi 10 o, dam bay moi thu tren duong (20 st).", TO);
        // ---- Nanami ----
        def("collapse", "strike", "Ratio: Collapse", "瓦落瓦落", "崩", 60, 300, 36, "yellow_stained_glass", "gold_block", 0xE0C060, 12, 3, 1, 0, "slow:40:2", "Cot sang bang xuong diem yeu cua muc tieu (36 st, lam cham).", NA);
        def("cleaver_throw", "proj", "Cleaver Throw", "鉈投げ", "鉈", 35, 100, 18, "yellow_stained_glass", "iron_block", 0xE0C060, 24, 2, 1, 1.6, "", "Nem dao bay thang, no ban kinh 2 (18 st).", NA);
        def("ratio_barrage", "slash", "Seven-Three Barrage", "十劃連斬", "劃", 55, 200, 27, "yellow_stained_glass", "white_concrete", 0xE0C060, 6, 3.5, 3, 0, "", "3 nhat chem lien tiep chia 7:3 (27 st).", NA);
        // ---- Nobara ----
        def("nail_barrage", "proj", "Nail Barrage", "釘連射", "釘", 40, 120, 24, "iron_block", "gray_concrete", 0xD07080, 20, 1.5, 8, 2.0, "", "Ban 8 mui dinh hinh quat (3 st moi mui).", NO);
        def("resonance_area", "nova", "Resonance: Spread", "共鳴り・拡散", "鳴", 70, 300, 18, "pink_stained_glass", "red_concrete", 0xD07080, 0, 9, 1, 0.5, "weak:80:1,slow:60:1", "Rung chan ban kinh 9: 18 st, Weakness + Slowness.", NO);
        def("straw_doll_hex", "debuff", "Straw Doll: Hex", "呪い人形", "呪", 45, 200, 20, "hay_block", "iron_block", 0xD07080, 16, 0, 1, 0, "wither:100:1,slow:60:1", "Nguyen rua muc tieu: Wither II 5s + Slowness (20 st).", NO);
        // ---- Choso ----
        def("flowing_red_scale", "buff", "Flowing Red Scale", "赤鱗躍動", "鱗", 80, 700, 0, RG, "redstone_block", 0xB01830, 0, 0, 1, 0, "speed:300:2,str:300:1,res:300:0,regen:100:1", "15 giay: Speed III, Strength II, Resistance I, hoi mau; hao quang mau 3D.", CH);
        def("convergence", "beam", "Convergence", "百斂", "百", 90, 300, 36, RG, "redstone_block", 0xB01830, 40, 0.4, 1, 0, "", "Tia mau xuyen 40 o toc do cao (36 st).", CH);
        def("blood_wave", "slash", "Crushing Blood Wave", "血の波", "波", 60, 200, 30, RG, "redstone_block", 0xB01830, 8, 4, 5, 0, "", "5 lan song mau quet ve phia truoc (30 st).", CH);
        // ---- Jogo ----
        def("ember_insects", "proj", "Ember Insects", "螢", "螢", 50, 160, 30, "magma_block", "orange_concrete", 0xFF6A20, 24, 1.5, 10, 1.0, "fire:80,home", "10 con tru lua tu tim quai (3 st moi con, chay).", JO);
        def("eruption", "strike", "Eruption", "噴火", "噴", 100, 500, 12, "magma_block", "orange_stained_glass", 0xFF6A20, 20, 3, 5, 0, "fire:100", "5 cot dung nham phun len quanh diem ngam (12 st moi cot).", JO);
        def("flame_breath", "beam", "Flame Breath", "炎吹", "吹", 60, 160, 26, OG, "yellow_concrete", 0xFF6A20, 14, 1.6, 1, 0, "fire:100", "Phun lua rong 14 o (26 st, chay).", JO);
        // ---- Mahito ----
        def("soul_blade", "slash", "Polymorphic Soul Isomer: Blade", "武器化", "刃", 45, 100, 24, "purple_stained_glass", "magenta_concrete", 0x8A5AC0, 5, 3, 2, 0, "", "Bien tay thanh luoi, chem 2 nhat (24 st).", MA);
        def("distorted_kill", "dash", "Distorted Killing", "変形殺", "殺", 50, 160, 22, "magenta_stained_glass", "pink_concrete", 0x8A5AC0, 12, 0, 1, 0, "nausea:100", "Bien than lao toi 12 o (22 st, Nausea).", MA);
        def("soul_distortion", "pull", "Soul Distortion", "魂の歪み", "歪", 70, 300, 18, "magenta_stained_glass", "pink_concrete", 0x8A5AC0, 14, 8, 50, 0, "nausea:80,weak:80:1", "Hut va xoan vo hon quai ban kinh 8 trong 2.5 giay (18 st).", MA);
        // ---- Inumaki ----
        def("speech_sleep", "debuff", "Cursed Speech: Sleep", "眠れ", "眠", 45, 200, 0, WG, "light_blue_concrete", 0xE8E8F0, 12, 12, 1, 0, "slow:200:6,weak:200:2,blind:100", "Moi quai trong 12 o ngu gat: gan nhu bat dong 10 giay.", IN);
        def("speech_crush", "nova", "Cursed Speech: Crush", "潰れろ", "潰", 70, 300, 28, WG, "gray_concrete", 0xE8E8F0, 0, 8, 1, 0.3, "slow:40:2", "Ep nat moi quai trong 8 o (28 st).", IN);
        def("speech_runaway", "nova", "Cursed Speech: Run Away", "逃げろ", "逃", 40, 160, 4, WG, "white_concrete", 0xE8E8F0, 0, 10, 1, 2.0, "slow:20:0", "Thet quai trong 10 o bat chay (day manh).", IN);
        // ---- Yuta ----
        def("yuta_slash", "slash", "Katana Slash", "斬撃", "斬", 40, 100, 27, LB, "white_concrete", 0x90B8FF, 6, 3.5, 3, 0, "", "3 nhat chem katana (27 st).", YU);
        def("rika_hand", "strike", "Rika: Giant Hand", "リカの手", "手", 90, 400, 40, "light_gray_concrete", "white_concrete", 0x90B8FF, 16, 4, 1, 0, "slow:60:3", "Ban tay Rika khong lo dap xuong diem ngam (40 st, ban kinh 4).", YU);
        // ---- Toji ----
        def("chain_whip", "chain", "Chain of a Thousand Miles", "万里の鎖", "鎖", 30, 100, 14, "iron_block", "gray_concrete", 0x909098, 18, 0, 1, 0, "slow:40:1", "Quang xich quang toi 18 o, keo muc tieu ve phia ban (14 st).", TJ);
        def("toji_rush", "multi", "Heavenly Rush", "天与の連撃", "撃", 40, 140, 30, "black_stained_glass", "white_concrete", 0x909098, 3, 2.6, 3, 4, "", "3 don dam chem thau giap (30 st).", TJ);
        def("knife_barrage", "proj", "Knife Barrage", "小刀投擲", "刀", 30, 100, 24, "iron_block", "gray_concrete", 0x909098, 22, 1.2, 6, 2.2, "", "Nem 6 con dao hinh quat (4 st moi con).", TJ);
        // ---- Hakari ----
        def("rough_energy", "beam", "Rough Energy", "粗い呪力", "粗", 60, 250, 34, "pink_stained_glass", "yellow_concrete", 0xFF40D0, 24, 1.1, 1, 0, "", "Dong chu luc tho bao xuyen 24 o (34 st).", HK);
        def("jackpot_slam", "nova", "Jackpot Slam", "大当たり", "当", 70, 300, 26, "yellow_stained_glass", "pink_concrete", 0xFF40D0, 0, 8, 1, 1.4, "", "Dap dat tao song xung kich ban kinh 8 (26 st).", HK);
        // ---- Higuruma ----
        def("gavel_smash", "strike", "Gavel Smash", "木槌", "槌", 60, 250, 30, "dark_oak_planks", "gold_block", 0xE0C040, 14, 3.5, 1, 0, "slow:60:3", "Cay bua phap quan khong lo dap xuong muc tieu (30 st).", HG);
        def("verdict_chain", "chain", "Verdict Chains", "判決の鎖", "判", 40, 160, 12, "gold_block", "yellow_concrete", 0xE0C040, 16, 0, 1, 0, "slow:100:6,weak:100:2", "Xich phan quyet troi muc tieu (12 st, gan nhu bat dong 5s).", HG);
        // ---- Kashimo ----
        def("lightning_cannon", "beam", "Lightning Cannon", "雷砲", "砲", 90, 300, 38, LB, "white_concrete", 0x40C0FF, 36, 1.0, 1, 0, "slow:40:3", "Tia set cuc dai 36 o (38 st, tê liet).", KS);
        def("thunder_rain", "strike", "Thunder Rain", "雷雨", "雷", 90, 400, 14, LB, "white_concrete", 0x40C0FF, 20, 2.5, 7, 0, "slow:30:3", "7 tia set danh xuong quanh diem ngam (14 st moi tia).", KS);
        // ---- Maki ----
        def("spear_throw", "proj", "Spear Throw", "槍投げ", "槍", 35, 100, 26, "gray_stained_glass", "iron_block", 0x4AA070, 28, 2.0, 1, 2.0, "", "Phi cay giao xuyen 28 o, no ban kinh 2 (26 st).", MK);
        def("maki_combo", "multi", "Maki Combo", "連撃", "連", 45, 140, 30, "green_stained_glass", "white_concrete", 0x4AA070, 3, 2.6, 5, 3, "", "5 don chem lien hoan (30 st).", MK);
        // ---- Kenjaku ----
        def("curse_swarm", "proj", "Curse Swarm", "呪霊群", "群", 60, 200, 28, "purple_concrete", "black_concrete", 0x9A60C0, 24, 1.5, 7, 0.9, "home", "7 chu linh nho tu tim quai (4 st moi con).", KJ);
        def("void_pull", "pull", "Void Pull", "虚空", "虚", 80, 400, 30, "purple_stained_glass", "black_concrete", 0x9A60C0, 16, 10, 60, 0, "slow:30:2", "Lo den hut moi thu trong 10 o trong 3 giay (30 st).", KJ);
    }

    // ---------- tien ich ----------
    static final Map<String, RegistryEntry<StatusEffect>> EFF = new LinkedHashMap<>();
    static {
        EFF.put("slow", StatusEffects.SLOWNESS); EFF.put("weak", StatusEffects.WEAKNESS); EFF.put("blind", StatusEffects.BLINDNESS);
        EFF.put("wither", StatusEffects.WITHER); EFF.put("nausea", StatusEffects.NAUSEA); EFF.put("poison", StatusEffects.POISON);
        EFF.put("fatigue", StatusEffects.MINING_FATIGUE); EFF.put("speed", StatusEffects.SPEED); EFF.put("str", StatusEffects.STRENGTH);
        EFF.put("res", StatusEffects.RESISTANCE); EFF.put("regen", StatusEffects.REGENERATION); EFF.put("haste", StatusEffects.HASTE);
    }

    static void applyFx(String fx, LivingEntity e) {
        if (fx == null || fx.isEmpty()) return;
        for (String tok : fx.split(",")) {
            String[] a = tok.trim().split(":");
            try {
                if (a[0].equals("fire")) { e.setFireTicks(Integer.parseInt(a[1])); continue; }
                RegistryEntry<StatusEffect> ef = EFF.get(a[0]);
                if (ef == null) continue;
                int dur = a.length > 1 ? Integer.parseInt(a[1]) : 60, amp = a.length > 2 ? Integer.parseInt(a[2]) : 0;
                e.addStatusEffect(new StatusEffectInstance(ef, dur, amp));
            } catch (RuntimeException ignored) { }
        }
    }

    static boolean has(M m, String flag) { return m.fx.contains(flag); }

    static double segDist(Vec3d p, Vec3d a, Vec3d b) {
        Vec3d ab = b.subtract(a);
        double l2 = ab.lengthSquared();
        double t = l2 < 1e-9 ? 0 : Math.max(0, Math.min(1, p.subtract(a).dotProduct(ab) / l2));
        return p.distanceTo(a.add(ab.multiply(t)));
    }

    static void knock(LivingEntity e, Vec3d from, double s) {
        Vec3d d = e.getEntityPos().subtract(from).multiply(1, 0, 1);
        if (d.lengthSquared() < 1e-4 || s <= 0) return;
        d = d.normalize().multiply(s);
        e.addVelocity(d.x, 0.3 + s * 0.08, d.z);
    }

    static void hit(ServerWorld w, ServerPlayerEntity p, M m, LivingEntity e, float dmg) {
        if (dmg > 0) Fx.hurt(w, p, e, dmg);
        applyFx(m.fx, e);
        Fx.put(w, Fx.dust(m.col, 1.4f), Fx.mid(e), 8, 0.4, 0.1);
    }

    // ---------- dispatch ----------
    public static boolean cast(String id, ServerWorld w, ServerPlayerEntity p) {
        M m = MAP.get(id);
        if (m == null) return false;
        switch (m.kind) {
            case "proj" -> proj(m, w, p);
            case "beam" -> beam(m, w, p);
            case "slash" -> slash(m, w, p);
            case "nova" -> nova(m, w, p);
            case "dash" -> dash(m, w, p);
            case "strike" -> strike(m, w, p);
            case "buff" -> buff(m, w, p);
            case "pull" -> pull(m, w, p);
            case "multi" -> multi(m, w, p);
            case "chain" -> chain(m, w, p);
            case "debuff" -> debuff(m, w, p);
            default -> { return false; }
        }
        return true;
    }

    // ---------- loai 1: vat the bay ----------
    static void proj(M m, ServerWorld w, ServerPlayerEntity p) {
        Vec3d eye = p.getEyePos(), look = p.getRotationVec(1f).normalize();
        Vec3d[] b = Fx.basis(look);
        int n = Math.max(1, m.n);
        boolean small = n > 2;
        Fx.snd(w, eye, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 1.3f);
        for (int i = 0; i < n; i++) {
            double yo = n > 1 ? (i - (n - 1) / 2.0) * 0.12 : 0, po = n > 1 ? Fx.rnd(-0.06, 0.06) : 0;
            Vec3d dir0 = look.add(b[1].multiply(yo)).add(b[2].multiply(po)).normalize();
            final int idx = i;
            Vec3d start = eye.add(look.multiply(1.2)).add(b[1].multiply((i - (n - 1) / 2.0) * 0.15));
            int ttl = (int) (m.range / m.speed) + 20;
            Disp.Orb orb = (!small && Config.displays) ? new Disp.Orb(w, start, m.b1, m.b2, null, 0.9, ttl) : null;
            Disp.H cube = (small && Config.displays) ? Disp.block(w, start, m.b1, 0.28, 0.28, 0.28, Disp.Q.ID, ttl) : null;
            Anims.add(new Anims.Anim() {
                int t = 0; Vec3d pos = start, dir = dir0;
                public boolean tick() {
                    t++;
                    if (has(m, "home")) {
                        LivingEntity tg = Shiki.nearest(w, p, pos, 14);
                        if (tg != null) dir = dir.multiply(0.8).add(Fx.mid(tg).subtract(pos).normalize().multiply(0.2)).normalize();
                    }
                    pos = pos.add(dir.multiply(m.speed));
                    if (orb != null) orb.update(pos, t * 0.4, 1.0, t % 2 == 0);
                    if (cube != null) cube.move(pos);
                    Fx.put(w, Fx.dust(m.col, 1.1f), pos, 1, 0.05, 0);
                    boolean boom = !w.isAir(BlockPos.ofFloored(pos)) || t * m.speed > m.range || !Fx.hostiles(w, p, new Box(pos, pos).expand(1.1)).isEmpty();
                    if (!boom) return false;
                    if (orb != null) orb.kill();
                    if (cube != null) cube.kill();
                    explode(m, w, p, pos, (float) (m.dmg / n), m.rad);
                    return true;
                }
            });
        }
    }

    static void explode(M m, ServerWorld w, ServerPlayerEntity p, Vec3d pos, float dmg, double rad) {
        if (Config.displays) {
            Vis3D.pulseGrow(w, pos, m.b1, 0.4, Math.max(1.2, rad * 2), 8);
            Vis3D.pulseGrow(w, pos, m.b2, 0.2, Math.max(0.6, rad * 0.9), 8);
        }
        Fx.sphere(w, Fx.dust(m.col, 1.5f), pos, Math.max(0.8, rad * 0.8), 36, 0);
        Fx.snd(w, pos, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 0.7f, 1.4f);
        for (LivingEntity e : Fx.hostiles(w, p, new Box(pos, pos).expand(rad + 1))) {
            if (e.getEntityPos().distanceTo(pos) > rad + 1.2) continue;
            hit(w, p, m, e, dmg);
            knock(e, pos, 0.5);
        }
    }

    // ---------- loai 2: tia ----------
    static void beam(M m, ServerWorld w, ServerPlayerEntity p) {
        Vec3d eye = p.getEyePos().add(0, -0.2, 0), look = p.getRotationVec(1f).normalize();
        Vec3d end = eye.add(look.multiply(m.range));
        for (double d = 1.5; d <= m.range; d += 0.5) {
            Vec3d v = eye.add(look.multiply(d));
            if (!w.isAir(BlockPos.ofFloored(v)) && !has(m, "pierce") && !m.id.equals("world_slash")) { end = v; break; }
        }
        Vec3d from = eye.add(look.multiply(1.0)), to = end;
        Fx.snd(w, eye, SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 0.9f, 1.4f);
        for (LivingEntity e : Fx.hostiles(w, p, new Box(from, to).expand(3))) {
            if (segDist(Fx.mid(e), from, to) > m.rad + 0.9) continue;
            hit(w, p, m, e, (float) m.dmg);
            Fx.put(w, ParticleTypes.EXPLOSION, Fx.mid(e), 1, 0, 0);
        }
        Fx.line(w, Fx.dust(m.col, 1.6f), from, to, 0.4);
        if (Config.displays) {
            Disp.Beam bm = new Disp.Beam(w, from, to, m.b1, m.b2, m.rad * 2.0, 12);
            Vis3D.pulseGrow(w, from, m.b1, 0.3, m.rad * 3.5, 8);
            Vis3D.pulseGrow(w, to, m.b1, 0.3, m.rad * 4.0, 8);
            Anims.add(new Anims.Anim() {
                int t = 0;
                public boolean tick() {
                    t++;
                    bm.update(from, to, m.rad * 2.0 * Math.max(0.05, 1 - t / 9.0));
                    if (t >= 9) { bm.kill(); return true; }
                    return false;
                }
            });
        }
    }

    // ---------- loai 3: vet chem ----------
    static void slash(M m, ServerWorld w, ServerPlayerEntity p) {
        Vec3d eye = p.getEyePos(), look = p.getRotationVec(1f).normalize();
        Vec3d[] b = Fx.basis(look);
        int n = Math.max(1, m.n);
        for (int k = 0; k < n; k++) {
            final int kk = k;
            Vis3D.later(k * 2 + 1, () -> {
                double tilt = n == 1 ? 0 : -1.1 + 2.2 * kk / (n - 1.0);
                Vec3d u = b[1].multiply(Math.cos(tilt)).add(b[2].multiply(Math.sin(tilt))).normalize();
                Vec3d c = eye.add(look.multiply(m.range * 0.55));
                if (Config.displays) {
                    new Disp.Crescent(w, c, u, look, m.rad, 0.5, 0.3, m.b2, 8, 5);
                    new Disp.Crescent(w, c, u, look, m.rad * 1.1, 0.55, 0.85, m.b1, 8, 7);
                }
                Fx.arc(w, Fx.dust(m.col, 1.5f), c, u, b[1].crossProduct(u).lengthSquared() > 1e-4 ? b[1].crossProduct(u).normalize() : b[2], m.rad, -1.2, 1.2, 28);
                Fx.snd(w, c, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 0.9f + (float) Fx.rnd(0, 0.5));
                for (LivingEntity e : Fx.hostiles(w, p, new Box(eye, eye.add(look.multiply(m.range))).expand(m.rad))) {
                    Vec3d rel = Fx.mid(e).subtract(eye);
                    double along = rel.dotProduct(look);
                    if (along < 0.3 || along > m.range + 1 || rel.subtract(look.multiply(along)).length() > m.rad + 0.7) continue;
                    hit(w, p, m, e, (float) (m.dmg / n));
                }
            });
        }
    }

    // ---------- loai 4: song xung kich quanh nguoi ----------
    static void nova(M m, ServerWorld w, ServerPlayerEntity p) {
        Vec3d feet = p.getEntityPos(), c = feet.add(0, 1, 0);
        if (Config.displays) {
            Vis3D.pulseGrow(w, c, m.b1, 0.5, m.rad * 2, 8);
            Vis3D.pulseGrow(w, c, m.b2, 0.3, m.rad * 0.9, 8);
            Vis3D.plate(w, feet.add(0, 0.1, 0), new Vec3d(0, 1, 0), m.b1, 1.0, m.rad * 2.2, 8);
        }
        Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
        for (int i = 1; i <= 3; i++) Fx.ring(w, Fx.dust(m.col, 1.6f), feet.add(0, 0.2 * i, 0), b[1], b[2], m.rad * i / 3.0, 40 + i * 12, 0);
        Fx.snd(w, c, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 1.0f, 0.9f);
        Fx.snd(w, c, SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 0.6f, 1.2f);
        for (LivingEntity e : Fx.hostiles(w, p, p.getBoundingBox().expand(m.rad))) {
            if (e.getEntityPos().distanceTo(feet) > m.rad) continue;
            hit(w, p, m, e, (float) m.dmg);
            knock(e, feet, m.speed);
        }
    }

    // ---------- loai 5: lao / dich chuyen ----------
    static void dash(M m, ServerWorld w, ServerPlayerEntity p) {
        Vec3d start = p.getEntityPos(), look = p.getRotationVec(1f);
        Vec3d dir = new Vec3d(look.x, 0, look.z);
        if (dir.lengthSquared() < 1e-4) return;
        dir = dir.normalize();
        Vec3d end = start;
        for (double d = 1; d <= m.range; d += 1) {
            Vec3d v = start.add(dir.multiply(d));
            if (!w.isAir(BlockPos.ofFloored(v.add(0, 0.5, 0))) || !w.isAir(BlockPos.ofFloored(v.add(0, 1.5, 0)))) break;
            end = v;
        }
        if (m.dmg > 0) for (LivingEntity e : Fx.hostiles(w, p, new Box(start, end).expand(1.6, 1.5, 1.6))) {
            hit(w, p, m, e, (float) m.dmg);
            Fx.put(w, ParticleTypes.EXPLOSION, Fx.mid(e), 1, 0, 0);
            knock(e, start, 0.8);
        }
        if (Config.displays) {
            new Disp.Beam(w, start.add(0, 1, 0), end.add(0, 1, 0), m.b1, m.b2, 0.9, 10);
            Vis3D.pulseShrink(w, start.add(0, 1, 0), m.b1, 2.4, 10);
            Vis3D.pulseGrow(w, end.add(0, 1, 0), m.b1, 0.4, 2.6, 8);
        }
        Fx.line(w, Fx.dust(m.col, 1.6f), start.add(0, 1, 0), end.add(0, 1, 0), 0.3);
        p.requestTeleport(end.x, end.y, end.z);
        Fx.snd(w, start, SoundEvents.ENTITY_ENDERMAN_TELEPORT, 0.8f, 1.5f);
    }

    // ---------- loai 6: cot gianh tu tren troi ----------
    static void strike(M m, ServerWorld w, ServerPlayerEntity p) {
        LivingEntity t = Stage2Skills.aim(w, p, m.range);
        Vec3d base = t != null ? t.getEntityPos() : Stage2Skills.rayEnd(w, p, m.range);
        int n = Math.max(1, m.n);
        double wide = Math.max(0.9, m.rad * 0.5);
        for (int i = 0; i < n; i++) {
            Vec3d pt = i == 0 ? base : base.add(Fx.rnd(-m.rad * 1.6, m.rad * 1.6), 0, Fx.rnd(-m.rad * 1.6, m.rad * 1.6));
            final Vec3d pp = pt;
            Vis3D.later(i * 3 + 1, () -> {
                Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
                Fx.ring(w, Fx.dust(m.col, 1.4f), pp.add(0, 0.2, 0), b[1], b[2], m.rad, 36, 0);
            });
            Vis3D.later(i * 3 + 10, () -> {
                if (Config.displays) {
                    Disp.block(w, pp.add(0, 9, 0), m.b1, wide, 18, wide, Disp.Q.ID, 6);
                    Disp.block(w, pp.add(0, 9, 0), m.b2, wide * 0.5, 18, wide * 0.5, Disp.Q.ID, 6);
                }
                for (double y = 0; y < 18; y += 1.2) Fx.pt(w, Fx.dust(m.col, 1.5f), pp.add(Fx.rnd(-wide * 0.4, wide * 0.4), y, Fx.rnd(-wide * 0.4, wide * 0.4)));
                explode(m, w, p, pp.add(0, 0.5, 0), (float) m.dmg, m.rad);
                Fx.snd(w, pp, SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT, 0.9f, 1.2f);
            });
        }
    }

    // ---------- loai 7: tang suc / hao quang ----------
    static void buff(M m, ServerWorld w, ServerPlayerEntity p) {
        for (String tok : m.fx.split(",")) {
            String[] a = tok.trim().split(":");
            RegistryEntry<StatusEffect> ef = EFF.get(a[0]);
            if (ef == null) continue;
            try { p.addStatusEffect(new StatusEffectInstance(ef, Integer.parseInt(a[1]), a.length > 2 ? Integer.parseInt(a[2]) : 0)); } catch (RuntimeException ignored) { }
        }
        Vec3d mid = p.getEntityPos().add(0, 1, 0);
        if (Config.displays) {
            Vis3D.pulseShrink(w, mid, m.b1, 4.0, 12);
            Vis3D.follow(w, p, 300, 6, m.b1, 0.28, 1.9, 1.1, 0.12, 0);
        }
        Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
        for (int i = 0; i < 6; i++) Fx.ring(w, Fx.dust(m.col, 1.4f), p.getEntityPos().add(0, i * 0.35, 0), b[1], b[2], 1.2 - i * 0.1, 30, i);
        Fx.snd(w, mid, SoundEvents.BLOCK_BEACON_ACTIVATE, 1.0f, 1.3f);
    }

    // ---------- loai 8: cau hut ----------
    static void pull(M m, ServerWorld w, ServerPlayerEntity p) {
        LivingEntity t = Stage2Skills.aim(w, p, m.range);
        Vec3d c = t != null ? Fx.mid(t) : Stage2Skills.rayEnd(w, p, m.range).add(0, 1, 0);
        int dur = Math.max(20, m.n);
        Disp.Orb orb = Config.displays ? new Disp.Orb(w, c, m.b1, m.b2, null, Math.max(1.6, m.rad * 0.18), dur + 10) : null;
        Fx.snd(w, c, SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 0.8f, 0.6f);
        Anims.add(new Anims.Anim() {
            int t2 = 0;
            public boolean tick() {
                t2++;
                if (p.isRemoved() || t2 > dur) {
                    if (orb != null) orb.kill();
                    explode(m, w, p, c, (float) (m.dmg * 0.5), m.rad * 0.4);
                    return true;
                }
                if (orb != null) orb.update(c, t2 * 0.35, 1.0 + 0.2 * Math.sin(t2 * 0.5), t2 % 2 == 0);
                Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
                Fx.ring(w, Fx.dust(m.col, 1.2f), c, b[1], b[2], m.rad * (1 - (t2 % 20) / 20.0), 36, t2 * 0.3);
                for (LivingEntity e : Fx.hostiles(w, p, new Box(c, c).expand(m.rad))) {
                    Vec3d to = c.subtract(Fx.mid(e));
                    if (to.length() > m.rad || to.length() < 0.6) continue;
                    Vec3d v = to.normalize().multiply(0.22);
                    e.addVelocity(v.x, v.y * 0.5, v.z);
                    if (t2 % 8 == 0) hit(w, p, m, e, (float) (m.dmg * 0.5 / (dur / 8.0)));
                }
                return false;
            }
        });
    }

    // ---------- loai 9: dam lien hoan ----------
    static void multi(M m, ServerWorld w, ServerPlayerEntity p) {
        int n = Math.max(1, m.n), gap = Math.max(1, (int) m.speed);
        for (int k = 0; k < n; k++) {
            Vis3D.later(k * gap + 1, () -> {
                if (p.isRemoved() || !p.isAlive()) return;
                Vec3d eye = p.getEyePos(), look = p.getRotationVec(1f).normalize();
                Vec3d[] b = Fx.basis(look);
                Vec3d at = eye.add(look.multiply(2.0));
                for (LivingEntity e : Fx.hostiles(w, p, new Box(at, at).expand(m.rad))) {
                    hit(w, p, m, e, (float) (m.dmg / n));
                    Fx.put(w, ParticleTypes.CRIT, Fx.mid(e), 6, 0.4, 0.2);
                    knock(e, p.getEntityPos(), 0.25);
                }
                Vec3d off = at.add(b[1].multiply(Fx.rnd(-0.7, 0.7))).add(b[2].multiply(Fx.rnd(-0.5, 0.7)));
                Vis3D.panel(w, off, look, k_blk(m, off), 2.4, 6);
                Fx.ring(w, Fx.dust(m.col, 1.4f), at, b[1], b[2], 1.0, 24, 0);
                Fx.snd(w, at, SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, 1f, 0.9f + (float) Fx.rnd(0, 0.5));
            });
        }
    }

    static String k_blk(M m, Vec3d v) { return ((int) (v.x * 7 + v.z * 3) & 1) == 0 ? m.b1 : m.b2; }

    // ---------- loai 10: xich ----------
    static void chain(M m, ServerWorld w, ServerPlayerEntity p) {
        LivingEntity t = Stage2Skills.aim(w, p, m.range);
        Vec3d from = p.getEyePos().add(0, -0.3, 0);
        if (t == null) {
            Vec3d end = Stage2Skills.rayEnd(w, p, m.range);
            if (Config.displays) new Disp.Beam(w, from, end, m.b1, m.b2, 0.12, 8);
            Fx.line(w, Fx.dust(m.col, 1.2f), from, end, 0.4);
            return;
        }
        Vec3d to = Fx.mid(t);
        Disp.Beam bm = Config.displays ? new Disp.Beam(w, from, to, m.b1, m.b2, 0.14, 24) : null;
        hit(w, p, m, t, (float) m.dmg);
        Fx.snd(w, to, SoundEvents.BLOCK_CHAIN_HIT, 1.2f, 0.8f);
        Anims.add(new Anims.Anim() {
            int n = 0;
            public boolean tick() {
                n++;
                Vec3d f = p.getEyePos().add(0, -0.3, 0), tm = Fx.mid(t);
                if (bm != null) bm.update(f, tm, 0.14);
                Fx.line(w, Fx.dust(m.col, 1.0f), f, tm, 0.7);
                Vec3d pullv = f.subtract(tm);
                if (n <= 8 && pullv.length() > 2) { Vec3d v = pullv.normalize().multiply(0.5); t.addVelocity(v.x, 0.05, v.z); }
                if (n >= 14 || !t.isAlive()) { if (bm != null) bm.kill(); return true; }
                return false;
            }
        });
    }

    // ---------- loai 11: bua / lam yeu ----------
    static void debuff(M m, ServerWorld w, ServerPlayerEntity p) {
        List<LivingEntity> targets = new ArrayList<>();
        if (m.rad > 0) {
            for (LivingEntity e : Fx.hostiles(w, p, p.getBoundingBox().expand(m.rad))) if (e.getEntityPos().distanceTo(p.getEntityPos()) <= m.rad) targets.add(e);
            Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
            Fx.ring(w, Fx.dust(m.col, 1.6f), p.getEntityPos().add(0, 0.3, 0), b[1], b[2], m.rad, 90, 0);
            if (Config.displays) {
                Vis3D.plate(w, p.getEntityPos().add(0, 0.2, 0), new Vec3d(0, 1, 0), m.b1, 1.0, m.rad * 2, 10);
                Vis3D.pulseGrow(w, p.getEntityPos().add(0, 1, 0), m.b2, 0.4, 3.0, 8);
            }
        } else {
            LivingEntity t = Stage2Skills.aim(w, p, m.range);
            if (t != null) targets.add(t);
        }
        for (LivingEntity e : targets) {
            Vec3d mid = Fx.mid(e);
            hit(w, p, m, e, (float) m.dmg);
            if (Config.displays) {
                Vis3D.pulseShrink(w, mid, m.b1, 3.2, 14);
                Disp.Orb o = new Disp.Orb(w, mid, m.b1, m.b2, null, 1.3, 40);
                Anims.add(new Anims.Anim() {
                    int n = 0;
                    public boolean tick() {
                        n++;
                        if (n > 30 || !e.isAlive()) { o.kill(); return true; }
                        o.update(Fx.mid(e), n * 0.3, 1.0, n % 2 == 0);
                        return false;
                    }
                });
            }
            for (int i = 0; i < 5; i++) Fx.line(w, Fx.dust(m.col, 1.0f), mid.add(Fx.randDir().multiply(3)), mid, 0.4);
        }
        Fx.snd(w, p.getEntityPos(), SoundEvents.ENTITY_EVOKER_CAST_SPELL, 1f, 1.1f);
    }

    // ---- Dot 5: them nhieu ky nang cho tat ca nhan vat ----
    static {
        Tech.Chara G = Tech.Chara.GOJO, S = Tech.Chara.SUKUNA, Y = Tech.Chara.YUJI, ME = Tech.Chara.MEGUMI, TO = Tech.Chara.TODO,
                NA = Tech.Chara.NANAMI, NO = Tech.Chara.NOBARA, CH = Tech.Chara.CHOSO, JO = Tech.Chara.JOGO, MA = Tech.Chara.MAHITO,
                IN = Tech.Chara.INUMAKI, YU = Tech.Chara.YUTA, TJ = Tech.Chara.TOJI, HK = Tech.Chara.HAKARI, HG = Tech.Chara.HIGURUMA,
                KS = Tech.Chara.KASHIMO, MK = Tech.Chara.MAKI, KJ = Tech.Chara.KENJAKU;
        def("hollow_purple_lite", "beam", "Hollow Purple: Flicker", "茈・瞬", "茈", 70, 300, 34, "purple_stained_glass", "purple_concrete", 0xA050FF, 26, 1.4, 1, 0, "", "Phat Tim thu nho: tia tim dai 26 o (34 st).", G);
        def("limitless_barrier", "buff", "Infinity: Barrier Aura", "無下限・結界", "結", 60, 500, 0, "white_stained_glass", "light_blue_concrete", 0x9FE8FF, 0, 0, 1, 0, "res:200:3,speed:200:1,regen:60:1", "10 giay: Resistance IV, Speed II, hoi mau; ao quang vo han.", G);
        def("azure_chain", "chain", "Blue: Chain Pull", "蒼・連", "連", 40, 160, 14, "light_blue_stained_glass", "blue_concrete", 0x3090FF, 20, 0, 1, 0, "slow:40:2", "Hut muc tieu ve phia ban bang luc hut cua Blue (14 st).", G);
        def("cleave_barrage", "slash", "Cleave: Barrage", "捌・連", "連", 70, 260, 36, "red_stained_glass", "white_concrete", 0xFF2020, 8, 4, 6, 0, "", "6 nhat Cleave lien tiep truoc mat (36 st).", S);
        def("dismantle_storm", "nova", "Dismantle: Storm", "解・嵐", "嵐", 90, 420, 28, "red_stained_glass", "white_concrete", 0xFF2020, 0, 10, 1, 1.2, "", "Bao luoi chem ban kinh 10 (28 st), hat tung moi quai.", S);
        def("hell_fire", "proj", "Fire Arrow: Hell Fire", "開", "開", 110, 450, 45, "orange_stained_glass", "magma_block", 0xFF6010, 36, 3, 1, 2.4, "fire:200", "Mui ten lua no ban kinh 3 (45 st, chay 10 giay).", S);
        def("blood_hunt", "dash", "King's Pounce", "王の跳躍", "跳", 35, 120, 22, "red_stained_glass", "red_concrete", 0xFF2020, 12, 0, 1, 0, "", "Lao toi 12 o chem moi quai tren duong (22 st).", S);
        def("tiger_claw", "slash", "Tiger Claw", "虎爪", "爪", 35, 110, 20, "orange_stained_glass", "white_concrete", 0xFF9A3A, 5, 3, 3, 0, "", "3 nhat vuot nhanh (20 st).", Y);
        def("soul_strike", "multi", "Soul-Piercing Strike", "魂撃", "魂", 60, 220, 34, "orange_stained_glass", "red_concrete", 0xE02020, 3, 2.4, 4, 2, "weak:60:1", "4 cu dam xuyen hon (34 st).", Y);
        def("yuji_rush", "dash", "Rush Step", "突進", "走", 30, 100, 16, "orange_stained_glass", "yellow_concrete", 0xFF9A3A, 10, 0, 1, 0, "", "Lao toi 10 o, dam moi quai tren duong (16 st).", Y);
        def("cursed_uppercut", "strike", "Uppercut Shockwave", "昇拳", "昇", 50, 180, 24, "orange_stained_glass", "white_concrete", 0xFF9A3A, 8, 2.6, 3, 0, "", "3 song xung kich hat tung truoc mat (24 st).", Y);
        def("sukuna_vessel", "buff", "Vessel Awakening", "器", "器", 90, 700, 0, "red_stained_glass", "red_concrete", 0xFF2020, 0, 0, 1, 0, "str:300:2,speed:300:1,res:300:1", "15 giay: Strength III, Speed II, Resistance II (thuc tinh sac do).", Y);
        def("black_flash_chain", "multi", "Black Flash: Chain", "黒閃・連鎖", "鎖", 85, 420, 50, "black_stained_glass", "red_concrete", 0xE02020, 3, 2.4, 8, 1, "", "8 cu Black Flash lien tiep (50 st tong).", Y);
        def("punch_wave", "beam", "Punch Shockwave", "衝撃波", "衝", 40, 140, 22, "orange_stained_glass", "white_concrete", 0xFF9A3A, 16, 0.8, 1, 0, "", "Song xung kich cu dam dai 16 o (22 st).", Y);
        def("regen_rush", "buff", "Cursed Reinforce Burst", "強化爆発", "強", 50, 300, 0, "orange_stained_glass", "yellow_concrete", 0xFF9A3A, 0, 0, 1, 0, "speed:200:2,haste:200:2,regen:100:1", "10 giay: Speed III, Haste III, hoi mau.", Y);
        def("todo_uppercut", "strike", "Todo Uppercut", "アッパー", "昇", 50, 180, 26, "white_stained_glass", "white_concrete", 0xC09060, 5, 2.6, 3, 0, "slow:30:1", "3 cu dam len tung dot (26 st).", TO);
        def("clap_trap", "nova", "Clap Trap", "柏手・罠", "罠", 45, 200, 16, "cyan_stained_glass", "cyan_concrete", 0xC09060, 0, 8, 1, 0.8, "slow:60:2", "Song vo tay lam cham moi quai ban kinh 8 (16 st).", TO);
        def("bare_knuckle", "multi", "Bare Knuckle Combo", "拳連打", "拳", 55, 200, 36, "white_stained_glass", "white_concrete", 0xC09060, 3, 2.4, 6, 2, "", "6 cu dam lien tiep (36 st).", TO);
        def("charge_slam", "dash", "Bull Charge", "猛進", "猛", 35, 120, 24, "brown_stained_glass", "white_concrete", 0xC09060, 12, 0, 1, 0, "", "Lao toi 12 o hat tung moi quai (24 st).", TO);
        def("bf_stomp", "nova", "Stomp: Black Flash", "踏み黒閃", "踏", 75, 300, 30, "black_stained_glass", "red_concrete", 0xE02020, 0, 7, 1, 1.5, "", "Giam dat Black Flash ban kinh 7 (30 st).", TO);
        def("swap_decoy", "dash", "Boogie Woogie: Evade", "不義遊戯・回避", "替", 30, 100, 0, "white_stained_glass", "light_blue_concrete", 0xC09060, 10, 0, 1, 0, "speed:60:2", "Doi cho tranh don ve phia truoc 10 o + Speed III.", TO);
        def("vibe_surge", "buff", "Brotherhood", "親友", "友", 60, 500, 0, "orange_stained_glass", "white_concrete", 0xC09060, 0, 0, 1, 0, "str:300:1,speed:300:1,res:200:1", "15 giay: Strength II, Speed II, Resistance II.", TO);
        def("clap_barrage", "multi", "Clap Barrage", "柏手連打", "連", 65, 260, 34, "white_stained_glass", "cyan_concrete", 0xC09060, 2, 3, 6, 2, "slow:40:1", "6 tieng vo tay lien tiep (34 st).", TO);
        def("boulder_throw", "proj", "Boulder Throw", "岩投げ", "岩", 45, 160, 30, "gray_stained_glass", "stone", 0xA0A0A0, 24, 2.5, 1, 1.6, "", "Nem tang da no ban kinh 2.5 (30 st).", TO);
        def("pillar_fist", "strike", "Earthshaker Fist", "地割れ", "割", 70, 300, 28, "brown_stained_glass", "white_concrete", 0xC09060, 10, 3, 4, 0, "slow:30:2", "4 vet nut dat quanh diem ngam (28 st).", TO);
        def("overtime_slash", "slash", "Overtime Slash", "残業斬り", "残", 55, 200, 36, "yellow_stained_glass", "gold_block", 0xE0C060, 6, 3.5, 4, 0, "", "4 nhat chem 7:3 (36 st).", NA);
        def("ratio_dash", "dash", "Weak Point Rush", "弱点突進", "弱", 30, 100, 20, "yellow_stained_glass", "white_concrete", 0xE0C060, 10, 0, 1, 0, "", "Lao toi 10 o chem trung diem yeu (20 st).", NA);
        def("collapse_wide", "strike", "Collapse: Wide", "瓦落瓦落・広", "広", 85, 360, 28, "yellow_stained_glass", "gold_block", 0xE0C060, 14, 3, 5, 0, "slow:40:2", "5 cot sang bang xuong (28 st moi cot).", NA);
        def("ratio_slash_wave", "beam", "Ratio Wave", "十劃波", "波", 50, 160, 24, "yellow_stained_glass", "white_concrete", 0xE0C060, 18, 0.8, 1, 0, "", "Song chem dai 18 o (24 st).", NA);
        def("blade_whirl", "nova", "Blade Whirl", "旋回斬", "旋", 60, 240, 22, "yellow_stained_glass", "gold_block", 0xE0C060, 0, 6, 1, 1.0, "", "Xoay chem ban kinh 6 (22 st).", NA);
        def("overtime_mode", "buff", "Overtime Mode", "超過勤務", "超", 70, 600, 0, "yellow_stained_glass", "gold_block", 0xE0C060, 0, 0, 1, 0, "str:300:2,speed:300:1,haste:300:1", "15 giay: Strength III, Speed II, Haste II.", NA);
        def("sevenths_barrage", "multi", "Seven-Three Combo", "七三連", "七", 60, 220, 40, "yellow_stained_glass", "white_concrete", 0xE0C060, 3, 2.6, 7, 2, "", "7 don lien tiep (40 st tong).", NA);
        def("tie_bind", "chain", "Necktie Bind", "ネクタイ", "結", 35, 140, 10, "yellow_stained_glass", "iron_block", 0xE0C060, 14, 0, 1, 0, "slow:60:3", "Troi muc tieu bang caravat (10 st).", NA);
        def("ratio_thrust", "proj", "Cleaver Thrust", "突き", "突", 40, 120, 26, "yellow_stained_glass", "iron_block", 0xE0C060, 20, 1.5, 1, 2.4, "", "Phi dao nhanh xuyen (26 st).", NA);
        def("hairpin_rain", "strike", "Hairpin Rain", "簪・雨", "雨", 70, 260, 16, "pink_stained_glass", "iron_block", 0xD07080, 20, 3, 6, 0, "", "6 cay dinh no roi xuong quanh diem ngam (16 st).", NO);
        def("resonance_chain", "chain", "Resonance: Chain", "共鳴り・連鎖", "連", 45, 160, 14, "pink_stained_glass", "iron_block", 0xD07080, 18, 0, 1, 0, "weak:60:1", "Dinh keo muc tieu ve phia ban roi no (14 st).", NO);
        def("nail_storm", "proj", "Nail Storm", "釘嵐", "嵐", 60, 220, 36, "gray_stained_glass", "iron_block", 0xD07080, 22, 1.2, 14, 2.4, "", "Ban 14 mui dinh hinh quat rong (3 st moi mui).", NO);
        def("hammer_smash", "strike", "Hammer Smash", "金槌", "槌", 40, 140, 24, "gray_stained_glass", "iron_block", 0xD07080, 8, 2.5, 2, 0, "", "2 cu dap bua (24 st).", NO);
        def("black_flash_nail", "proj", "Black Flash Nail", "黒閃・釘", "黒", 85, 380, 50, "black_stained_glass", "red_concrete", 0xE02020, 28, 2, 1, 2.8, "", "Dinh Black Flash xuyen (50 st).", NO);
        def("doll_curse", "debuff", "Straw Doll: Curse", "呪い人形・怨", "怨", 60, 260, 28, "hay_block", "iron_block", 0xD07080, 14, 6, 1, 0, "wither:140:1,weak:100:1,slow:80:1", "Nguyen toan vung 6 o: Wither + Weakness (28 st).", NO);
        def("nobara_barrage", "multi", "Hammer Combo", "連打", "連", 50, 200, 32, "gray_stained_glass", "iron_block", 0xD07080, 3, 2.6, 5, 2, "", "5 cu dap lien tiep (32 st).", NO);
        def("resonance_spiral", "nova", "Resonance: Spiral", "共鳴り・渦", "渦", 75, 320, 26, "pink_stained_glass", "red_concrete", 0xD07080, 0, 8, 1, 1.0, "slow:50:1", "Song cong huong ban kinh 8 (26 st).", NO);
        def("crimson_nails", "buff", "Crimson Resolve", "覚悟", "覚", 50, 400, 0, "pink_stained_glass", "red_concrete", 0xD07080, 0, 0, 1, 0, "speed:200:1,res:200:1,regen:100:1", "10 giay: Speed II, Resistance II, hoi mau.", NO);
        def("piercing_blood_max", "beam", "Piercing Blood: Max", "穿血・最大", "穿", 80, 300, 40, "red_stained_glass", "redstone_block", 0xB01830, 34, 0.6, 1, 0, "", "Tia mau xuyen 34 o (40 st).", CH);
        def("blood_orb", "pull", "Blood Orb", "血球", "球", 60, 260, 22, "red_stained_glass", "redstone_block", 0xB01830, 16, 8, 40, 0, "slow:30:2", "Cau mau hut muc tieu ban kinh 8 (22 st).", CH);
        def("blood_sword", "slash", "Blood Sword", "血剣", "剣", 45, 140, 26, "red_stained_glass", "redstone_block", 0xB01830, 5, 3, 3, 0, "", "3 nhat kiem mau (26 st).", CH);
        def("blood_arrow", "proj", "Blood Arrow Volley", "血矢", "矢", 55, 200, 36, "red_stained_glass", "redstone_block", 0xB01830, 26, 1.5, 8, 2.4, "", "8 mui ten mau ban cung luc (36 st).", CH);
        def("blood_wall", "buff", "Blood Shield", "血盾", "盾", 50, 400, 0, "red_stained_glass", "redstone_block", 0xB01830, 0, 0, 1, 0, "res:200:3,regen:100:1", "10 giay: Resistance IV, hoi mau.", CH);
        def("supernova_burst", "nova", "Supernova Burst", "苅祓", "苅", 90, 420, 34, "red_stained_glass", "redstone_block", 0xB01830, 0, 10, 1, 1.5, "", "No mau ban kinh 10 (34 st).", CH);
        def("blood_rush", "dash", "Blood Rush", "血走", "走", 30, 100, 18, "red_stained_glass", "red_concrete", 0xB01830, 12, 0, 1, 0, "", "Lao toi 12 o (18 st).", CH);
        def("convergence_orb", "beam", "Convergence", "百斂", "斂", 70, 260, 38, "red_stained_glass", "redstone_block", 0xB01830, 30, 0.8, 1, 0, "", "Tia mau tu thu hep xuyen 30 o (38 st).", CH);
        def("poison_blood", "debuff", "Poison Blood", "毒血", "毒", 40, 200, 18, "red_stained_glass", "redstone_block", 0xB01830, 14, 5, 1, 0, "poison:160:1,slow:80:1", "Mau doc: Poison II + Slowness (18 st).", CH);
        def("meteor_barrage", "strike", "Meteor Barrage", "極ノ番・連", "隕", 100, 450, 26, "orange_stained_glass", "magma_block", 0xFF6A20, 24, 4, 6, 0, "fire:100", "6 thien thach rot (26 st moi vien, chay).", JO);
        def("lava_wave", "slash", "Lava Wave", "溶岩波", "溶", 50, 180, 26, "orange_stained_glass", "magma_block", 0xFF6A20, 8, 4, 5, 0, "fire:80", "5 song dung nham (26 st).", JO);
        def("fire_breath", "beam", "Volcanic Breath", "火炎放射", "炎", 55, 200, 30, "orange_stained_glass", "orange_concrete", 0xFF6A20, 14, 2, 1, 0, "fire:160", "Phun lua dai 14 o (30 st).", JO);
        def("magma_fist", "multi", "Magma Fist", "溶岩拳", "拳", 50, 180, 32, "orange_stained_glass", "magma_block", 0xFF6A20, 3, 2.6, 4, 2, "fire:60", "4 cu dam dung nham (32 st).", JO);
        def("hell_wall", "buff", "Magma Armor", "溶岩甲", "甲", 60, 500, 0, "orange_stained_glass", "magma_block", 0xFF6A20, 0, 0, 1, 0, "res:300:2,str:300:1,speed:200:0", "15 giay: Resistance III, Strength II.", JO);
        def("ash_cloud", "debuff", "Ash Cloud", "灰", "灰", 40, 200, 10, "gray_stained_glass", "gray_concrete", 0x888888, 14, 7, 1, 0, "blind:100:0,slow:100:1,wither:60:0", "May tro: Blindness + Slowness vung 7 o (10 st).", JO);
        def("fire_dash", "dash", "Flame Dash", "炎走", "走", 30, 100, 18, "orange_stained_glass", "orange_concrete", 0xFF6A20, 12, 0, 1, 0, "fire:80", "Lao toi 12 o de lai vet lua (18 st).", JO);
        def("volcano_pillar", "strike", "Volcano Pillars", "噴火柱", "柱", 80, 320, 22, "orange_stained_glass", "magma_block", 0xFF6A20, 22, 3, 7, 0, "fire:100", "7 cot lua phun len (22 st moi cot).", JO);
        def("body_repel", "nova", "Body Repel", "改造・反発", "反", 55, 220, 22, "magenta_stained_glass", "magenta_concrete", 0x8A5AC0, 0, 7, 1, 1.3, "nausea:80:0", "Day lui ban kinh 7 (22 st).", MA);
        def("transfigured_horde", "proj", "Transfigured Horde", "無為転変・群", "群", 65, 240, 34, "magenta_stained_glass", "pink_concrete", 0xE0708A, 22, 1.5, 8, 1.6, "weak:60:1", "8 con quai thit lao ve phia truoc (34 st).", MA);
        def("flesh_whip", "chain", "Flesh Whip", "肉鞭", "鞭", 35, 140, 16, "pink_stained_glass", "pink_concrete", 0xE0708A, 16, 0, 1, 0, "slow:40:1", "Quat roi thit keo muc tieu (16 st).", MA);
        def("soul_shatter", "debuff", "Soul Shatter", "魂砕", "砕", 70, 300, 30, "magenta_stained_glass", "magenta_concrete", 0x8A5AC0, 14, 6, 1, 0, "nausea:140:0,weak:140:2,wither:80:1", "Pha vo hon: Nausea + Weakness + Wither (30 st).", MA);
        def("remodel_arm", "slash", "Arm Cannon", "改造腕", "腕", 50, 180, 30, "magenta_stained_glass", "purple_concrete", 0x8A5AC0, 6, 3, 4, 0, "", "4 nhat tay doi hinh (30 st).", MA);
        def("mahito_regrow", "buff", "Soul Regeneration", "魂再生", "再", 60, 500, 0, "magenta_stained_glass", "pink_concrete", 0xE0708A, 0, 0, 1, 0, "regen:200:3,res:200:1", "10 giay: Regeneration IV, Resistance II.", MA);
        def("flesh_spikes", "strike", "Flesh Spikes", "肉棘", "棘", 60, 240, 22, "pink_stained_glass", "pink_concrete", 0xE0708A, 14, 3, 6, 0, "", "6 gai thit tu duoi dat (22 st).", MA);
        def("mahito_dash", "dash", "Shape Shift Dash", "変身走", "変", 30, 100, 18, "magenta_stained_glass", "magenta_concrete", 0x8A5AC0, 12, 0, 1, 0, "", "Bien hinh lao toi 12 o (18 st).", MA);
        def("speech_freeze", "debuff", "Cursed Speech: Don't Move", "動くな", "止", 45, 220, 0, "white_stained_glass", "light_blue_concrete", 0xE8E8F0, 14, 12, 1, 0, "slow:100:6,weak:100:1", "Moi quai 12 o dung hinh 5 giay.", IN);
        def("speech_detonate", "nova", "Cursed Speech: Explode", "爆ぜろ", "爆", 75, 320, 32, "white_stained_glass", "white_concrete", 0xE8E8F0, 0, 9, 1, 1.6, "", "Nguyen rua no ban kinh 9 (32 st).", IN);
        def("speech_twist", "beam", "Cursed Speech: Twist", "捻れろ", "捻", 60, 240, 30, "white_stained_glass", "gray_concrete", 0xE8E8F0, 18, 1, 1, 0, "nausea:80:0", "Tia chu luc xoan 18 o (30 st).", IN);
        def("speech_gale", "proj", "Cursed Speech: Blast Away", "吹っ飛べ", "吹", 50, 180, 26, "white_stained_glass", "light_blue_concrete", 0xE8E8F0, 20, 2, 1, 2.0, "", "Chu luc thoi bay (26 st).", IN);
        def("speech_sleep_wave", "debuff", "Cursed Speech: Sleep Wave", "眠れ・波", "眠", 55, 260, 0, "white_stained_glass", "light_blue_concrete", 0xE8E8F0, 10, 10, 1, 0, "slow:160:5,blind:100:0", "Lam cham manh moi quai (10 o).", IN);
        def("speech_run", "buff", "Cursed Speech: Run", "走れ", "走", 40, 300, 0, "white_stained_glass", "white_concrete", 0xE8E8F0, 0, 0, 1, 0, "speed:200:3,haste:200:1", "10 giay: Speed IV, Haste II.", IN);
        def("speech_crush_wide", "strike", "Cursed Speech: Crush Wide", "潰れろ・広", "潰", 85, 380, 26, "white_stained_glass", "gray_concrete", 0xE8E8F0, 14, 3, 5, 0, "slow:40:3", "5 vung bi ep nat (26 st).", IN);
        def("snake_eyes_barrage", "multi", "Snake Fang Barrage", "蛇牙連", "牙", 50, 200, 30, "white_stained_glass", "white_concrete", 0xE8E8F0, 3, 2.6, 5, 2, "", "5 don danh lien tiep (30 st).", IN);
        def("rika_slash", "beam", "Rika: Cursed Beam", "リカ・呪力砲", "砲", 80, 300, 45, "purple_stained_glass", "purple_concrete", 0x90B8FF, 26, 1.5, 1, 0, "", "Rika ban tia chu luc dai 26 o (45 st).", YU);
        def("rika_fist", "multi", "Rika: Fist Barrage", "リカ・連打", "拳", 70, 260, 40, "purple_stained_glass", "purple_concrete", 0x90B8FF, 3, 3.2, 5, 2, "", "Ban tay Rika dam lien tiep (40 st).", YU);
        def("rika_guard", "buff", "Rika: Guardian", "リカ・守護", "守", 60, 500, 0, "purple_stained_glass", "white_concrete", 0x90B8FF, 0, 0, 1, 0, "res:300:3,str:300:1,regen:100:1", "15 giay: Resistance IV, Strength II, hoi mau.", YU);
        def("yuta_rush", "dash", "Reinforced Rush", "瞬歩", "瞬", 30, 100, 20, "light_blue_stained_glass", "white_concrete", 0x90B8FF, 12, 0, 1, 0, "", "Lao toi 12 o chem trung moi quai (20 st).", YU);
        def("moon_slash", "slash", "Crescent Slash", "三日月斬", "月", 55, 200, 34, "light_blue_stained_glass", "white_concrete", 0x90B8FF, 8, 4, 5, 0, "", "5 nhat chem lieu (34 st).", YU);
        def("copy_burst", "nova", "Copy: Echo Burst", "模倣・残響", "響", 75, 320, 28, "light_blue_stained_glass", "light_blue_concrete", 0x90B8FF, 0, 9, 1, 1.4, "", "Song vang cua ky thuat sao chep ban kinh 9 (28 st).", YU);
        def("sword_rain", "strike", "Sword Rain", "剣雨", "剣", 85, 380, 24, "light_blue_stained_glass", "iron_block", 0x90B8FF, 22, 3, 7, 0, "", "7 thanh kiem roi (24 st moi thanh).", YU);
        def("cursed_speech_copy", "debuff", "Copied Speech: Halt", "模倣・止", "止", 50, 240, 0, "light_blue_stained_glass", "white_concrete", 0x90B8FF, 12, 10, 1, 0, "slow:120:6,weak:100:1", "Copy Chu thuat: dung hinh 6 giay.", YU);
        def("blue_copy", "pull", "Copied Blue", "模倣・蒼", "蒼", 75, 350, 22, "light_blue_stained_glass", "blue_concrete", 0x3090FF, 16, 9, 50, 0, "slow:30:2", "Copy Blue: hut moi thu (22 st).", YU);
        def("playful_cloud_barrage", "slash", "Cloud Barrage", "游雲連", "雲", 50, 180, 34, "green_stained_glass", "iron_block", 0x707070, 7, 4, 5, 0, "", "5 nhat chem vo khi (34 st).", TJ);
        def("toji_dash", "dash", "Heavenly Dash", "天与走", "走", 25, 80, 18, "green_stained_glass", "white_concrete", 0x707070, 14, 0, 1, 0, "", "Lao toi 14 o (18 st).", TJ);
        def("gun_barrage", "proj", "Pistol Volley", "銃連射", "銃", 40, 150, 28, "gray_stained_glass", "iron_block", 0x707070, 30, 0.8, 6, 3.0, "", "Ban 6 vien dan nhanh (28 st).", TJ);
        def("toji_assassinate", "strike", "Assassinate", "暗殺", "殺", 70, 260, 40, "black_stained_glass", "black_concrete", 0x707070, 10, 2.2, 1, 0, "weak:80:1", "Chem ket lieu mot muc tieu (40 st).", TJ);
        def("chain_swing", "nova", "Chain Swing", "鎖旋回", "旋", 50, 200, 22, "gray_stained_glass", "iron_block", 0x707070, 0, 7, 1, 1.0, "slow:40:1", "Quang xich quet ban kinh 7 (22 st).", TJ);
        def("toji_buff", "buff", "Zero Cursed Energy", "天与呪縛", "縛", 40, 400, 0, "green_stained_glass", "white_concrete", 0x707070, 0, 0, 1, 0, "speed:300:2,str:300:2,res:200:1", "15 giay: Speed III, Strength III.", TJ);
        def("sword_combo", "multi", "Split Soul Combo", "連撃", "連", 55, 200, 38, "gray_stained_glass", "iron_block", 0x707070, 3, 2.6, 6, 3, "", "6 don chem lien tiep (38 st).", TJ);
        def("knife_rain", "strike", "Knife Rain", "小刀雨", "雨", 60, 240, 16, "gray_stained_glass", "iron_block", 0x707070, 18, 3, 8, 0, "", "8 con dao rot (16 st).", TJ);
        def("slot_blast", "beam", "Jackpot Beam", "大当たり砲", "砲", 70, 260, 38, "pink_stained_glass", "pink_concrete", 0xFF40D0, 26, 1.4, 1, 0, "", "Tia chu luc dai 26 o (38 st).", HK);
        def("hakari_rush", "dash", "Rush Fever", "突進", "走", 30, 100, 22, "pink_stained_glass", "yellow_concrete", 0xFF40D0, 12, 0, 1, 0, "", "Lao toi 12 o (22 st).", HK);
        def("pachinko_balls", "proj", "Pachinko Balls", "パチンコ弾", "弾", 50, 180, 32, "yellow_stained_glass", "gold_block", 0xFFD040, 24, 1.5, 10, 2.2, "", "10 vien bi no (32 st).", HK);
        def("hakari_fist", "multi", "Fever Combo", "フィーバー連打", "連", 55, 200, 36, "pink_stained_glass", "white_concrete", 0xFF40D0, 3, 2.6, 6, 2, "", "6 cu dam lien tiep (36 st).", HK);
        def("lucky_buff", "buff", "Lucky Streak", "ラッキー", "運", 70, 600, 0, "yellow_stained_glass", "gold_block", 0xFFD040, 0, 0, 1, 0, "str:300:2,speed:300:2,res:300:2,regen:100:2", "15 giay: tang co ban (hieu ung gan Jackpot).", HK);
        def("reel_strike", "strike", "Reel Strike", "リール", "輪", 65, 260, 22, "yellow_stained_glass", "gold_block", 0xFFD040, 16, 3, 5, 0, "", "5 diem bi dap (22 st).", HK);
        def("roulette_nova", "nova", "Roulette Burst", "ルーレット", "輪", 80, 340, 30, "pink_stained_glass", "yellow_concrete", 0xFF40D0, 0, 9, 1, 1.4, "", "No ban kinh 9 (30 st).", HK);
        def("rct_gamble", "buff", "Gambler's Recovery", "反転・博打", "博", 60, 400, 0, "green_stained_glass", "emerald_block", 0x60FF9A, 0, 0, 1, 0, "regen:200:4,res:100:1", "10 giay: Regeneration V.", HK);
        def("gavel_slam", "nova", "Gavel Slam", "槌打ち", "槌", 55, 220, 26, "yellow_stained_glass", "gold_block", 0xE0C040, 0, 7, 1, 1.3, "slow:40:2", "Dap bua ban kinh 7 (26 st).", HG);
        def("sword_slash", "slash", "Executioner Slash", "処刑斬", "処", 60, 220, 36, "yellow_stained_glass", "white_concrete", 0xE0C040, 7, 3.5, 5, 0, "", "5 nhat guom hinh phat (36 st).", HG);
        def("law_barrage", "proj", "Statute Barrage", "法条連射", "法", 50, 180, 30, "yellow_stained_glass", "gold_block", 0xE0C040, 24, 1.4, 8, 2.2, "", "8 tam bien phan quyet (30 st).", HG);
        def("judgeman_bind", "debuff", "Judgeman: Restrain", "拘束", "拘", 50, 250, 0, "yellow_stained_glass", "gold_block", 0xE0C040, 14, 8, 1, 0, "slow:140:7,weak:100:2", "Troi bi cao 7 giay.", HG);
        def("verdict_beam", "beam", "Verdict Beam", "判決光線", "判", 70, 260, 40, "yellow_stained_glass", "gold_block", 0xE0C040, 28, 1.2, 1, 0, "", "Tia phan quyet dai 28 o (40 st).", HG);
        def("courtroom_buff", "buff", "Judge's Authority", "裁判官", "官", 60, 500, 0, "yellow_stained_glass", "gold_block", 0xE0C040, 0, 0, 1, 0, "res:300:2,str:200:1", "15 giay: Resistance III, Strength II.", HG);
        def("gavel_rain", "strike", "Gavel Rain", "槌雨", "雨", 75, 300, 22, "yellow_stained_glass", "gold_block", 0xE0C040, 20, 3, 6, 0, "slow:30:2", "6 cu bua rot (22 st).", HG);
        def("guilty_dash", "dash", "Guilty Charge", "有罪突進", "罪", 30, 100, 20, "yellow_stained_glass", "white_concrete", 0xE0C040, 12, 0, 1, 0, "", "Lao toi 12 o (20 st).", HG);
        def("kashimo_dash", "dash", "Lightning Dash", "雷走", "走", 30, 100, 22, "cyan_stained_glass", "white_concrete", 0x40C0FF, 16, 0, 1, 0, "", "Lao toi 16 o (22 st).", KS);
        def("plasma_bolt", "beam", "Plasma Bolt", "プラズマ", "電", 65, 240, 38, "cyan_stained_glass", "white_concrete", 0x40C0FF, 28, 0.8, 1, 0, "slow:30:2", "Tia set xuyen 28 o (38 st).", KS);
        def("thunder_nova", "nova", "Thunder Nova", "雷爆", "雷", 80, 340, 30, "cyan_stained_glass", "light_blue_concrete", 0x40C0FF, 0, 9, 1, 1.4, "slow:50:2", "No dien ban kinh 9 (30 st).", KS);
        def("lightning_fist", "multi", "Lightning Fist", "雷拳", "拳", 55, 200, 36, "cyan_stained_glass", "white_concrete", 0x40C0FF, 3, 2.6, 6, 2, "", "6 cu dam dien (36 st).", KS);
        def("storm_buff", "buff", "Storm Body", "雷身", "雷", 60, 500, 0, "cyan_stained_glass", "white_concrete", 0x40C0FF, 0, 0, 1, 0, "speed:300:3,haste:300:2,str:300:1", "15 giay: Speed IV, Haste III.", KS);
        def("chain_lightning", "chain", "Chain Lightning", "連鎖雷", "鎖", 45, 180, 18, "cyan_stained_glass", "white_concrete", 0x40C0FF, 18, 0, 1, 0, "slow:40:2", "Set lan truyen kep (18 st).", KS);
        def("thunder_spears", "proj", "Thunder Spears", "雷槍", "槍", 65, 240, 34, "cyan_stained_glass", "white_concrete", 0x40C0FF, 26, 1.5, 5, 2.4, "", "5 mui lao dien (34 st).", KS);
        def("mythical_slash", "slash", "Mythical Slash", "幻獣斬", "幻", 60, 220, 34, "cyan_stained_glass", "light_blue_concrete", 0x40C0FF, 8, 4, 5, 0, "", "5 nhat chem dien (34 st).", KS);
        def("maki_dash", "dash", "Zero-Shadow Dash", "影無走", "走", 25, 80, 18, "green_stained_glass", "white_concrete", 0x4AA070, 14, 0, 1, 0, "", "Lao toi 14 o (18 st).", MK);
        def("glaive_sweep", "nova", "Glaive Sweep", "薙刀旋", "薙", 55, 200, 28, "green_stained_glass", "white_concrete", 0x4AA070, 0, 7, 1, 1.1, "", "Quet ban kinh 7 (28 st).", MK);
        def("chain_glaive", "slash", "Soul Split Glaive", "游雲連斬", "雲", 60, 220, 36, "green_stained_glass", "white_concrete", 0x4AA070, 8, 4, 5, 0, "", "5 nhat chem (36 st).", MK);
        def("maki_buff", "buff", "Heavenly Restriction", "天与呪縛", "縛", 40, 400, 0, "green_stained_glass", "white_concrete", 0x4AA070, 0, 0, 1, 0, "speed:300:2,str:300:2,res:200:1", "15 giay: Speed III, Strength III.", MK);
        def("maki_knives", "proj", "Knife Volley", "小刀連射", "刀", 40, 140, 26, "gray_stained_glass", "iron_block", 0x4AA070, 24, 1.2, 8, 2.4, "", "8 con dao hinh quat (26 st).", MK);
        def("gravity_crush", "pull", "Gravity Crush", "重力", "重", 85, 380, 34, "purple_stained_glass", "black_concrete", 0x9A60C0, 16, 10, 60, 0, "slow:30:3", "Hut moi thu ve tam (34 st).", KJ);
        def("curse_spirit_swarm", "proj", "Curse Swarm", "呪霊群", "群", 65, 240, 34, "purple_stained_glass", "purple_concrete", 0x9A60C0, 24, 1.5, 10, 1.8, "weak:60:1", "10 chu linh lao toi (34 st).", KJ);
        def("uzumaki_spiral", "beam", "Maximum: Uzumaki", "最大出力・うずまき", "渦", 110, 500, 60, "purple_stained_glass", "purple_concrete", 0x9A60C0, 34, 2, 1, 0, "", "Tia xoan lon dai 34 o (60 st).", KJ);
        def("brain_shock", "debuff", "Brain Shock", "脳衝撃", "脳", 60, 280, 22, "purple_stained_glass", "magenta_concrete", 0x9A60C0, 14, 7, 1, 0, "nausea:140:0,slow:100:3,blind:60:0", "Choang loan vung 7 o (22 st).", KJ);
        def("kenjaku_buff", "buff", "Body Swap", "肉体交換", "替", 70, 600, 0, "purple_stained_glass", "purple_concrete", 0x9A60C0, 0, 0, 1, 0, "res:300:3,regen:200:2,str:300:1", "15 giay: Resistance IV, Regen III.", KJ);
        def("cursed_manip_wave", "nova", "Cursed Spirit Manipulation", "呪霊操術", "操", 80, 340, 28, "purple_stained_glass", "magenta_concrete", 0x9A60C0, 0, 10, 1, 1.4, "weak:80:1", "No ban kinh 10 (28 st).", KJ);
        def("kenjaku_blades", "slash", "Phantom Blades", "幻刃", "刃", 55, 200, 32, "purple_stained_glass", "purple_concrete", 0x9A60C0, 8, 4, 5, 0, "", "5 nhat chem (32 st).", KJ);
        def("womb_strike", "strike", "Womb Profusion", "胎蔵", "胎", 75, 300, 26, "purple_stained_glass", "purple_concrete", 0x9A60C0, 18, 3, 6, 0, "", "6 cot nang luong (26 st).", KJ);
        def("kenjaku_dash", "dash", "Void Step", "虚歩", "歩", 30, 100, 0, "purple_stained_glass", "purple_concrete", 0x9A60C0, 14, 0, 1, 0, "", "Dich chuyen 14 o.", KJ);
    }
}
