package com.example.jjk;

import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/**
 * Mo hinh 3D ghep tu nhieu block_display (hop chu nhat) co the di chuyen, quay huong va hoat anh (chan vung, canh vo, duoi quet...).
 * Toa do cuc bo: +Z = phia truoc, +Y = len, +X = ben trai cua mo hinh. yaw quay quanh truc Y.
 * Moi bo phan co the "swing" (dao dong sin quanh mot truc tai diem xoay) hoac "spin" (quay lien tuc).
 */
public final class Rig {
    static final class Part {
        Disp.H h; Vec3d off, size, pivot, axis; double amp, speed, phase, spin; boolean anim;
    }

    final ServerWorld w; final List<Part> parts = new ArrayList<>();
    Vec3d pos; double yaw; final int ttl; double lastYaw = 1e9; double scale = 1.0;
    final boolean on = Config.displays;

    public Rig(ServerWorld w, Vec3d pos, double yaw, int ttl) { this.w = w; this.pos = pos; this.yaw = yaw; this.ttl = ttl; }

    public Rig scale(double s) { this.scale = s; return this; }

    private Part make(String block, double ox, double oy, double oz, double sx, double sy, double sz) {
        Part p = new Part();
        p.off = new Vec3d(ox * scale, oy * scale, oz * scale);
        p.size = new Vec3d(sx * scale, sy * scale, sz * scale);
        p.pivot = p.off; p.axis = new Vec3d(1, 0, 0);
        if (on) {
            Disp.Q q = Disp.Q.axis(0, 1, 0, yaw);
            p.h = Disp.block(w, pos.add(q.rot(p.off)), block, p.size.x, p.size.y, p.size.z, q, ttl);
        }
        parts.add(p);
        return p;
    }

    /** bo phan tinh */
    public Rig add(String block, double ox, double oy, double oz, double sx, double sy, double sz) {
        make(block, ox, oy, oz, sx, sy, sz);
        return this;
    }

    /** bo phan dao dong quanh (px,py,pz) theo truc (ax,ay,az): goc = amp * sin(speed * t + phase) */
    public Rig swing(String block, double ox, double oy, double oz, double sx, double sy, double sz,
                     double px, double py, double pz, double ax, double ay, double az, double amp, double speed, double phase) {
        Part p = make(block, ox, oy, oz, sx, sy, sz);
        p.pivot = new Vec3d(px * scale, py * scale, pz * scale);
        p.axis = new Vec3d(ax, ay, az);
        p.amp = amp; p.speed = speed; p.phase = phase; p.anim = true;
        return this;
    }

    /** bo phan quay deu quanh (px,py,pz) theo truc (ax,ay,az): goc = spin * t + phase */
    public Rig spin(String block, double ox, double oy, double oz, double sx, double sy, double sz,
                    double px, double py, double pz, double ax, double ay, double az, double spin, double phase) {
        Part p = make(block, ox, oy, oz, sx, sy, sz);
        p.pivot = new Vec3d(px * scale, py * scale, pz * scale);
        p.axis = new Vec3d(ax, ay, az);
        p.spin = spin; p.phase = phase; p.anim = true;
        return this;
    }

    /** cap nhat vi tri / huong / hoat anh. t = bo dem tick (tang dan) */
    public void place(Vec3d newPos, double newYaw, int t) {
        pos = newPos; yaw = newYaw;
        if (!on) return;
        Disp.Q yq = Disp.Q.axis(0, 1, 0, yaw);
        boolean turned = Math.abs(yaw - lastYaw) > 0.05;
        for (Part p : parts) {
            if (p.h == null) continue;
            Disp.Q local = Disp.Q.ID;
            Vec3d center = p.off;
            if (p.anim) {
                double ang = p.spin != 0 ? p.spin * t + p.phase : p.amp * Math.sin(p.speed * t + p.phase);
                local = Disp.Q.axis(p.axis.x, p.axis.y, p.axis.z, ang);
                center = p.pivot.add(local.rot(p.off.subtract(p.pivot)));
            }
            p.h.move(pos.add(yq.rot(center)));
            if (p.anim || turned) p.h.set(yq.mul(local), p.size.x, p.size.y, p.size.z, 2);
        }
        if (turned) lastYaw = yaw;
    }

    public void kill() { for (Part p : parts) if (p.h != null) p.h.kill(); parts.clear(); }

    public static double yawOf(Vec3d dir) { return Math.atan2(dir.x, dir.z); }
}
