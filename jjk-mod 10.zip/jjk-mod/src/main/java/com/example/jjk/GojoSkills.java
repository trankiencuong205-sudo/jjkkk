package com.example.jjk;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Gojo: Blue, Red, Hollow Purple, Unlimited Void. Moi chieu la mot hoat anh rieng, hitbox that. */
public class GojoSkills {

    // ====================== BLUE ======================
    public static void blue(ServerWorld w, ServerPlayerEntity p) { Anims.add(new Blue(w, p)); }

    private static class Blue implements Anims.Anim {
        static final int LIFE = 50;
        final ServerWorld w; final ServerPlayerEntity p; Vec3d c; int t = 0; Disp.Orb orb;
        Blue(ServerWorld w, ServerPlayerEntity p) {
            this.w = w; this.p = p;
            Vec3d eye = p.getEyePos(), look = p.getRotationVec(1.0f);
            Vec3d pos = eye.add(look.multiply(3));
            for (double d = 3; d <= 14; d += 0.5) {
                Vec3d v = eye.add(look.multiply(d));
                if (!w.isAir(BlockPos.ofFloored(v))) break;
                pos = v;
                if (!Fx.hostiles(w, p, new Box(v, v).expand(1.5)).isEmpty()) break;
            }
            c = pos;
            if (Config.displays) orb = new Disp.Orb(w, c, "light_blue_stained_glass", "white_concrete", "blue_stained_glass", 1.0, 80);
        }

        public boolean tick() {
            if (p.isRemoved()) { if (orb != null) orb.kill(); return true; }
            t++;
            if (orb != null) orb.update(c, t * 0.25, 1.0 + 0.1 * Math.sin(t * 0.8), t % 3 == 0);
            if (t == 1) {
                Fx.snd(w, c, SoundEvents.BLOCK_BEACON_ACTIVATE, 1.4f, 1.9f);
                Vec3d[] bs = Fx.basis(new Vec3d(0, 1, 0));
                Fx.ring(w, Fx.dust(0x9FE8FF, 1.4f), c, bs[1], bs[2], 3.0, 40, 0);
            }
            double R = 8;
            // loi
            double pulse = 0.45 + 0.08 * Math.sin(t * 0.8);
            if (orb == null) {
                Fx.sphere(w, Fx.dust(0x2E9BFF, 1.5f), c, pulse, 16, t * 0.3);
                Fx.sphere(w, Fx.dust(0xD8F4FF, 1.0f), c, pulse * 0.55, 8, -t * 0.4);
            }
            // 2 vong quy dao nghieng
            Vec3d[] b1 = Fx.basis(new Vec3d(Math.cos(t * 0.21), 0.5, Math.sin(t * 0.21)));
            Vec3d[] b2 = Fx.basis(new Vec3d(Math.sin(t * 0.17), Math.cos(t * 0.11), 0.7));
            Fx.ring(w, Fx.dust(0x4DB4FF, 1.1f), c, b1[1], b1[2], 1.15, 18, t * 0.45);
            Fx.ring(w, Fx.dust(0xA8E4FF, 0.9f), c, b2[1], b2[2], 1.65, 22, -t * 0.35);
            // 4 canh xoan oc hut vao
            for (int arm = 0; arm < 4; arm++) {
                double rad = R * 0.7 - ((t * 0.55 + arm * 1.4) % (R * 0.7));
                double ang = t * 0.3 + arm * Math.PI / 2 + rad * 0.6;
                Vec3d off = new Vec3d(Math.cos(ang) * rad, Math.sin(ang * 0.5) * rad * 0.35, Math.sin(ang) * rad);
                Fx.pt(w, Fx.dust(0xBFE9FF, 0.8f), c.add(off));
                Fx.pt(w, Fx.dust(0x2E78E8, 0.6f), c.add(off.multiply(1.08)));
            }
            // vong "thau kinh trong luc"
            if (t % 12 == 0) {
                Vec3d[] bs = Fx.basis(new Vec3d(0, 1, 0));
                Fx.ring(w, Fx.dust(0x1C3A78, 1.0f), c, bs[1], bs[2], 4.5, 36, 0);
            }
            // hut + nghien
            for (LivingEntity e : Fx.hostiles(w, p, new Box(c, c).expand(R))) {
                Vec3d d = c.subtract(Fx.mid(e));
                double dist = d.length();
                Vec3d vel = e.getVelocity();
                e.addVelocity(-vel.x * 0.25, -vel.y * 0.25, -vel.z * 0.25);
                if (dist > 0.6) e.addVelocity(d.normalize().multiply(0.2 * (1.2 - dist / R * 0.6)));
                if (dist < 2.2 && t % 8 == 0) {
                    Fx.hurt(w, p, e, 3.0f);
                    Fx.put(w, Fx.dust(0x9FE8FF, 1.0f), Fx.mid(e), 6, 0.4, 0);
                }
            }
            if (t >= LIFE) {
                Fx.snd(w, c, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 1.0f, 1.6f);
                Fx.snd(w, c, SoundEvents.BLOCK_BEACON_DEACTIVATE, 1.2f, 1.4f);
                for (LivingEntity e : Fx.hostiles(w, p, new Box(c, c).expand(3.2))) {
                    Fx.hurt(w, p, e, 6.0f);
                    Vec3d away = Fx.mid(e).subtract(c).normalize();
                    e.addVelocity(away.x * 0.9, 0.4, away.z * 0.9);
                }
                Vec3d[] bs = Fx.basis(new Vec3d(0, 1, 0));
                for (int r = 1; r <= 4; r++) Fx.ring(w, Fx.dust(0xBFEAFF, 1.4f), c, bs[1], bs[2], r * 0.8, 24 + r * 6, 0);
                Fx.sphere(w, Fx.dust(0x2E9BFF, 1.6f), c, 2.5, 50, 0);
                if (orb != null) orb.kill();
                return true;
            }
            return false;
        }
    }

    // ====================== RED ======================
    public static void red(ServerWorld w, ServerPlayerEntity p) { Anims.add(new Red(w, p)); }

    private static class Red implements Anims.Anim {
        final ServerWorld w; final ServerPlayerEntity p; Vec3d pos, dir; int t = 0, bt = 0; boolean boom = false; Vec3d bc; Disp.Orb orb, boomOrb;
        Red(ServerWorld w, ServerPlayerEntity p) {
            this.w = w; this.p = p;
            dir = p.getRotationVec(1.0f);
            pos = p.getEyePos().add(dir.multiply(1.5));
            Fx.snd(w, pos, SoundEvents.ENTITY_BLAZE_SHOOT, 1.2f, 0.6f);
            Fx.snd(w, pos, SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 0.5f, 1.8f);
            if (Config.displays) orb = new Disp.Orb(w, pos, "red_stained_glass", "redstone_block", "black_stained_glass", 0.9, 80);
        }

        public boolean tick() {
            if (!boom) {
                t++;
                pos = pos.add(dir.multiply(1.3));
                Vec3d[] b = Fx.basis(dir);
                double pulse = 0.5 + 0.1 * Math.sin(t);
                if (orb != null) orb.update(pos, t * 0.5, 1.0, t % 2 == 0);
                else {
                    Fx.sphere(w, Fx.dust(0xFF2A2A, 1.6f), pos, pulse, 14, t * 0.5);
                    Fx.sphere(w, Fx.dust(0xFFB0A0, 1.0f), pos, pulse * 0.5, 7, 0);
                    Fx.sphere(w, Fx.dust(0x180004, 1.4f), pos, pulse * 1.5, 8, -t * 0.4);
                }
                // xoan oc doi quanh duong bay (do + den)
                for (int k = 0; k < 2; k++) {
                    double a = t * 0.9 + k * Math.PI;
                    Vec3d off = b[1].multiply(Math.cos(a) * 0.9).add(b[2].multiply(Math.sin(a) * 0.9));
                    Fx.pt(w, Fx.dust(k == 0 ? 0xFF4040 : 0x100004, 1.1f), pos.add(off));
                    Fx.pt(w, Fx.dust(k == 0 ? 0xFF4040 : 0x100004, 0.8f), pos.add(off).subtract(dir.multiply(0.7)));
                }
                Fx.put(w, ParticleTypes.FLAME, pos.subtract(dir.multiply(0.5)), 2, 0.2, 0.02);
                boolean hitBlock = !w.isAir(BlockPos.ofFloored(pos));
                boolean hitMob = !Fx.hostiles(w, p, new Box(pos, pos).expand(1.3)).isEmpty();
                if (hitBlock || hitMob || t >= 36 || p.isRemoved()) {
                    boom = true; bc = pos.subtract(dir.multiply(0.6));
                    if (orb != null) { orb.kill(); orb = null; boomOrb = new Disp.Orb(w, bc, "red_stained_glass", "white_concrete", "black_stained_glass", 1.0, 30); }
                    explode();
                }
                return false;
            }
            bt++;
            if (boomOrb != null) { boomOrb.update(bc, bt * 0.5, 1.0 + bt * 1.5, true); if (bt >= 8) boomOrb.kill(); }
            Vec3d[] hb = Fx.basis(new Vec3d(0, 1, 0));
            Vec3d[] vb = Fx.basis(dir);
            double r = bt * 1.0;
            Fx.ring(w, Fx.dust(0xFF2A2A, 1.6f), bc, hb[1], hb[2], r, 30 + bt * 8, 0);
            Fx.ring(w, Fx.dust(0x120004, 1.4f), bc, hb[1], hb[2], r * 0.8, 24 + bt * 6, 0.2);
            Fx.ring(w, Fx.dust(0xFF7A60, 1.2f), bc, vb[1], vb[2], r * 0.9, 28 + bt * 6, 0);
            Fx.sphere(w, Fx.dust(0xFF3030, 1.5f), bc, r * 0.8, 40, bt * 0.3);
            return bt >= 8;
        }

        void explode() {
            Fx.snd(w, bc, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 1.6f, 0.8f);
            Fx.snd(w, bc, SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 1.0f, 1.2f);
            Fx.put(w, ParticleTypes.EXPLOSION_EMITTER, bc, 1, 0, 0);
            for (LivingEntity e : Fx.hostiles(w, p, new Box(bc, bc).expand(7))) {
                Vec3d away = Fx.mid(e).subtract(bc);
                double d = away.length();
                double f = Math.max(0.0, 1.0 - d / 8.0);
                Fx.hurt(w, p, e, (float) Math.max(4.0, 16.0 * f));
                Vec3d n = d < 0.01 ? new Vec3d(0, 1, 0) : away.normalize();
                e.addVelocity(n.x * (0.5 + 1.8 * f), 0.5 + 0.5 * f, n.z * (0.5 + 1.8 * f));
            }
        }
    }

    // ====================== HOLLOW PURPLE ======================
    public static void purple(ServerWorld w, ServerPlayerEntity p) { Anims.add(new Purple(w, p)); }

    private static class Purple implements Anims.Anim {
        static final int CHARGE = 36, FLY = 45, AFTER = 24;
        final ServerWorld w; final ServerPlayerEntity p; int t = 0, ft = 0, at = 0; int phase = 0;
        Vec3d head, dir, endPos; final Set<UUID> hit = new HashSet<>();
        Disp.Orb blueO, redO, core; Disp.Beam beam;
        void clean() { if (blueO != null) blueO.kill(); if (redO != null) redO.kill(); if (core != null) core.kill(); if (beam != null) beam.kill(); blueO = redO = null; core = null; beam = null; }
        Purple(ServerWorld w, ServerPlayerEntity p) {
            this.w = w; this.p = p;
            Fx.snd(w, p.getEntityPos(), SoundEvents.BLOCK_BEACON_POWER_SELECT, 1.2f, 0.6f);
        }

        public boolean tick() {
            if (p.isRemoved()) { clean(); return true; }
            if (phase == 0) {
                t++;
                Vec3d look = p.getRotationVec(1.0f);
                Vec3d[] b = Fx.basis(look);
                Vec3d c = p.getEyePos().add(look.multiply(3.6)).add(0, -0.1, 0);
                double k = Math.min(1.0, t / (double) CHARGE);
                double ease = k * k * (3 - 2 * k);
                double sep = 1.9 * (1 - ease);
                Vec3d bluePos = c.subtract(b[1].multiply(sep)), redPos = c.add(b[1].multiply(sep));
                if (Config.displays && k < 1.0) {
                    if (blueO == null) {
                        blueO = new Disp.Orb(w, bluePos, "light_blue_stained_glass", "white_concrete", null, 0.7, 80);
                        redO = new Disp.Orb(w, redPos, "red_stained_glass", "redstone_block", null, 0.7, 80);
                    }
                    blueO.update(bluePos, t * 0.4, 1.0, t % 3 == 0);
                    redO.update(redPos, t * 0.4, 1.0, t % 3 == 0);
                }
                if (k >= 1.0 && blueO != null) { blueO.kill(); redO.kill(); blueO = null; redO = null; }
                if (k < 1.0) {
                    if (!Config.displays) { orb(bluePos, 0x2E9BFF, 0xD8F4FF, 0.45, t); orb(redPos, 0xFF2A2A, 0xFFB0A0, 0.45, t); }
                    // vet xoan oc cua hai qua hoi tu
                    for (int i = 0; i < 4; i++) {
                        double a = t * 0.6 + i * 1.57;
                        Vec3d off = b[2].multiply(Math.sin(a) * 0.5 * (1 - ease)).add(look.multiply(Math.cos(a) * 0.3));
                        Fx.pt(w, Fx.dust(0x6FC0FF, 0.7f), bluePos.add(off));
                        Fx.pt(w, Fx.dust(0xFF6060, 0.7f), redPos.add(off));
                    }
                }
                if (k > 0.55) {
                    double g = (k - 0.55) / 0.45;
                    double r = 0.25 + 0.95 * g;
                    if (Config.displays) {
                        if (core == null) core = new Disp.Orb(w, c, "purple_stained_glass", "white_concrete", "black_stained_glass", 1.0, 200);
                        core.update(c, t * 0.3, 0.3 + 0.9 * g, t % 3 == 0);
                    } else {
                        Fx.sphere(w, Fx.dust(0x9B3DFF, 1.6f), c, r, 24, t * 0.4);
                        Fx.sphere(w, Fx.dust(0xE8C8FF, 1.0f), c, r * 0.55, 10, 0);
                    }
                    Fx.ring(w, Fx.dust(0x0A0014, 1.5f), c, b[1], b[2], r * 1.6, 26, t * 0.3);
                    if (t % 2 == 0) {
                        Vec3d end = c.add(Fx.randDir().multiply(Fx.rnd(1.8, 3.2)));
                        Fx.bolt(w, Fx.dust(0xB060FF, 1.0f), c, end, 0.4, 0.4);
                    }
                }
                if (t == CHARGE - 2) {
                    Fx.put(w, ParticleTypes.END_ROD, c, 40, 0.9, 0.35);
                    Fx.snd(w, c, SoundEvents.BLOCK_BEACON_ACTIVATE, 1.6f, 0.5f);
                }
                if (t >= CHARGE) {
                    phase = 1;
                    dir = p.getRotationVec(1.0f);
                    head = c;
                    if (Config.displays) beam = new Disp.Beam(w, c.subtract(dir.multiply(8)), c, "purple_stained_glass", "white_concrete", 1.1, 90);
                    Fx.snd(w, c, SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 2.0f, 0.7f);
                    Fx.snd(w, c, SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 1.0f, 0.5f);
                }
                return false;
            }
            if (phase == 1) {
                ft++;
                head = head.add(dir.multiply(1.4));
                Vec3d[] b = Fx.basis(dir);
                if (core != null) core.update(head, ft * 0.4, 2.2, ft % 3 == 0);
                if (beam != null) beam.update(head.subtract(dir.multiply(11)), head, 1.2);
                if (core == null) {
                    Fx.sphere(w, Fx.dust(0x9B3DFF, 1.8f), head, 1.2, 36, ft * 0.5);
                    Fx.sphere(w, Fx.dust(0xEBD2FF, 1.1f), head, 0.7, 14, -ft * 0.4);
                    Fx.sphere(w, Fx.dust(0x08000F, 1.5f), head, 1.9, 22, ft * 0.3);
                }
                for (int i = 0; i < 3; i++) {
                    Vec3d rc = head.subtract(dir.multiply(1.1 * i + 0.8));
                    Fx.ring(w, Fx.dust(i == 0 ? 0x5A18B0 : 0x2A0A58, 1.2f), rc, b[1], b[2], 2.5 - i * 0.4, 28, ft * 0.35 + i);
                }
                Fx.line(w, Fx.dust(0x7A30D0, 1.0f), head.subtract(dir.multiply(9)), head.subtract(dir.multiply(1.5)), 0.8);
                if (ft % 3 == 0) Fx.put(w, ParticleTypes.END_ROD, head, 3, 1.4, 0.1);

                for (LivingEntity e : Fx.hostiles(w, p, new Box(head, head).expand(3.2))) {
                    if (hit.add(e.getUuid())) {
                        Fx.hurt(w, p, e, 45.0f);
                        e.addVelocity(dir.x * 1.6, 0.5, dir.z * 1.6);
                        Fx.put(w, Fx.dust(0xB060FF, 1.6f), Fx.mid(e), 30, 0.6, 0);
                    }
                }
                boolean block = false;
                if (Config.purpleErasesBlocks) {
                    BlockPos hp = BlockPos.ofFloored(head);
                    for (int dx = -2; dx <= 2; dx++) for (int dy = -2; dy <= 2; dy++) for (int dz = -2; dz <= 2; dz++) {
                        if (dx * dx + dy * dy + dz * dz > 5) continue;
                        BlockPos bp = hp.add(dx, dy, dz);
                        if (!w.isAir(bp) && w.getBlockState(bp).getHardness(w, bp) >= 0) w.breakBlock(bp, false);
                    }
                } else block = !w.isAir(BlockPos.ofFloored(head));
                if (block || ft >= FLY) { phase = 2; endPos = head; if (beam != null) { beam.kill(); beam = null; } Fx.snd(w, head, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 2.0f, 0.5f); }
                return false;
            }
            at++;
            if (core != null) core.update(endPos, at * 0.3, 2.2 + at * 0.28, true);
            Vec3d[] hb = Fx.basis(new Vec3d(0, 1, 0));
            double r = at * 0.45;
            Fx.sphere(w, Fx.dust(0x08000F, 1.8f), endPos, Math.max(0.3, 3.2 - at * 0.12), 30, at * 0.3);
            Fx.ring(w, Fx.dust(0x9B3DFF, 1.6f), endPos, hb[1], hb[2], r * 2.2, 32 + at * 2, 0);
            Fx.ring(w, Fx.dust(0x3A0A80, 1.4f), endPos.add(0, 0.4, 0), hb[1], hb[2], r * 1.6, 28, 0.3);
            if (at == 1) Fx.put(w, ParticleTypes.EXPLOSION_EMITTER, endPos, 1, 0, 0);
            if (at >= AFTER) { clean(); return true; }
            return false;
        }

        void orb(Vec3d c, int main, int core, double r, int t) {
            Fx.sphere(w, Fx.dust(main, 1.4f), c, r, 14, t * 0.4);
            Fx.sphere(w, Fx.dust(core, 0.9f), c, r * 0.5, 6, 0);
        }
    }

    // ====================== UNLIMITED VOID ======================
    public static void unlimitedVoid(ServerWorld w, ServerPlayerEntity p) { Anims.add(new VoidDomain(w, p)); }

    private static class VoidDomain implements Anims.Anim {
        static final double R = 14; static final int EXPAND = 24, COLLAPSE = 12;
        final ServerWorld w; final ServerPlayerEntity p; final Vec3d c; int t = 0; final int dur; boolean ending = false; int et = 0; final Domains.Scene scene;
        VoidDomain(ServerWorld w, ServerPlayerEntity p) {
            this.w = w; this.p = p;
            c = p.getEntityPos().add(0, 1.0, 0);
            dur = Config.domainSeconds * 20;
            Data.DOMAIN_END.put(p.getUuid(), Data.now + EXPAND + dur + COLLAPSE);
            scene = Domains.voidScene(w, p.getEntityPos(), EXPAND + dur + COLLAPSE + 20, EXPAND);
            Domains.announce(w, p, R, "領域展開", "Unlimited Void - 無量空処", "aqua");
            Fx.snd(w, c, SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 2.0f, 0.5f);
            Fx.snd(w, c, SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 1.2f, 0.4f);
        }

        public boolean tick() {
            if (p.isRemoved() || !p.isAlive()) { Data.DOMAIN_END.remove(p.getUuid()); scene.kill(); return true; }
            if (ending) {
                et++;
                if (et == 1) scene.beginEnd(COLLAPSE);
                double r = R * (1 - et / (double) COLLAPSE);
                Fx.sphere(w, Fx.dust(0x7A5CFF, 1.6f), c, Math.max(0.5, r), 90, t * 0.05);
                if (et >= COLLAPSE) { scene.kill(); Fx.snd(w, c, SoundEvents.BLOCK_BEACON_DEACTIVATE, 1.5f, 0.6f); return true; }
                return false;
            }
            t++;
            scene.tick(t);
            if (t <= EXPAND) {
                double r = R * (t / (double) EXPAND);
                Fx.sphere(w, Fx.dust(0xFFFFFF, 1.8f), c, r, 110, t * 0.12);
                Fx.sphere(w, Fx.dust(0x5A3CFF, 1.4f), c, r * 0.97, 60, -t * 0.1);
                Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
                Fx.ring(w, Fx.dust(0xB8A0FF, 1.6f), c, b[1], b[2], r, 60, 0);
                if (t == 1) Fx.put(w, ParticleTypes.END_ROD, c, 60, 1.5, 0.6);
                return false;
            }
            // ---- vung hoat dong ----
            double rot = t * 0.02;
            Fx.sphere(w, Fx.dust(0x3A2A9A, 1.3f), c, R, 56, rot);              // vo cau
            for (int i = 0; i < 18; i++) {                                        // sao
                Vec3d pt = c.add(Fx.randDir().multiply(R * Math.cbrt(Fx.rnd())));
                Fx.pt(w, ParticleTypes.END_ROD, pt);
            }
            int[] cols = {0xFFFFFF, 0x6FC0FF, 0xC070FF, 0x3030C0};
            for (int i = 0; i < 12; i++) {
                Vec3d pt = c.add(Fx.randDir().multiply(R * Math.cbrt(Fx.rnd())));
                Fx.pt(w, Fx.dust(cols[i % 4], 0.8f), pt);
            }
            // 3 vong thien ha
            for (int k = 0; k < 3; k++) {
                Vec3d[] b = Fx.basis(new Vec3d(Math.sin(k * 2.1 + t * 0.01), 1, Math.cos(k * 2.1)));
                Fx.ring(w, Fx.dust(cols[k + 1], 1.0f), c, b[1], b[2], R * (0.45 + 0.2 * k), 36, t * 0.04 * (k % 2 == 0 ? 1 : -1));
            }
            // quai trong domain
            for (LivingEntity e : Fx.hostiles(w, p, new Box(c, c).expand(R))) {
                if (e.getEntityPos().distanceTo(c) > R) continue;
                if (t % 10 == 0) {
                    e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 30, 6));
                    e.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 30, 3));
                    e.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 60, 0));
                }
                if (t % 20 == 0) Fx.hurt(w, p, e, 2.0f);
                Vec3d v = e.getVelocity();
                e.addVelocity(-v.x * 0.6, 0, -v.z * 0.6);
                Vec3d head = e.getEntityPos().add(0, e.getHeight(), 0);
                for (int i = 0; i < 3; i++) {                                     // thong tin do vao dau
                    Vec3d from = head.add(Fx.randDir().multiply(Fx.rnd(3, 7)));
                    Fx.line(w, Fx.dust(i == 0 ? 0xFFFFFF : 0x80A0FF, 0.7f), from, head, 0.9);
                }
                Fx.put(w, ParticleTypes.ELECTRIC_SPARK, head, 2, 0.3, 0.05);
            }
            if (t - EXPAND >= dur) ending = true;
            return false;
        }
    }
}
