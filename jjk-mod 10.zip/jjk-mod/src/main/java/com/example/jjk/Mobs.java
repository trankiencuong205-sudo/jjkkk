package com.example.jjk;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;

import java.util.*;

/**
 * Quai Jujutsu: than xac la quai vanilla (husk / vex / spider / ravager / drowned / wither_skeleton) duoc /summon
 * voi ten, scale, mau, trang phuc rieng (jjk:<ten>) va gan tag "jjk_mob". Ky nang cua tung con duoc chay bang Java moi 10 tick.
 * Khong co model rieng (can model that thi phai lam them bang Blockbench / GeckoLib).
 */
public class Mobs {
    public record Def(String id, String name, String color, String base, double scale, double hp, double dmg, String outfit, String weapon, String desc) { }

    public static final Def[] DEFS = {
            new Def("spirit", "Cursed Spirit (Grade 4)", "dark_purple", "minecraft:vex", 1.0, 14, 3, null, null, "Chu linh bay nho, dong. Dien hinh la bay dan."),
            new Def("grade2", "Cursed Spirit (Grade 2)", "dark_red", "minecraft:spider", 1.6, 45, 6, null, null, "Chu linh nhen to, mau tim."),
            new Def("special", "Special-Grade Cursed Spirit", "red", "minecraft:ravager", 1.2, 160, 12, null, null, "Dac cap: dam xung kich quanh minh."),
            new Def("mahito", "Mahito", "gray", "minecraft:husk", 1.0, 140, 6, "mahito", null, "Vo Ta Chuyen Hoa: buff yeu + buon non, goi dong doi khi mau thap."),
            new Def("jogo", "Jogo", "gold", "minecraft:husk", 1.1, 160, 6, "jogo", null, "Lua phun, Nui Lua (thien thach). Mien nhiem lua."),
            new Def("hanami", "Hanami", "green", "minecraft:ravager", 1.5, 220, 10, null, null, "Re cay troi chan, tu hoi mau."),
            new Def("dagon", "Dagon", "aqua", "minecraft:drowned", 1.5, 180, 7, null, "minecraft:trident", "Tia nuoc day lui, manh trong nuoc."),
            new Def("sukuna", "Ryomen Sukuna (boss)", "dark_red", "minecraft:husk", 1.15, 450, 12, "sukuna", null, "Cleave / Dismantle / Fuga; duoi 40% mau mo Malevolent Shrine."),
            new Def("mahoraga", "Eight-Handled Sword Divergent Sila Divine General Mahoraga", "white", "minecraft:wither_skeleton", 2.2, 600, 14, null, "minecraft:iron_sword", "Thich ung: cang bi mot loai sat thuong danh nhieu, cang hoi mau lai."),
    };

    private static final Map<UUID, Integer> TICKS = new HashMap<>();
    private static final Map<UUID, Map<String, Integer>> ADAPT = new HashMap<>();
    private static final Set<UUID> SPLIT = new HashSet<>();
    private static final List<Pend> PEND = new ArrayList<>();
    private static int spawnTimer = 0;

    private static final class Pend {
        ServerWorld w; Vec3d pos; int t; int kind; UUID owner;
        Pend(ServerWorld w, Vec3d pos, int t, int kind, UUID owner) { this.w = w; this.pos = pos; this.t = t; this.kind = kind; this.owner = owner; }
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(Mobs::tick);
        ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamage, damageTaken, blocked) -> {
            if (blocked || !entity.getCommandTags().contains("jjk_mahoraga") || !(entity.getEntityWorld() instanceof ServerWorld w)) return;
            String key = source.getType().msgId();
            Map<String, Integer> m = ADAPT.computeIfAbsent(entity.getUuid(), k -> new HashMap<>());
            int n = m.merge(key, 1, Integer::sum);
            if (n >= 2) {
                double frac = Math.min(0.9, 0.3 * (n - 1));
                entity.setHealth((float) Math.min(entity.getMaxHealth(), entity.getHealth() + damageTaken * frac));
                Vec3d c = Fx.mid(entity);
                Fx.put(w, Fx.dust(0xFFE070, 1.4f), c, 12, 0.8, 0.05);
            }
        });
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (!entity.getCommandTags().contains("jjk_mob") || !(entity.getEntityWorld() instanceof ServerWorld w)) return;
            TICKS.remove(entity.getUuid()); ADAPT.remove(entity.getUuid()); SPLIT.remove(entity.getUuid());
            PlayerEntity near = w.getClosestPlayer(entity, 24);
            if (near instanceof ServerPlayerEntity sp) {
                Data.addEnergy(sp.getUuid(), 80);
                if (entity.getCommandTags().contains("jjk_boss")) {
                    Disp.tryRun(w, "give " + sp.getUuid() + " minecraft:bone[custom_name={text:\"Cursed Finger\",italic:false,color:\"dark_red\"},enchantment_glint_override=true]");
                    sp.sendMessage(Text.literal("Boss ha guc! +Cursed Finger"), true);
                }
            }
        });
    }

    // ---------- spawn ----------
    public static boolean spawn(ServerWorld w, int idx, Vec3d pos) {
        if (idx < 0 || idx >= DEFS.length) return false;
        Def d = DEFS[idx];
        String tags = "\"jjk_mob\",\"jjk_" + d.id + "\"" + (d.hp >= 400 || d.id.equals("special") ? ",\"jjk_boss\"" : "");
        StringBuilder sb = new StringBuilder();
        sb.append(String.format(Locale.ROOT, "summon %s %.2f %.2f %.2f {CustomName:{text:\"%s\",color:\"%s\"},CustomNameVisible:1b,PersistenceRequired:1b,Health:%.1ff,Tags:[%s],",
                d.base, pos.x, pos.y, pos.z, d.name, d.color, d.hp, tags));
        sb.append(String.format(Locale.ROOT, "attributes:[{id:\"minecraft:max_health\",base:%.1fd},{id:\"minecraft:scale\",base:%.2fd},{id:\"minecraft:attack_damage\",base:%.1fd},{id:\"minecraft:follow_range\",base:40.0d}],", d.hp, d.scale, d.dmg));
        sb.append("equipment:{");
        List<String> eq = new ArrayList<>();
        if (d.outfit != null) eq.add(Outfits.mobEquipment(d.outfit));
        if (d.weapon != null) eq.add("mainhand:{id:\"" + d.weapon + "\",count:1}");
        sb.append(String.join(",", eq));
        sb.append("},drop_chances:{head:0.0f,chest:0.0f,legs:0.0f,feet:0.0f,mainhand:0.0f}}");
        boolean ok = Disp.tryRun(w, sb.toString());
        if (!ok) { // du phong: khong co equipment/attribute
            ok = Disp.tryRun(w, String.format(Locale.ROOT, "summon %s %.2f %.2f %.2f {CustomName:{text:\"%s\"},CustomNameVisible:1b,PersistenceRequired:1b,Tags:[%s]}", d.base, pos.x, pos.y, pos.z, d.name, tags));
        }
        if (ok) Fx.put(w, Fx.dust(0x30104A, 1.6f), pos.add(0, 1, 0), 40, 0.8, 0.05);
        return ok;
    }

    /** lenh tu menu: chi creative */
    public static void spawnNear(ServerPlayerEntity p, int idx) {
        if (!(p.getEntityWorld() instanceof ServerWorld w)) return;
        if (!p.isCreative()) { p.sendMessage(Text.literal("Goi quai chi dung duoc o che do Creative."), true); return; }
        Vec3d pos = p.getEntityPos().add(p.getRotationVec(1f).multiply(1, 0, 1).normalize().multiply(6));
        boolean ok = spawn(w, idx, pos);
        p.sendMessage(Text.literal(ok ? "Da goi: " + DEFS[idx].name : "Khong goi duoc (xem log)"), true);
    }

    // ---------- tick ----------
    private static void tick(MinecraftServer server) {
        for (Iterator<Pend> it = PEND.iterator(); it.hasNext(); ) {
            Pend p = it.next();
            if (--p.t <= 0) { resolve(p); it.remove(); }
            else if (p.t % 4 == 0) Fx.ring(p.w, Fx.dust(p.kind == 0 ? 0xFF5010 : 0xFFE070, 1.3f), p.pos.add(0, 0.2, 0), new Vec3d(1, 0, 0), new Vec3d(0, 0, 1), p.kind == 0 ? 4.0 : 6.0, 28, p.t * 0.2);
        }
        Set<UUID> done = new HashSet<>();
        for (ServerWorld w : server.getWorlds()) {
            for (ServerPlayerEntity pl : w.getPlayers()) {
                for (LivingEntity m : w.getEntitiesByClass(LivingEntity.class, pl.getBoundingBox().expand(48), e -> e.isAlive() && e.getCommandTags().contains("jjk_mob"))) {
                    if (!done.add(m.getUuid())) continue;
                    int t = TICKS.merge(m.getUuid(), 1, Integer::sum);
                    if (t % 10 == 0) ai(w, m, t);
                }
            }
        }
        if (++spawnTimer >= 200) { spawnTimer = 0; naturalSpawns(server); }
    }

    private static ServerPlayerEntity target(ServerWorld w, LivingEntity m, double r) {
        PlayerEntity p = w.getClosestPlayer(m, r);
        if (p instanceof ServerPlayerEntity sp && !sp.isCreative() && !sp.isSpectator()) return sp;
        return null;
    }

    private static void hit(ServerWorld w, LivingEntity m, ServerPlayerEntity p, float dmg) {
        p.damage(w, w.getDamageSources().mobAttack(m), dmg);
    }

    private static void knock(LivingEntity m, LivingEntity t, double s) {
        Vec3d d = t.getEntityPos().subtract(m.getEntityPos()).multiply(1, 0, 1);
        if (d.lengthSquared() < 1e-4) return;
        d = d.normalize().multiply(s);
        t.addVelocity(d.x, 0.35, d.z);
    }

    private static void ai(ServerWorld w, LivingEntity m, int t) {
        Set<String> tg = m.getCommandTags();
        Vec3d c = Fx.mid(m);
        double sc = Math.max(1, m.getHeight() / 1.8);
        // hao quang chu luc
        int aura = tg.contains("jjk_sukuna") ? 0x701010 : tg.contains("jjk_jogo") ? 0xFF5010 : tg.contains("jjk_hanami") ? 0x30A030 : tg.contains("jjk_dagon") ? 0x2080D0 : tg.contains("jjk_mahoraga") ? 0xFFE070 : 0x301048;
        Fx.put(w, Fx.dust(aura, 1.2f), c, 4, 0.4 * sc, 0.01);
        ServerPlayerEntity pl = target(w, m, 24);
        if (tg.contains("jjk_mahoraga")) {
            int n = ADAPT.getOrDefault(m.getUuid(), Map.of()).size();
            Vec3d top = m.getEntityPos().add(0, m.getHeight() + 0.6, 0);
            Fx.ring(w, Fx.dust(0xFFE070, 1.2f), top, new Vec3d(1, 0, 0), new Vec3d(0, 0, 1), 0.9, 8 + n * 4, t * 0.15);
        }
        if (pl == null) return;
        double dist = pl.getEntityPos().distanceTo(m.getEntityPos());
        if (tg.contains("jjk_special") && t % 60 == 0 && dist < 7) {
            shock(w, m, 6.5, 7f, 0x602020);
        } else if (tg.contains("jjk_mahito") && t % 80 == 0 && dist < 12) {
            hit(w, m, pl, 4f);
            pl.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 120, 0));
            pl.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 200, 1));
            pl.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 1));
            Fx.sphere(w, Fx.dust(0x9AA0C0, 1.5f), pl.getEntityPos().add(0, 1, 0), 1.1, 50, t * 0.1);
            if (m.getHealth() < m.getMaxHealth() * 0.5 && SPLIT.add(m.getUuid())) {
                Vec3d p = m.getEntityPos();
                spawn(w, 0, p.add(2, 0, 0)); spawn(w, 0, p.add(-2, 0, 0));
            }
        } else if (tg.contains("jjk_jogo")) {
            m.setFireTicks(0);
            if (t % 60 == 0 && dist < 22) {
                Fx.line(w, Fx.dust(0xFF6010, 1.5f), c, Fx.mid(pl), 0.4);
                hit(w, m, pl, 5f); pl.setFireTicks(100);
            }
            if (t % 200 == 0 && dist < 26) PEND.add(new Pend(w, pl.getEntityPos(), 40, 0, m.getUuid()));
        } else if (tg.contains("jjk_hanami")) {
            if (t % 40 == 0) m.setHealth(Math.min(m.getMaxHealth(), m.getHealth() + 3));
            if (t % 60 == 0 && dist < 9) {
                pl.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 2));
                hit(w, m, pl, 3f);
                Fx.ring(w, Fx.dust(0x30B030, 1.5f), pl.getEntityPos().add(0, 0.1, 0), new Vec3d(1, 0, 0), new Vec3d(0, 0, 1), 1.0, 30, 0);
                Fx.line(w, Fx.dust(0x206020, 1.2f), pl.getEntityPos(), pl.getEntityPos().add(0, 2, 0), 0.25);
            }
        } else if (tg.contains("jjk_dagon") && t % 50 == 0 && dist < 16) {
            Fx.line(w, Fx.dust(0x40A0FF, 1.6f), c, Fx.mid(pl), 0.35);
            hit(w, m, pl, 5f); knock(m, pl, 1.1);
        } else if (tg.contains("jjk_sukuna")) {
            sukuna(w, m, pl, dist, t);
        } else if (tg.contains("jjk_mahoraga") && t % 40 == 0 && dist < 6) {
            shock(w, m, 5.5, 10f, 0xFFE070);
        }
    }

    private static void shock(ServerWorld w, LivingEntity m, double r, float dmg, int col) {
        Vec3d o = m.getEntityPos().add(0, 0.2, 0);
        Fx.ring(w, Fx.dust(col, 1.8f), o, new Vec3d(1, 0, 0), new Vec3d(0, 0, 1), r, 60, 0);
        Fx.ring(w, Fx.dust(col, 1.3f), o.add(0, 0.4, 0), new Vec3d(1, 0, 0), new Vec3d(0, 0, 1), r * 0.6, 40, 0);
        Fx.snd(w, o, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 1.0f, 0.8f);
        for (ServerPlayerEntity p : w.getPlayers()) {
            if (p.isCreative() || p.isSpectator() || p.getEntityPos().distanceTo(m.getEntityPos()) > r) continue;
            hit(w, m, p, dmg); knock(m, p, 1.2);
        }
    }

    private static void sukuna(ServerWorld w, LivingEntity m, ServerPlayerEntity pl, double dist, int t) {
        if (t % 400 == 0 && m.getHealth() < m.getMaxHealth() * 0.4) {
            PEND.add(new Pend(w, m.getEntityPos(), 60, 1, m.getUuid()));   // Malevolent Shrine
            return;
        }
        if (t % 40 != 0) return;
        Vec3d c = Fx.mid(m), tp = Fx.mid(pl);
        if (dist < 6) { // Cleave
            Vec3d look = tp.subtract(c).normalize();
            Vec3d[] b = Fx.basis(look);
            Fx.arc(w, Fx.dust(0xFF2020, 1.6f), c.add(look.multiply(1.5)), b[0], b[1], 2.2, -1.2, 1.2, 30);
            hit(w, m, pl, 12f);
        } else if (dist < 15 && Fx.rnd() < 0.6) { // Dismantle
            Fx.bolt(w, Fx.dust(0xFFFFFF, 1.2f), c, tp, 0.3, 0.3);
            Fx.line(w, Fx.dust(0xFF3030, 1.4f), c.add(0, 0.5, 0), tp.add(0, 0.5, 0), 0.3);
            hit(w, m, pl, 8f);
        } else if (dist < 28) { // Fuga
            Fx.line(w, Fx.dust(0xFF7020, 2.0f), c, tp, 0.25);
            Fx.sphere(w, Fx.dust(0xFF5010, 2.0f), tp, 1.6, 60, 0);
            Fx.snd(w, tp, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 1.0f, 1.2f);
            hit(w, m, pl, 11f); pl.setFireTicks(120);
        }
    }

    private static void resolve(Pend p) {
        if (p.kind == 0) { // thien thach Jogo
            Fx.sphere(p.w, Fx.dust(0xFF4000, 2.2f), p.pos.add(0, 1, 0), 3.5, 120, 0);
            Fx.snd(p.w, p.pos, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 1.5f, 0.6f);
            for (ServerPlayerEntity pl : p.w.getPlayers()) {
                if (pl.isCreative() || pl.isSpectator() || pl.getEntityPos().distanceTo(p.pos) > 4.5) continue;
                LivingEntity own = p.w.getEntitiesByClass(LivingEntity.class, new Box(p.pos, p.pos).expand(60), e -> e.getUuid().equals(p.owner)).stream().findFirst().orElse(null);
                if (own != null) hit(p.w, own, pl, 10f); else pl.damage(p.w, p.w.getDamageSources().magic(), 10f);
                pl.setFireTicks(120);
            }
        } else { // Malevolent Shrine (3 nhip chem)
            Fx.sphere(p.w, Fx.dust(0xFF2020, 1.6f), p.pos.add(0, 1.5, 0), 12, 260, 0);
            for (ServerPlayerEntity pl : p.w.getPlayers()) {
                if (pl.isCreative() || pl.isSpectator() || pl.getEntityPos().distanceTo(p.pos) > 12) continue;
                pl.damage(p.w, p.w.getDamageSources().magic(), 14f);
                Fx.bolt(p.w, Fx.dust(0xFFFFFF, 1.2f), p.pos.add(0, 3, 0), Fx.mid(pl), 0.4, 0.3);
            }
        }
    }

    // ---------- tu xuat hien ban dem ----------
    private static void naturalSpawns(MinecraftServer server) {
        if (!Config.naturalMobs) return;
        for (ServerWorld w : server.getWorlds()) {
            long tod = w.getTimeOfDay() % 24000L;
            if (tod < 13000 || tod > 23000) continue;
            for (ServerPlayerEntity pl : w.getPlayers()) {
                if (pl.isSpectator() || Fx.rnd() > 0.25) continue;
                int near = w.getEntitiesByClass(LivingEntity.class, pl.getBoundingBox().expand(48), e -> e.getCommandTags().contains("jjk_mob")).size();
                if (near >= 4) continue;
                double ang = Fx.rnd() * Math.PI * 2, r = Fx.rnd(18, 30);
                int x = (int) (pl.getX() + Math.cos(ang) * r), z = (int) (pl.getZ() + Math.sin(ang) * r);
                int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING, x, z);
                double roll = Fx.rnd();
                int idx = roll < 0.55 ? 0 : roll < 0.85 ? 1 : roll < 0.95 ? 2 : (3 + (int) (Fx.rnd() * 3));   // rat hiem: Mahito/Jogo/Hanami
                spawn(w, idx, new Vec3d(x + 0.5, y, z + 0.5));
            }
        }
    }
}
