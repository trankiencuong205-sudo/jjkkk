package com.example.jjk;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

import java.util.Locale;

/**
 * Trang phuc cho 13 nhan vat. Moi bo = 4 mon giap da, gan component equippable tro toi asset_id "jjk:<ten>"
 * -> hien thi bang texture rieng (assets/jjk/equipment/<ten>.json + textures/entity/equipment/...).
 * Khong dung API giap cua Java, chi dung lenh /item replace. Neu lenh bi tu choi, thu lai chi nhuom mau da.
 */
public class Outfits {
    public static final String[] NAMES = {"gojo", "sukuna", "yuji", "megumi", "todo", "nanami", "nobara", "choso", "jogo", "mahito", "inumaki", "yuta", "toji", "hakari", "higuruma", "kashimo", "maki", "kenjaku"};
    // mau du phong (khi khong co texture) {mu, ao, quan, giay}
    static final int[][] COLORS = {
            {0x101018, 0x15151F, 0x1A1A24, 0x101018}, {0xB07A8A, 0xE8A0B0, 0x2A1A2A, 0x201018},
            {0xC03A20, 0x1E2848, 0x1E2848, 0x141828}, {0x141C2C, 0x182030, 0x182030, 0x101620},
            {0x4A3A30, 0x7A5A8A, 0x3A3A4A, 0x2A2420}, {0xE0D098, 0xD8C8A0, 0xC8B890, 0x4A3A2A},
            {0xB8683A, 0xC08040, 0x4A3A30, 0x2A2018}, {0x2A1A18, 0x6A4A3A, 0x4A3A30, 0x2A2018},
            {0xFF7A20, 0x6A5A50, 0x4A4038, 0x2A2420}, {0x9AA0B0, 0x7A8AA0, 0x5A6A80, 0x3A4458},
            {0xE8E8F0, 0xE0E0EA, 0xD0D0DC, 0x303040}, {0x101010, 0xF0F0F0, 0xE8E8E8, 0x202020},
            {0x202020, 0x1C1C1C, 0x242424, 0x181818},
            {0xF0D860, 0xC8A030, 0x2A2A30, 0x4A3A2A}, {0x2A2A30, 0x2A2A32, 0x2A2A32, 0x141418},
            {0x202028, 0x1E1E28, 0x1E1E28, 0x14141C}, {0x1A1A22, 0x1E3A2A, 0x1E3A2A, 0x141C18},
            {0x14141A, 0x26263A, 0x26263A, 0x14141C}};
    static final String[] ITEMS = {"leather_helmet", "leather_chestplate", "leather_leggings", "leather_boots"};
    static final String[] SLOT = {"head", "chest", "legs", "feet"};
    static final String[] CMD_SLOT = {"armor.head", "armor.chest", "armor.legs", "armor.feet"};
    static final String[] PIECE_VN = {"Mu / toc", "Ao", "Quan", "Giay"};

    /** SNBT item dung cho mob (equipment:{head:...}) */
    public static String mobItem(int piece, String outfit) {
        return "{id:\"minecraft:" + ITEMS[piece] + "\",count:1,components:{\"minecraft:equippable\":{slot:\"" + SLOT[piece] + "\",asset_id:\"jjk:" + outfit + "\"}}}";
    }

    public static String mobEquipment(String outfit) {
        return "head:" + mobItem(0, outfit) + ",chest:" + mobItem(1, outfit) + ",legs:" + mobItem(2, outfit) + ",feet:" + mobItem(3, outfit);
    }

    /** mac bo trang phuc (thay giap dang mac). chara < 0 = thao het. Tra ve true neu lenh chay duoc. */
    public static boolean wear(ServerWorld w, ServerPlayerEntity p, int chara) {
        String t = p.getUuid().toString();
        if (chara < 0) {
            for (String s : CMD_SLOT) Disp.tryRun(w, "item replace entity " + t + " " + s + " with minecraft:air");
            return true;
        }
        if (chara >= NAMES.length) return false;
        Tech.Chara c = Tech.Chara.values()[chara];
        boolean ok = true;
        for (int i = 0; i < 4; i++) {
            String nm = String.format(Locale.ROOT, "{text:\"%s - %s\",italic:false,color:\"gold\"}", c.title, PIECE_VN[i]);
            String a = String.format(Locale.ROOT, "item replace entity %s %s with minecraft:%s[equippable={slot:\"%s\",asset_id:\"jjk:%s\"},custom_name=%s,unbreakable={}]",
                    t, CMD_SLOT[i], ITEMS[i], SLOT[i], NAMES[chara], nm);
            String b = String.format(Locale.ROOT, "item replace entity %s %s with minecraft:%s[dyed_color=%d,custom_name=%s]", t, CMD_SLOT[i], ITEMS[i], COLORS[chara][i], nm);
            if (!Disp.tryRun(w, a) && !Disp.tryRun(w, b)) ok = false;
        }
        return ok;
    }
}
