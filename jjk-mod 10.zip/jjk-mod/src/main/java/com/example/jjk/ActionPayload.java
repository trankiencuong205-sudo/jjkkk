package com.example.jjk;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/**
 * action: 0 chon nhan vat(a) | 2 xin dong bo | 3 dung ky nang o o a | 4 dung ky nang (chi so a trong danh sach)
 *         7 trang bi: o a <- ky nang chi so b | 8 xoa o a | 9 dat lai o mac dinh
 */
public record ActionPayload(int action, int a, int b) implements CustomPayload {
    public static final CustomPayload.Id<ActionPayload> ID = new CustomPayload.Id<>(Identifier.of(Jjk.ID, "action"));
    public static final PacketCodec<RegistryByteBuf, ActionPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, ActionPayload::action,
            PacketCodecs.VAR_INT, ActionPayload::a,
            PacketCodecs.VAR_INT, ActionPayload::b,
            ActionPayload::new);

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
}
