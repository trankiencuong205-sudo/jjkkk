package com.example.jjk;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Giai doan 3: Hakari, Higuruma, Kashimo, Maki, Kenjaku + domain moi (xem Domains). */
public class Stage3Skills {
    static final Map<UUID, Integer> UZUMAKI = new HashMap<>();

    public static void dispatch(String id, ServerWorld w, ServerPlayerEntity p) {
        switch (id) {
            case "chimera_garden" -> Domains.garden(w, p);
            case "self_embodiment" -> Domains.flesh(w, p);
            case "idle_death_gamble" -> Domains.gamble(w, p);
            case "deadly_sentencing" -> Domains.court(w, p);
            case "shutter_doors" -> shutterDoors(w, p);
            case "executioners_sword" -> executioner(w, p);
            case "confiscation" -> confiscation(w, p);
            case "lightning_discharge" -> discharge(w, p);
            case "lightning_dash" -> dash(w, p);
            case "mythical_beast_amber" -> amber(w, p);
            case "split_soul_katana" -> soulKatana(w, p);
            case "slash_flurry" -> flurry(w, p);
            case "uzumaki_absorb" -> absorb(w, p);
            case "maximum_uzumaki" -> uzumaki(w, p);
            default -> { }
        }
    }

    static int dust(int c) { return c; }

    // ---------- Hakari ----------
    static void shutterDoors(ServerWorld w, ServerPlayerEntity p) {
        float dmg = Domains.jackpot(p.getUuid()) ? 6.0f : 3.0f;
        Fx.snd(w, p.getEntityPos(), SoundEvents.ENTITY_IRON_GOLEM_ATTACK, 1.2f, 1.4f);
        Anims.add(new Anims.Anim() {
            int n = 0;
            public boolean tick() {
                if (p.isRemoved() || !p.isAlive()) return true;
                n++;
                if (n % 2 == 0) {
                    Vec3d eye = p.getEyePos(), look = p.getRotationVec(1f);
                    Vec3d hit = eye.add(look.multiply(2.2));
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(hit, hit).expand(2.2))) {
                        Fx.hurt(w, p, e, dmg);
                        Fx.put(w, ParticleTypes.CRIT, Fx.mid(e), 6, 0.4, 0.2);
                        Fx.put(w, Fx.dust(0xFF40D0, 1.3f), Fx.mid(e), 6, 0.4, 0.1);
                    }
                    Vec3d[] b = Fx.basis(look);
                    Vis3D.panel(w, hit.add(b[1].multiply(Fx.rnd(-0.6, 0.6))).add(b[2].multiply(Fx.rnd(-0.4, 0.8))), look, n % 4 == 0 ? "pink_concrete" : "yellow_stained_glass", 2.4, 6);
                    Fx.ring(w, Fx.dust(n % 4 == 0 ? 0xFF40D0 : 0xFFD040, 1.4f), hit, b[1], b[2], 1.0 + (n % 6) * 0.2, 24, n);
                    Fx.snd(w, hit, SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, 1f, 1.0f + (float) Fx.rnd(0, 0.5));
                }
                return n >= 20;
            }
        });
    }

    // ---------- Higuruma ----------
    /** Thanh kiem khong lo rot xuong muc tieu */
    static void swordDrop(ServerWorld w, ServerPlayerEntity p, LivingEntity t, float dmg, boolean execute) {
        Vec3d top = t.getEntityPos().add(0, 10, 0);
        Disp.H blade = Config.displays ? Disp.block(w, top, "iron_block", 0.35, 6, 0.9, Disp.Q.ID, 40) : null;
        Disp.H guard = Config.displays ? Disp.block(w, top.add(0, 3.2, 0), "gold_block", 1.5, 0.3, 0.5, Disp.Q.ID, 40) : null;
        Disp.H grip = Config.displays ? Disp.block(w, top.add(0, 4.3, 0), "dark_oak_log", 0.25, 2, 0.25, Disp.Q.ID, 40) : null;
        Anims.add(new Anims.Anim() {
            int n = 0;
            public boolean tick() {
                n++;
                Vec3d g = t.getEntityPos();
                double y = g.y + 10 - n * (10.0 / 8);
                if (blade != null) { blade.move(new Vec3d(g.x, y + 3, g.z)); guard.move(new Vec3d(g.x, y + 6.2, g.z)); grip.move(new Vec3d(g.x, y + 7.3, g.z)); }
                Fx.line(w, Fx.dust(0xFFE070, 1.0f), new Vec3d(g.x, y + 6, g.z), new Vec3d(g.x, y, g.z), 0.5);
                if (n >= 8) {
                    Vec3d m = Fx.mid(t);
                    if (t.isAlive()) {
                        boolean low = t.getHealth() < t.getMaxHealth() * 0.35;
                        Fx.hurt(w, p, t, execute && low ? 9999f : dmg);
                    }
                    Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
                    for (int r = 1; r <= 3; r++) Fx.ring(w, Fx.dust(0xFFD040, 1.6f), g.add(0, 0.2, 0), b[1], b[2], r * 1.1, 30, 0);
                    Fx.put(w, ParticleTypes.EXPLOSION, m, 1, 0, 0);
                    Fx.snd(w, m, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 1.0f, 1.4f);
                    if (blade != null) { blade.kill(); guard.kill(); grip.kill(); }
                    return true;
                }
                return false;
            }
        });
    }

    static void executioner(ServerWorld w, ServerPlayerEntity p) {
        LivingEntity t = Stage2Skills.aim(w, p, 14);
        if (t == null) { Stage2Skills.msg(p, "Can ngam vao muc tieu (<=14 o)"); return; }
        swordDrop(w, p, t, 25f, true);
    }

    static void confiscation(ServerWorld w, ServerPlayerEntity p) {
        LivingEntity t = Stage2Skills.aim(w, p, 10);
        if (t == null) { Stage2Skills.msg(p, "Can ngam vao muc tieu (<=10 o)"); return; }
        t.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 200, 2));
        t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 200, 1));
        t.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, 200, 2));
        Fx.hurt(w, p, t, 4f);
        Vec3d m = Fx.mid(t);
        for (int i = 0; i < 8; i++) Fx.line(w, Fx.dust(0xFFD040, 1.1f), m.add(Fx.randDir().multiply(3)), m, 0.3);
        Fx.sphere(w, Fx.dust(0xFFE070, 1.4f), m, 1.0, 50, 0);
        Fx.snd(w, m, SoundEvents.BLOCK_ANVIL_LAND, 1.0f, 1.4f);
    }

    // ---------- Kashimo ----------
    static void discharge(ServerWorld w, ServerPlayerEntity p) {
        LivingEntity first = Stage2Skills.aim(w, p, 18);
        Vec3d from = p.getEyePos().add(0, -0.3, 0);
        if (first == null) {
            Vec3d end = Stage2Skills.rayEnd(w, p, 18);
            Fx.bolt(w, Fx.dust(0x80E0FF, 1.3f), from, end, 0.5, 0.3);
            Vis3D.bolt(w, from, end, 0.14, 8);
            Fx.snd(w, from, SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 0.8f, 1.6f);
            return;
        }
        List<LivingEntity> hit = new ArrayList<>();
        hit.add(first);
        float[] dm = {14, 10, 8, 6};
        LivingEntity cur = first;
        for (int i = 1; i < 4; i++) {
            LivingEntity best = null; double bd = 99;
            for (LivingEntity e : Fx.hostiles(w, p, cur.getBoundingBox().expand(7))) {
                if (hit.contains(e)) continue;
                double d = e.getEntityPos().distanceTo(cur.getEntityPos());
                if (d < bd) { bd = d; best = e; }
            }
            if (best == null) break;
            hit.add(best); cur = best;
        }
        Vec3d prev = from;
        for (int i = 0; i < hit.size(); i++) {
            LivingEntity e = hit.get(i);
            Vec3d m = Fx.mid(e);
            Fx.bolt(w, Fx.dust(i == 0 ? 0xFFFFFF : 0x60C0FF, 1.4f), prev, m, 0.5, 0.3);
            Fx.bolt(w, Fx.dust(0xFFF080, 1.0f), prev, m, 0.8, 0.4);
            Vis3D.bolt(w, prev, m, 0.14, 8);
            Fx.hurt(w, p, e, dm[i]);
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 30, 6));
            Fx.put(w, ParticleTypes.ELECTRIC_SPARK, m, 20, 0.5, 0.3);
            prev = m;
        }
        Fx.snd(w, first.getEntityPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT, 1.2f, 1.5f);
    }

    static void dash(ServerWorld w, ServerPlayerEntity p) {
        Vec3d start = p.getEntityPos(), look = p.getRotationVec(1f);
        Vec3d dir = new Vec3d(look.x, 0, look.z);
        if (dir.lengthSquared() < 1.0E-4) return;
        dir = dir.normalize();
        Vec3d pos = start;
        for (double d = 1; d <= 14; d += 1) {
            Vec3d v = start.add(dir.multiply(d));
            if (!w.isAir(BlockPos.ofFloored(v.add(0, 0.5, 0))) || !w.isAir(BlockPos.ofFloored(v.add(0, 1.5, 0)))) break;
            pos = v;
        }
        for (LivingEntity e : Fx.hostiles(w, p, new Box(start, pos).expand(1.6, 1.5, 1.6))) {
            Fx.hurt(w, p, e, 12f);
            Fx.put(w, ParticleTypes.ELECTRIC_SPARK, Fx.mid(e), 16, 0.4, 0.3);
        }
        for (int i = 0; i < 4; i++) Fx.bolt(w, Fx.dust(i % 2 == 0 ? 0xFFFFFF : 0x50B0FF, 1.4f), start.add(0, 1, 0), pos.add(0, 1, 0), 0.5, 0.3);
        Vis3D.bolt(w, start.add(0, 1, 0), pos.add(0, 1, 0), 0.2, 8);
        Vis3D.bolt(w, start.add(0, 0.5, 0), pos.add(0, 1.5, 0), 0.12, 8);
        p.requestTeleport(pos.x, pos.y, pos.z);
        Fx.snd(w, start, SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 0.7f, 2.0f);
    }

    static void amber(ServerWorld w, ServerPlayerEntity p) {
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 300, 2));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 300, 1));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 300, 0));
        Fx.snd(w, p.getEntityPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 1.2f, 1.2f);
        Anims.add(new Anims.Anim() {
            int n = 0;
            public boolean tick() {
                if (p.isRemoved() || !p.isAlive()) return true;
                n++;
                Vec3d c = p.getEntityPos().add(0, 1, 0);
                if (n % 2 == 0) for (int i = 0; i < 3; i++) Fx.bolt(w, Fx.dust(i == 0 ? 0xFFFFFF : 0x60C0FF, 1.1f), c, c.add(Fx.randDir().multiply(Fx.rnd(1.2, 2.4))), 0.3, 0.3);
                if (n % 6 == 0) Vis3D.bolt(w, c, c.add(Fx.randDir().multiply(Fx.rnd(1.5, 2.6))), 0.07, 4);
                if (n % 5 == 0) for (LivingEntity e : Fx.hostiles(w, p, p.getBoundingBox().expand(3))) {
                    Fx.hurt(w, p, e, 3f);
                    Fx.put(w, ParticleTypes.ELECTRIC_SPARK, Fx.mid(e), 6, 0.3, 0.2);
                }
                return n >= 300;
            }
        });
    }

    // ---------- Maki ----------
    static void soulKatana(ServerWorld w, ServerPlayerEntity p) {
        LivingEntity t = Stage2Skills.aim(w, p, 5);
        Vec3d look = p.getRotationVec(1f), c = p.getEyePos().add(look.multiply(2));
        Vec3d[] b = Fx.basis(look);
        Fx.arc(w, Fx.dust(0xE8FFF0, 1.5f), c, b[1], b[2], 2.4, -1.4, 1.4, 36);
        Fx.arc(w, Fx.dust(0x40D090, 1.2f), c, b[1], b[2], 2.5, -1.3, 1.3, 30);
        if (Config.displays) {
            new Disp.Crescent(w, c, b[1], look, 2.6, 0.5, 0.35, "white_concrete", 8, 6);
            new Disp.Crescent(w, c, b[1], look, 2.8, 0.55, 0.9, "green_stained_glass", 8, 8);
        }
        Fx.snd(w, c, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.2f, 1.2f);
        if (t == null) return;
        float d = 22f + (float) Math.min(18, t.getMaxHealth() * 0.10);
        Fx.hurt(w, p, t, d);
        Fx.put(w, Fx.dust(0xA0FFD0, 1.6f), Fx.mid(t), 14, 0.5, 0.2);
    }

    static void flurry(ServerWorld w, ServerPlayerEntity p) {
        Anims.add(new Anims.Anim() {
            int n = 0;
            public boolean tick() {
                if (p.isRemoved() || !p.isAlive()) return true;
                n++;
                if (n % 2 == 0) {
                    Vec3d look = p.getRotationVec(1f), c = p.getEyePos().add(look.multiply(2));
                    Vec3d[] b = Fx.basis(look);
                    double tilt = (n / 2) * 0.9;
                    Vec3d u = b[1].multiply(Math.cos(tilt)).add(b[2].multiply(Math.sin(tilt)));
                    Vec3d v = b[1].multiply(-Math.sin(tilt)).add(b[2].multiply(Math.cos(tilt)));
                    Fx.arc(w, Fx.dust(0xE8FFF0, 1.4f), c, u, v, 2.2, -1.2, 1.2, 28);
                    if (Config.displays) {
                        new Disp.Crescent(w, c, u, look, 2.4, 0.5, 0.3, "white_concrete", 8, 5);
                        new Disp.Crescent(w, c, u, look, 2.6, 0.55, 0.8, "green_stained_glass", 8, 6);
                    }
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(c, c).expand(2.4))) Fx.hurt(w, p, e, 4f);
                    Fx.snd(w, c, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 1.0f + (float) Fx.rnd(0, 0.5));
                }
                return n >= 12;
            }
        });
    }

    // ---------- Kenjaku ----------
    static void absorb(ServerWorld w, ServerPlayerEntity p) {
        Vec3d c = p.getEntityPos().add(0, 1, 0);
        Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
        Fx.ring(w, Fx.dust(0x9A60C0, 1.6f), c, b[1], b[2], 10, 80, 0);
        int got = 0;
        for (LivingEntity e : Fx.hostiles(w, p, p.getBoundingBox().expand(10))) {
            if (e.getEntityPos().distanceTo(p.getEntityPos()) > 10) continue;
            Fx.line(w, Fx.dust(0xB080E0, 1.2f), Fx.mid(e), c, 0.35);
            Fx.hurt(w, p, e, 10f);
            if (!e.isAlive() || e.getHealth() <= 0) {
                got++;
                Data.addEnergy(p.getUuid(), 30);
                UZUMAKI.merge(p.getUuid(), 1, (a, x) -> Math.min(10, a + x));
            }
        }
        Fx.sphere(w, Fx.dust(0x6A30A0, 1.4f), c, 1.2, 40, 0);
        Vis3D.blackHole(w, c);
        if (got > 0) Stage2Skills.msg(p, "Hap thu " + got + " | Uzumaki x" + UZUMAKI.getOrDefault(p.getUuid(), 0));
        Fx.snd(w, c, SoundEvents.ENTITY_ENDERMAN_SCREAM, 0.8f, 0.5f);
    }

    static void uzumaki(ServerWorld w, ServerPlayerEntity p) {
        int stacks = UZUMAKI.getOrDefault(p.getUuid(), 0);
        UZUMAKI.remove(p.getUuid());
        float dmg = 15f + 12f * stacks;
        Vec3d from = p.getEyePos().add(0, -0.2, 0), look = p.getRotationVec(1f);
        Vec3d to = from.add(look.multiply(40));
        Fx.snd(w, from, SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 1.5f, 0.7f);
        Vec3d[] b = Fx.basis(look);
        Anims.add(new Anims.Anim() {
            int n = 0;
            Disp.Beam beam = Config.displays ? new Disp.Beam(w, from, to, "purple_stained_glass", "magenta_concrete", 1.2, 14) : null;
            public boolean tick() {
                n++;
                for (double d = 0; d < 40; d += 0.9) {
                    double a = d * 0.7 + n * 0.6, r = 0.9 + d * 0.02;
                    Vec3d ctr = from.add(look.multiply(d));
                    Fx.pt(w, Fx.dust(0xB050FF, 1.4f), ctr.add(b[1].multiply(Math.cos(a) * r)).add(b[2].multiply(Math.sin(a) * r)));
                    Fx.pt(w, Fx.dust(0xFFFFFF, 0.8f), ctr.add(b[1].multiply(-Math.cos(a) * r * 0.6)).add(b[2].multiply(-Math.sin(a) * r * 0.6)));
                }
                if (n == 3) {
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(from, to).expand(2.5))) {
                        Vec3d m = Fx.mid(e).subtract(from);
                        double along = m.dotProduct(look);
                        if (along < 0 || along > 40) continue;
                        if (m.subtract(look.multiply(along)).length() > 2.5) continue;
                        Fx.hurt(w, p, e, dmg);
                        Fx.put(w, ParticleTypes.EXPLOSION, Fx.mid(e), 1, 0, 0);
                    }
                }
                if (n >= 12) { if (beam != null) beam.kill(); return true; }
                return false;
            }
        });
    }
}
