package com.example.jjk;

import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** Sukuna: Cleave, Dismantle, Fire Arrow, Malevolent Shrine. */
public class SukunaSkills {
    static ParticleEffect red(float s) { return Fx.dust(0xFF2030, s); }
    static ParticleEffect dark(float s) { return Fx.dust(0x14000A, s); }
    static ParticleEffect pale(float s) { return Fx.dust(0xFFE0E4, s); }

    /** nhat chem cong: duong cong tu -L den +L quanh tam, truc u, cong ve phia 'dir' */
    static void slashCurve(ServerWorld w, Vec3d c, Vec3d u, Vec3d dir, double L, double bend, double s0, double s1, float size) {
        int n = (int) (Math.abs(s1 - s0) * L * 3) + 2;
        for (int i = 0; i <= n; i++) {
            double s = s0 + (s1 - s0) * i / n;
            Vec3d p = c.add(u.multiply(s * L)).subtract(dir.multiply(bend * s * s));
            Fx.pt(w, red(size), p);
            Fx.pt(w, pale(size * 0.55f), p);
            if (i % 2 == 0) Fx.pt(w, dark(size * 1.3f), p.add(Fx.rnd(-0.08, 0.08), Fx.rnd(-0.08, 0.08), Fx.rnd(-0.08, 0.08)));
        }
    }

    // ====================== CLEAVE ======================
    public static void cleave(ServerWorld w, ServerPlayerEntity p) {
        Vec3d eye = p.getEyePos(), look = p.getRotationVec(1.0f);
        Vec3d[] b = Fx.basis(look);
        double tilt = Fx.rnd(-0.9, 0.9);
        Vec3d u = b[1].multiply(Math.cos(tilt)).add(b[2].multiply(Math.sin(tilt))).normalize();
        Vec3d center = eye.add(look.multiply(4.5));
        Fx.snd(w, eye, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.4f, 0.5f);
        Fx.snd(w, eye, SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, 1.0f, 0.6f);
        if (Config.displays) {
            new Disp.Crescent(w, center, u, look, 4.8, 0.7, 1.1, "red_stained_glass", 10, 9);
            new Disp.Crescent(w, center, u, look, 4.6, 0.7, 0.45, "white_concrete", 10, 7);
            new Disp.Crescent(w, center.add(look.multiply(0.15)), u, look, 5.2, 0.8, 0.3, "black_stained_glass", 10, 11);
        }
        List<LivingEntity> targets = Fx.hostiles(w, p, new Box(eye, eye.add(look.multiply(9))).expand(1.4));
        for (LivingEntity e : targets) {
            float dmg = (float) Math.min(60.0, 6.0 + 0.25 * e.getMaxHealth());
            Fx.hurt(w, p, e, dmg);
            Vec3d mid = Fx.mid(e);
            // vet cat doc theo than muc tieu, ton tai vai tick
            Anims.add(new Anims.Anim() {
                int t = 0;
                public boolean tick() {
                    t++;
                    Vec3d a = mid.add(u.multiply(1.6)).add(0, 0.4, 0), c2 = mid.subtract(u.multiply(1.6)).add(0, -0.4, 0);
                    Fx.line(w, t < 4 ? red(1.3f) : pale(0.8f), a, c2, 0.3);
                    return t >= 6;
                }
            });
            Fx.put(w, red(1.5f), mid, 20, 0.5, 0);
        }
        Anims.add(new Anims.Anim() {
            int t = 0;
            public boolean tick() {
                t++;
                double ext = Math.min(1.0, t / 3.0);
                if (t <= 8 && !Config.displays) slashCurve(w, center, u, look, 4.6, 0.12, -ext, ext, 1.5f - t * 0.1f);
                if (t == 1) for (int i = 0; i < 24; i++) Fx.pt(w, ParticleTypes.CRIT, center.add(u.multiply(Fx.rnd(-4.6, 4.6))));
                return t >= 8;
            }
        });
    }

    // ====================== DISMANTLE ======================
    public static void dismantle(ServerWorld w, ServerPlayerEntity p) {
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d[] b = Fx.basis(look);
        Fx.snd(w, p.getEyePos(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.3f, 1.4f);
        Anims.add(new Anims.Anim() {
            int t = 0;
            public boolean tick() {
                if (t < 5) {
                    double spread = (t - 2) * 0.11;
                    Vec3d dir = look.add(b[1].multiply(spread)).add(b[2].multiply(Fx.rnd(-0.06, 0.06))).normalize();
                    double roll = Fx.rnd(-1.1, 1.1);
                    Anims.add(new Blade(w, p, p.getEyePos().add(dir.multiply(1.4)).add(0, -0.3, 0), dir, roll));
                    Fx.snd(w, p.getEyePos(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 0.7f, 1.8f);
                }
                t++;
                return t >= 5;
            }
        });
    }

    private static class Blade implements Anims.Anim {
        final ServerWorld w; final ServerPlayerEntity p; Vec3d pos, dir, u; int t = 0; final Set<UUID> hit = new HashSet<>();
        final List<Vec3d> trail = new ArrayList<>(); Disp.Crescent cres;
        Blade(ServerWorld w, ServerPlayerEntity p, Vec3d pos, Vec3d dir, double roll) {
            this.w = w; this.p = p; this.pos = pos; this.dir = dir;
            Vec3d[] b = Fx.basis(dir);
            u = b[1].multiply(Math.cos(roll)).add(b[2].multiply(Math.sin(roll))).normalize();
            if (Config.displays) cres = new Disp.Crescent(w, pos, u, dir, 1.1, 0.5, 0.55, "red_stained_glass", 5, 24);
        }
        public boolean tick() {
            t++;
            pos = pos.add(dir.multiply(1.6));
            trail.add(pos);
            if (trail.size() > 4) trail.remove(0);
            if (cres != null) cres.moveTo(pos);
            else for (int i = 0; i < trail.size(); i++) {
                float s = 0.5f + 0.2f * i;
                slashCurve(w, trail.get(i), u, dir, 1.0, 0.45, -1, 1, s);
            }
            for (LivingEntity e : Fx.hostiles(w, p, new Box(pos, pos).expand(1.0))) {
                if (hit.add(e.getUuid())) {
                    Fx.hurt(w, p, e, 6.0f);
                    e.addVelocity(dir.x * 0.25, 0.1, dir.z * 0.25);
                    Fx.put(w, red(1.3f), Fx.mid(e), 10, 0.4, 0);
                    Fx.pt(w, ParticleTypes.SWEEP_ATTACK, Fx.mid(e));
                }
            }
            if (!w.isAir(BlockPos.ofFloored(pos))) {
                Fx.put(w, pale(1.0f), pos, 8, 0.3, 0);
                if (cres != null) cres.kill();
                return true;
            }
            boolean done = t >= 12 || p.isRemoved();
            if (done && cres != null) cres.kill();
            return done;
        }
    }

    // ====================== FIRE ARROW ======================
    public static void fireArrow(ServerWorld w, ServerPlayerEntity p) { Anims.add(new Fuga(w, p)); }

    private static class Fuga implements Anims.Anim {
        static final int CHARGE = 14, FLY = 28;
        final ServerWorld w; final ServerPlayerEntity p; int t = 0, ft = 0, bt = 0; int phase = 0; Vec3d pos, dir, bc;
        final Set<UUID> hit = new HashSet<>(); Disp.Beam arrow; Disp.Orb head, boomOrb;
        static ParticleEffect fire(float s) { return Fx.dust(0xFF7A1A, s); }
        static ParticleEffect gold(float s) { return Fx.dust(0xFFD040, s); }
        Fuga(ServerWorld w, ServerPlayerEntity p) {
            this.w = w; this.p = p;
            Fx.snd(w, p.getEntityPos(), SoundEvents.ITEM_FIRECHARGE_USE, 1.4f, 0.5f);
        }
        public boolean tick() {
            if (p.isRemoved()) return true;
            if (phase == 0) {
                t++;
                Vec3d look = p.getRotationVec(1.0f);
                Vec3d[] b = Fx.basis(look);
                Vec3d c = p.getEyePos().add(look.multiply(2.2)).add(0, -0.2, 0);
                double k = t / (double) CHARGE;
                // vong lua "huy hieu" (2 vong + 8 tia) xoay quanh huong nham
                Fx.ring(w, fire(1.5f), c, b[1], b[2], 1.5, 40, t * 0.25);
                Fx.ring(w, gold(1.1f), c, b[1], b[2], 0.9, 26, -t * 0.4);
                for (int i = 0; i < 8; i++) {
                    double a = t * 0.25 + i * Math.PI / 4;
                    Vec3d d = b[1].multiply(Math.cos(a)).add(b[2].multiply(Math.sin(a)));
                    Fx.line(w, fire(1.0f), c.add(d.multiply(0.9)), c.add(d.multiply(1.5)), 0.3);
                }
                // mui ten lua hinh thanh theo tien trinh
                Vec3d tail = c.subtract(look.multiply(1.8)), tip = c.add(look.multiply(2.0 * k));
                Fx.line(w, gold(1.3f), tail, tip, 0.3);
                Fx.line(w, fire(1.7f), tail.add(0, 0.05, 0), tip, 0.35);
                for (int i = 0; i < 4; i++) Fx.pt(w, ParticleTypes.FLAME, tail.add(look.multiply(Fx.rnd(0, 3.8 * k))).add(Fx.rnd(-0.1, 0.1), Fx.rnd(-0.1, 0.1), Fx.rnd(-0.1, 0.1)));
                if (t >= CHARGE) {
                    phase = 1; dir = look; pos = c;
                    if (Config.displays) {
                        arrow = new Disp.Beam(w, c.subtract(dir.multiply(4)), c, "orange_stained_glass", "yellow_concrete", 0.5, 70);
                        head = new Disp.Orb(w, c, "orange_stained_glass", "yellow_concrete", "red_stained_glass", 0.9, 70);
                    }
                    Fx.snd(w, c, SoundEvents.ENTITY_BLAZE_SHOOT, 2.0f, 0.5f);
                    Fx.snd(w, c, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 0.8f, 1.8f);
                }
                return false;
            }
            if (phase == 1) {
                ft++;
                pos = pos.add(dir.multiply(2.2));
                Vec3d[] b = Fx.basis(dir);
                if (arrow != null) {
                    arrow.update(pos.subtract(dir.multiply(4.5)), pos, 0.5);
                    head.update(pos.add(dir.multiply(0.6)), ft * 0.5, 1.0, ft % 3 == 0);
                } else {
                    Fx.line(w, gold(1.4f), pos.subtract(dir.multiply(2.6)), pos, 0.3);
                    Fx.line(w, fire(1.8f), pos.subtract(dir.multiply(5.0)), pos, 0.5);
                }
                Fx.put(w, ParticleTypes.FLAME, pos, 5, 0.25, 0.05);
                Fx.put(w, ParticleTypes.LARGE_SMOKE, pos.subtract(dir.multiply(1.5)), 2, 0.3, 0.02);
                Fx.ring(w, fire(1.2f), pos.subtract(dir.multiply(0.5)), b[1], b[2], 0.7, 16, ft);
                boolean blk = !w.isAir(BlockPos.ofFloored(pos));
                boolean mob = !Fx.hostiles(w, p, new Box(pos, pos).expand(1.5)).isEmpty();
                if (blk || mob || ft >= FLY) {
                    phase = 2; bc = pos.subtract(dir.multiply(0.8));
                    if (arrow != null) { arrow.kill(); head.kill(); arrow = null; head = null; boomOrb = new Disp.Orb(w, bc, "orange_stained_glass", "yellow_concrete", "red_stained_glass", 1.0, 30); }
                    Fx.snd(w, bc, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 2.0f, 0.6f);
                    Fx.put(w, ParticleTypes.EXPLOSION_EMITTER, bc, 1, 0, 0);
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(bc, bc).expand(7))) {
                        double d = Fx.mid(e).distanceTo(bc);
                        double f = Math.max(0.3, 1.0 - d / 8.0);
                        Fx.hurt(w, p, e, (float) (30.0 * f));
                        e.setFireTicks(160);
                        Vec3d away = Fx.mid(e).subtract(bc).normalize();
                        e.addVelocity(away.x * 1.2 * f, 0.5, away.z * 1.2 * f);
                    }
                }
                return false;
            }
            bt++;
            if (boomOrb != null) { boomOrb.update(bc, bt * 0.4, 1.0 + bt * 1.3, true); if (bt >= 9) boomOrb.kill(); }
            Vec3d[] hb = Fx.basis(new Vec3d(0, 1, 0));
            double r = bt * 1.2;
            for (int s = 0; s < 3; s++) Fx.sphere(w, s == 0 ? gold(1.6f) : fire(1.6f - s * 0.2f), bc, Math.max(0.5, r - s * 0.9), 40, bt * 0.4 + s);
            Fx.ring(w, fire(1.8f), bc, hb[1], hb[2], r * 1.3, 50, 0);
            for (double y = 0; y < bt * 1.6; y += 0.7) {                                // cot lua
                Vec3d cp = bc.add(Fx.rnd(-0.6, 0.6), y, Fx.rnd(-0.6, 0.6));
                Fx.pt(w, ParticleTypes.FLAME, cp);
                Fx.pt(w, fire(1.6f), cp);
            }
            return bt >= 9;
        }
    }

    // ====================== MALEVOLENT SHRINE ======================
    public static void shrine(ServerWorld w, ServerPlayerEntity p) { Anims.add(new Shrine(w, p)); }

    private static class Shrine implements Anims.Anim {
        static final double R = 16; static final int RISE = 30, FADE = 10;
        final ServerWorld w; final ServerPlayerEntity p; final Vec3d c; int t = 0, et = 0; boolean ending = false; final int dur;
        final List<Vec3d> pts = new ArrayList<>(); final List<Integer> cols = new ArrayList<>(); final Domains.Scene scene;
        Shrine(ServerWorld w, ServerPlayerEntity p) {
            this.w = w; this.p = p;
            c = p.getEntityPos();
            dur = Config.domainSeconds * 16;   // ~8s khi domainSeconds=10
            Data.DOMAIN_END.put(p.getUuid(), Data.now + RISE + dur + FADE);
            build();
            scene = Domains.shrineScene(w, p.getEntityPos(), RISE + dur + FADE + 20);
            Domains.announce(w, p, R, "領域展開", "Malevolent Shrine - 伏魔御廚子", "dark_red");
            Fx.snd(w, c, SoundEvents.ENTITY_WITHER_SPAWN, 1.6f, 0.5f);
            Fx.snd(w, c, SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 1.2f, 0.3f);
        }
        private void add(double x, double y, double z, int col) { pts.add(new Vec3d(x, y, z)); cols.add(col); }
        private void build() {
            int RED = 0xB01020, BLACK = 0x18000A, BONE = 0xEBE2D0, GOLD = 0xD0A030;
            for (int i = 0; i < 96; i++) { double a = i * Math.PI * 2 / 96; add(Math.cos(a) * 14, 0.05, Math.sin(a) * 14, i % 2 == 0 ? RED : BLACK); }
            for (int i = 0; i < 64; i++) { double a = i * Math.PI * 2 / 64; add(Math.cos(a) * 10, 0.05, Math.sin(a) * 10, BLACK); }
            for (int k = 0; k < 8; k++) {                                         // 8 tia tren nen
                double a = k * Math.PI / 4;
                for (double r = 2; r <= 10; r += 0.8) add(Math.cos(a) * r, 0.05, Math.sin(a) * r, RED);
            }
            for (int k = 0; k < 8; k++) {                                         // 8 tru
                double a = k * Math.PI / 4 + Math.PI / 8;
                for (double y = 0; y <= 9; y += 0.6) { add(Math.cos(a) * 9.5, y, Math.sin(a) * 9.5, y > 8 ? GOLD : BLACK); add(Math.cos(a) * 9.5 + 0.2, y, Math.sin(a) * 9.5, RED); }
            }
            double[] half = {11, 8, 5}, hgt = {9, 11.5, 14};
            for (int tier = 0; tier < 3; tier++) {                                // 3 tang mai cong vut
                double H = half[tier];
                for (double s = -H; s <= H; s += 0.7) for (int side = 0; side < 4; side++) {
                    double x = side < 2 ? s : (side == 2 ? H : -H), z = side < 2 ? (side == 0 ? H : -H) : s;
                    double corner = Math.pow(Math.abs(x) / H * Math.abs(z) / H, 3);
                    add(x, hgt[tier] + 2.6 * corner, z, tier == 2 ? GOLD : (side % 2 == 0 ? BLACK : RED));
                }
            }
            for (double y = 14; y <= 20; y += 0.5) add(0, y, 0, BONE);             // cot song
            for (int plane = 0; plane < 2; plane++) for (int side = -1; side <= 1; side += 2) for (int rib = 0; rib < 6; rib++) {
                double yk = 15 + rib * 0.8;
                for (int j = 0; j <= 5; j++) {
                    double a = j / 5.0 * Math.PI / 2;
                    double off = side * 3.4 * Math.sin(a) * (1 - rib * 0.1), yy = yk - 1.8 * (1 - Math.cos(a));
                    if (plane == 0) add(off, yy, 0, BONE); else add(0, yy, off, BONE);
                }
            }
            for (int i = 0; i < 44; i++) {                                         // so
                double y = 1 - 2.0 * (i + 0.5) / 44, rad = Math.sqrt(1 - y * y), th = i * 2.399963;
                add(Math.cos(th) * rad * 1.8, 22 + y * 1.9, Math.sin(th) * rad * 1.5, BONE);
            }
            for (int j = 0; j <= 8; j++) { double a = Math.PI + j / 8.0 * Math.PI; add(Math.cos(a) * 1.2, 20.6 + Math.sin(a) * 0.5, 1.2, BONE); }
        }
        public boolean tick() {
            if (p.isRemoved() || !p.isAlive()) { Data.DOMAIN_END.remove(p.getUuid()); scene.kill(); return true; }
            if (ending) {
                et++;
                if (et == 1) scene.kill();
                Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
                Fx.ring(w, red(1.6f), c.add(0, 0.2, 0), b[1], b[2], R * (1 - et / (double) FADE) + 0.5, 60, 0);
                return et >= FADE;
            }
            t++;
            double rise = Math.min(1.0, t / (double) RISE);
            int step = (t % 4);
            if (step < 2) {                                                        // ve xen ke de giam hat
                for (int i = step; i < pts.size(); i += 2) {
                    Vec3d v = pts.get(i);
                    Fx.pt(w, Fx.dust(cols.get(i), 1.2f), c.add(v.x, v.y * rise, v.z));
                }
            }
            if (t <= RISE) {
                Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
                Fx.ring(w, red(1.8f), c.add(0, 0.2, 0), b[1], b[2], R * rise, 70, 0);
            }
            if (t >= RISE) {
                // chem lien tuc: ngau nhien quanh moi quai + tren nen
                List<LivingEntity> in = new ArrayList<>();
                for (LivingEntity e : Fx.hostiles(w, p, new Box(c, c).expand(R, 12, R))) if (e.getEntityPos().distanceTo(c) <= R + 2) in.add(e);
                for (LivingEntity e : in) {
                    for (int i = 0; i < 2; i++) {
                        Vec3d m = Fx.mid(e), d = Fx.randDir();
                        Fx.line(w, i == 0 ? red(1.2f) : pale(0.8f), m.add(d.multiply(2.2)), m.subtract(d.multiply(2.2)), 0.35);
                    }
                    if (t % 10 == 0) {
                        Fx.hurt(w, p, e, t % 40 == 0 ? 10.0f : 4.0f);
                        Fx.pt(w, ParticleTypes.SWEEP_ATTACK, Fx.mid(e));
                    }
                }
                for (int i = 0; i < 3; i++) {
                    Vec3d a = c.add(Fx.rnd(-R, R) * 0.9, Fx.rnd(0.2, 3), Fx.rnd(-R, R) * 0.9), d = Fx.randDir();
                    Fx.line(w, dark(1.3f), a.add(d.multiply(2)), a.subtract(d.multiply(2)), 0.5);
                }
                if (t % 8 == 0) Fx.snd(w, c, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.2f, 0.7f + (float) Fx.rnd(0, 0.5));
                if (t - RISE >= dur) ending = true;
            }
            return false;
        }
    }
}
