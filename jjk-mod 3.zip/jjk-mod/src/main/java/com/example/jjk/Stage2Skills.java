package com.example.jjk;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Giai doan 2: Megumi, Todo, Nanami, Nobara, Choso, Jogo, Mahito, Inumaki, Yuta, Toji. */
public class Stage2Skills {

    public static void dispatch(String id, ServerWorld w, ServerPlayerEntity p) {
        switch (id) {
            case "nue" -> nue(w, p);
            case "toad" -> toad(w, p);
            case "great_serpent" -> serpent(w, p);
            case "boogie_woogie" -> boogie(w, p);
            case "ratio" -> ratio(w, p);
            case "overtime" -> overtime(w, p);
            case "resonance" -> resonance(w, p);
            case "hairpin" -> hairpin(w, p);
            case "piercing_blood" -> piercingBlood(w, p);
            case "supernova" -> supernova(w, p);
            case "meteor" -> meteor(w, p);
            case "coffin" -> coffin(w, p);
            case "idle_transfig" -> idleTransfig(w, p);
            case "speech_stop" -> speechStop(w, p);
            case "speech_blast" -> speechBlast(w, p);
            case "speech_explode" -> speechExplode(w, p);
            case "rika_beam" -> rikaBeam(w, p);
            case "rika_manifest" -> rikaManifest(w, p);
            case "heavenly_restriction" -> heavenly(w, p);
            case "inverted_spear" -> invertedSpear(w, p);
            case "playful_cloud" -> playfulCloud(w, p);
            default -> { }
        }
    }

    // ---------- tien ich ----------
    static LivingEntity aim(ServerWorld w, ServerPlayerEntity p, double range) {
        Vec3d eye = p.getEyePos(), look = p.getRotationVec(1.0f);
        for (double d = 1; d <= range; d += 0.5) {
            Vec3d v = eye.add(look.multiply(d));
            if (!w.isAir(BlockPos.ofFloored(v))) return null;
            List<LivingEntity> l = Fx.hostiles(w, p, new Box(v, v).expand(0.9));
            if (!l.isEmpty()) return l.get(0);
        }
        return null;
    }

    static Vec3d rayEnd(ServerWorld w, ServerPlayerEntity p, double range) {
        Vec3d eye = p.getEyePos(), look = p.getRotationVec(1.0f), end = eye.add(look.multiply(range));
        for (double d = 1; d <= range; d += 0.5) {
            Vec3d v = eye.add(look.multiply(d));
            if (!w.isAir(BlockPos.ofFloored(v)) || !Fx.hostiles(w, p, new Box(v, v).expand(0.9)).isEmpty()) return v;
        }
        return end;
    }

    static void msg(ServerPlayerEntity p, String s) { p.sendMessage(net.minecraft.text.Text.literal(s).formatted(net.minecraft.util.Formatting.YELLOW), true); }

    static ParticleEffect d(int rgb, float s) { return Fx.dust(rgb, s); }

    // ====================== MEGUMI ======================
    static void nue(ServerWorld w, ServerPlayerEntity p) {
        Vec3d tgt = rayEnd(w, p, 28);
        Vec3d start = p.getEyePos().add(0, 6, 0);
        Fx.snd(w, p.getEntityPos(), SoundEvents.ENTITY_PHANTOM_SWOOP, 1.5f, 0.8f);
        Anims.add(new Anims.Anim() {
            int t = 0; static final int FLY = 20;
            public boolean tick() {
                t++;
                double k = Math.min(1.0, t / (double) FLY);
                Vec3d high = start.add(tgt.subtract(start).multiply(k * 0.5)).add(0, 14 * Math.sin(k * Math.PI * 0.5), 0);
                Vec3d pos = start.add(tgt.subtract(start).multiply(k)).add(0, 14 * (1 - k) * (1 - k) + 0.0, 0);
                if (t <= FLY) {
                    Vec3d dir = pos.subtract(high).lengthSquared() > 0.01 ? pos.subtract(high).normalize() : new Vec3d(0, -1, 0);
                    Vec3d[] b = Fx.basis(dir);
                    double flap = Math.sin(t * 0.9) * 0.9;
                    for (int s = -1; s <= 1; s += 2) {                                   // canh
                        Vec3d tip = pos.add(b[1].multiply(s * 2.4)).add(b[2].multiply(flap + 0.5));
                        Fx.line(w, d(0x14141F, 1.5f), pos, tip, 0.3);
                        Fx.line(w, d(0x5A8AFF, 0.9f), pos.add(0, 0.1, 0), tip.add(0, 0.1, 0), 0.5);
                    }
                    Fx.sphere(w, d(0x20202C, 1.6f), pos, 0.45, 10, t);
                    Fx.pt(w, d(0xFFFF80, 1.0f), pos.add(dir.multiply(0.5)));
                    Fx.put(w, ParticleTypes.ELECTRIC_SPARK, pos, 2, 0.4, 0.05);
                    return false;
                }
                if (t == FLY + 1) {
                    Fx.bolt(w, d(0xFFFFB0, 1.8f), tgt.add(0, 30, 0), tgt, 1.0, 0.35);
                    Fx.bolt(w, d(0x80B0FF, 1.2f), tgt.add(0.5, 30, 0), tgt, 1.2, 0.5);
                    Fx.snd(w, tgt, SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 2.0f, 1.2f);
                    Vec3d[] hb = Fx.basis(new Vec3d(0, 1, 0));
                    for (int r = 1; r <= 3; r++) Fx.ring(w, d(0xFFFFA0, 1.4f), tgt.add(0, 0.2, 0), hb[1], hb[2], r * 1.6, 28 + r * 6, 0);
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(tgt, tgt).expand(5))) {
                        Fx.hurt(w, p, e, 18.0f);
                        e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 2));
                    }
                    return true;
                }
                return true;
            }
        });
    }

    static void toad(ServerWorld w, ServerPlayerEntity p) {
        LivingEntity t = aim(w, p, 14);
        Vec3d from = p.getEyePos().add(0, -0.3, 0);
        Fx.snd(w, from, SoundEvents.ENTITY_FROG_TONGUE, 1.4f, 0.7f);
        Vec3d end = t != null ? Fx.mid(t) : from.add(p.getRotationVec(1.0f).multiply(8));
        Anims.add(new Anims.Anim() {
            int n = 0;
            public boolean tick() {
                n++;
                double k = Math.min(1.0, n / 3.0);
                Vec3d tip = from.add(end.subtract(from).multiply(k));
                Fx.line(w, d(0xE0508A, 1.7f), from, tip, 0.25);
                Fx.line(w, d(0xFFB0C8, 0.9f), from, tip, 0.5);
                Fx.sphere(w, d(0xE0508A, 1.8f), tip, 0.3, 6, 0);
                if (n == 3 && t != null) {
                    Fx.hurt(w, p, t, 4.0f);
                    Vec3d pull = p.getEntityPos().subtract(t.getEntityPos()).normalize();
                    t.addVelocity(pull.x * 1.6, 0.3, pull.z * 1.6);
                }
                return n >= 6;
            }
        });
    }

    static void serpent(ServerWorld w, ServerPlayerEntity p) {
        Vec3d dir0 = p.getRotationVec(1.0f).multiply(1, 0.2, 1).normalize();
        Vec3d start = p.getEntityPos().add(0, 0.8, 0).add(dir0.multiply(1.5));
        Vec3d[] b = Fx.basis(dir0);
        Fx.snd(w, start, SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 1.0f, 1.8f);
        Anims.add(new Anims.Anim() {
            int t = 0; final List<Vec3d> body = new ArrayList<>(); final Set<UUID> hit = new HashSet<>();
            public boolean tick() {
                t++;
                Vec3d head = start.add(dir0.multiply(t * 1.0)).add(b[1].multiply(Math.sin(t * 0.5) * 1.6));
                body.add(head);
                if (body.size() > 14) body.remove(0);
                for (int i = 0; i < body.size(); i++) {
                    double r = 0.25 + 0.35 * i / body.size();
                    Fx.sphere(w, d(i % 2 == 0 ? 0x10101A : 0x2A4A2A, 1.6f), body.get(i), r, 6, 0);
                }
                Fx.sphere(w, d(0x0E0E16, 1.8f), head, 0.6, 10, t);
                Fx.pt(w, d(0xFF2020, 1.0f), head.add(b[1].multiply(0.25)).add(0, 0.25, 0));
                Fx.pt(w, d(0xFF2020, 1.0f), head.subtract(b[1].multiply(0.25)).add(0, 0.25, 0));
                for (LivingEntity e : Fx.hostiles(w, p, new Box(head, head).expand(1.4)))
                    if (hit.add(e.getUuid())) {
                        Fx.hurt(w, p, e, 14.0f);
                        e.addVelocity(dir0.x * 0.9, 0.4, dir0.z * 0.9);
                        e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 2));
                    }
                return t >= 22 || p.isRemoved() || !w.isAir(BlockPos.ofFloored(head.add(0, 0.5, 0)));
            }
        });
    }

    // ====================== TODO ======================
    static void boogie(ServerWorld w, ServerPlayerEntity p) {
        LivingEntity t = aim(w, p, 25);
        Fx.snd(w, p.getEntityPos(), SoundEvents.ITEM_SHIELD_BLOCK, 1.6f, 1.6f);
        if (t == null) { msg(p, "Khong co muc tieu"); return; }
        Vec3d a = p.getEntityPos(), b = t.getEntityPos();
        Vec3d[] hb = Fx.basis(new Vec3d(0, 1, 0));
        Fx.line(w, d(0xB8E8FF, 0.8f), a.add(0, 1, 0), b.add(0, 1, 0), 0.6);
        for (int i = 1; i <= 3; i++) {
            Fx.ring(w, d(0xFFFFFF, 1.3f), a.add(0, 1, 0), hb[1], hb[2], i * 0.7, 20, 0);
            Fx.ring(w, d(0x6FC0FF, 1.3f), b.add(0, 1, 0), hb[1], hb[2], i * 0.7, 20, 0);
        }
        p.requestTeleport(b.x, b.y, b.z);
        t.requestTeleport(a.x, a.y, a.z);
        t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 20, 3));
        Fx.snd(w, b, SoundEvents.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.8f);
    }

    // ====================== NANAMI ======================
    static void ratio(ServerWorld w, ServerPlayerEntity p) {
        LivingEntity t = aim(w, p, 5.5);
        Fx.snd(w, p.getEntityPos(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.2f, 0.6f);
        if (t == null) { msg(p, "Ratio Technique can muc tieu trong 5 o"); return; }
        Vec3d base = t.getEntityPos(), look = p.getRotationVec(1.0f);
        double h = t.getHeight();
        Vec3d mark = base.add(0, h * 0.7, 0);                     // diem 7:3
        Vec3d[] b = Fx.basis(look);
        Anims.add(new Anims.Anim() {
            int n = 0;
            public boolean tick() {
                n++;
                if (n <= 6) {                                       // chia than thanh 7:3
                    Fx.line(w, d(0xFFFFFF, 0.9f), base.add(0, 0, 0).add(b[1].multiply(0.7)), base.add(0, h, 0).add(b[1].multiply(0.7)), 0.25);
                    Fx.line(w, d(0xFFE070, 1.4f), mark.subtract(b[1].multiply(0.9)), mark.add(b[1].multiply(0.9)), 0.15);
                    Fx.pt(w, d(0xFF4040, 1.2f), mark);
                }
                if (n == 7) {
                    Fx.hurt(w, p, t, (float) (12.0 + 0.12 * t.getMaxHealth()));
                    Fx.put(w, ParticleTypes.CRIT, mark, 18, 0.3, 0.3);
                    Fx.put(w, d(0xFFD040, 1.6f), mark, 14, 0.25, 0);
                    Fx.snd(w, mark, SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, 1.4f, 0.7f);
                }
                return n >= 8;
            }
        });
    }

    static void overtime(ServerWorld w, ServerPlayerEntity p) {
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 240, 1));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 240, 1));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 240, 0));
        Fx.snd(w, p.getEntityPos(), SoundEvents.BLOCK_BELL_USE, 1.4f, 0.7f);
        msg(p, "Overtime: 12 giay manh hon, sau do kiet suc");
        Anims.add(new Anims.Anim() {
            int n = 0;
            public boolean tick() {
                n++;
                if (n <= 20 || n % 10 == 0) {                       // dong ho 12 vach quay quanh chan
                    Vec3d c = p.getEntityPos().add(0, 0.1, 0);
                    Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
                    Fx.ring(w, d(0xFFD060, 1.2f), c, b[1], b[2], 1.3, 36, n * 0.1);
                    for (int i = 0; i < 12; i++) {
                        double a = i * Math.PI / 6;
                        Fx.line(w, d(0xFFFFFF, 0.9f), c.add(Math.cos(a) * 1.0, 0, Math.sin(a) * 1.0), c.add(Math.cos(a) * 1.4, 0, Math.sin(a) * 1.4), 0.2);
                    }
                }
                if (n == 240) {
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 200, 1));
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 200, 0));
                    msg(p, "Overtime ket thuc: kiet suc");
                    return true;
                }
                return p.isRemoved();
            }
        });
    }

    // ====================== NOBARA ======================
    static final Map<UUID, Integer> MARKS = new HashMap<>();

    static void resonance(ServerWorld w, ServerPlayerEntity p) {
        LivingEntity t = aim(w, p, 10);
        Fx.snd(w, p.getEntityPos(), SoundEvents.BLOCK_ANVIL_LAND, 0.8f, 1.8f);
        if (t == null) { msg(p, "Khong co muc tieu"); return; }
        Fx.hurt(w, p, t, 6.0f);
        MARKS.put(t.getUuid(), Data.now + 160);
        t.addStatusEffect(new StatusEffectInstance(StatusEffects.GLOWING, 160, 0));
        Vec3d m = Fx.mid(t);
        Fx.line(w, d(0xC0C0D0, 1.2f), m.add(0.4, 0.6, 0), m, 0.15);          // cay dinh
        Fx.put(w, d(0xFF4040, 1.2f), m, 10, 0.3, 0);
        Fx.snd(w, m, SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, 1.0f, 1.4f);
    }

    static void hairpin(ServerWorld w, ServerPlayerEntity p) {
        List<LivingEntity> marked = new ArrayList<>();
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(32), x -> MARKS.getOrDefault(x.getUuid(), 0) > Data.now)) marked.add(e);
        if (marked.isEmpty()) { msg(p, "Khong co muc tieu da dong Resonance"); return; }
        Fx.snd(w, p.getEntityPos(), SoundEvents.ENTITY_PLAYER_ATTACK_KNOCKBACK, 1.4f, 0.7f);
        Anims.add(new Anims.Anim() {
            int n = 0;
            public boolean tick() {
                n++;
                for (LivingEntity e : marked) Fx.line(w, d(0xFF3030, 1.0f), p.getEyePos(), Fx.mid(e), 0.7);
                if (n == 6) {
                    for (LivingEntity e : marked) {
                        Vec3d m = Fx.mid(e);
                        Fx.hurt(w, p, e, 20.0f);
                        MARKS.remove(e.getUuid());
                        Fx.put(w, ParticleTypes.EXPLOSION, m, 1, 0, 0);
                        Fx.sphere(w, d(0xFF3030, 1.6f), m, 1.5, 24, 0);
                        for (LivingEntity o : Fx.hostiles(w, p, new Box(m, m).expand(3))) if (o != e) Fx.hurt(w, p, o, 8.0f);
                        Fx.snd(w, m, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 0.9f, 1.4f);
                    }
                    return true;
                }
                return false;
            }
        });
    }

    // ====================== CHOSO ======================
    static void piercingBlood(ServerWorld w, ServerPlayerEntity p) {
        Fx.snd(w, p.getEntityPos(), SoundEvents.BLOCK_BEACON_POWER_SELECT, 1.2f, 1.6f);
        Anims.add(new Anims.Anim() {
            int t = 0; Vec3d dir;
            public boolean tick() {
                if (p.isRemoved()) return true;
                t++;
                Vec3d look = p.getRotationVec(1.0f);
                Vec3d[] b = Fx.basis(look);
                Vec3d c = p.getEyePos().add(look.multiply(1.5));
                if (t <= 10) {                                       // nen mau
                    double r = 0.9 * (1 - t / 10.0) + 0.2;
                    Fx.sphere(w, d(0xB01020, 1.5f), c, r, 12, t);
                    for (int i = 0; i < 6; i++) {
                        double a = t * 0.6 + i * Math.PI / 3;
                        Fx.pt(w, d(0xFF5060, 0.9f), c.add(b[1].multiply(Math.cos(a) * (1.4 - t * 0.1))).add(b[2].multiply(Math.sin(a) * (1.4 - t * 0.1))));
                    }
                    return false;
                }
                if (t == 11) {
                    dir = look;
                    Fx.snd(w, c, SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 1.4f, 1.6f);
                }
                Vec3d s = p.getEyePos().add(dir.multiply(1.2)), e = s.add(dir.multiply(45));
                Vec3d end = e;
                for (double dd = 1; dd <= 45; dd += 1) { Vec3d v = s.add(dir.multiply(dd)); if (!w.isAir(BlockPos.ofFloored(v))) { end = v; break; } }
                if (t <= 14) {
                    Fx.line(w, d(0xFFB0B8, 1.0f), s, end, 0.5);
                    Fx.line(w, d(0xC01028, 1.6f), s, end, 0.35);
                    Vec3d[] bb = Fx.basis(dir);
                    for (double dd = 2; dd < s.distanceTo(end); dd += 3) Fx.ring(w, d(0x700818, 1.0f), s.add(dir.multiply(dd)), bb[1], bb[2], 0.5, 8, dd);
                    if (t == 12) {
                        for (LivingEntity x : Fx.hostiles(w, p, new Box(s, end).expand(1.2))) {
                            Fx.hurt(w, p, x, 22.0f);
                            x.addVelocity(dir.x * 0.6, 0.2, dir.z * 0.6);
                            Fx.put(w, d(0xFF2030, 1.5f), Fx.mid(x), 15, 0.4, 0);
                        }
                        Fx.put(w, ParticleTypes.EXPLOSION, end, 1, 0, 0);
                    }
                    return false;
                }
                return true;
            }
        });
    }

    static void supernova(ServerWorld w, ServerPlayerEntity p) {
        Vec3d look = p.getRotationVec(1.0f);
        Vec3d[] b = Fx.basis(look);
        Fx.snd(w, p.getEntityPos(), SoundEvents.ENTITY_BLAZE_SHOOT, 1.2f, 0.7f);
        for (int i = 0; i < 7; i++) {
            double ang = (i - 3) * 0.16;
            Vec3d dir = look.add(b[1].multiply(ang)).add(0, 0.25, 0).normalize();
            Vec3d from = p.getEyePos().add(dir.multiply(1.2));
            final int delay = i * 2;
            Anims.add(new Anims.Anim() {
                int n = 0; Vec3d pos = from, vel = dir.multiply(1.1);
                public boolean tick() {
                    n++;
                    if (n <= delay) return false;
                    vel = vel.add(0, -0.05, 0);
                    pos = pos.add(vel);
                    Fx.sphere(w, d(0xB01020, 1.4f), pos, 0.4, 8, n);
                    Fx.pt(w, d(0xFF7080, 0.8f), pos);
                    Fx.pt(w, d(0x500010, 1.0f), pos.subtract(vel.multiply(0.6)));
                    boolean hit = !w.isAir(BlockPos.ofFloored(pos)) || !Fx.hostiles(w, p, new Box(pos, pos).expand(1.0)).isEmpty();
                    if (hit || n > delay + 40) {
                        for (LivingEntity e : Fx.hostiles(w, p, new Box(pos, pos).expand(2.5))) Fx.hurt(w, p, e, 9.0f);
                        Fx.put(w, ParticleTypes.EXPLOSION, pos, 1, 0, 0);
                        Fx.sphere(w, d(0xFF2030, 1.5f), pos, 1.6, 22, 0);
                        Fx.snd(w, pos, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 0.6f, 1.6f);
                        return true;
                    }
                    return false;
                }
            });
        }
    }

    // ====================== JOGO ======================
    static void meteor(ServerWorld w, ServerPlayerEntity p) {
        Vec3d tgt = rayEnd(w, p, 40);
        Vec3d start = tgt.add(-14, 45, 8);
        Fx.snd(w, p.getEntityPos(), SoundEvents.ENTITY_BLAZE_SHOOT, 1.5f, 0.4f);
        Anims.add(new Anims.Anim() {
            int t = 0; static final int FALL = 32;
            public boolean tick() {
                t++;
                Vec3d[] hb = Fx.basis(new Vec3d(0, 1, 0));
                if (t <= FALL) {
                    double k = (double) t / FALL, e = k * k;
                    Vec3d pos = start.add(tgt.subtract(start).multiply(e));
                    Fx.ring(w, d(0xFF4010, 1.2f), tgt.add(0, 0.2, 0), hb[1], hb[2], 8 * (1 - k) + 1.5, 40, 0);   // vong canh bao thu nho
                    Fx.sphere(w, d(0xFF5A10, 2.0f), pos, 1.7, 40, t * 0.3);
                    Fx.sphere(w, d(0xFFD040, 1.5f), pos, 1.0, 20, -t * 0.4);
                    Fx.sphere(w, d(0x2A0A00, 1.8f), pos, 2.2, 22, t * 0.2);
                    Vec3d back = start.subtract(tgt).normalize();
                    for (int i = 1; i <= 6; i++) Fx.put(w, ParticleTypes.FLAME, pos.add(back.multiply(i * 1.2)), 2, 0.5, 0.02);
                    Fx.put(w, ParticleTypes.LARGE_SMOKE, pos.add(back.multiply(2)), 2, 0.6, 0.02);
                    return false;
                }
                if (t == FALL + 1) {
                    Fx.snd(w, tgt, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 2.5f, 0.5f);
                    Fx.put(w, ParticleTypes.EXPLOSION_EMITTER, tgt, 1, 0, 0);
                    for (LivingEntity x : Fx.hostiles(w, p, new Box(tgt, tgt).expand(9))) {
                        double dist = Fx.mid(x).distanceTo(tgt);
                        Fx.hurt(w, p, x, (float) (40.0 * Math.max(0.3, 1 - dist / 10.0)));
                        x.setFireTicks(200);
                        Vec3d away = Fx.mid(x).subtract(tgt).normalize();
                        x.addVelocity(away.x * 1.5, 0.8, away.z * 1.5);
                    }
                }
                int bt = t - FALL;
                Fx.ring(w, d(0xFF6A10, 1.8f), tgt.add(0, 0.3, 0), hb[1], hb[2], bt * 1.3, 40 + bt * 6, 0);
                Fx.sphere(w, d(0xFFB030, 1.6f), tgt, Math.max(0.5, bt * 1.0), 40, bt);
                for (double y = 0; y < bt * 1.8; y += 0.8) Fx.put(w, ParticleTypes.FLAME, tgt.add(Fx.rnd(-1, 1), y, Fx.rnd(-1, 1)), 1, 0.3, 0.02);
                return bt >= 9;
            }
        });
    }

    static void coffin(ServerWorld w, ServerPlayerEntity p) {
        Vec3d c = p.getEntityPos();
        int dur = Config.domainSeconds * 16;
        Data.DOMAIN_END.put(p.getUuid(), Data.now + 20 + dur + 10);
        Fx.snd(w, c, SoundEvents.ENTITY_WITHER_SPAWN, 1.5f, 0.4f);
        Fx.snd(w, c, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 1.5f, 0.4f);
        Anims.add(new Anims.Anim() {
            int t = 0;
            public boolean tick() {
                if (p.isRemoved() || !p.isAlive()) { Data.DOMAIN_END.remove(p.getUuid()); return true; }
                t++;
                double rise = Math.min(1.0, t / 20.0);
                Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
                if (t % 2 == 0) {                                        // nui lua hinh non
                    for (double y = 0; y <= 13 * rise; y += 1.6) {
                        double r = 9 - y * 0.55;
                        Fx.ring(w, d(y % 3.2 < 1.6 ? 0x6A1A08 : 0x2A0A04, 1.6f), c.add(0, y, 0), b[1], b[2], Math.max(1.5, r), 28, y);
                    }
                    Fx.ring(w, d(0xFF5A10, 1.6f), c.add(0, 13 * rise, 0), b[1], b[2], 2.4, 20, t * 0.2);   // mieng nui
                }
                Fx.ring(w, d(0xFF3A08, 1.8f), c.add(0, 0.1, 0), b[1], b[2], 15, 70, 0);
                for (int i = 0; i < 4; i++) {                              // dung nham phun
                    Vec3d top = c.add(0, 13, 0);
                    Fx.put(w, ParticleTypes.LAVA, top, 1, 1.2, 0.5);
                    Fx.put(w, ParticleTypes.FLAME, top.add(Fx.rnd(-2, 2), Fx.rnd(0, 6), Fx.rnd(-2, 2)), 2, 0.4, 0.05);
                }
                if (t > 20) {
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(c, c).expand(15, 10, 15))) {
                        if (e.getEntityPos().distanceTo(c) > 16) continue;
                        e.setFireTicks(60);
                        if (t % 10 == 0) {
                            Fx.hurt(w, p, e, 5.0f);
                            e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 25, 1));
                            Fx.put(w, ParticleTypes.LAVA, Fx.mid(e), 4, 0.4, 0);
                        }
                    }
                }
                if (t - 20 >= dur) { Data.DOMAIN_END.remove(p.getUuid()); return true; }
                return false;
            }
        });
    }

    // ====================== MAHITO ======================
    static void idleTransfig(ServerWorld w, ServerPlayerEntity p) {
        LivingEntity t = aim(w, p, 6);
        if (t == null) { msg(p, "Idle Transfiguration can cham muc tieu (<=6 o)"); return; }
        Fx.snd(w, Fx.mid(t), SoundEvents.ENTITY_SLIME_SQUISH, 1.6f, 0.5f);
        Anims.add(new Anims.Anim() {
            int n = 0;
            public boolean tick() {
                n++;
                Vec3d m = Fx.mid(t);
                Vec3d[] b = Fx.basis(new Vec3d(Math.sin(n * 0.3), 1, Math.cos(n * 0.3)));
                double r = 0.5 + n * 0.08;
                Fx.ring(w, d(n % 2 == 0 ? 0x7A3AD0 : 0x40C070, 1.3f), m, b[1], b[2], r, 24, n * 0.5);   // mop meo hinh
                Fx.ring(w, d(0xB0B0B0, 1.0f), m, b[2], b[1], r * 0.8, 20, -n * 0.4);
                if (n == 10) {
                    Fx.hurt(w, p, t, (float) Math.min(60.0, 0.3 * t.getMaxHealth() + 4));
                    t.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 100, 1));
                    t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 1));
                    t.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 120, 0));
                    Fx.put(w, d(0x9040E0, 1.6f), m, 25, 0.6, 0);
                    Fx.snd(w, m, SoundEvents.ENTITY_SLIME_DEATH, 1.4f, 0.5f);
                }
                return n >= 14 || !t.isAlive();
            }
        });
    }

    // ====================== INUMAKI ======================
    static void speechStop(ServerWorld w, ServerPlayerEntity p) {
        Vec3d c = p.getEntityPos().add(0, 0.2, 0);
        Fx.snd(w, c, SoundEvents.BLOCK_NOTE_BLOCK_BELL.value(), 1.6f, 0.5f);
        Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
        for (int r = 1; r <= 4; r++) Fx.ring(w, d(r % 2 == 0 ? 0xFFFFFF : 0x202020, 1.4f), c, b[1], b[2], r * 3.0, 40 + r * 8, 0);
        for (int i = 0; i < 6; i++) { double a = i * Math.PI / 3; Fx.line(w, d(0xFFFFFF, 1.0f), c, c.add(Math.cos(a) * 12, 0, Math.sin(a) * 12), 0.8); }
        for (LivingEntity e : Fx.hostiles(w, p, p.getBoundingBox().expand(12))) {
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 9));
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 100, 2));
            Fx.put(w, d(0xFFFFFF, 1.2f), Fx.mid(e), 8, 0.4, 0);
        }
    }

    static void speechBlast(ServerWorld w, ServerPlayerEntity p) {
        Vec3d look = p.getRotationVec(1.0f).multiply(1, 0, 1);
        if (look.lengthSquared() < 1.0E-4) look = new Vec3d(0, 0, 1);
        final Vec3d dir = look.normalize();
        Vec3d c = p.getEyePos();
        Vec3d[] b = Fx.basis(dir);
        Fx.snd(w, c, SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 1.0f, 1.5f);
        Anims.add(new Anims.Anim() {
            int n = 0;
            public boolean tick() {
                n++;
                double r = n * 2.2;
                for (double a = -0.8; a <= 0.8; a += 0.1) {
                    Vec3d v = dir.multiply(Math.cos(a)).add(b[1].multiply(Math.sin(a)));
                    Fx.pt(w, d(0xFFFFFF, 1.3f), c.add(v.multiply(r)));
                    Fx.pt(w, d(0x303040, 1.1f), c.add(v.multiply(r * 0.85)));
                }
                if (n == 1) for (LivingEntity e : Fx.hostiles(w, p, p.getBoundingBox().expand(10, 3, 10))) {
                    Vec3d rel = e.getEntityPos().subtract(p.getEntityPos());
                    Vec3d flat = new Vec3d(rel.x, 0, rel.z);
                    if (flat.lengthSquared() < 0.01) continue;
                    if (flat.normalize().dotProduct(dir) > 0.55) {
                        e.addVelocity(dir.x * 2.5, 0.5, dir.z * 2.5);
                        Fx.hurt(w, p, e, 5.0f);
                    }
                }
                return n >= 5;
            }
        });
    }

    static void speechExplode(ServerWorld w, ServerPlayerEntity p) {
        LivingEntity t = aim(w, p, 20);
        Fx.snd(w, p.getEntityPos(), SoundEvents.BLOCK_NOTE_BLOCK_BELL.value(), 1.6f, 0.7f);
        if (t == null) { msg(p, "Khong co muc tieu"); return; }
        Vec3d m = Fx.mid(t);
        Anims.add(new Anims.Anim() {
            int n = 0;
            public boolean tick() {
                n++;
                Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
                Fx.ring(w, d(0xFFFFFF, 1.2f), m, b[1], b[2], 3.0 - n * 0.35, 24, n);
                if (n == 7) {
                    Fx.snd(w, m, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 1.4f, 1.2f);
                    Fx.put(w, ParticleTypes.EXPLOSION_EMITTER, m, 1, 0, 0);
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(m, m).expand(3.5))) Fx.hurt(w, p, e, 18.0f);
                    return true;
                }
                return false;
            }
        });
    }

    // ====================== YUTA ======================
    static void rikaBeam(ServerWorld w, ServerPlayerEntity p) {
        Fx.snd(w, p.getEntityPos(), SoundEvents.ENTITY_ENDER_DRAGON_GROWL, 1.5f, 0.5f);
        Anims.add(new Anims.Anim() {
            int t = 0; Vec3d dir;
            public boolean tick() {
                if (p.isRemoved()) return true;
                t++;
                Vec3d look = p.getRotationVec(1.0f);
                Vec3d[] b = Fx.basis(look);
                Vec3d c = p.getEyePos().add(look.multiply(2.5));
                if (t <= 16) {
                    Fx.sphere(w, d(0xB8D8FF, 1.6f), c, 0.3 + t * 0.07, 14, t);
                    Fx.ring(w, d(0x203060, 1.4f), c, b[1], b[2], 1.5 - t * 0.04, 26, t * 0.4);
                    if (t % 3 == 0) Fx.bolt(w, d(0xC8E0FF, 1.0f), c, c.add(Fx.randDir().multiply(2.5)), 0.3, 0.4);
                    return false;
                }
                if (t == 17) { dir = look; Fx.snd(w, c, SoundEvents.ENTITY_WARDEN_SONIC_BOOM, 2.0f, 0.6f); }
                Vec3d s = p.getEyePos().add(dir.multiply(1.5)), end = s.add(dir.multiply(40));
                for (double dd = 1; dd <= 40; dd += 1) { Vec3d v = s.add(dir.multiply(dd)); if (!w.isAir(BlockPos.ofFloored(v))) { end = v; break; } }
                if (t <= 22) {
                    Vec3d[] bb = Fx.basis(dir);
                    Fx.line(w, d(0xFFFFFF, 1.8f), s, end, 0.5);
                    for (double dd = 0; dd < s.distanceTo(end); dd += 1.2) {
                        Vec3d cp = s.add(dir.multiply(dd));
                        Fx.ring(w, d(0x7AA8FF, 1.4f), cp, bb[1], bb[2], 1.6, 14, dd + t);
                        Fx.ring(w, d(0x14204A, 1.4f), cp, bb[1], bb[2], 2.3, 16, -dd);
                    }
                    if (t == 18) {
                        for (LivingEntity e : Fx.hostiles(w, p, new Box(s, end).expand(2.0))) {
                            Fx.hurt(w, p, e, 35.0f);
                            e.addVelocity(dir.x * 1.2, 0.4, dir.z * 1.2);
                        }
                        Fx.put(w, ParticleTypes.EXPLOSION_EMITTER, end, 1, 0, 0);
                    }
                    return false;
                }
                return true;
            }
        });
    }

    static void rikaManifest(ServerWorld w, ServerPlayerEntity p) {
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 400, 1));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 400, 1));
        Fx.snd(w, p.getEntityPos(), SoundEvents.ENTITY_WITHER_SPAWN, 1.0f, 1.6f);
        Anims.add(new Anims.Anim() {
            int n = 0;
            public boolean tick() {
                if (p.isRemoved() || !p.isAlive()) return true;
                n++;
                Vec3d base = p.getEntityPos().subtract(p.getRotationVec(1.0f).multiply(1, 0, 1).normalize().multiply(1.2));
                Vec3d[] b = Fx.basis(p.getRotationVec(1.0f).multiply(1, 0, 1));
                if (n % 2 == 0) {
                    for (double y = 0; y <= 6; y += 0.5) Fx.pt(w, d(0x10101C, (float) (1.8 - y * 0.1)), base.add(0, y, 0).add(Math.sin(y + n * 0.1) * 0.15, 0, 0));
                    for (int s = -1; s <= 1; s += 2) {                                     // hai canh tay dai
                        Vec3d shoulder = base.add(0, 4.5, 0);
                        Vec3d hand = shoulder.add(b[1].multiply(s * 2.8)).add(0, -1.5 + Math.sin(n * 0.2 + s) * 0.5, 0).add(p.getRotationVec(1.0f).multiply(1.2));
                        Fx.line(w, d(0x14141F, 1.5f), shoulder, hand, 0.4);
                        Fx.pt(w, d(0xFFFFFF, 1.0f), hand);
                    }
                    Vec3d head = base.add(0, 6.5, 0);
                    Fx.sphere(w, d(0x10101C, 1.6f), head, 0.6, 12, n);
                    Fx.pt(w, d(0xFF2020, 1.4f), head.add(0.2, 0.1, 0.3));
                    Fx.pt(w, d(0xFF2020, 1.4f), head.add(-0.2, 0.1, 0.3));
                    Fx.ring(w, d(0xFFFFFF, 0.8f), head.add(0, 0.9, 0), Fx.basis(new Vec3d(0, 1, 0))[1], Fx.basis(new Vec3d(0, 1, 0))[2], 0.6, 12, n * 0.1);  // vong hao quang
                }
                if (n % 30 == 0) {
                    for (LivingEntity e : Fx.hostiles(w, p, p.getBoundingBox().expand(7))) {
                        Fx.hurt(w, p, e, 8.0f);
                        Fx.line(w, d(0xB0D0FF, 1.3f), base.add(0, 4.5, 0), Fx.mid(e), 0.4);
                        e.addVelocity(0, 0.35, 0);
                        break;
                    }
                }
                return n >= 400;
            }
        });
    }

    // ====================== TOJI ======================
    static void heavenly(ServerWorld w, ServerPlayerEntity p) {
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 600, 2));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 600, 2));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 600, 0));
        Fx.snd(w, p.getEntityPos(), SoundEvents.ENTITY_RAVAGER_ROAR, 1.2f, 1.2f);
        msg(p, "Heavenly Restriction: 30 giay");
        Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
        for (int i = 0; i < 4; i++) Fx.ring(w, d(0x808080, 1.3f), p.getEntityPos().add(0, 0.2 + i * 0.5, 0), b[1], b[2], 1.0, 24, i);
    }

    static void invertedSpear(ServerWorld w, ServerPlayerEntity p) {
        LivingEntity t = aim(w, p, 4.5);
        Fx.snd(w, p.getEntityPos(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.2f, 1.0f);
        if (t == null) { msg(p, "Khong co muc tieu"); return; }
        Vec3d m = Fx.mid(t), from = p.getEyePos().add(0, -0.3, 0);
        Fx.line(w, d(0x707080, 1.4f), from, m, 0.3);
        Fx.line(w, d(0xFF2020, 0.8f), from, m, 0.6);
        Fx.hurt(w, p, t, 10.0f);
        t.clearStatusEffects();                       // huy ky thuat / buff cua muc tieu
        Fx.put(w, d(0xFF4040, 1.4f), m, 14, 0.4, 0);
        Fx.put(w, ParticleTypes.ELECTRIC_SPARK, m, 10, 0.4, 0.2);
        Fx.snd(w, m, SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, 1.2f, 0.6f);
    }

    static void playfulCloud(ServerWorld w, ServerPlayerEntity p) {
        Vec3d look = p.getRotationVec(1.0f).multiply(1, 0, 1);
        if (look.lengthSquared() < 1.0E-4) look = new Vec3d(0, 0, 1);
        final Vec3d dir = look.normalize();
        Vec3d c = p.getEntityPos().add(0, 1.0, 0);
        Fx.snd(w, c, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.6f, 0.5f);
        Anims.add(new Anims.Anim() {
            int n = 0; final Set<UUID> hit = new HashSet<>();
            public boolean tick() {
                n++;
                double sweep = -1.6 + n * 0.8;                                  // quet 180 do trong 4 tick
                Vec3d perp = new Vec3d(-dir.z, 0, dir.x);
                Vec3d v = dir.multiply(Math.cos(sweep)).add(perp.multiply(Math.sin(sweep)));
                for (double r = 1.0; r <= 4.2; r += 0.4) {
                    Fx.pt(w, d(0xE0E0E8, 1.6f), c.add(v.multiply(r)));
                    Fx.pt(w, d(0x404048, 1.2f), c.add(v.multiply(r)).add(0, 0.2, 0));
                }
                for (LivingEntity e : Fx.hostiles(w, p, p.getBoundingBox().expand(4.2, 1.5, 4.2))) {
                    Vec3d rel = e.getEntityPos().subtract(p.getEntityPos());
                    Vec3d flat = new Vec3d(rel.x, 0, rel.z);
                    if (flat.lengthSquared() < 0.01 || !hit.add(e.getUuid())) continue;
                    if (flat.normalize().dotProduct(dir) > -0.2) {
                        Fx.hurt(w, p, e, 16.0f);
                        e.addVelocity(dir.x * 1.2, 0.35, dir.z * 1.2);
                        Fx.put(w, ParticleTypes.CRIT, Fx.mid(e), 10, 0.3, 0.2);
                    }
                }
                return n >= 5;
            }
        });
    }
}
