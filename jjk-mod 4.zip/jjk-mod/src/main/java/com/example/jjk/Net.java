package com.example.jjk;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.List;
import java.util.UUID;

public class Net {
    public static void register() {
        PayloadTypeRegistry.playC2S().register(ActionPayload.ID, ActionPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SyncPayload.ID, SyncPayload.CODEC);

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> Data.sync(handler.player));

        ServerPlayNetworking.registerGlobalReceiver(ActionPayload.ID, (payload, context) -> {
            ServerPlayerEntity p = context.player();
            UUID id = p.getUuid();
            List<Tech.T> list = Data.techs(id);
            switch (payload.action()) {
                case 0 -> Data.setChara(id, payload.a());
                case 4 -> {                                       // dung ky nang theo chi so trong danh sach nhan vat (nut trong menu)
                    if (payload.a() >= 0 && payload.a() < list.size()) Abilities.cast(context.server(), p, list.get(payload.a()));
                }
                case 7 -> {                                       // phim slot: server tu tra o -> ky nang (khong tin client)
                    String[] sl = Data.slots(id);
                    int s = payload.a();
                    if (s >= 0 && s < sl.length && sl[s] != null) {
                        Tech.T t = Tech.byId(sl[s]);
                        if (t != null) Abilities.cast(context.server(), p, t);
                    }
                }
                case 8 -> {                                       // gan / thay / xoa ky nang trong slot
                    int b = payload.b();
                    if (b < 0) Data.equip(id, payload.a(), null);
                    else if (b < list.size()) Data.equip(id, payload.a(), list.get(b).id());
                }
                default -> { }                                    // 2 = xin dong bo (sync ben duoi)
            }
            Data.sync(p);
        });
    }
}
