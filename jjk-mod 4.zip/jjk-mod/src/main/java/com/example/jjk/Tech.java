package com.example.jjk;

import java.util.ArrayList;
import java.util.List;

/** Danh muc ky thuat. status: trung thuc, chua co ban nao duoc test trong game. */
public class Tech {
    public enum Chara {
        GOJO("Satoru Gojo", "Limitless + Six Eyes", 0x6FD0FF),
        SUKUNA("Ryomen Sukuna", "Cleave / Dismantle / Fuga / Malevolent Shrine", 0xFF4A4A),
        YUJI("Yuji Itadori", "Cursed Energy + Black Flash", 0xFF9A3A),
        MEGUMI("Megumi Fushiguro", "Ten Shadows", 0x5A6A9A),
        TODO("Aoi Todo", "Boogie Woogie + Black Flash", 0xC09060),
        NANAMI("Kento Nanami", "Ratio Technique", 0xE0C060),
        NOBARA("Nobara Kugisaki", "Straw Doll Technique", 0xD07080),
        CHOSO("Choso", "Blood Manipulation", 0xB01830),
        JOGO("Jogo", "Disaster Flames", 0xFF6A20),
        MAHITO("Mahito", "Idle Transfiguration", 0x8A5AC0),
        INUMAKI("Toge Inumaki", "Cursed Speech", 0xE8E8F0),
        YUTA("Yuta Okkotsu", "Rika", 0x90B8FF),
        TOJI("Toji Fushiguro", "Heavenly Restriction", 0x909098);
        public final String title, desc; public final int color;
        Chara(String t, String d, int c) { title = t; desc = d; color = c; }
    }

    public static final String UNTESTED = "Da viet, CHUA test trong game";

    /** kind: toggle / instant / charge / domain */
    public record T(String id, String en, String jp, int energy, int cooldown, double damage, String kind, String desc, String status, Chara... users) {
        public boolean toggle() { return kind.equals("toggle"); }
        public boolean domain() { return kind.equals("domain"); }
        public boolean usedBy(Chara c) { for (Chara u : users) if (u == c) return true; return false; }
    }

    public static final List<T> ALL = new ArrayList<>();

    private static void add(String id, String en, String jp, int energy, int cd, double dmg, String kind, String desc, String status, Chara... users) {
        ALL.add(new T(id, en, jp, energy, cd, dmg, kind, desc, status, users));
    }

    static {
        Chara G = Chara.GOJO, S = Chara.SUKUNA, Y = Chara.YUJI;
        add("infinity", "Infinity", "無下限", 0, 20, 0, "toggle",
                "Bat/tat. Chan moi don danh vat ly va dan (co ke tan cong). Quai bi day ra, dan bi lam cham.\nTon 4 nang luong/giay. Khong chan lua, roi, doc.",
                UNTESTED + " (dan bi cham = do server, client co the thay giat)", G);
        add("blue", "Cursed Technique Lapse: Blue", "術式順転「蒼」", 40, 80, 3, "instant",
                "Tao qua cau hut dat truoc mat 50 tick: keo moi quai trong 8 o ve tam, nghien nat 3 st moi 8 tick.\nCuoi cung no tung xung noi.",
                UNTESTED, G);
        add("red", "Cursed Technique Reversal: Red", "術式反転「赫」", 55, 100, 16, "instant",
                "Ban cau do day lui: no khi cham, bung song xung kich ban kinh 7, hat tung moi thu ra ngoai.\nKhong pha khoi dat.",
                UNTESTED, G);
        add("purple", "Secret Technique: Hollow Purple", "茈", 150, 400, 45, "charge",
                "Hai qua Blue va Red hoi tu trong 1.8s thanh qua cau tim, bay 60 o, xuyen moi quai (45 st).\nBat 'purpleErasesBlocks' trong config de xoa dia hinh (mac dinh TAT).",
                UNTESTED, G);
        add("unlimited_void", "Domain Expansion: Unlimited Void", "領域展開「無量空処」", 300, 1800, 2, "domain",
                "Ban kinh 14. Mo rong vo cau thien ha; moi quai ben trong bi cam (khong di chuyen duoc, yeu di), chiu 'qua tai thong tin' 2 st/s.\n10 giay. Chua co: dam doi dien tich (domain clash), moi truong 3D that.",
                UNTESTED + " (hieu ung hat, khong thay doi bau troi/dia hinh)", G);

        add("cleave", "Cleave", "捌", 35, 40, 12, "instant",
                "Nhat chem lon tam 9 o: sat thuong tang theo mau toi da cua muc tieu (6 + 25% mau toi da, toi da 60).",
                UNTESTED, S);
        add("dismantle", "Dismantle", "解", 20, 20, 6, "instant",
                "Loat 5 luoi chem mong bay lien tiep theo quat hinh quat, moi luoi 6 st, tam ~19 o.\nTrung lap, khong xuyen khoi.",
                UNTESTED, S);
        add("fire_arrow", "Fire Arrow", "開 (Fuga)", 90, 160, 30, "charge",
                "Vong lua trieu hoi mui ten lua (14 tick) roi ban di 2.2 o/tick. No ban kinh 7: 30 st, chay 8s.\nKhong dot khoi.",
                UNTESTED, S);
        add("malevolent_shrine", "Domain Expansion: Malevolent Shrine", "領域展開「伏魔御廚子」", 300, 2400, 4, "domain",
                "Ban kinh 16, khong co hang rao. Den tho (xuong + so lau) dung len bang hat; moi quai trong vung bi chem lien tuc.\n8 giay. Chua co: khoi that, domain clash.",
                UNTESTED + " (den tho la hat, khong phai khoi)", S);

        add("black_flash", "Black Flash", "黒閃", 25, 60, 8, "instant",
                "Dam lao toi muc tieu gan nhat (<=6 o). Co co hoi 'Black Flash': sat thuong x2.5, tia set den-do.\nThanh cong lien tuc se vao 'Zone' (Strength II 8s, ti le tang).",
                UNTESTED, Y);


        // ================= GIAI DOAN 2 =================
        Chara ME = Chara.MEGUMI, TO = Chara.TODO, NA = Chara.NANAMI, NO = Chara.NOBARA, CH = Chara.CHOSO,
              JO = Chara.JOGO, MA = Chara.MAHITO, IN = Chara.INUMAKI, YU = Chara.YUTA, TJ = Chara.TOJI;
        String U2 = UNTESTED + " (giai doan 2)";
        add("nue", "Nue", "鵺", 60, 120, 18, "instant", "Trieu hoi chim Nue bay vong len roi sa xuong diem ngam; set danh ban kinh 5 (18 st, lam cham).\nChim la hoat anh hat, khong phai mob that.", U2, ME);
        add("toad", "Toad", "蝦蟇", 35, 60, 4, "instant", "Luoi ech phong toi muc tieu (14 o) va keo no ve phia ban.", U2, ME);
        add("great_serpent", "Great Serpent", "大蛇", 55, 140, 14, "instant", "Ran bong lon luon qua theo duong zigzag, xuyen nhieu quai (14 st, lam cham).\nRan la hoat anh hat.", U2, ME);
        add("boogie_woogie", "Boogie Woogie", "不義遊戯", 30, 40, 0, "instant", "Vo tay: doi cho voi quai trong tam nhin (25 o).", U2, TO);
        add("ratio", "Ratio Technique (7:3)", "十劃呪法", 40, 60, 12, "instant", "Chia than muc tieu 7:3, danh trung diem yeu: 12 + 12% mau toi da. Tam 5.5 o.", U2, NA);
        add("overtime", "Overtime", "残業", 50, 400, 0, "instant", "12 giay Strength II + Speed II + Resistance I, sau do kiet suc 10 giay.", U2, NA);
        add("resonance", "Straw Doll: Resonance", "共鳴り", 30, 50, 6, "instant", "Dong dinh len muc tieu (6 st) va danh dau trong 8 giay.", U2, NO);
        add("hairpin", "Hairpin", "簪", 50, 100, 20, "instant", "Kich no moi muc tieu dang bi Resonance trong 32 o (20 st + no lan).", U2, NO);
        add("piercing_blood", "Piercing Blood", "穿血", 55, 120, 22, "instant", "Nen mau roi ban tia mau xuyen 45 o (22 st).", U2, CH);
        add("supernova", "Supernova", "苅祓", 70, 160, 9, "instant", "Chum 7 cau mau bay cong roi no (9 st moi qua).", U2, CH);
        add("meteor", "Maximum: Meteor", "極ノ番「隕」", 120, 500, 40, "instant", "Thien thach lua roi tu tren cao, vong canh bao thu nho. No ban kinh 9 (40 st, chay 10s). Khong pha khoi.", U2, JO);
        add("coffin", "Domain Expansion: Coffin of the Iron Mountain", "領域展開「蓋棺鉄囲山」", 300, 2400, 5, "domain", "Nui lua hinh non bang hat: quai trong ban kinh 15 bi chay va 5 st/0.5s.\nChua co: domain clash, khoi that.", U2, JO);
        add("idle_transfig", "Idle Transfiguration", "無為転変", 70, 160, 20, "instant", "Cham muc tieu (<=6 o): 30% mau toi da (toi da 60) + Weakness/Slowness/Nausea.", U2, MA);
        add("speech_stop", "Cursed Speech: Stop", "止まれ", 40, 160, 0, "instant", "Quai trong 12 o gan nhu dung yen 5 giay.", U2, IN);
        add("speech_blast", "Cursed Speech: Blast Away", "吹っ飛べ", 35, 100, 5, "instant", "Hat bay moi quai o hinh quat truoc mat (10 o).", U2, IN);
        add("speech_explode", "Cursed Speech: Explode", "爆ぜろ", 60, 140, 18, "instant", "No muc tieu tai cho (tam 20 o), ban kinh 3.5.", U2, IN);
        add("rika_beam", "Rika: Cursed Energy Beam", "リカ・呪力砲", 100, 260, 35, "instant", "Nap nang luong 16 tick roi ban tia khong lo xuyen 40 o (35 st).", U2, YU);
        add("rika_manifest", "Rika Manifestation", "完全顕現", 80, 600, 8, "instant", "20 giay: bong Rika khong lo sau lung, tan cong quai gan (8 st/1.5s), Strength II + Resistance II.\nBong la hoat anh hat.", U2, YU);
        add("heavenly_restriction", "Heavenly Restriction", "天与呪縛", 0, 1200, 0, "instant", "30 giay Strength III + Speed III + Resistance I. Khong ton chu luc.", U2, TJ);
        add("inverted_spear", "Inverted Spear of Heaven", "天逆鉾", 25, 100, 10, "instant", "Dam trung (<=4.5 o): 10 st va xoa moi hieu ung cua muc tieu.", U2, TJ);
        add("playful_cloud", "Playful Cloud", "游雲", 20, 80, 16, "instant", "Vung quet nang 180 do ban kinh 4: 16 st, hat tung.", U2, TJ);

        add("rct", "Reverse Cursed Technique", "反転術式", 60, 100, 0, "instant",
                "Hoi 8 mau (4 tim) va xoa doc / wither.", UNTESTED, G, S);
        add("reinforce", "Cursed Energy Reinforcement", "呪力強化", 0, 20, 0, "toggle",
                "Bat/tat. Speed I + Strength I, ton 1.5 nang luong/giay.", UNTESTED, G, S, Y);
    }

    public static List<T> of(Chara c) {
        List<T> out = new ArrayList<>();
        for (T t : ALL) if (t.usedBy(c)) out.add(t);
        return out;
    }

    /** ky hieu 2 chu cai cho icon */
    public static String abbr(T t) {
        String n = t.en();
        int c = n.lastIndexOf(':');
        if (c >= 0) n = n.substring(c + 1);
        n = n.replaceAll("\\(.*?\\)", "").trim();
        String[] w = n.split("\\s+");
        if (w.length >= 2) return ("" + w[0].charAt(0) + w[1].charAt(0)).toUpperCase();
        return n.length() >= 2 ? Character.toUpperCase(n.charAt(0)) + n.substring(1, 2).toLowerCase() : n;
    }

    public static int iconColor(T t) {
        return switch (t.id()) {
            case "infinity" -> 0x9FE8FF; case "blue" -> 0x2E9BFF; case "red" -> 0xFF3030; case "purple" -> 0xB060FF;
            case "unlimited_void" -> 0x6A5CFF; case "cleave" -> 0xFF4040; case "dismantle" -> 0xFFB0B8;
            case "fire_arrow" -> 0xFF7A1A; case "malevolent_shrine" -> 0xB01020; case "black_flash" -> 0xE02020;
            case "rct" -> 0x60FF9A; case "reinforce" -> 0x7A5CFF;
            default -> t.users().length > 0 ? t.users()[0].color : 0x888888;
        };
    }

    public static String icon(String id) {
        return switch (id) {
            case "infinity" -> "無"; case "blue" -> "蒼"; case "red" -> "赫"; case "purple" -> "茈"; case "unlimited_void" -> "領";
            case "cleave" -> "捌"; case "dismantle" -> "解"; case "fire_arrow" -> "開"; case "malevolent_shrine" -> "伏";
            case "black_flash" -> "黒"; case "rct" -> "反"; case "reinforce" -> "強";
            case "nue" -> "鵺"; case "toad" -> "蝦"; case "great_serpent" -> "蛇"; case "boogie_woogie" -> "戯";
            case "ratio" -> "十"; case "overtime" -> "残"; case "resonance" -> "鳴"; case "hairpin" -> "簪";
            case "piercing_blood" -> "穿"; case "supernova" -> "苅"; case "meteor" -> "隕"; case "coffin" -> "蓋";
            case "idle_transfig" -> "転"; case "speech_stop" -> "止"; case "speech_blast" -> "吹"; case "speech_explode" -> "爆";
            case "rika_beam" -> "砲"; case "rika_manifest" -> "顕"; case "heavenly_restriction" -> "天";
            case "inverted_spear" -> "逆"; case "playful_cloud" -> "游";
            default -> "?";
        };
    }

    public static int iconColor(String id) {
        return switch (id) {
            case "blue" -> 0x2E9BFF; case "red" -> 0xE02A2A; case "purple" -> 0x9B3DFF; case "infinity" -> 0x9FE8FF;
            case "unlimited_void" -> 0x5A3CFF; case "cleave" -> 0xC01830; case "dismantle" -> 0xD84860;
            case "fire_arrow" -> 0xFF7A1A; case "malevolent_shrine" -> 0x8A1020; case "black_flash" -> 0x601020;
            case "rct" -> 0x40D080; case "reinforce" -> 0x6A4AD0;
            default -> {
                T t = byId(id);
                yield t != null && t.users().length > 0 ? t.users()[0].color : 0x808080;
            }
        };
    }

    public static T byId(String id) {
        for (T t : ALL) if (t.id().equals(id)) return t;
        return null;
    }
}
