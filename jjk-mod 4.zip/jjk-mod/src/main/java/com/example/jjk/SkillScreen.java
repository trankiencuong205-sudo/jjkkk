package com.example.jjk;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.List;

/**
 * Menu (phim K). Chon nhan vat -> chon ky nang (danh sach tat ca ky nang cua nhan vat) ->
 * bam o slot de GAN/THAY vao slot do (gan trung se hoan doi) -> "x" de xoa slot. Moi slot co phim rieng.
 */
public class SkillScreen extends Screen {
    private int view = 0;   // chi so ky nang dang xem trong danh sach nhan vat

    public SkillScreen() { super(Text.literal("Jujutsu - Ky nang")); }

    @Override
    protected void init() {
        ClientData.listener = this::clearAndInit;
        Tech.Chara[] cs = Tech.Chara.values();
        for (int i = 0; i < cs.length; i++) {
            final int ci = i;
            boolean cur = ClientData.chara == i;
            addDrawableChild(ButtonWidget.builder(Text.literal((cur ? "> " : "") + cs[i].title.split(" ")[0]), b -> { view = 0; send(0, ci, 0); })
                    .dimensions(10 + (i % 5) * 80, 6 + (i / 5) * 18, 78, 16).build());
        }
        List<Tech.T> list = Tech.of(ClientData.chara());
        if (view >= list.size()) view = 0;
        for (int i = 0; i < list.size(); i++) {
            final int ti = i;
            Tech.T t = list.get(i);
            int rem = ClientData.cd.getOrDefault(t.id(), 0);
            String equipped = "";
            for (int s = 0; s < Data.SLOTS; s++) if (t.id().equals(ClientData.slots[s])) equipped += (equipped.isEmpty() ? "" : ",") + JjkClient.keyLabel(s);
            String label = (view == i ? "> " : "") + t.en() + (equipped.isEmpty() ? "" : "  [" + equipped + "]") + (rem > 0 ? "  " + rem / 20 + "s" : "");
            addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> { view = ti; clearAndInit(); })
                    .dimensions(10, 62 + i * 17, 250, 15).build());
        }
        // hang slot o duoi: bam de gan ky nang dang xem; "x" de xoa
        int n = Data.SLOTS;
        int sw = Math.max(36, Math.min(60, (width - 20) / n - 2));
        int y = height - 58;
        for (int s = 0; s < n; s++) {
            final int si = s;
            String id = ClientData.slots[s];
            Tech.T t = id == null ? null : Tech.byId(id);
            String lab = "[" + JjkClient.keyLabel(s) + "] " + (t == null ? "-" : Tech.abbr(t));
            int x = 10 + s * (sw + 2);
            addDrawableChild(ButtonWidget.builder(Text.literal(lab), b -> send(8, si, view))
                    .dimensions(x, y, sw, 18).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("x"), b -> send(8, si, -1))
                    .dimensions(x, y + 20, sw, 14).build());
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Dung ky nang dang xem"), b -> send(4, view, 0))
                .dimensions(270, 62, 150, 18).build());
    }

    private void send(int action, int a, int b) { ClientPlayNetworking.send(new ActionPayload(action, a, b)); }

    @Override
    public void removed() { ClientData.listener = null; }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Chu luc: " + ClientData.energy + "/" + ClientData.maxEnergy).formatted(Formatting.AQUA), 270, 90, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Bam 1 ky nang ben trai, roi bam o slot de gan/thay. Phim doi trong Options > Controls.").formatted(Formatting.GRAY), 10, height - 14, 0xFFFFFFFF);
        List<Tech.T> list = Tech.of(ClientData.chara());
        if (view < 0 || view >= list.size()) return;
        Tech.T t = list.get(view);
        int x = 270, y = 104;
        ctx.drawTextWithShadow(textRenderer, Text.literal(t.en()).formatted(Formatting.BOLD, Formatting.WHITE), x, y, 0xFFFFFFFF); y += 11;
        ctx.drawTextWithShadow(textRenderer, Text.literal(t.jp()).formatted(Formatting.GOLD), x, y, 0xFFFFFFFF); y += 12;
        ctx.drawTextWithShadow(textRenderer, Text.literal("CE " + t.energy() + "  CD " + (t.cooldown() / 20.0) + "s  DMG " + (int) t.damage()), x, y, 0xFFCCCCCC); y += 12;
        int maxW = Math.max(120, width - x - 8);
        for (String line : t.desc().split("\n")) {
            for (var seq : textRenderer.wrapLines(Text.literal(line), maxW)) {
                if (y > height - 66) break;
                ctx.drawTextWithShadow(textRenderer, seq, x, y, 0xFFDDDDDD);
                y += 10;
            }
        }
        if (y <= height - 76) ctx.drawTextWithShadow(textRenderer, Text.literal(t.status()).formatted(Formatting.YELLOW), x, y + 2, 0xFFFFFFFF);
    }
}
