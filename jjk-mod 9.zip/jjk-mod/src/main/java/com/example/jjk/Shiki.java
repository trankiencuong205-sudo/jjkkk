package com.example.jjk;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Ten Shadows cua Megumi: 10 shikigami, moi con la mot mo hinh 3D ghep tu block_display (Rig), co hoat anh
 * (chan chay, canh vo, duoi quet...). Thu tu: Divine Dogs, Nue, Great Serpent, Toad, Max Elephant, Rabbit Escape,
 * Round Deer, Piercing Ox, Tiger Funeral, Mahoraga. Chua duoc test trong game.
 */
public class Shiki {
    public static boolean dispatch(String id, ServerWorld w, ServerPlayerEntity p) {
        switch (id) {
            case "divine_dogs" -> dogs(w, p);
            case "nue" -> nue(w, p);
            case "great_serpent" -> serpent(w, p);
            case "toad" -> toad(w, p);
            case "max_elephant" -> elephant(w, p);
            case "rabbit_escape" -> rabbits(w, p);
            case "round_deer" -> deer(w, p);
            case "piercing_ox" -> ox(w, p);
            case "tiger_funeral" -> tiger(w, p);
            case "mahoraga_summon" -> mahoraga(w, p);
            default -> { return false; }
        }
        return true;
    }

    // ---------- tien ich ----------
    static Vec3d flat(Vec3d v) { return new Vec3d(v.x, 0, v.z); }

    static Vec3d dirOf(ServerPlayerEntity p) {
        Vec3d l = flat(p.getRotationVec(1f));
        return l.lengthSquared() < 1.0E-4 ? new Vec3d(0, 0, 1) : l.normalize();
    }

    static Vec3d rightOf(Vec3d dir) { return new Vec3d(-dir.z, 0, dir.x); }   // ben trai cua mo hinh la +X cuc bo

    static LivingEntity nearest(ServerWorld w, ServerPlayerEntity p, Vec3d from, double r) {
        LivingEntity best = null; double bd = 1e9;
        for (LivingEntity e : Fx.hostiles(w, p, new Box(from, from).expand(r))) {
            double d = e.getEntityPos().distanceTo(from);
            if (d < bd && d <= r) { bd = d; best = e; }
        }
        return best;
    }

    static void summonFx(ServerWorld w, Vec3d pos, int col) {
        Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
        for (int i = 0; i < 3; i++) Fx.ring(w, Fx.dust(col, 1.6f), pos.add(0, 0.1 + i * 0.05, 0), b[1], b[2], 0.8 + i * 0.7, 36, 0);
        Fx.put(w, ParticleTypes.LARGE_SMOKE, pos.add(0, 0.5, 0), 14, 0.5, 0.03);
        Fx.snd(w, pos, SoundEvents.ENTITY_WITHER_SHOOT, 0.7f, 1.4f);
    }

    // ---------- mo hinh ----------
    static Rig dogModel(ServerWorld w, Vec3d pos, double yaw, String main, String acc, int ttl) {
        Rig r = new Rig(w, pos, yaw, ttl).scale(1.25);
        r.add(main, 0, 0.85, 0, 0.6, 0.6, 1.3).add(main, 0, 0.92, 0.5, 0.7, 0.72, 0.5);
        r.add(main, 0, 1.2, 0.98, 0.5, 0.5, 0.55).add(acc, 0, 1.08, 1.32, 0.24, 0.22, 0.3);
        r.add(main, 0.17, 1.55, 0.9, 0.12, 0.26, 0.12).add(main, -0.17, 1.55, 0.9, 0.12, 0.26, 0.12);
        r.add(acc, 0.13, 1.28, 1.25, 0.08, 0.08, 0.05).add(acc, -0.13, 1.28, 1.25, 0.08, 0.08, 0.05);
        r.swing(main, 0, 1.0, -0.95, 0.12, 0.12, 0.6, 0, 1.0, -0.65, 0, 1, 0, 0.6, 0.5, 0);
        for (int i = 0; i < 4; i++) {
            double x = (i % 2 == 0 ? 0.2 : -0.2), z = (i < 2 ? 0.45 : -0.45);
            r.swing(main, x, 0.35, z, 0.2, 0.7, 0.2, x, 0.7, z, 1, 0, 0, 0.8, 0.9, (i == 0 || i == 3) ? 0 : Math.PI);
        }
        return r;
    }

    static Rig nueModel(ServerWorld w, Vec3d pos, double yaw, int ttl) {
        Rig r = new Rig(w, pos, yaw, ttl).scale(1.2);
        r.add("gray_concrete", 0, 2.0, 0, 0.9, 0.9, 1.6).add("white_concrete", 0, 1.75, 0.2, 0.7, 0.4, 1.0);
        r.add("white_concrete", 0, 2.35, 1.0, 0.65, 0.65, 0.6).add("orange_concrete", 0, 2.25, 1.45, 0.2, 0.25, 0.3);
        r.add("yellow_concrete", 0.17, 2.5, 1.32, 0.14, 0.14, 0.05).add("yellow_concrete", -0.17, 2.5, 1.32, 0.14, 0.14, 0.05);
        r.add("gray_concrete", 0, 2.05, -1.15, 0.5, 0.1, 1.0);
        r.swing("black_concrete", 1.7, 2.3, 0, 2.5, 0.12, 1.3, 0.45, 2.3, 0, 0, 0, 1, 0.7, 0.9, 0);
        r.swing("black_concrete", -1.7, 2.3, 0, 2.5, 0.12, 1.3, -0.45, 2.3, 0, 0, 0, 1, -0.7, 0.9, 0);
        r.swing("cyan_concrete", 3.0, 2.3, 0, 0.8, 0.14, 1.0, 0.45, 2.3, 0, 0, 0, 1, 0.7, 0.9, 0);
        r.swing("cyan_concrete", -3.0, 2.3, 0, 0.8, 0.14, 1.0, -0.45, 2.3, 0, 0, 0, 1, -0.7, 0.9, 0);
        return r;
    }

    static Rig toadModel(ServerWorld w, Vec3d pos, double yaw, int ttl) {
        Rig r = new Rig(w, pos, yaw, ttl).scale(1.3);
        r.add("lime_concrete", 0, 0.45, 0, 1.0, 0.8, 1.2).add("green_concrete", 0, 0.9, -0.1, 0.9, 0.2, 0.9);
        r.add("white_concrete", 0, 0.25, 0.5, 0.8, 0.4, 0.3);
        r.add("white_concrete", 0.3, 1.0, 0.5, 0.28, 0.28, 0.28).add("white_concrete", -0.3, 1.0, 0.5, 0.28, 0.28, 0.28);
        r.add("black_concrete", 0.3, 1.0, 0.65, 0.12, 0.2, 0.05).add("black_concrete", -0.3, 1.0, 0.65, 0.12, 0.2, 0.05);
        r.add("lime_concrete", 0.6, 0.3, -0.35, 0.3, 0.6, 0.8).add("lime_concrete", -0.6, 0.3, -0.35, 0.3, 0.6, 0.8);
        r.add("lime_concrete", 0.45, 0.12, 0.6, 0.25, 0.25, 0.4).add("lime_concrete", -0.45, 0.12, 0.6, 0.25, 0.25, 0.4);
        return r;
    }

    static Rig elephantModel(ServerWorld w, Vec3d pos, double yaw, int ttl) {
        Rig r = new Rig(w, pos, yaw, ttl);
        String g = "light_blue_stained_glass";
        r.add(g, 0, 3.2, 0, 3.0, 2.6, 4.2).add("cyan_stained_glass", 0, 4.0, -0.2, 2.2, 0.5, 3.0);
        r.add(g, 0, 3.5, 2.5, 1.9, 1.9, 1.6).add(g, 1.2, 3.8, 1.9, 0.12, 1.4, 1.3).add(g, -1.2, 3.8, 1.9, 0.12, 1.4, 1.3);
        r.add("white_concrete", 0.55, 2.9, 3.2, 0.2, 0.2, 1.0).add("white_concrete", -0.55, 2.9, 3.2, 0.2, 0.2, 1.0);
        r.add(g, 0, 2.9, 3.6, 0.75, 0.75, 1.4);
        r.swing("blue_stained_glass", 0, 2.9, 4.6, 0.6, 0.6, 1.4, 0, 2.9, 3.9, 1, 0, 0, 0.35, 0.3, 0);
        r.add("black_concrete", 0.45, 3.9, 3.3, 0.18, 0.18, 0.1).add("black_concrete", -0.45, 3.9, 3.3, 0.18, 0.18, 0.1);
        for (int i = 0; i < 4; i++) r.add(g, (i % 2 == 0 ? 1.0 : -1.0), 1.0, (i < 2 ? 1.4 : -1.4), 0.95, 2.0, 0.95);
        r.add(g, 0, 3.0, -2.3, 0.18, 1.2, 0.18);
        return r;
    }

    static Rig rabbitModel(ServerWorld w, Vec3d pos, double yaw, int ttl) {
        Rig r = new Rig(w, pos, yaw, ttl).scale(1.0);
        r.add("white_concrete", 0, 0.25, 0, 0.35, 0.3, 0.55).add("white_concrete", 0, 0.42, 0.33, 0.24, 0.24, 0.24);
        r.add("white_concrete", 0.06, 0.72, 0.3, 0.07, 0.3, 0.07).add("white_concrete", -0.06, 0.72, 0.3, 0.07, 0.3, 0.07);
        r.add("pink_concrete", 0, 0.38, 0.46, 0.1, 0.08, 0.05).add("white_concrete", 0, 0.3, -0.33, 0.14, 0.14, 0.12);
        return r;
    }

    static Rig deerModel(ServerWorld w, Vec3d pos, double yaw, int ttl) {
        Rig r = new Rig(w, pos, yaw, ttl).scale(1.3);
        r.add("white_concrete", 0, 1.25, 0, 0.7, 0.8, 1.4).add("white_concrete", 0, 1.9, 0.7, 0.3, 0.9, 0.3);
        r.add("white_concrete", 0, 2.45, 0.95, 0.36, 0.36, 0.56).add("black_concrete", 0, 2.4, 1.25, 0.12, 0.1, 0.06);
        for (int s = -1; s <= 1; s += 2) {
            r.add("bone_block", 0.15 * s, 2.85, 0.9, 0.07, 0.6, 0.07);
            r.add("bone_block", 0.3 * s, 3.1, 0.9, 0.3, 0.07, 0.07).add("bone_block", 0.25 * s, 2.95, 1.05, 0.06, 0.06, 0.3);
        }
        r.add("lime_stained_glass", 0, 1.25, 0, 0.78, 0.88, 1.48);
        for (int i = 0; i < 4; i++) {
            double x = (i % 2 == 0 ? 0.22 : -0.22), z = (i < 2 ? 0.55 : -0.55);
            r.swing("white_concrete", x, 0.45, z, 0.14, 0.9, 0.14, x, 0.9, z, 1, 0, 0, 0.35, 0.25, (i == 0 || i == 3) ? 0 : Math.PI);
        }
        r.add("white_concrete", 0, 1.5, -0.75, 0.15, 0.2, 0.15);
        return r;
    }

    static Rig oxModel(ServerWorld w, Vec3d pos, double yaw, int ttl) {
        Rig r = new Rig(w, pos, yaw, ttl).scale(1.3);
        r.add("black_concrete", 0, 1.2, 0, 1.0, 1.0, 1.8).add("black_concrete", 0, 1.8, 0.5, 0.8, 0.5, 0.7);
        r.add("black_concrete", 0, 1.35, 1.25, 0.7, 0.7, 0.8).add("red_concrete", 0, 1.2, 1.7, 0.4, 0.3, 0.1);
        r.add("bone_block", 0.4, 1.7, 1.5, 0.14, 0.14, 0.7).add("bone_block", -0.4, 1.7, 1.5, 0.14, 0.14, 0.7);
        r.add("bone_block", 0.55, 1.8, 1.95, 0.12, 0.12, 0.5).add("bone_block", -0.55, 1.8, 1.95, 0.12, 0.12, 0.5);
        r.add("red_concrete", 0.22, 1.5, 1.66, 0.1, 0.1, 0.05).add("red_concrete", -0.22, 1.5, 1.66, 0.1, 0.1, 0.05);
        r.swing("black_concrete", 0, 1.1, -1.1, 0.12, 0.8, 0.12, 0, 1.6, -0.95, 1, 0, 0, 0.5, 0.6, 0);
        for (int i = 0; i < 4; i++) {
            double x = (i % 2 == 0 ? 0.3 : -0.3), z = (i < 2 ? 0.65 : -0.65);
            r.swing("black_concrete", x, 0.45, z, 0.25, 0.9, 0.25, x, 0.9, z, 1, 0, 0, 0.9, 1.1, (i == 0 || i == 3) ? 0 : Math.PI);
        }
        return r;
    }

    static Rig tigerModel(ServerWorld w, Vec3d pos, double yaw, int ttl) {
        Rig r = new Rig(w, pos, yaw, ttl).scale(1.4);
        r.add("orange_concrete", 0, 1.1, 0, 0.9, 0.9, 2.0).add("white_concrete", 0, 0.7, 0.2, 0.7, 0.2, 1.2);
        for (int i = 0; i < 5; i++) r.add("black_concrete", 0, 1.12, -0.8 + i * 0.4, 0.94, 0.94, 0.12);
        r.add("orange_concrete", 0, 1.4, 1.3, 0.85, 0.75, 0.7).add("white_concrete", 0, 1.25, 1.7, 0.45, 0.3, 0.2);
        r.add("black_concrete", 0, 1.38, 1.8, 0.14, 0.1, 0.05).add("orange_concrete", 0.3, 1.85, 1.2, 0.2, 0.2, 0.1).add("orange_concrete", -0.3, 1.85, 1.2, 0.2, 0.2, 0.1);
        r.add("yellow_concrete", 0.2, 1.52, 1.66, 0.12, 0.1, 0.05).add("yellow_concrete", -0.2, 1.52, 1.66, 0.12, 0.1, 0.05);
        r.swing("orange_concrete", 0, 1.3, -1.45, 0.16, 0.16, 1.1, 0, 1.2, -1.05, 1, 0, 0, -0.5, 0.4, 0);
        r.swing("black_concrete", 0, 1.3, -1.9, 0.17, 0.17, 0.25, 0, 1.2, -1.05, 1, 0, 0, -0.5, 0.4, 0);
        for (int i = 0; i < 4; i++) {
            double x = (i % 2 == 0 ? 0.3 : -0.3), z = (i < 2 ? 0.75 : -0.75);
            r.swing("orange_concrete", x, 0.45, z, 0.26, 0.9, 0.26, x, 0.9, z, 1, 0, 0, 0.9, 1.0, (i == 0 || i == 3) ? 0 : Math.PI);
        }
        return r;
    }

    static Rig mahoragaModel(ServerWorld w, Vec3d pos, double yaw, int ttl) {
        Rig r = new Rig(w, pos, yaw, ttl);
        String st = "light_gray_concrete";
        r.swing(st, 0.4, 1.1, 0, 0.6, 2.2, 0.6, 0.4, 2.2, 0, 1, 0, 0, 0.35, 0.18, 0);
        r.swing(st, -0.4, 1.1, 0, 0.6, 2.2, 0.6, -0.4, 2.2, 0, 1, 0, 0, 0.35, 0.18, Math.PI);
        r.add(st, 0, 3.2, 0, 1.6, 1.8, 0.9).add("white_concrete", 0, 3.4, 0.46, 1.1, 1.0, 0.1);
        r.add("gray_concrete", 0, 2.3, 0, 1.2, 0.4, 0.8);
        r.add(st, 0, 4.4, 0.05, 0.8, 0.8, 0.8).add("white_concrete", 0, 4.4, 0.46, 0.7, 0.7, 0.1);
        r.add("red_concrete", 0.2, 4.5, 0.52, 0.14, 0.08, 0.05).add("red_concrete", -0.2, 4.5, 0.52, 0.14, 0.08, 0.05);
        r.add("gold_block", 0, 4.9, 0.05, 0.9, 0.12, 0.9);
        // 4 canh tay, tay phai cam thanh kiem
        r.swing(st, 1.1, 3.4, 0.1, 0.45, 1.4, 0.45, 1.1, 4.0, 0.1, 1, 0, 0, 0.5, 0.3, 0);
        r.swing(st, -1.1, 3.4, 0.1, 0.45, 1.4, 0.45, -1.1, 4.0, 0.1, 1, 0, 0, 0.5, 0.3, Math.PI);
        r.swing(st, 1.3, 2.7, 0.3, 0.4, 1.2, 0.4, 1.3, 3.2, 0.3, 1, 0, 0, 0.4, 0.3, 1.5);
        r.swing(st, -1.3, 2.7, 0.3, 0.4, 1.2, 0.4, -1.3, 3.2, 0.3, 1, 0, 0, 0.4, 0.3, 3.0);
        r.swing("iron_block", 1.3, 2.9, 1.5, 0.16, 0.34, 3.0, 1.3, 3.1, 0.3, 1, 0, 0, 0.25, 0.3, 1.5);
        r.swing("gold_block", 1.3, 2.9, 0.4, 0.5, 0.18, 0.2, 1.3, 3.1, 0.3, 1, 0, 0, 0.25, 0.3, 1.5);
        // banh xe tren lung
        double cy = 4.6, cz = -0.7;
        for (int k = 0; k < 4; k++) r.spin("gold_block", 0, cy, cz, 0.1, 2.4, 0.1, 0, cy, cz, 0, 0, 1, 0.08, k * Math.PI / 4);
        for (int k = 0; k < 8; k++) {
            double a = k * Math.PI / 4;
            r.spin("gold_block", Math.cos(a) * 1.2, cy + Math.sin(a) * 1.2, cz, 0.2, 0.2, 0.2, 0, cy, cz, 0, 0, 1, 0.08, 0);
        }
        return r;
    }

    // ================= 1. Divine Dogs =================
    static void dogs(ServerWorld w, ServerPlayerEntity p) {
        Vec3d dir = dirOf(p), rt = rightOf(dir);
        Vec3d base = p.getEntityPos();
        Vec3d s1 = base.add(rt.multiply(1.5)), s2 = base.subtract(rt.multiply(1.5));
        int total = 140;
        Rig a = dogModel(w, s1, Rig.yawOf(dir), "white_concrete", "black_concrete", total + 20);
        Rig b = dogModel(w, s2, Rig.yawOf(dir), "black_concrete", "white_concrete", total + 20);
        summonFx(w, s1, 0x202030); summonFx(w, s2, 0x202030);
        Fx.snd(w, base, SoundEvents.ENTITY_WOLF_GROWL, 1.2f, 0.8f);
        Anims.add(new Anims.Anim() {
            int t = 0; Vec3d pa = s1, pb = s2; double ya = Rig.yawOf(dir), yb = ya;
            public boolean tick() {
                t++;
                if (p.isRemoved() || !p.isAlive() || t > total) { a.kill(); b.kill(); return true; }
                Vec3d here = p.getEntityPos();
                for (int i = 0; i < 2; i++) {
                    Vec3d cur = i == 0 ? pa : pb;
                    LivingEntity tg = nearest(w, p, cur, 18);
                    Vec3d goal = tg != null ? tg.getEntityPos() : here.add(rt.multiply(i == 0 ? 2 : -2)).subtract(dir.multiply(1.5));
                    Vec3d to = flat(goal.subtract(cur));
                    double dist = to.length();
                    Vec3d nx = cur;
                    if (dist > (tg != null ? 1.6 : 1.0)) { Vec3d st = to.normalize().multiply(Math.min(dist, tg != null ? 0.65 : 0.4)); nx = cur.add(st); nx = new Vec3d(nx.x, here.y, nx.z); }
                    double yw = dist > 0.05 ? Rig.yawOf(to) : (i == 0 ? ya : yb);
                    if (tg != null && dist <= 2.2 && t % 10 == (i == 0 ? 0 : 5)) {
                        Fx.hurt(w, p, tg, 5f);
                        Fx.put(w, Fx.dust(i == 0 ? 0xFFFFFF : 0x101018, 1.4f), Fx.mid(tg), 10, 0.4, 0.1);
                        Fx.put(w, ParticleTypes.CRIT, Fx.mid(tg), 6, 0.4, 0.2);
                        Fx.snd(w, Fx.mid(tg), SoundEvents.ENTITY_WOLF_AMBIENT, 0.8f, 0.7f);
                    }
                    if (i == 0) { pa = nx; ya = yw; } else { pb = nx; yb = yw; }
                }
                if (t % 2 == 0) { a.place(pa, ya, t); b.place(pb, yb, t); }
                return false;
            }
        });
    }

    // ================= 2. Nue =================
    static void nue(ServerWorld w, ServerPlayerEntity p) {
        Vec3d c0 = p.getEntityPos();
        LivingEntity aimT = Stage2Skills.aim(w, p, 22);
        Vec3d tgt = aimT != null ? aimT.getEntityPos() : Stage2Skills.rayEnd(w, p, 14);
        Rig r = nueModel(w, c0.add(0, 4, 0), Rig.yawOf(dirOf(p)), 90);
        summonFx(w, c0, 0x202040);
        Fx.snd(w, c0, SoundEvents.ENTITY_PHANTOM_SWOOP, 1.2f, 0.6f);
        Anims.add(new Anims.Anim() {
            int t = 0; Vec3d pos = c0.add(0, 4, 0); double yaw = Rig.yawOf(dirOf(p)); Vec3d diveFrom;
            public boolean tick() {
                t++;
                if (t > 60) { r.kill(); return true; }
                Vec3d old = pos;
                if (t <= 20) {
                    double a = t * 0.3;
                    pos = c0.add(Math.cos(a) * 4, 4.5 + Math.sin(t * 0.4) * 0.4, Math.sin(a) * 4);
                } else if (t <= 32) {
                    if (diveFrom == null) diveFrom = pos;
                    double k = (t - 20) / 12.0;
                    pos = diveFrom.add(tgt.add(0, 1, 0).subtract(diveFrom).multiply(k * k));
                } else if (t <= 52) {
                    pos = pos.add(0, 0.5, 0).add(flat(tgt.subtract(c0)).normalize().multiply(0.3));
                }
                Vec3d mv = flat(pos.subtract(old));
                if (mv.lengthSquared() > 1.0E-4) yaw = Rig.yawOf(mv);
                if (t % 2 == 0) r.place(pos, yaw, t);
                if (t % 3 == 0) Fx.put(w, ParticleTypes.ELECTRIC_SPARK, pos.add(0, 2.4, 0), 6, 0.8, 0.1);
                if (t == 32) {
                    Vec3d hit = tgt.add(0, 0.5, 0);
                    Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
                    Fx.ring(w, Fx.dust(0x80E0FF, 1.8f), hit, b[1], b[2], 4.5, 70, 0);
                    for (int i = 0; i < 5; i++) Vis3D.bolt(w, hit.add(Fx.rnd(-2, 2), 9, Fx.rnd(-2, 2)), hit.add(Fx.rnd(-1.5, 1.5), 0, Fx.rnd(-1.5, 1.5)), 0.18, 8);
                    Fx.snd(w, hit, SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 1.5f, 1.4f);
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(hit, hit).expand(5, 3, 5))) {
                        if (e.getEntityPos().distanceTo(hit) > 5.2) continue;
                        Fx.hurt(w, p, e, 18f);
                        e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 3));
                    }
                }
                return false;
            }
        });
    }

    // ================= 3. Great Serpent =================
    static void serpent(ServerWorld w, ServerPlayerEntity p) {
        Vec3d eye = p.getEyePos().add(0, -0.6, 0), look = p.getRotationVec(1f);
        Vec3d dir = look.normalize(), side = rightOf(flat(dir).lengthSquared() < 1e-4 ? new Vec3d(0, 0, 1) : flat(dir).normalize());
        final int N = 14, TOTAL = 56;
        final List<Vec3d> hist = new ArrayList<>();
        final List<Disp.H> seg = new ArrayList<>();
        if (Config.displays) for (int i = 0; i < N; i++) {
            double th = 0.9 * (1 - i / (double) N) + 0.25;
            String blk = i == 0 ? "black_concrete" : (i % 2 == 0 ? "light_gray_concrete" : "gray_concrete");
            seg.add(Disp.block(w, eye, blk, 1.0, th, th, Disp.Q.ID, TOTAL + 20));
        }
        Fx.snd(w, eye, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 0.4f);
        final Set<LivingEntity> hit = new HashSet<>();
        Anims.add(new Anims.Anim() {
            int t = 0; Vec3d head = eye;
            public boolean tick() {
                t++;
                if (t > TOTAL) { for (Disp.H h : seg) h.kill(); return true; }
                if (t <= 18) head = eye.add(dir.multiply(t * 1.3)).add(side.multiply(Math.sin(t * 0.7) * 2.0)).add(0, Math.sin(t * 0.35) * 0.5, 0);
                hist.add(0, head);
                if (hist.size() > 80) hist.remove(hist.size() - 1);
                if (t % 2 == 0) for (int i = 0; i < seg.size(); i++) {
                    int ia = Math.min(hist.size() - 1, i * 2), ib = Math.min(hist.size() - 1, i * 2 + 2);
                    Vec3d a = hist.get(ia), b = hist.get(ib);
                    Vec3d d = a.subtract(b);
                    double len = Math.max(0.35, d.length() + 0.5);
                    if (d.lengthSquared() < 1.0E-5) d = dir;
                    Disp.Q q = Disp.Q.fromTo(new Vec3d(1, 0, 0), d.normalize());
                    double th = (i == 0 ? 0.9 : 0.8 * (1 - i / (double) N) + 0.25);
                    seg.get(i).move(a.add(b).multiply(0.5));
                    seg.get(i).set(q, len, th, th, 2);
                }
                if (t <= 20) {
                    Fx.put(w, Fx.dust(0x303040, 1.2f), head, 2, 0.3, 0.02);
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(head, head).expand(2.0))) {
                        if (!hit.add(e)) continue;
                        Fx.hurt(w, p, e, 14f);
                        e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 2));
                        Fx.put(w, ParticleTypes.CRIT, Fx.mid(e), 10, 0.4, 0.2);
                    }
                }
                return false;
            }
        });
    }

    // ================= 4. Toad =================
    static void toad(ServerWorld w, ServerPlayerEntity p) {
        LivingEntity t = Stage2Skills.aim(w, p, 16);
        Vec3d dir = dirOf(p), pos = p.getEntityPos().add(rightOf(dir).multiply(1.8));
        Vec3d to = t != null ? flat(t.getEntityPos().subtract(pos)) : dir;
        Rig r = toadModel(w, pos, Rig.yawOf(to.lengthSquared() < 1e-4 ? dir : to.normalize()), 70);
        summonFx(w, pos, 0x20A020);
        Fx.snd(w, pos, SoundEvents.ENTITY_FROG_AMBIENT, 1.4f, 0.5f);
        Anims.add(new Anims.Anim() {
            int n = 0; Disp.Beam tongue;
            public boolean tick() {
                n++;
                if (n > 40 || (t != null && !t.isAlive() && n > 12)) { if (tongue != null) tongue.kill(); r.kill(); return true; }
                Vec3d mouth = pos.add(0, 1.0, 0).add(flat(to).lengthSquared() > 1e-4 ? flat(to).normalize().multiply(1.1) : Vec3d.ZERO);
                if (n == 1) r.place(pos, r.yaw, 0);
                if (t != null && n >= 6 && n <= 20) {
                    Vec3d tm = Fx.mid(t);
                    if (n == 6) { tongue = Config.displays ? new Disp.Beam(w, mouth, tm, "pink_concrete", "red_concrete", 0.22, 40) : null; Fx.snd(w, mouth, SoundEvents.ENTITY_FROG_TONGUE, 1.4f, 0.8f); }
                    if (tongue != null) tongue.update(mouth, tm, 0.22);
                    Vec3d pull = mouth.subtract(tm);
                    if (n <= 14 && pull.length() > 1.5) { Vec3d v = pull.normalize().multiply(0.55); t.addVelocity(v.x, 0.05, v.z); }
                    if (n == 8) { Fx.hurt(w, p, t, 4f); t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 2)); }
                    Fx.line(w, Fx.dust(0xFF70A0, 1.0f), mouth, tm, 0.5);
                } else if (tongue != null && n > 20) { tongue.kill(); tongue = null; }
                return false;
            }
        });
    }

    // ================= 5. Max Elephant =================
    static void elephant(ServerWorld w, ServerPlayerEntity p) {
        Vec3d dir = dirOf(p);
        Vec3d pos = p.getEntityPos().add(dir.multiply(3.5));
        double yaw = Rig.yawOf(dir);
        int total = 70;
        Rig r = elephantModel(w, pos, yaw, total + 10);
        summonFx(w, pos, 0x2090FF);
        Fx.snd(w, pos, SoundEvents.ENTITY_ELDER_GUARDIAN_AMBIENT, 1.3f, 0.5f);
        Anims.add(new Anims.Anim() {
            int t = 0;
            public boolean tick() {
                t++;
                if (t > total) { Fx.put(w, ParticleTypes.SPLASH, pos.add(0, 3, 0), 40, 1.5, 0.2); r.kill(); return true; }
                if (t % 2 == 0) r.place(pos, yaw, t);
                Vec3d tip = pos.add(dir.multiply(5.2)).add(0, 3.2, 0);
                if (t >= 15) {
                    for (int i = 0; i < 14; i++) {
                        double d = Fx.rnd(0, 11), spread = d * 0.22;
                        Vec3d pt = tip.add(dir.multiply(d)).add(Fx.rnd(-spread, spread), -d * 0.12 + Fx.rnd(-spread, spread) * 0.5, Fx.rnd(-spread, spread));
                        Fx.pt(w, Fx.dust(i % 2 == 0 ? 0x40A0FF : 0xB0E8FF, 1.4f), pt);
                        if (i % 4 == 0) Fx.pt(w, ParticleTypes.SPLASH, pt);
                    }
                    if (t % 5 == 0) for (LivingEntity e : Fx.hostiles(w, p, new Box(tip, tip.add(dir.multiply(11))).expand(3.2))) {
                        Vec3d rel = Fx.mid(e).subtract(tip);
                        double along = rel.dotProduct(dir);
                        if (along < 0 || along > 11 || rel.subtract(dir.multiply(along)).length() > 1.0 + along * 0.25) continue;
                        Fx.hurt(w, p, e, 3.5f);
                        e.addVelocity(dir.x * 0.6, 0.12, dir.z * 0.6);
                        e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 30, 1));
                    }
                    if (t % 12 == 0) Fx.snd(w, tip, SoundEvents.ENTITY_PLAYER_SPLASH, 1.0f, 0.7f);
                }
                return false;
            }
        });
    }

    // ================= 6. Rabbit Escape =================
    static void rabbits(ServerWorld w, ServerPlayerEntity p) {
        Vec3d c = p.getEntityPos();
        int total = 100, N = 12;
        List<Rig> rigs = new ArrayList<>();
        List<Vec3d> ps = new ArrayList<>(), vs = new ArrayList<>();
        for (int i = 0; i < N; i++) {
            double a = Fx.rnd(0, 6.28), r = Fx.rnd(1.5, 5);
            Vec3d pos = c.add(Math.cos(a) * r, 0, Math.sin(a) * r);
            rigs.add(rabbitModel(w, pos, Fx.rnd(0, 6.28), total + 10));
            ps.add(pos); vs.add(Vec3d.ZERO);
        }
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, 100, 0, true, false));
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 100, 2, true, false));
        for (LivingEntity e : Fx.hostiles(w, p, p.getBoundingBox().expand(10))) e.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 80, 0));
        summonFx(w, c, 0xFFFFFF);
        Fx.snd(w, c, SoundEvents.ENTITY_RABBIT_AMBIENT, 1.5f, 1.4f);
        Anims.add(new Anims.Anim() {
            int t = 0;
            public boolean tick() {
                t++;
                if (t > total || p.isRemoved()) { for (Rig r : rigs) r.kill(); return true; }
                Vec3d here = p.getEntityPos();
                if (t % 2 == 0) for (int i = 0; i < rigs.size(); i++) {
                    if ((t + i * 3) % 20 == 0) {
                        double a = Fx.rnd(0, 6.28);
                        Vec3d toC = flat(here.subtract(ps.get(i)));
                        Vec3d d = new Vec3d(Math.cos(a), 0, Math.sin(a));
                        if (toC.length() > 7) d = toC.normalize();
                        vs.set(i, d.multiply(0.22));
                    }
                    double hop = Math.abs(Math.sin((t + i * 3) * 0.16)) * 0.6;
                    Vec3d np = ps.get(i).add(vs.get(i));
                    ps.set(i, np);
                    Vec3d v = vs.get(i);
                    rigs.get(i).place(new Vec3d(np.x, here.y + hop, np.z), v.lengthSquared() > 1e-4 ? Rig.yawOf(v) : rigs.get(i).yaw, t);
                }
                return false;
            }
        });
    }

    // ================= 7. Round Deer =================
    static void deer(ServerWorld w, ServerPlayerEntity p) {
        Vec3d dir = dirOf(p);
        Vec3d pos = p.getEntityPos().add(rightOf(dir).multiply(-2.2)).add(dir.multiply(0.5));
        double yaw = Rig.yawOf(rightOf(dir));
        int total = 80;
        Rig r = deerModel(w, pos, yaw, total + 10);
        summonFx(w, pos, 0x60FF90);
        p.heal(8f);
        Fx.snd(w, pos, SoundEvents.ENTITY_PLAYER_LEVELUP, 1.0f, 1.6f);
        Anims.add(new Anims.Anim() {
            int t = 0;
            public boolean tick() {
                t++;
                if (t > total) { r.kill(); return true; }
                if (t % 2 == 0) r.place(pos, yaw, t);
                Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
                if (t % 3 == 0) Fx.ring(w, Fx.dust(0x60FF90, 1.2f), pos.add(0, 0.1 + (t % 30) * 0.12, 0), b[1], b[2], 2.5, 40, t);
                if (t % 10 == 0) {
                    for (ServerPlayerEntity o : w.getPlayers()) {
                        if (o.getEntityPos().distanceTo(pos) > 9) continue;
                        o.heal(2f);
                        o.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 60, 1));
                        Fx.put(w, ParticleTypes.HAPPY_VILLAGER, o.getEntityPos().add(0, 1, 0), 6, 0.5, 0);
                    }
                }
                return false;
            }
        });
    }

    // ================= 8. Piercing Ox =================
    static void ox(ServerWorld w, ServerPlayerEntity p) {
        Vec3d dir = dirOf(p);
        Vec3d start = p.getEntityPos().add(dir.multiply(1.2));
        double yaw = Rig.yawOf(dir);
        Rig r = oxModel(w, start, yaw, 50);
        summonFx(w, start, 0x401010);
        Fx.snd(w, start, SoundEvents.ENTITY_RAVAGER_ROAR, 1.2f, 0.9f);
        Set<LivingEntity> hit = new HashSet<>();
        Anims.add(new Anims.Anim() {
            int t = 0; Vec3d pos = start; boolean stopped = false; int stopT = 0;
            public boolean tick() {
                t++;
                if (!stopped) {
                    Vec3d nx = pos.add(dir.multiply(1.1));
                    if (!w.isAir(BlockPos.ofFloored(nx.add(0, 1, 0))) || t > 18) stopped = true; else pos = nx;
                } else if (++stopT > 6) { r.kill(); return true; }
                if (t % 2 == 0) r.place(pos, yaw, stopped ? 0 : t);
                if (!stopped) {
                    Fx.put(w, Fx.dust(0x601818, 1.4f), pos.add(0, 0.3, 0), 3, 0.5, 0.02);
                    Fx.put(w, ParticleTypes.CAMPFIRE_COSY_SMOKE, pos.add(0, 0.2, 0), 1, 0.2, 0.01);
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(pos, pos).expand(2.4, 2, 2.4))) {
                        if (!hit.add(e)) continue;
                        Fx.hurt(w, p, e, 20f);
                        e.addVelocity(dir.x * 1.3, 0.35, dir.z * 1.3);
                        Fx.put(w, ParticleTypes.EXPLOSION, Fx.mid(e), 1, 0, 0);
                        Fx.snd(w, Fx.mid(e), SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, 1.2f, 0.7f);
                    }
                }
                return false;
            }
        });
    }

    // ================= 9. Tiger Funeral =================
    static void tiger(ServerWorld w, ServerPlayerEntity p) {
        Vec3d dir = dirOf(p);
        Vec3d start = p.getEntityPos().add(rightOf(dir).multiply(2.5));
        LivingEntity t0 = nearest(w, p, p.getEntityPos(), 18);
        Vec3d end = t0 != null ? t0.getEntityPos() : p.getEntityPos().add(dir.multiply(9));
        Vec3d toE = flat(end.subtract(start));
        double yaw = Rig.yawOf(toE.lengthSquared() < 1e-4 ? dir : toE.normalize());
        Rig r = tigerModel(w, start, yaw, 60);
        summonFx(w, start, 0xFF8000);
        Fx.snd(w, start, SoundEvents.ENTITY_RAVAGER_ROAR, 1.4f, 1.3f);
        Anims.add(new Anims.Anim() {
            int t = 0; Vec3d pos = start; boolean landed = false;
            public boolean tick() {
                t++;
                if (t > 38) { r.kill(); return true; }
                if (t >= 8 && t <= 20) {
                    double k = (t - 8) / 12.0;
                    pos = start.add(end.subtract(start).multiply(k)).add(0, Math.sin(k * Math.PI) * 3.0, 0);
                    Fx.put(w, Fx.dust(0xFF9020, 1.4f), pos.add(0, 1, 0), 3, 0.4, 0.02);
                }
                if (t % 2 == 0) r.place(pos, yaw, t);
                if (t == 20 && !landed) {
                    landed = true;
                    Vec3d hit = end.add(0, 1, 0);
                    Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
                    for (int i = 1; i <= 3; i++) Fx.ring(w, Fx.dust(0xFF8000, 1.7f), end.add(0, 0.2, 0), b[1], b[2], i * 1.3, 40, 0);
                    Fx.snd(w, end, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 1.2f, 1.1f);
                    Vec3d look = toE.lengthSquared() < 1e-4 ? dir : toE.normalize();
                    Vec3d[] bb = Fx.basis(look);
                    if (Config.displays) for (int i = 0; i < 3; i++) {
                        double tilt = -0.5 + i * 0.5;
                        Vec3d u = bb[1].multiply(Math.cos(tilt)).add(bb[2].multiply(Math.sin(tilt))).normalize();
                        new Disp.Crescent(w, hit.add(look.multiply(-0.5)), u, look, 2.6, 0.4, 0.5, "white_concrete", 8, 8);
                        new Disp.Crescent(w, hit.add(look.multiply(-0.5)), u, look, 2.8, 0.45, 0.9, "orange_stained_glass", 8, 10);
                    }
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(end, end).expand(3, 2, 3))) {
                        if (e.getEntityPos().distanceTo(end) > 3.2) continue;
                        Fx.hurt(w, p, e, 30f);
                        e.setFireTicks(60);
                    }
                }
                return false;
            }
        });
    }

    // ================= 10. Mahoraga =================
    static void mahoraga(ServerWorld w, ServerPlayerEntity p) {
        Vec3d dir = dirOf(p);
        Vec3d start = p.getEntityPos().subtract(dir.multiply(4));
        int total = 300;
        Rig r = mahoragaModel(w, start, Rig.yawOf(dir), total + 20);
        summonFx(w, start, 0xFFE070);
        Vec3d[] b = Fx.basis(new Vec3d(0, 1, 0));
        for (int i = 0; i < 4; i++) Fx.ring(w, Fx.dust(0xFFE070, 1.8f), start.add(0, 0.1, 0), b[1], b[2], 1.5 + i * 1.1, 60, 0);
        Fx.snd(w, start, SoundEvents.ENTITY_WARDEN_ROAR, 1.5f, 0.7f);
        Fx.snd(w, start, SoundEvents.BLOCK_BELL_USE, 2.0f, 0.5f);
        Anims.add(new Anims.Anim() {
            int t = 0; Vec3d pos = start; double yaw = Rig.yawOf(dir);
            public boolean tick() {
                t++;
                if (p.isRemoved() || !p.isAlive() || t > total) {
                    Fx.sphere(w, Fx.dust(0xFFE070, 1.6f), pos.add(0, 3, 0), 2.5, 80, 0);
                    r.kill();
                    return true;
                }
                Vec3d here = p.getEntityPos();
                LivingEntity tg = nearest(w, p, pos, 16);
                Vec3d goal = tg != null ? tg.getEntityPos() : here.subtract(rightOf(dirOf(p)).multiply(3)).subtract(dirOf(p).multiply(3));
                Vec3d to = flat(goal.subtract(pos));
                double dist = to.length();
                if (dist > (tg != null ? 3.6 : 1.2)) { pos = pos.add(to.normalize().multiply(Math.min(dist, tg != null ? 0.4 : 0.3))); }
                pos = new Vec3d(pos.x, here.y, pos.z);
                if (dist > 0.05) yaw = Rig.yawOf(to);
                if (t % 2 == 0) r.place(pos, yaw, t);
                if (tg != null && dist <= 5.5 && t % 20 == 0) {
                    Vec3d look = flat(tg.getEntityPos().subtract(pos)).normalize();
                    Vec3d hit = pos.add(look.multiply(3)).add(0, 2.5, 0);
                    Vec3d[] bb = Fx.basis(look);
                    if (Config.displays) {
                        new Disp.Crescent(w, hit, bb[1].multiply(Math.cos(0.4)).add(bb[2].multiply(Math.sin(0.4))).normalize(), look, 4.0, 0.6, 1.0, "white_concrete", 10, 8);
                        new Disp.Crescent(w, hit, bb[1].multiply(Math.cos(0.4)).add(bb[2].multiply(Math.sin(0.4))).normalize(), look, 4.4, 0.7, 1.4, "yellow_stained_glass", 10, 10);
                    }
                    Fx.snd(w, hit, SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, 1.5f, 0.5f);
                    Fx.snd(w, hit, SoundEvents.ENTITY_GENERIC_EXPLODE.value(), 0.8f, 0.8f);
                    for (LivingEntity e : Fx.hostiles(w, p, new Box(pos, pos).expand(5, 3, 5))) {
                        if (e.getEntityPos().distanceTo(pos) > 5.5) continue;
                        Fx.hurt(w, p, e, 18f);
                        Vec3d kb = flat(e.getEntityPos().subtract(pos)).normalize();
                        e.addVelocity(kb.x * 0.9, 0.3, kb.z * 0.9);
                    }
                }
                if (t % 4 == 0) Fx.put(w, Fx.dust(0xFFE070, 1.0f), pos.add(0, 5.2, -0.7), 2, 0.6, 0.02);
                return false;
            }
        });
    }
}
