package com.example.jjk;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

public class Jjk implements ModInitializer {
    public static final String ID = "jjk";

    @Override
    public void onInitialize() {
        Config.load();
        Data.load();
        Net.register();
        Anims.register();
        ServerTickEvents.END_SERVER_TICK.register(Data::tick);
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> Data.save());

        // Infinity: chan moi don co ke tan cong (quai, dan, no). Lua / roi / doc / hu vo van tac dung.
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof PlayerEntity pl && Data.INFINITY.contains(pl.getUuid())) {
                Entity attacker = source.getAttacker();
                Entity direct = source.getSource();
                if (attacker != null || direct != null) return false;
            }
            return true;
        });
        System.out.println("[jjk] Jujutsu Cursed Techniques loaded (stage 1: Gojo, Sukuna, Yuji)");
    }
}
