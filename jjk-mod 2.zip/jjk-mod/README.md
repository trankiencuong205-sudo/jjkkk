# Jujutsu Cursed Techniques (Fabric 1.21.11) — giai đoạn 1

Mod hoàn toàn độc lập (id `jjk`), không liên quan Demon Slayer.

## Điều khiển
- **K**: mở menu kỹ năng. Chọn nhân vật (13 nhân vật), bấm một kỹ năng ở danh sách trái, rồi bấm một **ô slot** ở hàng dưới để gắn/thay kỹ năng vào ô đó (gắn trùng sẽ hoán đổi). Nút **x** xóa ô. Nút "Dung ky nang dang xem" dùng thử ngay.
- **8 ô kỹ năng, mỗi ô một phím riêng**: Z, X, C, V, G, B, H, Y. Đổi phím trong **Options > Controls > Jujutsu Cursed Techniques** (cả phím mở menu K).
- Mỗi nhân vật có bộ 8 ô riêng, lưu trong `config/jjk-players.properties` (còn nguyên sau khi thoát game).
- HUD: 8 ô kỹ năng với icon (màu + chữ viết tắt), phím, đếm ngược hồi chiêu, viền xanh khi Infinity/Reinforcement đang bật, thanh chú lực phía trên.

## Build ra file .jar
**Cách 1 — GitHub Actions (như mod trước):**
1. Tạo repo GitHub MỚI (ví dụ `jjk`).
2. Upload `jjk-mod.zip` và file `jjk-build.yml` (đặt vào `.github/workflows/build.yml`).
3. Chờ Actions chạy → tải artifact `jjk-jar`. Nếu đỏ, mở mục Annotations và gửi lỗi.

**Cách 2 — trên PC có Java 21 + Gradle 9.2:** giải nén, mở thư mục `jjk-mod`, chạy `gradle build`,
jar nằm ở `build/libs/jujutsu-cursed-0.1.0.jar`. Cần cài kèm Fabric API 0.141.1+1.21.11.

## Cấu hình
`config/jjk-config.properties`: maxEnergy, regenPerSecond, costMultiplier, cooldownMultiplier,
disableCooldowns, unlimitedEnergy, purpleErasesBlocks, domainSeconds.

Xem `CHECKLIST.md` để biết cái gì đã viết / chưa test / chưa làm.
